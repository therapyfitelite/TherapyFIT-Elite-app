import { useState, useEffect } from "react";

export type DisplayTheme = "default" | "glass" | "hc";

export interface RippleData {
  x: number;
  y: number;
  /** HRV score 0-100. Higher = calmer = cyan. Lower = stressed = red/orange. */
  hrv: number;
}

function readHRV(): number {
  try {
    const stored = localStorage.getItem("tf_hrv_score");
    if (stored) return Math.max(0, Math.min(100, Number(stored)));
  } catch {}
  // fallback: derive from stored biometrics
  try {
    const metrics = JSON.parse(localStorage.getItem("tf_biometrics") || "{}");
    if (metrics.hrv) return Math.max(0, Math.min(100, Number(metrics.hrv)));
  } catch {}
  return 62; // default neutral HRV
}

export function useDisplayTheme() {
  const [displayTheme, setDisplayThemeState] = useState<DisplayTheme>(() => {
    try {
      return (
        (localStorage.getItem("tf_display_theme") as DisplayTheme) || "default"
      );
    } catch {
      return "default";
    }
  });

  const [rippleData, setRippleData] = useState<RippleData | null>(null);

  useEffect(() => {
    const root = document.documentElement;
    root.classList.remove("theme-glass", "theme-hc");
    if (displayTheme === "glass") root.classList.add("theme-glass");
    if (displayTheme === "hc") root.classList.add("theme-hc");
  }, [displayTheme]);

  const setDisplayTheme = (
    theme: DisplayTheme,
    event?: React.MouseEvent | MouseEvent,
  ) => {
    if (event) {
      const hrv = readHRV();
      setRippleData({ x: event.clientX, y: event.clientY, hrv });
      setTimeout(() => setRippleData(null), 1200);
    }
    setDisplayThemeState(theme);
    try {
      localStorage.setItem("tf_display_theme", theme);
    } catch {}
  };

  // Keep backward compat: expose rippleOrigin as well
  const rippleOrigin = rippleData ? { x: rippleData.x, y: rippleData.y } : null;

  return { displayTheme, setDisplayTheme, rippleOrigin, rippleData };
}
