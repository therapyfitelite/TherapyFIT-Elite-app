import { useEffect, useState } from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { ThemeProvider } from "next-themes";
import { ErrorBoundary, logError } from "@/components/ErrorBoundary";
import Index from "./pages/Index";
import Audit from "./pages/Audit";
import Profile from "./pages/Profile";
import Leaderboard from "./pages/Leaderboard";
import Calibration from "./pages/Calibration";
import Flow from "./pages/Flow";
import Breathing from "./pages/Breathing";
import GlobalMap from "./pages/GlobalMap";
import WarRoom from "./pages/WarRoom";
import TechTree from "./pages/TechTree";
import Settings from "./pages/Settings";
import Integrations from "./pages/Integrations";
import Upgrade from "./pages/Upgrade";
import Somatic from "./pages/Somatic";
import Ops from "./pages/Ops";
import Intel from "./pages/Intel";
import Feed from "./pages/Feed";
import Marketplace from "./pages/Marketplace";
import NotFound from "./pages/NotFound";
import Welcome from "./pages/Welcome";
import AdminAnalytics from "./pages/AdminAnalytics";
import Loadout from "./pages/Loadout";
import SleepArchitecture from "./pages/SleepArchitecture";
import Hub from "./pages/Hub";
import Layout from "./components/Layout";
import { BootSequence } from "./components/BootSequence";
import { CookieConsentBanner } from "./components/CookieConsentBanner";
import NexusAvatarBuilder from "./pages/NexusAvatarBuilder";
import MorningCheckIn from "./pages/MorningCheckIn";
import Habits from "./pages/Habits";
import Activity from "./pages/Activity";

const queryClient = new QueryClient();

const App = () => {
  const [onboarded, setOnboarded] = useState<boolean | null>(null);

  // Global unhandled error / promise rejection monitor — captures faults that
  // occur outside React's render cycle (e.g. async handlers, third-party scripts)
  // and logs them locally so incidents can be reviewed before launch.
  useEffect(() => {
    const handleError = (event: ErrorEvent) => {
      logError({
        message: event.message || "Unhandled error",
        stack: event.error?.stack,
        incidentId: `UNH-${Math.random().toString(36).slice(2, 8).toUpperCase()}`,
        timestamp: new Date().toISOString(),
        route: window.location?.pathname,
      });
    };
    const handleRejection = (event: PromiseRejectionEvent) => {
      const reason = event.reason;
      logError({
        message:
          typeof reason === "string"
            ? reason
            : reason?.message || "Unhandled promise rejection",
        stack: reason?.stack,
        incidentId: `PRJ-${Math.random().toString(36).slice(2, 8).toUpperCase()}`,
        timestamp: new Date().toISOString(),
        route: window.location?.pathname,
      });
    };
    window.addEventListener("error", handleError);
    window.addEventListener("unhandledrejection", handleRejection);
    return () => {
      window.removeEventListener("error", handleError);
      window.removeEventListener("unhandledrejection", handleRejection);
    };
  }, []);

  useEffect(() => {
    try {
      const color = localStorage.getItem("accentColor");
      if (color) {
        document.documentElement.style.setProperty("--primary", color);
        document.documentElement.style.setProperty("--ring", color);
      }
    } catch (e) {}

    const checkOnboarding = () => {
      try {
        const hasOnboarded = localStorage.getItem("tf_onboarded") === "true";
        setOnboarded(hasOnboarded);
      } catch (e) {
        setOnboarded(false);
      }
    };

    checkOnboarding();

    window.addEventListener("tf_onboarding_complete", checkOnboarding);
    window.addEventListener("storage", checkOnboarding);

    return () => {
      window.removeEventListener("tf_onboarding_complete", checkOnboarding);
      window.removeEventListener("storage", checkOnboarding);
    };
  }, []);

  if (onboarded === null) return null;

  return (
    <ErrorBoundary>
      <QueryClientProvider client={queryClient}>
        <ThemeProvider
          attribute="class"
          defaultTheme="dark"
          enableSystem
          disableTransitionOnChange
        >
          <TooltipProvider>
            <Toaster />
            <Sonner />
            {onboarded && <BootSequence />}
            <BrowserRouter>
              <Routes>
                <Route path="/welcome" element={<Welcome />} />
                <Route
                  element={
                    onboarded ? <Layout /> : <Navigate to="/welcome" replace />
                  }
                >
                  <Route path="/" element={<Index />} />
                  <Route path="/ops" element={<Ops />} />
                  <Route path="/intel" element={<Intel />} />
                  <Route path="/feed" element={<Feed />} />
                  <Route path="/audit" element={<Audit />} />
                  <Route path="/profile" element={<Profile />} />
                  <Route path="/leaderboard" element={<Leaderboard />} />
                  <Route path="/calibration" element={<Calibration />} />
                  <Route path="/flow" element={<Flow />} />
                  <Route path="/breathing" element={<Breathing />} />
                  <Route path="/map" element={<GlobalMap />} />
                  <Route path="/war-room" element={<WarRoom />} />
                  <Route path="/tech-tree" element={<TechTree />} />
                  <Route path="/settings" element={<Settings />} />
                  <Route path="/integrations" element={<Integrations />} />
                  <Route path="/upgrade" element={<Upgrade />} />
                  <Route path="/somatic" element={<Somatic />} />
                  <Route path="/marketplace" element={<Marketplace />} />
                  <Route path="/admin" element={<AdminAnalytics />} />
                  <Route path="/sleep" element={<SleepArchitecture />} />
                  <Route path="/loadout" element={<Loadout />} />
                  <Route path="/hub" element={<Hub />} />
                  <Route
                    path="/nexus-builder"
                    element={<NexusAvatarBuilder />}
                  />
                  <Route path="/morning-checkin" element={<MorningCheckIn />} />
                  <Route path="/habits" element={<Habits />} />
                  <Route path="/activity" element={<Activity />} />
                  {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
                  <Route path="*" element={<NotFound />} />
                </Route>
              </Routes>
            </BrowserRouter>
            <CookieConsentBanner />
          </TooltipProvider>
        </ThemeProvider>
      </QueryClientProvider>
    </ErrorBoundary>
  );
};

export default App;
