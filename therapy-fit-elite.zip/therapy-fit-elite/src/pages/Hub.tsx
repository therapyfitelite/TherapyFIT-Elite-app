import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  Activity,
  Crosshair,
  Hexagon,
  Moon,
  Shield,
  Rss,
  ArrowRightLeft,
  Users,
  Settings,
  Award,
  Zap,
  Wind,
  Globe,
  Grid,
  GitBranch,
  Link,
  Lock,
  BarChart,
  Package,
  ChevronRight,
  Pin,
  Search,
} from "lucide-react";
import NeuralBackground from "@/components/NeuralBackground";
import { hapticFeedback, cn } from "@/lib/utils";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

const HUB_SECTIONS = [
  {
    title: "Core Protocols",
    items: [
      {
        id: "dash",
        label: "DASH",
        path: "/",
        icon: Activity,
        color: "text-primary",
        tags: ["Core", "Monitoring"],
      },
      {
        id: "ops",
        label: "Tactical Ops",
        path: "/ops",
        icon: Crosshair,
        color: "text-red-500",
        tags: ["Focus", "Performance"],
      },
      {
        id: "somatic",
        label: "Body & Somatic",
        path: "/somatic",
        icon: Hexagon,
        color: "text-blue-500",
        tags: ["Recovery", "Body"],
      },
      {
        id: "sleep",
        label: "Sleep Architecture",
        path: "/sleep",
        icon: Moon,
        color: "text-purple-500",
        tags: ["Recovery", "Sleep"],
      },
    ],
  },
  {
    title: "Network & Intel",
    items: [
      {
        id: "feed",
        label: "Global Feed",
        path: "/feed",
        icon: Rss,
        color: "text-emerald-500",
        tags: ["Community", "Social"],
      },
      {
        id: "intel",
        label: "Intelligence",
        path: "/intel",
        icon: Shield,
        color: "text-yellow-500",
        tags: ["Data", "Analysis"],
      },
      {
        id: "leaderboard",
        label: "Leaderboard",
        path: "/leaderboard",
        icon: Award,
        color: "text-orange-500",
        tags: ["Community", "Performance"],
      },
      {
        id: "map",
        label: "Global Map",
        path: "/map",
        icon: Globe,
        color: "text-cyan-500",
        tags: ["Community", "Global"],
      },
      {
        id: "war-room",
        label: "War Room",
        path: "/war-room",
        icon: Grid,
        color: "text-red-500",
        tags: ["Focus", "Performance"],
      },
    ],
  },
  {
    title: "Training & Upgrades",
    items: [
      {
        id: "activity",
        label: "Kinetic Log",
        path: "/activity",
        icon: Activity,
        color: "text-orange-500",
        tags: ["Performance", "Community"],
      },
      {
        id: "breathing",
        label: "Neural Reset",
        path: "/breathing",
        icon: Wind,
        color: "text-teal-500",
        tags: ["Recovery", "Focus"],
      },
      {
        id: "flow",
        label: "Flow State",
        path: "/flow",
        icon: Zap,
        color: "text-yellow-400",
        tags: ["Focus", "Performance"],
      },
      {
        id: "tech-tree",
        label: "Tech Tree",
        path: "/tech-tree",
        icon: GitBranch,
        color: "text-fuchsia-500",
        tags: ["Progression", "Upgrades"],
      },
      {
        id: "loadout",
        label: "Tactical Loadout",
        path: "/loadout",
        icon: Package,
        color: "text-red-400",
        tags: ["Performance", "Preparation"],
      },
      {
        id: "marketplace",
        label: "Marketplace",
        path: "/marketplace",
        icon: ArrowRightLeft,
        color: "text-green-500",
        tags: ["Community", "Upgrades"],
      },
    ],
  },
  {
    title: "System & Settings",
    items: [
      {
        id: "profile",
        label: "Operator Profile",
        path: "/profile",
        icon: Users,
        color: "text-blue-400",
        tags: ["System", "Settings"],
      },
      {
        id: "settings",
        label: "System Settings",
        path: "/settings",
        icon: Settings,
        color: "text-gray-400",
        tags: ["System", "Settings"],
      },
      {
        id: "integrations",
        label: "Integrations",
        path: "/integrations",
        icon: Link,
        color: "text-indigo-400",
        tags: ["System", "Data"],
      },
      {
        id: "upgrade",
        label: "Elite Upgrade",
        path: "/upgrade",
        icon: Lock,
        color: "text-yellow-500",
        tags: ["System", "Upgrades"],
      },
      {
        id: "admin",
        label: "Analytics (Admin)",
        path: "/admin",
        icon: BarChart,
        color: "text-red-500",
        tags: ["System", "Data"],
      },
    ],
  },
];

const ALL_TAGS = Array.from(
  new Set(HUB_SECTIONS.flatMap((s) => s.items).flatMap((i) => i.tags)),
).sort();

export default function Hub() {
  const navigate = useNavigate();
  const [pinnedIds, setPinnedIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem("tf_hub_pins");
      return saved ? JSON.parse(saved) : ["dash", "ops"];
    } catch {
      return ["dash", "ops"];
    }
  });

  const [draggedId, setDraggedId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [recentPaths, setRecentPaths] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem("tf_recent_paths") || "[]");
    } catch {
      return [];
    }
  });

  const toggleTag = (tag: string) => {
    hapticFeedback(5);
    setSelectedTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag],
    );
  };

  useEffect(() => {
    localStorage.setItem("tf_hub_pins", JSON.stringify(pinnedIds));
  }, [pinnedIds]);

  const handleNavigate = (path: string) => {
    hapticFeedback(10);
    navigate(path);
  };

  const togglePin = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    hapticFeedback(10);
    setPinnedIds((prev) =>
      prev.includes(id) ? prev.filter((p) => p !== id) : [...prev, id],
    );
  };

  const handleDragStart = (e: React.DragEvent, id: string) => {
    setDraggedId(id);
    e.dataTransfer.effectAllowed = "move";
  };

  const handleDragOver = (e: React.DragEvent, id: string) => {
    e.preventDefault();
    if (!draggedId || draggedId === id) return;

    setPinnedIds((prev) => {
      const draggedIndex = prev.indexOf(draggedId);
      const overIndex = prev.indexOf(id);

      if (draggedIndex === -1 || overIndex === -1) return prev;

      const newPinned = [...prev];
      newPinned.splice(draggedIndex, 1);
      newPinned.splice(overIndex, 0, draggedId);
      return newPinned;
    });
  };

  const handleDragEnd = () => {
    setDraggedId(null);
  };

  const allItems = HUB_SECTIONS.flatMap((s) => s.items);
  const pinnedItems = pinnedIds
    .map((id) => allItems.find((i) => i.id === id))
    .filter(Boolean) as typeof allItems;

  const filteredSections = HUB_SECTIONS.map((section) => ({
    ...section,
    items: section.items.filter((item) => {
      const matchesSearch = item.label
        .toLowerCase()
        .includes(searchQuery.toLowerCase());
      const matchesTags =
        selectedTags.length === 0 ||
        item.tags.some((tag) => selectedTags.includes(tag));
      return matchesSearch && matchesTags;
    }),
  })).filter((section) => section.items.length > 0);

  const filteredPinnedItems = pinnedItems.filter((item) => {
    const matchesSearch = item.label
      .toLowerCase()
      .includes(searchQuery.toLowerCase());
    const matchesTags =
      selectedTags.length === 0 ||
      item.tags.some((tag) => selectedTags.includes(tag));
    return matchesSearch && matchesTags;
  });

  const recentItems = recentPaths
    .map((path) => allItems.find((i) => i.path === path))
    .filter(Boolean) as typeof allItems;
  const filteredRecentItems = recentItems.filter((item) => {
    const matchesSearch = item.label
      .toLowerCase()
      .includes(searchQuery.toLowerCase());
    const matchesTags =
      selectedTags.length === 0 ||
      item.tags.some((tag) => selectedTags.includes(tag));
    return matchesSearch && matchesTags;
  });

  const getGlowStyles = (colorStr: string) => {
    if (colorStr.includes("red"))
      return "hover:border-red-500/60 hover:bg-red-500/10 hover:shadow-[0_0_20px_rgba(239,68,68,0.4)] border-red-500/20";
    if (colorStr.includes("blue") && !colorStr.includes("cyan"))
      return "hover:border-blue-500/60 hover:bg-blue-500/10 hover:shadow-[0_0_20px_rgba(59,130,246,0.4)] border-blue-500/20";
    if (colorStr.includes("purple"))
      return "hover:border-purple-500/60 hover:bg-purple-500/10 hover:shadow-[0_0_20px_rgba(168,85,247,0.4)] border-purple-500/20";
    if (colorStr.includes("emerald") || colorStr.includes("green"))
      return "hover:border-emerald-500/60 hover:bg-emerald-500/10 hover:shadow-[0_0_20px_rgba(16,185,129,0.4)] border-emerald-500/20";
    if (colorStr.includes("yellow"))
      return "hover:border-yellow-500/60 hover:bg-yellow-500/10 hover:shadow-[0_0_20px_rgba(234,179,8,0.4)] border-yellow-500/20";
    if (colorStr.includes("orange"))
      return "hover:border-orange-500/60 hover:bg-orange-500/10 hover:shadow-[0_0_20px_rgba(249,115,22,0.4)] border-orange-500/20";
    if (colorStr.includes("teal"))
      return "hover:border-teal-500/60 hover:bg-teal-500/10 hover:shadow-[0_0_20px_rgba(20,184,166,0.4)] border-teal-500/20";
    if (colorStr.includes("fuchsia"))
      return "hover:border-fuchsia-500/60 hover:bg-fuchsia-500/10 hover:shadow-[0_0_20px_rgba(217,70,239,0.4)] border-fuchsia-500/20";
    if (colorStr.includes("indigo"))
      return "hover:border-indigo-500/60 hover:bg-indigo-500/10 hover:shadow-[0_0_20px_rgba(99,102,241,0.4)] border-indigo-500/20";
    return "hover:border-cyan-500/60 hover:bg-cyan-500/10 hover:shadow-[0_0_20px_rgba(0,255,255,0.4)] border-cyan-500/20";
  };

  const renderCard = (item: (typeof allItems)[0], isDraggable = false) => {
    const Icon = item.icon;
    const isPinned = pinnedIds.includes(item.id);
    const isDragging = draggedId === item.id;
    return (
      <Card
        key={item.id}
        draggable={isDraggable}
        onDragStart={(e) => isDraggable && handleDragStart(e, item.id)}
        onDragOver={(e) => isDraggable && handleDragOver(e, item.id)}
        onDragEnd={isDraggable ? handleDragEnd : undefined}
        onPointerDown={() => hapticFeedback(5)}
        className={cn(
          "bg-black/80 transition-all duration-500 cursor-pointer group overflow-hidden relative border-2 backdrop-blur-xl",
          getGlowStyles(item.color),
          isDraggable && "cursor-grab active:cursor-grabbing",
          isDragging && "opacity-50 scale-95 border-primary/50",
          "hover:scale-[1.02] active:scale-[0.98]",
        )}
        onClick={() => handleNavigate(item.path)}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-transparent to-white/[0.02] opacity-0 group-hover:opacity-100 transition-opacity" />
        <div className="p-4 flex items-center justify-between relative z-10">
          <div className="flex items-center gap-3">
            <div
              className={cn(
                "w-8 h-8 rounded-lg bg-black/50 border border-white/10 flex items-center justify-center shadow-inner",
                item.color,
              )}
            >
              <Icon className="w-4 h-4" />
            </div>
            <span className="text-sm font-bold tracking-wide text-white/90 group-hover:text-white transition-colors">
              {item.label}
            </span>
          </div>
          <div className="flex items-center gap-1">
            <button
              onClick={(e) => togglePin(e, item.id)}
              className="p-2 -mr-1 text-white/20 hover:text-white/80 transition-colors"
            >
              <Pin
                className={cn(
                  "w-4 h-4",
                  isPinned && "fill-primary text-primary",
                )}
              />
            </button>
            <ChevronRight className="w-4 h-4 text-white/20 group-hover:text-white/60 transition-colors transform group-hover:translate-x-1" />
          </div>
        </div>
      </Card>
    );
  };

  return (
    <div className="flex flex-1 flex-col bg-[#050505] text-foreground relative min-h-full">
      {/* Background */}
      <div className="absolute inset-0 pointer-events-none z-0 overflow-hidden">
        <NeuralBackground />
        <div className="absolute inset-0 bg-gradient-to-b from-black/90 via-transparent to-black/90" />

        {/* Extra intense animations */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(0,255,255,0.08)_0%,transparent_70%)] animate-[pulse_4s_ease-in-out_infinite_alternate]" />

        {/* Glowing Rings */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[1000px] h-[1000px] border border-cyan-500/5 rounded-full animate-[ping_12s_linear_infinite]" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] border border-cyan-400/10 rounded-full animate-[spin_30s_linear_infinite] border-dashed" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] border-2 border-cyan-300/15 rounded-full animate-[spin_20s_linear_infinite_reverse] border-dotted" />

        {/* Tactical Commander Shapes (Abstract WiFi/Neural) */}
        <div className="absolute top-[10%] left-[5%] w-64 h-64 bg-cyan-500/10 rounded-full blur-[80px] animate-float" />
        <div className="absolute bottom-[10%] right-[5%] w-96 h-96 bg-blue-500/10 rounded-full blur-[100px] animate-[float_8s_ease-in-out_infinite_reverse]" />
      </div>

      <div className="relative z-10 flex-1 flex flex-col w-full h-full p-2 sm:p-4 md:p-8 lg:p-12 max-h-[100dvh]">
        <div className="relative flex-1 flex flex-col w-full max-w-6xl mx-auto tactical-monitor">
          {/* CRT Scanline effect moved to tactical-monitor utility */}

          {/* Screen glare */}
          <div className="absolute inset-0 pointer-events-none bg-gradient-to-tr from-transparent via-white/5 to-transparent z-40" />

          <header className="px-6 py-8 sm:px-10 sm:py-10 relative z-20 border-b border-cyan-500/30 bg-black/60 backdrop-blur-xl flex-shrink-0">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <h1 className="text-3xl sm:text-4xl font-black tracking-tighter text-white high-res-glow uppercase glow-text-cyan">
                  Command Hub
                </h1>
                <p className="text-[10px] text-primary/80 font-black uppercase tracking-[0.5em] flex items-center gap-2">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary animate-pulse" />
                  Neural Protocol Interface v2.0
                </p>
              </div>
            </div>

            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search protocols..."
                className="w-full bg-black/40 border-cyan-500/30 pl-10 text-white placeholder:text-white/40 focus-visible:ring-primary/50"
              />
            </div>

            <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
              {ALL_TAGS.map((tag) => (
                <Badge
                  key={tag}
                  variant={selectedTags.includes(tag) ? "default" : "outline"}
                  className={cn(
                    "cursor-pointer whitespace-nowrap transition-colors",
                    selectedTags.includes(tag)
                      ? "bg-primary text-primary-foreground hover:bg-primary/90"
                      : "text-white/60 border-cyan-500/30 hover:text-white hover:border-cyan-400/50",
                  )}
                  onClick={() => toggleTag(tag)}
                >
                  {tag}
                </Badge>
              ))}
            </div>
          </header>

          <main className="flex-1 px-6 py-6 w-full relative z-20 space-y-8 overflow-y-auto pb-6 scrollbar-hide">
            {filteredPinnedItems.length > 0 && (
              <div className="space-y-3">
                <h2 className="text-xs font-bold uppercase tracking-widest text-primary flex items-center gap-2">
                  <Pin className="w-3 h-3 fill-primary" />
                  Pinned Protocols
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {filteredPinnedItems.map((item) => renderCard(item, true))}
                </div>
              </div>
            )}

            {filteredRecentItems.length > 0 && (
              <div className="space-y-3">
                <h2 className="text-xs font-bold uppercase tracking-widest text-emerald-500 flex items-center gap-2">
                  <Activity className="w-3 h-3" />
                  Recently Used
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {filteredRecentItems.map((item) => renderCard(item))}
                </div>
              </div>
            )}

            {filteredSections.length > 0 ? (
              filteredSections.map((section, idx) => (
                <div key={idx} className="space-y-3">
                  <h2 className="text-xs font-bold uppercase tracking-widest text-cyan-400 flex items-center gap-2">
                    <div className="w-1 h-3 bg-cyan-400/50 rounded-full" />
                    {section.title}
                  </h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {section.items.map((item) => renderCard(item))}
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-12 text-white/40 text-sm">
                No protocols found matching "{searchQuery}"
              </div>
            )}
          </main>
        </div>
      </div>
    </div>
  );
}
