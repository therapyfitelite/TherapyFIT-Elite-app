import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  ChevronLeft,
  Crosshair,
  Shield,
  Zap,
  Activity,
  Cpu,
} from "lucide-react";
import { hapticFeedback, cn } from "@/lib/utils";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const GEAR_CATEGORIES = [
  {
    id: "supplements",
    label: "Supplements",
    icon: Activity,
    color: "text-red-500",
    bg: "bg-red-500/10",
    border: "border-red-500/30",
  },
  {
    id: "wearables",
    label: "Wearables",
    icon: Shield,
    color: "text-cyan-500",
    bg: "bg-cyan-500/10",
    border: "border-cyan-500/30",
  },
  {
    id: "audio",
    label: "Audio Protocols",
    icon: Zap,
    color: "text-orange-500",
    bg: "bg-orange-500/10",
    border: "border-orange-500/30",
  },
  {
    id: "neural",
    label: "Neural Stims",
    icon: Cpu,
    color: "text-fuchsia-500",
    bg: "bg-fuchsia-500/10",
    border: "border-fuchsia-500/30",
  },
];

const INVENTORY = {
  supplements: [
    { id: "s1", name: "L-Theanine 200mg", type: "Focus", active: true },
    { id: "s2", name: "Alpha-GPC 300mg", type: "Cognitive", active: false },
    { id: "s3", name: "Rhodiola Rosea", type: "Adaptogen", active: true },
  ],
  wearables: [
    { id: "w1", name: "Whoop Strap 4.0", type: "Biometrics", active: true },
    { id: "w2", name: "Oura Ring Gen3", type: "Recovery", active: false },
  ],
  audio: [
    {
      id: "a1",
      name: "40Hz Binaural Beats",
      type: "Gamma State",
      active: true,
    },
    { id: "a2", name: "Brown Noise", type: "Deep Work", active: false },
  ],
  neural: [
    { id: "n1", name: "tDCS Headset", type: "Stimulation", active: false },
    {
      id: "n2",
      name: "Vagus Nerve Stim",
      type: "Parasympathetic",
      active: true,
    },
  ],
};

export default function Loadout() {
  const navigate = useNavigate();
  const [activeCategory, setActiveCategory] = useState("supplements");
  const [inventory, setInventory] = useState(INVENTORY);

  const toggleItem = (category: keyof typeof INVENTORY, itemId: string) => {
    hapticFeedback(10);
    setInventory((prev) => ({
      ...prev,
      [category]: prev[category].map((item) =>
        item.id === itemId ? { ...item, active: !item.active } : item,
      ),
    }));
  };

  return (
    <div className="flex flex-1 flex-col bg-[#050505] text-foreground relative min-h-full">
      {/* Tactical Military Grid Background */}
      <div className="absolute inset-0 pointer-events-none z-0">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#ef444410_1px,transparent_1px),linear-gradient(to_bottom,#ef444410_1px,transparent_1px)] bg-[size:3rem_3rem] [mask-image:radial-gradient(ellipse_80%_80%_at_50%_50%,#000_20%,transparent_100%)]" />
        <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-red-500/10 rounded-full blur-[100px] animate-pulse mix-blend-screen" />
        <div
          className="absolute bottom-1/4 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-[100px] animate-pulse mix-blend-screen"
          style={{ animationDelay: "2s" }}
        />
      </div>

      <header className="px-4 py-6 relative z-10 border-b border-red-500/20 bg-black/50 backdrop-blur-md shadow-[0_0_15px_rgba(239,68,68,0.1)] flex items-center gap-4">
        <button
          onClick={() => {
            hapticFeedback(5);
            navigate(-1);
          }}
          className="w-10 h-10 rounded-full bg-red-500/10 border border-red-500/30 flex items-center justify-center text-red-500 hover:bg-red-500/20 transition-colors"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <div>
          <h1 className="text-2xl font-bold tracking-tighter text-white drop-shadow-[0_0_10px_rgba(239,68,68,0.5)]">
            TACTICAL LOADOUT
          </h1>
          <p className="text-xs text-red-500 uppercase tracking-widest font-mono flex items-center gap-2">
            Mission Gear Configuration
          </p>
        </div>
      </header>

      <main className="flex-1 px-4 py-6 max-w-md mx-auto w-full relative z-10 space-y-6">
        {/* Categories Grid */}
        <div className="grid grid-cols-2 gap-3">
          {GEAR_CATEGORIES.map((cat) => {
            const Icon = cat.icon;
            const isActive = activeCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => {
                  hapticFeedback(5);
                  setActiveCategory(cat.id);
                }}
                className={cn(
                  "p-4 rounded-xl border transition-all duration-300 flex flex-col items-center justify-center gap-2 relative overflow-hidden",
                  isActive
                    ? `border-${cat.color.split("-")[1]}-500 bg-${cat.color.split("-")[1]}-500/20 shadow-[0_0_20px_rgba(var(--${cat.color.split("-")[1]}-500),0.3)]`
                    : "bg-black/40 border-white/10 hover:border-white/20",
                )}
              >
                {isActive && (
                  <div className="absolute inset-0 bg-[linear-gradient(transparent_50%,rgba(255,255,255,0.05)_50%)] bg-[length:100%_4px] pointer-events-none" />
                )}
                <Icon
                  className={cn(
                    "w-6 h-6",
                    isActive ? cat.color : "text-muted-foreground",
                  )}
                />
                <span
                  className={cn(
                    "text-[10px] uppercase tracking-widest font-bold",
                    isActive ? "text-white" : "text-muted-foreground",
                  )}
                >
                  {cat.label}
                </span>
              </button>
            );
          })}
        </div>

        {/* Active Category Inventory */}
        <div className="space-y-3">
          <h2 className="text-sm font-bold uppercase tracking-widest text-muted-foreground mb-4">
            Available{" "}
            {GEAR_CATEGORIES.find((c) => c.id === activeCategory)?.label ||
              "Gear"}
          </h2>

          {inventory[activeCategory as keyof typeof INVENTORY].map((item) => {
            const catInfo = GEAR_CATEGORIES.find(
              (c) => c.id === activeCategory,
            )!;
            return (
              <Card
                key={item.id}
                className={cn(
                  "bg-black/60 border backdrop-blur-sm transition-all duration-300 cursor-pointer overflow-hidden relative",
                  item.active
                    ? catInfo.border
                    : "border-white/5 opacity-70 hover:opacity-100",
                )}
                onClick={() =>
                  toggleItem(activeCategory as keyof typeof INVENTORY, item.id)
                }
              >
                {item.active && (
                  <div
                    className="absolute left-0 top-0 bottom-0 w-1 bg-current"
                    style={{
                      color: `var(--${catInfo.color.split("-")[1]}-500)`,
                    }}
                  />
                )}
                <CardContent className="p-4 flex items-center justify-between">
                  <div>
                    <h3
                      className={cn(
                        "font-bold text-sm",
                        item.active ? "text-white" : "text-muted-foreground",
                      )}
                    >
                      {item.name}
                    </h3>
                    <p className="text-[10px] text-muted-foreground uppercase tracking-widest mt-1">
                      {item.type}
                    </p>
                  </div>
                  <div
                    className={cn(
                      "w-6 h-6 rounded-full border-2 flex items-center justify-center transition-colors",
                      item.active
                        ? catInfo.border + " " + catInfo.bg
                        : "border-white/20",
                    )}
                  >
                    {item.active && (
                      <Crosshair className={cn("w-3 h-3", catInfo.color)} />
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </main>
    </div>
  );
}
