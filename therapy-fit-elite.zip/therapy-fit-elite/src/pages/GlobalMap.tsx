import { useState, useEffect, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Globe,
  Zap,
  Activity,
  Users,
  Map as MapIcon,
  Layers,
  Crosshair,
  Search,
  MessageSquare,
  Mic,
  MicOff,
  Shield,
  Swords,
  Flag,
  TrendingUp,
  AlertTriangle,
  Radar,
  Briefcase,
  Target,
  BrainCircuit,
  Bell,
} from "lucide-react";
import { Logo } from "@/components/Logo";
import { NeuralNotificationCenter } from "@/components/NeuralNotifications";
import GlobalChat from "@/components/GlobalChat";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { cn, hapticFeedback } from "@/lib/utils";
import { Progress } from "@/components/ui/progress";
import { toast } from "sonner";

const GLOBAL_NODES = [
  {
    id: 1,
    city: "San Francisco",
    lat: 37.7749,
    lng: -122.4194,
    intensity: 0.92,
    status: "Peak Flow",
    users: 1240,
    friction: 0.08,
    sector: "North America",
  },
  {
    id: 2,
    city: "London",
    lat: 51.5074,
    lng: -0.1278,
    intensity: 0.85,
    status: "Optimal",
    users: 850,
    friction: 0.15,
    sector: "Europe",
  },
  {
    id: 3,
    city: "Tokyo",
    lat: 35.6762,
    lng: 139.6503,
    intensity: 0.95,
    status: "Hyper Focus",
    users: 2100,
    friction: 0.05,
    sector: "Asia Pacific",
  },
  {
    id: 4,
    city: "Berlin",
    lat: 52.52,
    lng: 13.405,
    intensity: 0.78,
    status: "Recovering",
    users: 620,
    friction: 0.22,
    sector: "Europe",
  },
  {
    id: 5,
    city: "New York",
    lat: 40.7128,
    lng: -74.006,
    intensity: 0.88,
    status: "Optimal",
    users: 1580,
    friction: 0.12,
    sector: "North America",
  },
  {
    id: 6,
    city: "Singapore",
    lat: 1.3521,
    lng: 103.8198,
    intensity: 0.91,
    status: "Peak Flow",
    users: 940,
    friction: 0.09,
    sector: "Asia Pacific",
  },
  {
    id: 7,
    city: "Sydney",
    lat: -33.8688,
    lng: 151.2093,
    intensity: 0.82,
    status: "Optimal",
    users: 430,
    friction: 0.18,
    sector: "Asia Pacific",
  },
];

const SECTORS = ["North America", "Europe", "Asia Pacific"];

const SECTOR_DOMINANCE = {
  "North America": {
    dominance: 42,
    color: "text-primary",
    bg: "bg-primary",
    faction: "Aegis Vanguard",
    buff: "+10% Shield Integrity",
  },
  Europe: {
    dominance: 28,
    color: "text-blue-400",
    bg: "bg-blue-400",
    faction: "Synapse Syndicate",
    buff: "+15% Focus Duration",
  },
  "Asia Pacific": {
    dominance: 30,
    color: "text-fuchsia-400",
    bg: "bg-fuchsia-400",
    faction: "Nexus Collective",
    buff: "-5% Neural Friction",
  },
};

const SECTOR_CHALLENGES = [
  {
    id: "uplink",
    title: "Neural Uplink",
    desc: "Establish a high-bandwidth biometric tunnel.",
    reward: 0.05,
    icon: Zap,
  },
  {
    id: "dampen",
    title: "Friction Dampening",
    desc: "Neutralize local cognitive interference.",
    reward: 0.08,
    icon: Shield,
  },
  {
    id: "synthesis",
    title: "Data Synthesis",
    desc: "Compress and relay local telemetry packets.",
    reward: 0.03,
    icon: BrainCircuit,
  },
];

const NeuralStorm = ({ intensity }: { intensity: number }) => {
  if (intensity <= 0.2) return null;

  return (
    <div className="absolute inset-0 pointer-events-none z-40 overflow-hidden">
      {/* Static/Noise Overlay */}
      <div className="absolute inset-0 bg-[url('https://vibe.filesafe.space/1776727899133821812/assets/671353ff-4646-40cd-8c0d-ab4b03765afb.png')] opacity-[0.03] mix-blend-overlay animate-pulse" />

      {/* Lightning Bolts */}
      {Array.from({ length: Math.floor(intensity * 10) }).map((_, i) => (
        <div
          key={i}
          className="absolute bg-primary/40 blur-[2px] animate-[lightning_3s_infinite]"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            width: "1px",
            height: `${20 + Math.random() * 100}px`,
            transform: `rotate(${Math.random() * 45 - 22.5}deg)`,
            animationDelay: `${Math.random() * 3}s`,
          }}
        />
      ))}

      {/* Atmospheric Glow */}
      <div
        className="absolute inset-0 bg-destructive/10 animate-pulse"
        style={{ opacity: (intensity - 0.2) * 0.5 }}
      />
    </div>
  );
};

const NeuralShieldMinigame = ({
  onComplete,
  onCancel,
}: {
  onComplete: () => void;
  onCancel: () => void;
}) => {
  const [power, setPower] = useState(0);

  useEffect(() => {
    if (power >= 100) {
      onComplete();
    }
  }, [power, onComplete]);

  useEffect(() => {
    const interval = setInterval(() => {
      setPower((p) => Math.max(0, p - 5)); // Decays over time
    }, 200);
    return () => clearInterval(interval);
  }, []);

  const handleTap = () => {
    setPower((p) => Math.min(100, p + 15));
    hapticFeedback(10);
  };

  return (
    <div className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-md flex flex-col items-center justify-center p-4 animate-in fade-in duration-300">
      <div className="max-w-md w-full space-y-8 text-center">
        <div>
          <h2 className="text-2xl font-bold text-primary tracking-widest uppercase mb-2">
            Neural Shield Calibration
          </h2>
          <p className="text-muted-foreground text-sm">
            Rapidly tap the core to generate shield integrity and dissipate the
            neural storm.
          </p>
        </div>

        <div className="relative w-48 h-48 mx-auto flex items-center justify-center">
          <div className="absolute inset-0 rounded-full border-4 border-primary/20" />
          <div
            className="absolute bottom-0 w-full bg-primary/20 rounded-full transition-all duration-200"
            style={{ height: `${power}%` }}
          />
          <button
            onClick={handleTap}
            className="relative z-10 w-32 h-32 rounded-full bg-primary flex items-center justify-center shadow-[0_0_30px_rgba(0,255,255,0.5)] active:scale-95 transition-transform"
          >
            <Shield className="w-12 h-12 text-primary-foreground" />
          </button>
        </div>

        <div className="space-y-2">
          <div className="flex justify-between text-xs font-bold uppercase text-primary">
            <span>Integrity</span>
            <span>{power}%</span>
          </div>
          <Progress value={power} className="h-2" />
        </div>

        <Button
          variant="outline"
          onClick={onCancel}
          className="mt-8 border-primary/50 text-primary hover:bg-primary/10"
        >
          ABORT CALIBRATION
        </Button>
      </div>
    </div>
  );
};

const NeuralContestMinigame = ({
  sector,
  onComplete,
  onCancel,
}: {
  sector: string;
  onComplete: (contribution: number) => void;
  onCancel: () => void;
}) => {
  const [energy, setEnergy] = useState(0);
  const [timeLeft, setTimeLeft] = useState(15);

  useEffect(() => {
    if (timeLeft <= 0) {
      onComplete(energy);
      return;
    }
    const timer = setInterval(() => setTimeLeft((t) => t - 1), 1000);
    return () => clearInterval(timer);
  }, [timeLeft, energy, onComplete]);

  const handleSurge = () => {
    setEnergy((e) => e + 5);
    hapticFeedback([20, 10, 20]);
  };

  return (
    <div className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-xl flex flex-col items-center justify-center p-4 animate-in zoom-in duration-300">
      <div className="max-w-md w-full space-y-8 text-center relative">
        <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-48 h-48 bg-primary/20 rounded-full blur-3xl animate-pulse" />

        <div className="space-y-2">
          <Badge className="bg-primary/20 text-primary border-primary/30 uppercase tracking-widest px-4 py-1">
            Sector War Active
          </Badge>
          <h2 className="text-3xl font-bold text-foreground tracking-tighter uppercase">
            Contesting: {sector}
          </h2>
          <p className="text-muted-foreground text-sm">
            Generate neural energy to claim regional dominance for your sector.
          </p>
        </div>

        <div className="relative h-64 flex items-center justify-center">
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-48 h-48 rounded-full border-2 border-primary/20 animate-[spin_10s_linear_infinite]" />
            <div className="w-56 h-56 rounded-full border border-primary/10 animate-[spin_15s_linear_infinite_reverse]" />
          </div>

          <div className="text-center z-10">
            <div className="text-6xl font-black text-primary mb-2 drop-shadow-[0_0_15px_rgba(0,255,255,0.5)]">
              {energy}
            </div>
            <div className="text-xs font-bold text-primary/70 uppercase tracking-[0.3em]">
              Neural Energy
            </div>
          </div>

          <button
            onClick={handleSurge}
            className="absolute inset-0 w-full h-full rounded-full opacity-0 cursor-pointer"
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="bg-card/50 border border-border/50 rounded-lg p-4">
            <div className="text-[10px] text-muted-foreground uppercase mb-1">
              Time Remaining
            </div>
            <div
              className={cn(
                "text-2xl font-bold",
                timeLeft < 5
                  ? "text-destructive animate-pulse"
                  : "text-foreground",
              )}
            >
              {timeLeft}s
            </div>
          </div>
          <div className="bg-card/50 border border-border/50 rounded-lg p-4">
            <div className="text-[10px] text-muted-foreground uppercase mb-1">
              Current Output
            </div>
            <div className="text-2xl font-bold text-primary">
              {(energy / 15).toFixed(1)}/s
            </div>
          </div>
        </div>

        <Button
          variant="ghost"
          onClick={onCancel}
          className="text-muted-foreground hover:text-destructive"
        >
          WITHDRAW FROM CONTEST
        </Button>
      </div>
    </div>
  );
};

export default function GlobalMap() {
  const navigate = useNavigate();
  const [nodes, setNodes] = useState(GLOBAL_NODES);
  const [activeLayer, setActiveLayer] = useState<
    "neural" | "biometric" | "traffic" | "wars"
  >("neural");
  const [selectedNodeId, setSelectedNodeId] = useState<number | null>(null);
  const [activeStrikes, setActiveStrikes] = useState<number[]>([]);

  const selectedNode = useMemo(
    () => nodes.find((n) => n.id === selectedNodeId) || null,
    [nodes, selectedNodeId],
  );
  const [isScanning, setIsScanning] = useState(false);
  const [activeContract, setActiveContract] = useState<{
    sector: string;
    reward: number;
    objective: string;
  } | null>(() => {
    const saved = localStorage.getItem("active_mercenary_contract");
    return saved ? JSON.parse(saved) : null;
  });
  const [satellites, setSatellites] = useState<
    { id: number; lat: number; lng: number }[]
  >([]);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [globalFriction, setGlobalFriction] = useState(0.12);
  const [isShieldGameOpen, setIsShieldGameOpen] = useState(false);
  const [isContestOpen, setIsContestOpen] = useState(false);
  const [sectorWarActive, setSectorWarActive] = useState(true);
  const [dominance, setDominance] = useState(SECTOR_DOMINANCE);
  const [completedChallenges, setCompletedChallenges] = useState<string[]>(
    () => {
      const saved = localStorage.getItem("completed_sector_challenges");
      return saved ? JSON.parse(saved) : [];
    },
  );

  const allChallengesCompleted =
    completedChallenges.length === SECTOR_CHALLENGES.length;

  const contestedSector = useMemo(() => {
    const hours = new Date().getHours();
    return SECTORS[hours % SECTORS.length];
  }, []);

  useEffect(() => {
    localStorage.setItem(
      "completed_sector_challenges",
      JSON.stringify(completedChallenges),
    );

    if (completedChallenges.length === SECTOR_CHALLENGES.length) {
      // Update the main achievement in Profile.tsx via localStorage (mocking sync)
      localStorage.setItem("sector_master_achievement", "completed");
    }
  }, [completedChallenges]);

  useEffect(() => {
    if (globalFriction > 0.4) {
      const interval = setInterval(() => {
        hapticFeedback([10, 50, 10]);
      }, 5000);
      return () => clearInterval(interval);
    }
  }, [globalFriction]);

  const startVoiceCommand = () => {
    const SpeechRecognition =
      (window as any).SpeechRecognition ||
      (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      toast.error("Voice recognition not supported in this browser.");
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = "en-US";
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    recognition.onstart = () => {
      setIsListening(true);
      hapticFeedback([10, 30, 10]);
    };

    recognition.onresult = (event: any) => {
      const command = event.results[0][0].transcript.toLowerCase();
      console.log("Voice Command:", command);

      if (
        command.includes("deploy satellite") ||
        command.includes("launch satellite")
      ) {
        if (selectedNode) {
          handleDeploySatellite();
        } else {
          toast.error("Please select a node first to deploy a satellite.");
        }
      } else if (
        command.includes("scan") ||
        command.includes("initiate scan")
      ) {
        handleScan();
      } else {
        toast.info(`Command not recognized: "${command}"`);
      }
    };

    recognition.onerror = () => {
      setIsListening(false);
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    recognition.start();
  };

  const handleScan = () => {
    setIsScanning(true);
    hapticFeedback([30, 20, 30, 20, 50]);
    setTimeout(() => {
      setIsScanning(false);
      hapticFeedback([100, 50, 100]);
    }, 2000);
  };

  const handleDeploySatellite = () => {
    if (!selectedNode) return;
    hapticFeedback([100, 50, 100, 50, 200]);
    setSatellites((prev) => [
      ...prev,
      { id: Date.now(), lat: selectedNode.lat, lng: selectedNode.lng },
    ]);
    toast.success("Neural Satellite Deployed", {
      description: `Local sync intensity boosted in ${selectedNode.city}.`,
    });
  };

  const handleNeuralStrike = (nodeId: number) => {
    setActiveStrikes((prev) => [...prev, nodeId]);
    hapticFeedback([100, 50, 200, 50, 300]);
    toast.error("Neural Strike Authorized", {
      description: "Orbital kinetic dampening deployed. Friction neutralizing.",
    });

    setTimeout(() => {
      setNodes((prev) =>
        prev.map((n) =>
          n.id === nodeId
            ? { ...n, friction: 0.05, status: "Optimal", intensity: 0.95 }
            : n,
        ),
      );
      setActiveStrikes((prev) => prev.filter((id) => id !== nodeId));
      toast.success("Strike Complete", {
        description: "Node friction neutralized.",
      });
    }, 2000);
  };

  // Convert lat/lng to simplified X/Y for the SVG map
  const getCoords = (lat: number, lng: number) => {
    const x = (lng + 180) * (800 / 360);
    const y = (90 - lat) * (400 / 180);
    return { x, y };
  };

  return (
    <div className="flex flex-1 flex-col bg-background text-foreground">
      {/* Header */}
      <main className="flex-1 relative overflow-hidden flex flex-col">
        <div className="absolute top-4 right-4 z-40 flex flex-col items-end gap-2">
          <div className="flex items-center gap-2 sm:gap-4">
            <Badge
              variant="outline"
              className="hidden sm:flex bg-primary/10 text-primary border-primary/20 gap-1.5 animate-pulse"
            >
              <div className="h-1.5 w-1.5 rounded-full bg-primary" />
              14,284 NODES LIVE
            </Badge>
            {activeContract && (
              <Badge
                variant="outline"
                className="hidden sm:flex bg-yellow-500/10 text-yellow-500 border-yellow-500/20 gap-1.5 animate-pulse"
              >
                <Briefcase className="h-3 w-3" />
                MERCENARY ACTIVE: {activeContract.sector}
              </Badge>
            )}
            <Button
              variant="outline"
              size="sm"
              className={cn(
                "h-9 border-primary/50 text-primary hover:bg-primary/10 gap-2",
                isChatOpen && "bg-primary/20",
              )}
              onClick={() => {
                setIsChatOpen(!isChatOpen);
                hapticFeedback(10);
              }}
            >
              <MessageSquare className="w-4 h-4" />
              <span className="hidden sm:inline">GLOBAL CHAT</span>
            </Button>
            <NeuralNotificationCenter />
          </div>
        </div>
        {/* Map Visualization */}
        <div className="flex-1 relative bg-black/40 overflow-hidden cursor-crosshair group">
          {/* Grid Overlay */}
          <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:40px_40px] pointer-events-none" />

          {/* Radial Glow */}
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(0,255,255,0.05)_0%,transparent_70%)] pointer-events-none" />

          {/* SVG World Map (Stylized) */}
          <svg
            viewBox="0 0 800 400"
            className="w-full h-full opacity-20 stroke-primary/30 fill-none"
          >
            {/* Very basic world outline */}
            <path d="M150,100 Q200,80 250,100 T350,120 T450,100 T550,120 T650,100 T750,120" />
            <path d="M100,200 Q200,180 300,200 T500,220 T700,200" />
            <path d="M200,300 Q300,280 400,300 T600,320" />
          </svg>

          {/* Interactive Nodes */}
          <div className="absolute inset-0">
            {nodes.map((node) => {
              const { x, y } = getCoords(node.lat, node.lng);
              const isActive = selectedNode?.id === node.id;

              return (
                <TooltipProvider key={node.id}>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <button
                        onClick={() => {
                          setSelectedNodeId(node.id);
                          hapticFeedback(10);
                        }}
                        className={cn(
                          "absolute w-4 h-4 -ml-2 -mt-2 rounded-full transition-all duration-500 hover:scale-150",
                          isActive ? "z-30" : "z-20",
                        )}
                        style={{
                          left: `${(x / 800) * 100}%`,
                          top: `${(y / 400) * 100}%`,
                        }}
                      >
                        <span
                          className={cn(
                            "absolute inset-0 rounded-full animate-ping opacity-75",
                            node.intensity > 0.9 ? "bg-primary" : "bg-blue-400",
                          )}
                        />
                        <span
                          className={cn(
                            "relative block w-full h-full rounded-full border-2 border-background",
                            node.intensity > 0.9
                              ? "bg-primary shadow-[0_0_15px_rgba(0,255,255,0.8)]"
                              : "bg-blue-500 shadow-[0_0_10px_rgba(59,130,246,0.5)]",
                          )}
                        />
                      </button>
                    </TooltipTrigger>
                    <TooltipContent
                      side="top"
                      className="bg-card/95 border-primary/30 backdrop-blur-md p-3"
                    >
                      <div className="space-y-1">
                        <div className="text-xs font-bold text-primary uppercase tracking-widest">
                          {node.city}
                        </div>
                        <div className="flex items-center gap-2">
                          <Zap className="w-3 h-3 text-primary" />
                          <span className="text-[10px] font-mono">
                            {node.status} ({Math.round(node.intensity * 100)}%)
                          </span>
                        </div>
                        <div className="text-[10px] text-muted-foreground">
                          {node.users.toLocaleString()} Optimizers Active
                        </div>
                      </div>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              );
            })}
          </div>

          {/* Neural Strikes */}
          {activeStrikes.map((strikeId) => {
            const node = nodes.find((n) => n.id === strikeId);
            if (!node) return null;
            const { x, y } = getCoords(node.lat, node.lng);
            return (
              <div
                key={strikeId}
                className="absolute pointer-events-none z-50"
                style={{
                  left: `${(x / 800) * 100}%`,
                  top: `${(y / 400) * 100}%`,
                }}
              >
                <div
                  className="absolute bottom-0 left-1/2 -translate-x-1/2 w-1 sm:w-2 h-[800px] bg-destructive shadow-[0_0_30px_rgba(255,0,0,1)] animate-pulse"
                  style={{ transformOrigin: "bottom" }}
                />
                <div
                  className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 rounded-full border-4 border-destructive animate-ping"
                  style={{ animationDuration: "1s" }}
                />
                <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-24 h-24 rounded-full bg-destructive/40 blur-xl animate-pulse" />
              </div>
            );
          })}

          {/* Satellites */}
          {satellites.map((sat) => {
            const { x, y } = getCoords(sat.lat, sat.lng);
            return (
              <div
                key={sat.id}
                className="absolute w-32 h-32 -ml-16 -mt-16 pointer-events-none z-10"
                style={{
                  left: `${(x / 800) * 100}%`,
                  top: `${(y / 400) * 100}%`,
                }}
              >
                <div
                  className="absolute inset-0 rounded-full border border-fuchsia-500/50 animate-ping"
                  style={{ animationDuration: "3s" }}
                />
                <div
                  className="absolute inset-4 rounded-full border border-fuchsia-500/30 animate-ping"
                  style={{ animationDuration: "2s" }}
                />
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(217,70,239,0.2)_0%,transparent_70%)] animate-pulse" />
              </div>
            );
          })}

          {/* Scan Line */}
          {isScanning && (
            <div className="absolute top-0 left-0 w-full h-1 bg-primary/50 shadow-[0_0_20px_rgba(0,255,255,0.5)] animate-[scan_2s_linear_infinite] z-40" />
          )}

          {/* Neural Storm Overlay */}
          <NeuralStorm intensity={globalFriction} />

          {/* HUD Overlay */}
          <div className="absolute top-6 left-6 flex flex-col gap-4 pointer-events-none">
            <Card className="bg-background/40 border-primary/20 backdrop-blur-sm w-48 pointer-events-auto">
              <CardHeader className="p-3 pb-1">
                <CardTitle className="text-[10px] uppercase tracking-[0.2em] font-bold text-muted-foreground flex items-center gap-2">
                  <Layers className="w-3 h-3" />
                  Map Layers
                </CardTitle>
              </CardHeader>
              <CardContent className="p-2 space-y-1">
                <Button
                  variant="ghost"
                  size="sm"
                  className={cn(
                    "w-full justify-start text-[10px] h-7 gap-2",
                    activeLayer === "neural" && "bg-primary/10 text-primary",
                  )}
                  onClick={() => {
                    setActiveLayer("neural");
                    hapticFeedback(5);
                  }}
                >
                  <BrainCircuit className="w-3 h-3" /> NEURAL DENSITY
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className={cn(
                    "w-full justify-start text-[10px] h-7 gap-2",
                    activeLayer === "biometric" && "bg-primary/10 text-primary",
                  )}
                  onClick={() => {
                    setActiveLayer("biometric");
                    hapticFeedback(5);
                  }}
                >
                  <Activity className="w-3 h-3" /> BIOMETRIC SYNC
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className={cn(
                    "w-full justify-start text-[10px] h-7 gap-2",
                    activeLayer === "traffic" && "bg-primary/10 text-primary",
                  )}
                  onClick={() => {
                    setActiveLayer("traffic");
                    hapticFeedback(5);
                  }}
                >
                  <Users className="w-3 h-3" /> USER TRAFFIC
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className={cn(
                    "w-full justify-start text-[10px] h-7 gap-2",
                    activeLayer === "wars" && "bg-primary/10 text-primary",
                  )}
                  onClick={() => {
                    setActiveLayer("wars");
                    hapticFeedback(5);
                  }}
                >
                  <Swords className="w-3 h-3" /> SECTOR WARS
                </Button>
              </CardContent>
            </Card>

            {activeLayer === "wars" && (
              <Card className="bg-background/40 border-primary/20 backdrop-blur-sm w-48 pointer-events-auto animate-in slide-in-from-left-2">
                <CardHeader className="p-3 pb-1 flex flex-row items-center justify-between">
                  <CardTitle className="text-[10px] uppercase tracking-[0.2em] font-bold text-muted-foreground flex items-center gap-2">
                    <Flag className="w-3 h-3" />
                    Dominance
                  </CardTitle>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6 text-primary hover:text-primary hover:bg-primary/20"
                    onClick={() => navigate("/war-room")}
                  >
                    <Radar className="h-4 w-4" />
                  </Button>
                </CardHeader>
                <CardContent className="p-3 space-y-3">
                  {Object.entries(dominance).map(([name, data]) => (
                    <div
                      key={name}
                      className="space-y-1 pb-2 border-b border-border/20 last:border-0 last:pb-0"
                    >
                      <div className="flex justify-between text-[8px] uppercase">
                        <span className="text-muted-foreground">{name}</span>
                        <span className={cn("font-bold", (data as any).color)}>
                          {(data as any).dominance}%
                        </span>
                      </div>
                      <div className="flex flex-col">
                        <span className="text-[10px] font-bold text-foreground">
                          {(data as any).faction}
                        </span>
                        <span
                          className={cn(
                            "text-[8px] italic",
                            (data as any).color,
                          )}
                        >
                          {(data as any).buff}
                        </span>
                      </div>
                      <div className="h-1 bg-secondary rounded-full overflow-hidden mt-1">
                        <div
                          className={cn(
                            "h-full transition-all duration-1000",
                            (data as any).bg,
                          )}
                          style={{ width: `${(data as any).dominance}%` }}
                        />
                      </div>
                    </div>
                  ))}
                  <div className="pt-2 mt-2">
                    <div className="text-[8px] text-muted-foreground uppercase mb-2">
                      Contested:{" "}
                      <span className="text-primary font-bold">
                        {contestedSector} (
                        {(dominance as any)[contestedSector]?.faction})
                      </span>
                    </div>
                    <Button
                      size="sm"
                      className="w-full h-8 text-[9px] gap-2 bg-primary/20 text-primary border border-primary/30 hover:bg-primary/30"
                      onClick={() => {
                        setIsContestOpen(true);
                        hapticFeedback([50, 100, 50]);
                      }}
                    >
                      <Swords className="w-3 h-3" />
                      JOIN CONTEST
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            <Card className="bg-background/40 border-primary/20 backdrop-blur-sm w-48 pointer-events-auto">
              <CardHeader className="p-3 pb-1">
                <CardTitle className="text-[10px] uppercase tracking-[0.2em] font-bold text-muted-foreground flex items-center gap-2">
                  <Crosshair className="w-3 h-3" />
                  Telemetry
                </CardTitle>
              </CardHeader>
              <CardContent className="p-3 space-y-2">
                <div className="space-y-1">
                  <div className="flex justify-between text-[8px] uppercase text-muted-foreground">
                    <span>Global Sync</span>
                    <span className="text-primary font-bold">
                      {Math.round((1 - globalFriction) * 1000) / 10}%
                    </span>
                  </div>
                  <div className="h-1 bg-secondary rounded-full overflow-hidden">
                    <div
                      className="h-full bg-primary transition-all duration-1000"
                      style={{ width: `${(1 - globalFriction) * 100}%` }}
                    />
                  </div>
                </div>
                <div className="space-y-1">
                  <div className="flex justify-between text-[8px] uppercase text-muted-foreground">
                    <span>Global Friction</span>
                    <span
                      className={cn(
                        "font-bold",
                        globalFriction > 0.4
                          ? "text-destructive"
                          : "text-primary",
                      )}
                    >
                      {Math.round(globalFriction * 100)}%
                    </span>
                  </div>
                  <div className="h-1 bg-secondary rounded-full overflow-hidden">
                    <div
                      className={cn(
                        "h-full transition-all duration-1000",
                        globalFriction > 0.4 ? "bg-destructive" : "bg-primary",
                      )}
                      style={{ width: `${globalFriction * 100}%` }}
                    />
                  </div>
                </div>
                <div className="space-y-1 pt-1">
                  {globalFriction > 0.4 ? (
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full h-8 text-[9px] border-primary text-primary hover:bg-primary/20 animate-pulse shadow-[0_0_15px_rgba(0,255,255,0.3)]"
                      onClick={() => setIsShieldGameOpen(true)}
                    >
                      <Shield className="w-3 h-3 mr-2" />
                      DEPLOY NEURAL SHIELD
                    </Button>
                  ) : (
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full h-6 text-[7px] border-primary/20 hover:bg-primary/10"
                      onClick={() => {
                        setGlobalFriction(0.65);
                        hapticFeedback([50, 100, 50]);
                        toast("NEURAL STORM DETECTED", {
                          description:
                            "High-intensity friction surge in multiple sectors.",
                        });
                      }}
                    >
                      SIMULATE SURGE
                    </Button>
                  )}
                </div>
                <div className="space-y-1">
                  <div className="flex justify-between text-[8px] uppercase text-muted-foreground">
                    <span>Active Satellites</span>
                    <span className="text-fuchsia-400 font-bold">
                      {satellites.length}
                    </span>
                  </div>
                  <div className="h-1 bg-secondary rounded-full overflow-hidden">
                    <div
                      className="h-full bg-fuchsia-500 transition-all duration-500"
                      style={{
                        width: `${Math.min(100, satellites.length * 10)}%`,
                      }}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Button
              onClick={startVoiceCommand}
              className={cn(
                "w-full h-10 gap-2 border-primary/30 backdrop-blur-md pointer-events-auto",
                isListening
                  ? "bg-primary/30 text-primary animate-pulse border-primary"
                  : "bg-background/40 text-muted-foreground hover:bg-primary/10 hover:text-primary",
              )}
              variant="outline"
            >
              {isListening ? (
                <>
                  <Mic className="w-4 h-4" />
                  LISTENING...
                </>
              ) : (
                <>
                  <MicOff className="w-4 h-4" />
                  VOICE COMMAND
                </>
              )}
            </Button>
          </div>

          <div className="absolute bottom-6 left-6 pointer-events-none">
            <Button
              onClick={handleScan}
              disabled={isScanning}
              className="pointer-events-auto bg-primary/20 text-primary border border-primary/30 hover:bg-primary/30 gap-2 h-10 px-6 backdrop-blur-md shadow-[0_0_20px_rgba(0,255,255,0.1)]"
            >
              <Search className={cn("w-4 h-4", isScanning && "animate-spin")} />
              {isScanning ? "SCANNING SECTORS..." : "INITIATE SECTOR SCAN"}
            </Button>
          </div>

          {/* Node Details (Mobile Slide-up / Desktop Card) */}
          {selectedNode && (
            <div className="absolute bottom-6 right-6 z-50 w-full max-w-[320px] animate-in slide-in-from-right-10 fade-in duration-500">
              <Card className="bg-card/95 border-primary/50 backdrop-blur-md shadow-[0_0_40px_rgba(0,255,255,0.1)]">
                <CardHeader className="p-4 pb-2 flex flex-row items-center justify-between">
                  <div>
                    <CardTitle className="text-lg">
                      {selectedNode.city}
                    </CardTitle>
                    <CardDescription className="text-[10px] uppercase tracking-widest font-bold text-primary">
                      Node Analysis
                    </CardDescription>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-muted-foreground"
                    onClick={() => setSelectedNodeId(null)}
                  >
                    <Zap className="h-4 w-4" />
                  </Button>
                </CardHeader>
                <CardContent className="p-4 pt-0 space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <div className="text-[10px] text-muted-foreground uppercase">
                        Resonance
                      </div>
                      <div className="text-xl font-bold text-primary">
                        {Math.round(selectedNode.intensity * 100)}%
                      </div>
                    </div>
                    <div className="space-y-1">
                      <div className="text-[10px] text-muted-foreground uppercase">
                        Pop. Density
                      </div>
                      <div className="text-xl font-bold text-foreground">
                        {selectedNode.users.toLocaleString()}
                      </div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-[10px] uppercase font-bold">
                      <span>Neural Stability</span>
                      <span className="text-primary">Optimal</span>
                    </div>
                    <div className="h-1.5 bg-secondary rounded-full overflow-hidden">
                      <div className="h-full bg-primary w-[92%] animate-shimmer" />
                    </div>
                  </div>
                  <div className="flex flex-col gap-2 mt-4">
                    <div className="space-y-2 mb-2">
                      <div className="text-[10px] text-muted-foreground uppercase tracking-widest font-bold">
                        Sector Challenges
                      </div>
                      <div className="grid gap-2">
                        {SECTOR_CHALLENGES.map((challenge) => {
                          const isCompleted = completedChallenges.includes(
                            challenge.id,
                          );
                          return (
                            <Button
                              key={challenge.id}
                              variant="ghost"
                              size="sm"
                              className={cn(
                                "w-full justify-start h-auto py-2 px-3 border border-primary/10 hover:bg-primary/10 group/btn relative overflow-hidden",
                                isCompleted && "border-primary/40 bg-primary/5",
                              )}
                              onClick={() => {
                                if (isCompleted) return;
                                hapticFeedback([50, 30, 50]);
                                setCompletedChallenges((prev) => [
                                  ...prev,
                                  challenge.id,
                                ]);
                                toast.success(`${challenge.title} Calibrated`, {
                                  description: `Boosting sync intensity in ${selectedNode.city} by ${Math.round(challenge.reward * 100)}%.`,
                                });

                                if (
                                  completedChallenges.length + 1 ===
                                  SECTOR_CHALLENGES.length
                                ) {
                                  hapticFeedback([100, 50, 100, 50, 200]);
                                  toast.success("NEURAL SYNC REWARD UNLOCKED", {
                                    description:
                                      "Sector Master status achieved. Claim your reward in Profile.",
                                  });
                                }
                              }}
                            >
                              <challenge.icon
                                className={cn(
                                  "w-3.5 h-3.5 text-primary mr-2 shrink-0",
                                  !isCompleted &&
                                    "group-hover/btn:animate-pulse",
                                )}
                              />
                              <div className="text-left">
                                <div className="text-[10px] font-bold text-primary leading-none mb-0.5 flex items-center gap-2">
                                  {challenge.title}
                                  {isCompleted && (
                                    <Badge className="h-3 px-1 text-[7px] bg-primary text-primary-foreground">
                                      SYNCED
                                    </Badge>
                                  )}
                                </div>
                                <div className="text-[8px] text-muted-foreground leading-none">
                                  {challenge.desc}
                                </div>
                              </div>
                            </Button>
                          );
                        })}
                      </div>
                    </div>
                    {allChallengesCompleted && (
                      <Card className="bg-primary/10 border-primary/30 animate-glow-cyan">
                        <CardContent className="p-3 flex items-center gap-3">
                          <div className="h-10 w-10 rounded-full bg-primary/20 border border-primary/50 flex items-center justify-center text-primary shadow-[0_0_15px_rgba(0,255,255,0.3)]">
                            <Zap className="h-5 w-5 animate-pulse" />
                          </div>
                          <div className="flex-1">
                            <div className="text-[10px] font-bold text-primary uppercase tracking-widest">
                              Neural Sync Reward
                            </div>
                            <div className="text-[11px] font-medium">
                              Sector Master Aura Unlocked
                            </div>
                          </div>
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-7 text-[10px] border-primary/50 text-primary hover:bg-primary/10"
                            onClick={() => navigate("/profile")}
                          >
                            CLAIM
                          </Button>
                        </CardContent>
                      </Card>
                    )}
                    <Button
                      className="w-full h-9 text-xs gap-2 bg-primary/20 text-primary border border-primary/30 hover:bg-primary/30"
                      onClick={() => {
                        hapticFeedback([50, 30, 50]);
                        toast.success("Sector Sync", {
                          description: `Calibrating with ${selectedNode.city} nodes...`,
                        });
                      }}
                    >
                      <Crosshair className="w-3.5 h-3.5" />
                      SYNC WITH SECTOR
                    </Button>
                    <Button
                      className="w-full h-9 text-xs gap-2 bg-fuchsia-500/20 text-fuchsia-400 border border-fuchsia-500/30 hover:bg-fuchsia-500/30"
                      onClick={handleDeploySatellite}
                    >
                      <Zap className="w-3.5 h-3.5" />
                      DEPLOY NEURAL SATELLITE
                    </Button>
                    {selectedNode.friction > 0.15 && (
                      <Button
                        className="w-full h-9 text-xs gap-2 bg-destructive/20 text-destructive border border-destructive/30 hover:bg-destructive/30"
                        onClick={() => handleNeuralStrike(selectedNode.id)}
                      >
                        <Target className="w-3.5 h-3.5" />
                        INITIATE NEURAL STRIKE
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>

        {/* Global Chat Sidebar */}
        <div
          className={cn(
            "absolute top-0 right-0 h-full w-full sm:w-[380px] z-50 transition-transform duration-500 transform",
            isChatOpen ? "translate-x-0" : "translate-x-full",
          )}
        >
          <GlobalChat onClose={() => setIsChatOpen(false)} />
        </div>
        {isShieldGameOpen && (
          <NeuralShieldMinigame
            onComplete={() => {
              setIsShieldGameOpen(false);
              setGlobalFriction(0.12);
              hapticFeedback([100, 50, 100, 50, 200]);
              toast.success("Storm Dissipated", {
                description: "Neural shield successfully cleared the friction.",
              });
            }}
            onCancel={() => setIsShieldGameOpen(false)}
          />
        )}
        {isContestOpen && (
          <NeuralContestMinigame
            sector={contestedSector}
            onComplete={(energy) => {
              setIsContestOpen(false);
              hapticFeedback([100, 50, 100, 50, 200]);

              // Mock dominance update
              setDominance((prev) => {
                const next = { ...prev };
                const sectorData = next[contestedSector];
                if (sectorData) {
                  sectorData.dominance = Math.min(
                    100,
                    sectorData.dominance + Math.floor(energy / 10),
                  );
                }
                return next;
              });

              toast.success("Contest Protocol Finalized", {
                description: `Contributed ${energy} Neural Energy to ${contestedSector}. Dominance increased.`,
              });
            }}
            onCancel={() => setIsContestOpen(false)}
          />
        )}
      </main>

      <style
        dangerouslySetInnerHTML={{
          __html: `
        @keyframes scan {
          from { top: 0; }
          to { top: 100%; }
        }
      `,
        }}
      />
    </div>
  );
}
