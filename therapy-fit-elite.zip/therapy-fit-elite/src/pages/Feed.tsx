import { useState, useEffect } from "react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import {
  ShieldCheck,
  Beaker,
  Plus,
  Flame,
  Zap,
  Camera,
  X,
  Wand2,
  TrendingUp,
  Users,
  Video,
  Radio,
  PlayCircle,
} from "lucide-react";
import { hapticFeedback, cn } from "@/lib/utils";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import NeuralBackground from "@/components/NeuralBackground";

const VIDEO_FILTERS = [
  { id: "none", label: "Normal", style: {} },
  {
    id: "thermal",
    label: "Thermal",
    style: { filter: "sepia(1) hue-rotate(270deg) saturate(300%) invert(80%)" },
  },
  {
    id: "night",
    label: "Night Vision",
    style: {
      filter:
        "sepia(1) hue-rotate(50deg) saturate(400%) brightness(1.2) contrast(1.2)",
    },
  },
  {
    id: "matrix",
    label: "Matrix",
    style: {
      filter:
        "sepia(1) hue-rotate(80deg) saturate(300%) brightness(1.5) contrast(1.2)",
    },
  },
  {
    id: "grayscale",
    label: "Grayscale",
    style: { filter: "grayscale(100%) contrast(1.2)" },
  },
];

const FeedPost = ({ user, role, content, time, likes }: any) => (
  <Card className="bg-[#111] border-white/5 overflow-hidden">
    <CardContent className="p-4 space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Avatar className="w-8 h-8 border border-white/10">
            <AvatarImage src={`https://i.pravatar.cc/150?u=${user}`} />
            <AvatarFallback>{user[0]}</AvatarFallback>
          </Avatar>
          <div>
            <div className="flex items-center gap-1">
              <span className="font-bold text-sm">{user}</span>
              <ShieldCheck className="w-3 h-3 text-primary" />
            </div>
            <div className="text-[10px] text-muted-foreground uppercase tracking-widest">
              {role}
            </div>
          </div>
        </div>
        <span className="text-xs text-muted-foreground">{time}</span>
      </div>
      <p className="text-sm text-foreground/90">{content}</p>
      <div className="flex items-center gap-4 pt-2">
        <button
          className="flex items-center gap-1 text-xs text-muted-foreground hover:text-primary transition-colors"
          onClick={() => hapticFeedback(5)}
        >
          <Flame className="w-3 h-3" /> {likes}
        </button>
      </div>
    </CardContent>
  </Card>
);

const RecipePost = ({
  user,
  role,
  title,
  image,
  video,
  videoFilter,
  ingredients,
  macros,
  time,
  points,
  type,
  isSaved,
  onSave,
}: any) => {
  const [liked, setLiked] = useState(false);
  const [currentPoints, setCurrentPoints] = useState(points);

  const handleLike = () => {
    hapticFeedback(10);
    if (!liked) {
      setCurrentPoints(currentPoints + 1);
      setLiked(true);
    } else {
      setCurrentPoints(currentPoints - 1);
      setLiked(false);
    }
  };

  const isShake = type === "shake";
  const Icon = isShake ? Flame : Zap;
  const colorClass = isShake ? "text-orange-400" : "text-purple-400";

  return (
    <Card className="bg-[#111] border-white/5 overflow-hidden shadow-2xl rounded-2xl group">
      <CardContent className="p-0">
        <div className="p-4 flex items-center justify-between border-b border-white/5">
          <div className="flex items-center gap-3">
            <Avatar className="w-10 h-10 border border-white/10 shadow-[0_0_15px_rgba(0,255,102,0.15)]">
              <AvatarImage src={`https://i.pravatar.cc/150?u=${user}`} />
              <AvatarFallback>{user[0]}</AvatarFallback>
            </Avatar>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-sm text-white">{user}</span>
                <ShieldCheck className="w-3.5 h-3.5 text-[#00FF66]" />
              </div>
              <div className="text-[10px] text-[#00FF66]/80 uppercase tracking-widest font-bold">
                {role}
              </div>
            </div>
          </div>
          <span className="text-[10px] text-muted-foreground uppercase tracking-widest font-bold">
            {time}
          </span>
        </div>

        {(image || video) && (
          <Dialog>
            <DialogTrigger asChild>
              <div
                className="w-full h-64 bg-black relative overflow-hidden group/video cursor-pointer"
                onClick={() => hapticFeedback(10)}
              >
                {video ? (
                  <video
                    src={video}
                    className="w-full h-full object-cover opacity-90"
                    controls={false}
                    loop
                    muted
                    playsInline
                    style={
                      VIDEO_FILTERS.find((f) => f.id === videoFilter)?.style ||
                      {}
                    }
                  />
                ) : (
                  <img
                    src={image}
                    alt={title}
                    className="w-full h-full object-cover opacity-90"
                    style={
                      VIDEO_FILTERS.find((f) => f.id === videoFilter)?.style ||
                      {}
                    }
                  />
                )}

                {/* Play Button Overlay */}
                <div className="absolute inset-0 flex items-center justify-center bg-black/10 group-hover/video:bg-black/40 transition-colors duration-300">
                  <div className="w-16 h-16 rounded-full bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center shadow-[0_0_30px_rgba(0,255,102,0.2)] group-hover/video:scale-110 transition-transform duration-300">
                    <PlayCircle className="w-8 h-8 text-[#00FF66] drop-shadow-[0_0_10px_rgba(0,255,102,0.5)]" />
                  </div>
                </div>

                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/10 to-transparent pointer-events-none opacity-90" />
                <div className="absolute bottom-4 left-4 pointer-events-none">
                  <h3 className="font-black text-xl text-white tracking-tight drop-shadow-lg">
                    {title}
                  </h3>
                </div>
              </div>
            </DialogTrigger>
            <DialogContent className="bg-black/95 border-[#00FF66]/30 p-0 overflow-hidden max-w-4xl w-[95vw] h-[80vh] flex flex-col justify-center rounded-2xl shadow-[0_0_50px_rgba(0,255,102,0.15)]">
              {video ? (
                <video
                  src={video}
                  className="w-full h-full object-contain"
                  controls
                  autoPlay
                  playsInline
                  style={
                    VIDEO_FILTERS.find((f) => f.id === videoFilter)?.style || {}
                  }
                />
              ) : (
                <img
                  src={image}
                  alt={title}
                  className="w-full h-full object-contain"
                  style={
                    VIDEO_FILTERS.find((f) => f.id === videoFilter)?.style || {}
                  }
                />
              )}
            </DialogContent>
          </Dialog>
        )}

        <div className="p-5 space-y-5 bg-[#0a0a0a]">
          {!image && !video && (
            <h3 className="font-black text-xl text-white tracking-tight">
              {title}
            </h3>
          )}

          <div className="space-y-3">
            <h4 className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">
              {isShake ? "Ingredients" : "Compounds"}
            </h4>
            <div className="space-y-2">
              {ingredients.map((ing: any, i: number) => (
                <div
                  key={i}
                  className="flex justify-between text-sm items-center py-2 border-b border-white/5 last:border-0"
                >
                  <span className="text-white font-medium">{ing.name}</span>
                  <span className="text-muted-foreground font-mono">
                    {ing.amount}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {macros && (
            <div className="grid grid-cols-4 gap-3 pt-3 border-t border-white/5">
              <div className="bg-[#111] p-3 rounded-xl border border-white/5 flex flex-col items-center justify-center">
                <div className="text-[9px] text-muted-foreground uppercase tracking-widest mb-1">
                  Kcal
                </div>
                <div className="font-mono text-sm font-bold text-white">
                  {macros.kcal}
                </div>
              </div>
              <div className="bg-[#111] p-3 rounded-xl border border-white/5 flex flex-col items-center justify-center">
                <div className="text-[9px] text-muted-foreground uppercase tracking-widest mb-1">
                  Pro
                </div>
                <div className="font-mono text-sm font-bold text-white">
                  {macros.pro}g
                </div>
              </div>
              <div className="bg-[#111] p-3 rounded-xl border border-white/5 flex flex-col items-center justify-center">
                <div className="text-[9px] text-muted-foreground uppercase tracking-widest mb-1">
                  Carb
                </div>
                <div className="font-mono text-sm font-bold text-white">
                  {macros.carb}g
                </div>
              </div>
              <div className="bg-[#111] p-3 rounded-xl border border-white/5 flex flex-col items-center justify-center">
                <div className="text-[9px] text-muted-foreground uppercase tracking-widest mb-1">
                  Fat
                </div>
                <div className="font-mono text-sm font-bold text-white">
                  {macros.fat}g
                </div>
              </div>
            </div>
          )}

          <div className="flex items-center justify-between pt-3 border-t border-white/5">
            <button
              className={cn(
                "flex items-center gap-2 text-xs transition-colors font-bold uppercase tracking-widest",
                liked
                  ? "text-[#00FF66]"
                  : "text-muted-foreground hover:text-white",
              )}
              onClick={handleLike}
            >
              <Icon
                className={cn(
                  "w-4 h-4",
                  liked &&
                    "fill-current drop-shadow-[0_0_8px_rgba(0,255,102,0.8)]",
                )}
              />
              {currentPoints} {isShake ? "Shake Pts" : "Stack Pts"}
            </button>
            <Button
              variant="ghost"
              size="sm"
              className={cn(
                "h-8 text-[10px] uppercase tracking-widest font-bold transition-colors",
                isSaved
                  ? "text-[#00FF66] bg-[#00FF66]/10"
                  : "text-muted-foreground hover:text-white hover:bg-white/5",
              )}
              onClick={() => onSave && onSave(title)}
            >
              {isSaved ? "Saved" : `Save ${isShake ? "Recipe" : "Stack"}`}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

const CreateRecipeDialog = ({
  type,
  onPost,
}: {
  type: "shake" | "stack";
  onPost: (data: any) => void;
}) => {
  const [title, setTitle] = useState("");
  const [ingredients, setIngredients] = useState([{ name: "", amount: "" }]);
  const [macros, setMacros] = useState({
    kcal: "",
    pro: "",
    carb: "",
    fat: "",
  });
  const [open, setOpen] = useState(false);
  const [isCalculating, setIsCalculating] = useState(false);
  const [mediaType, setMediaType] = useState<"none" | "photo" | "video">(
    "none",
  );
  const [videoFilter, setVideoFilter] = useState("none");

  const isShake = type === "shake";
  const colorClass = isShake ? "text-orange-400" : "text-purple-400";
  const bgClass = isShake
    ? "bg-orange-500 hover:bg-orange-600"
    : "bg-purple-500 hover:bg-purple-600";

  const handleAutoCalculate = () => {
    if (ingredients.every((i) => !i.name)) {
      toast.error("Add ingredients first to estimate macros.");
      return;
    }

    setIsCalculating(true);
    hapticFeedback([50, 30, 50]);

    setTimeout(() => {
      let kcal = 0,
        pro = 0,
        carb = 0,
        fat = 0;

      ingredients.forEach((ing) => {
        const name = ing.name.toLowerCase();

        if (name.includes("whey") || name.includes("protein")) {
          pro += 25;
          kcal += 120;
        } else if (name.includes("banana")) {
          carb += 27;
          kcal += 105;
        } else if (name.includes("oat")) {
          carb += 25;
          pro += 5;
          fat += 3;
          kcal += 150;
        } else if (
          name.includes("mct") ||
          name.includes("oil") ||
          name.includes("butter")
        ) {
          fat += 14;
          kcal += 120;
        } else if (name.includes("milk") || name.includes("almond")) {
          kcal += 60;
          pro += 2;
          carb += 5;
          fat += 3;
        } else if (name.includes("berry") || name.includes("fruit")) {
          carb += 15;
          kcal += 60;
        } else if (name.includes("collagen")) {
          pro += 18;
          kcal += 70;
        } else if (name.includes("nut") || name.includes("peanut")) {
          fat += 16;
          pro += 7;
          carb += 6;
          kcal += 190;
        } else if (name.includes("spinach") || name.includes("kale")) {
          kcal += 10;
          pro += 1;
          carb += 2;
        }
      });

      setMacros({
        kcal: Math.round(kcal).toString(),
        pro: Math.round(pro).toString(),
        carb: Math.round(carb).toString(),
        fat: Math.round(fat).toString(),
      });

      setIsCalculating(false);
      toast.success("Macros estimated based on ingredient profile!");
    }, 800);
  };

  const handleAddIngredient = () => {
    hapticFeedback(5);
    setIngredients([...ingredients, { name: "", amount: "" }]);
  };

  const handleRemoveIngredient = (index: number) => {
    hapticFeedback(5);
    setIngredients(ingredients.filter((_, i) => i !== index));
  };

  const handleIngredientChange = (
    index: number,
    field: "name" | "amount",
    value: string,
  ) => {
    const newIngredients = [...ingredients];
    newIngredients[index][field] = value;
    setIngredients(newIngredients);
  };

  const handleSubmit = () => {
    hapticFeedback(10);
    if (!title || ingredients.some((i) => !i.name || !i.amount)) {
      toast.error("Please fill out all fields.");
      return;
    }

    onPost({
      user: "You",
      role: "Elite Operative",
      title,
      image:
        mediaType === "photo"
          ? isShake
            ? "https://vibe.filesafe.space/1776727899133821812/assets/973f32a3-d067-4765-bdac-06fce919d495.png"
            : "https://vibe.filesafe.space/1776727899133821812/assets/3be874e8-6f0c-4f99-af57-050b0ca1d002.png"
          : null,
      video:
        mediaType === "video"
          ? "https://assets.mixkit.co/videos/preview/mixkit-athlete-doing-push-ups-in-a-dark-gym-42672-large.mp4"
          : null,
      videoFilter: mediaType === "video" ? videoFilter : null,
      ingredients,
      macros: isShake ? macros : null,
      time: "Just now",
      points: 0,
      type,
    });
    setOpen(false);
    setTitle("");
    setIngredients([{ name: "", amount: "" }]);
    setMacros({ kcal: "", pro: "", carb: "", fat: "" });
    toast.success(`${isShake ? "Shake" : "Stack"} posted to the community!`);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button
          size="icon"
          className={cn(
            "w-8 h-8 rounded-full text-white",
            isShake
              ? "bg-orange-500 hover:bg-orange-600"
              : "bg-purple-500 hover:bg-purple-600",
          )}
          onClick={() => hapticFeedback(10)}
        >
          <Plus className="w-4 h-4" />
        </Button>
      </DialogTrigger>
      <DialogContent className="bg-[#111] border-white/10 text-foreground max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className={colorClass}>
            Post New {isShake ? "Shake Recipe" : "Supplement Stack"}
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-6 pt-4">
          <div className="flex gap-2">
            <div
              className={cn(
                "flex-1 h-24 border border-dashed rounded-xl flex flex-col items-center justify-center gap-2 transition-colors cursor-pointer",
                mediaType === "photo"
                  ? "bg-primary/20 border-primary text-primary"
                  : "bg-black/50 border-white/20 text-muted-foreground hover:bg-black/70 hover:border-white/40",
              )}
              onClick={() => {
                hapticFeedback(5);
                setMediaType("photo");
              }}
            >
              <Camera className="w-6 h-6" />
              <span className="text-[10px] font-bold uppercase tracking-widest">
                Snap Photo
              </span>
            </div>
            <div
              className={cn(
                "flex-1 h-24 border border-dashed rounded-xl flex flex-col items-center justify-center gap-2 transition-colors cursor-pointer",
                mediaType === "video"
                  ? "bg-blue-500/20 border-blue-500 text-blue-400"
                  : "bg-black/50 border-white/20 text-muted-foreground hover:bg-black/70 hover:border-white/40",
              )}
              onClick={() => {
                hapticFeedback(5);
                setMediaType("video");
              }}
            >
              <Video className="w-6 h-6" />
              <span className="text-[10px] font-bold uppercase tracking-widest">
                Record Clip
              </span>
            </div>
          </div>

          {mediaType === "video" && (
            <div className="space-y-2 animate-in fade-in slide-in-from-top-2">
              <Label className="text-xs text-muted-foreground uppercase tracking-widest">
                Video Filter
              </Label>
              <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide -mx-1 px-1">
                {VIDEO_FILTERS.map((filter) => (
                  <Badge
                    key={filter.id}
                    variant="outline"
                    className={cn(
                      "whitespace-nowrap cursor-pointer transition-colors",
                      videoFilter === filter.id
                        ? "bg-blue-500/20 text-blue-400 border-blue-500/50"
                        : "bg-black/50 text-muted-foreground border-white/10 hover:border-white/30 hover:text-white",
                    )}
                    onClick={() => {
                      hapticFeedback(5);
                      setVideoFilter(filter.id);
                    }}
                  >
                    {filter.label}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          <div className="space-y-2">
            <Label className="text-xs text-muted-foreground uppercase tracking-widest">
              {isShake ? "Shake Name" : "Stack Name"}
            </Label>
            <Input
              className="bg-black/50 border-white/10"
              placeholder={
                isShake ? "e.g. Deep CNS Recovery" : "e.g. Morning Flow State"
              }
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="text-xs text-muted-foreground uppercase tracking-widest">
                {isShake ? "Ingredients" : "Compounds"}
              </Label>
              <Button
                variant="ghost"
                size="sm"
                className={cn(
                  "h-6 text-[10px] uppercase tracking-widest",
                  colorClass,
                )}
                onClick={handleAddIngredient}
              >
                + Add Item
              </Button>
            </div>
            {ingredients.map((ing, i) => (
              <div key={i} className="flex items-center gap-2">
                <Input
                  className="bg-black/50 border-white/10 flex-1"
                  placeholder="Name"
                  value={ing.name}
                  onChange={(e) =>
                    handleIngredientChange(i, "name", e.target.value)
                  }
                />
                <Input
                  className="bg-black/50 border-white/10 w-24"
                  placeholder={isShake ? "Amount" : "Dosage"}
                  value={ing.amount}
                  onChange={(e) =>
                    handleIngredientChange(i, "amount", e.target.value)
                  }
                />
                {ingredients.length > 1 && (
                  <Button
                    variant="ghost"
                    size="icon"
                    className="w-8 h-8 text-muted-foreground hover:text-destructive shrink-0"
                    onClick={() => handleRemoveIngredient(i)}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                )}
              </div>
            ))}
          </div>

          {isShake && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-xs text-muted-foreground uppercase tracking-widest">
                  Macros (Optional)
                </Label>
                <Button
                  variant="ghost"
                  size="sm"
                  className={cn(
                    "h-6 text-[10px] uppercase tracking-widest gap-1",
                    colorClass,
                  )}
                  onClick={handleAutoCalculate}
                  disabled={isCalculating}
                >
                  <Wand2
                    className={cn("w-3 h-3", isCalculating && "animate-pulse")}
                  />
                  {isCalculating ? "Analyzing..." : "Neural Estimate"}
                </Button>
              </div>
              <div className="grid grid-cols-4 gap-2">
                <Input
                  className="bg-black/50 border-white/10 text-center"
                  placeholder="Kcal"
                  value={macros.kcal}
                  onChange={(e) =>
                    setMacros({ ...macros, kcal: e.target.value })
                  }
                />
                <Input
                  className="bg-black/50 border-white/10 text-center"
                  placeholder="Pro (g)"
                  value={macros.pro}
                  onChange={(e) =>
                    setMacros({ ...macros, pro: e.target.value })
                  }
                />
                <Input
                  className="bg-black/50 border-white/10 text-center"
                  placeholder="Carb (g)"
                  value={macros.carb}
                  onChange={(e) =>
                    setMacros({ ...macros, carb: e.target.value })
                  }
                />
                <Input
                  className="bg-black/50 border-white/10 text-center"
                  placeholder="Fat (g)"
                  value={macros.fat}
                  onChange={(e) =>
                    setMacros({ ...macros, fat: e.target.value })
                  }
                />
              </div>
            </div>
          )}

          <Button
            className={cn(
              "w-full font-bold text-white",
              isShake
                ? "bg-orange-500 hover:bg-orange-600"
                : "bg-purple-500 hover:bg-purple-600",
            )}
            onClick={handleSubmit}
          >
            Publish to Community
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

const GoLiveDialog = ({ onStart }: { onStart: (data: any) => void }) => {
  const [title, setTitle] = useState("");
  const [open, setOpen] = useState(false);

  const handleStart = () => {
    hapticFeedback(10);
    if (!title) {
      toast.error("Enter a broadcast title");
      return;
    }
    onStart({
      user: "You",
      role: "Elite Operative",
      title,
      viewers: 0,
      image:
        "https://vibe.filesafe.space/1776727899133821812/assets/aa49c943-5294-4f48-9046-cc01122ef315.png",
    });
    setOpen(false);
    setTitle("");
    toast.success("Broadcast initiated.");
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button
          size="sm"
          className="bg-red-500/20 text-red-400 hover:bg-red-500/30 border border-red-500/50"
          onClick={() => hapticFeedback(5)}
        >
          <Radio className="w-4 h-4 mr-2" /> Go Live
        </Button>
      </DialogTrigger>
      <DialogContent className="bg-[#111] border-white/10 text-foreground">
        <DialogHeader>
          <DialogTitle className="text-red-400 flex items-center gap-2">
            <Radio className="w-5 h-5 animate-pulse" /> Initialize Broadcast
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4 pt-4">
          <div className="space-y-2">
            <Label className="text-xs text-muted-foreground uppercase tracking-widest">
              Broadcast Title
            </Label>
            <Input
              className="bg-black/50 border-white/10"
              placeholder="e.g. Live Q&A: Flow State"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
          </div>
          <Button
            className="w-full bg-red-500 hover:bg-red-600 text-white font-bold"
            onClick={handleStart}
          >
            Start Streaming
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default function Feed() {
  const [activeTab, setActiveTab] = useState("community");
  const [activeFilter, setActiveFilter] = useState("All");
  const [savedItems, setSavedItems] = useState<string[]>([]);
  const GOALS = [
    "All",
    "Muscle Gain",
    "Fat Loss",
    "CNS Recovery",
    "Focus",
    "Deep Sleep",
  ];

  const [streams, setStreams] = useState([
    {
      user: "Dr. Huberman",
      role: "Verified Scientist",
      title: "Live: Deep Sleep Q&A",
      viewers: 1205,
      image:
        "https://vibe.filesafe.space/1776727899133821812/assets/3be874e8-6f0c-4f99-af57-050b0ca1d002.png",
    },
    {
      user: "Marcus_Fit",
      role: "Elite Athlete",
      title: "Pre-Mission Prep",
      viewers: 843,
      image:
        "https://vibe.filesafe.space/1776727899133821812/assets/aa49c943-5294-4f48-9046-cc01122ef315.png",
    },
  ]);

  useEffect(() => {
    const interval = setInterval(() => {
      setStreams((prev) =>
        prev.map((s) => ({
          ...s,
          viewers: Math.max(0, s.viewers + Math.floor(Math.random() * 15) - 5),
        })),
      );
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const [shakes, setShakes] = useState([
    {
      user: "Marcus_Fit",
      role: "Elite Athlete",
      title: "Post-Mission CNS Reset",
      video:
        "https://assets.mixkit.co/videos/preview/mixkit-athlete-doing-push-ups-in-a-dark-gym-42672-large.mp4",
      videoFilter: "none",
      ingredients: [
        { name: "Whey Isolate", amount: "40g" },
        { name: "Tart Cherry Juice", amount: "8oz" },
        { name: "Creatine Monohydrate", amount: "5g" },
        { name: "Banana", amount: "1 med" },
      ],
      macros: { kcal: "320", pro: "42", carb: "35", fat: "2" },
      time: "2h ago",
      points: 124,
      type: "shake",
      goal: "CNS Recovery",
    },
    {
      user: "Sarah_Opt",
      role: "Sovereign Optimizer",
      title: "Morning Flow State Fuel",
      image:
        "https://vibe.filesafe.space/1776727899133821812/assets/973f32a3-d067-4765-bdac-06fce919d495.png",
      ingredients: [
        { name: "Cold Brew Coffee", amount: "10oz" },
        { name: "MCT Oil", amount: "1 tbsp" },
        { name: "Collagen Peptides", amount: "20g" },
        { name: "L-Theanine", amount: "200mg" },
      ],
      macros: { kcal: "210", pro: "18", carb: "2", fat: "14" },
      time: "5h ago",
      points: 89,
      type: "shake",
      goal: "Focus",
    },
  ]);

  const [stacks, setStacks] = useState([
    {
      user: "Dr. Huberman",
      role: "Verified Scientist",
      title: "Deep Sleep Architecture Stack",
      image:
        "https://vibe.filesafe.space/1776727899133821812/assets/3be874e8-6f0c-4f99-af57-050b0ca1d002.png",
      ingredients: [
        { name: "Magnesium Threonate", amount: "145mg" },
        { name: "Apigenin", amount: "50mg" },
        { name: "L-Theanine", amount: "400mg" },
        { name: "Inositol", amount: "900mg" },
      ],
      time: "1h ago",
      points: 342,
      type: "stack",
      goal: "Deep Sleep",
    },
    {
      user: "Alex_Neural",
      role: "Cognitive Hacker",
      title: "Pre-Workout Dopamine Primer",
      ingredients: [
        { name: "L-Tyrosine", amount: "1000mg" },
        { name: "Alpha-GPC", amount: "300mg" },
        { name: "Caffeine", amount: "150mg" },
      ],
      time: "8h ago",
      points: 56,
      type: "stack",
      goal: "Focus",
    },
  ]);

  const communityPosts = [
    {
      user: "Dr. Huberman",
      role: "Verified Scientist",
      content:
        "Just dropped a new protocol on light exposure and circadian alignment. Check the Intel tab.",
      time: "2h ago",
      likes: 124,
    },
    {
      user: "Marcus_Fit",
      role: "Elite Athlete",
      content:
        "CNS is finally back in the green after 3 days of high-intensity missions. Recovery is everything.",
      time: "5h ago",
      likes: 89,
    },
  ];

  const trendingItems = [...shakes, ...stacks]
    .filter((item) => activeFilter === "All" || item.goal === activeFilter)
    .sort((a, b) => b.points - a.points);

  const trendingCreators = [
    { user: "Dr. Huberman", points: 2450 },
    { user: "Marcus_Fit", points: 1820 },
    { user: "Sarah_Opt", points: 1560 },
    { user: "Alex_Neural", points: 1240 },
    { user: "Operator_01", points: 980 },
  ];

  const handleSave = (title: string) => {
    hapticFeedback(10);
    setSavedItems((prev) => {
      if (prev.includes(title)) {
        toast.success("Removed from Library");
        return prev.filter((t) => t !== title);
      } else {
        toast.success("Saved to Library");
        return [...prev, title];
      }
    });
  };

  const savedProtocols = [...shakes, ...stacks].filter((item) =>
    savedItems.includes(item.title),
  );

  return (
    <div className="flex flex-1 flex-col bg-gradient-to-b from-[#0B0C10] to-[#121212] text-foreground relative min-h-full">
      <div className="absolute inset-0 pointer-events-none z-0">
        <NeuralBackground />
        <div className="absolute inset-0 bg-gradient-to-b from-black/90 via-transparent to-black/90" />
      </div>

      <header className="px-6 py-8 relative z-10 border-b border-[#00FF66]/30 bg-black/60 backdrop-blur-xl shadow-[0_0_40px_rgba(0,255,102,0.25)]">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <h1
              className="text-3xl font-black tracking-tighter text-white high-res-glow uppercase"
              style={{ textShadow: "0 0 20px rgba(0,255,102,0.5)" }}
            >
              Global Feed
            </h1>
            <p className="text-[10px] text-[#00FF66]/80 uppercase tracking-[0.4em] font-black flex items-center gap-2">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-500 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              Neural Network Live v3.1
            </p>
          </div>
        </div>
      </header>

      <main className="flex-1 px-4 max-w-md mx-auto w-full relative z-10 mt-6">
        <Tabs
          value={activeTab}
          onValueChange={(v) => {
            setActiveTab(v);
            hapticFeedback(5);
          }}
          className="w-full"
        >
          <TabsList className="grid w-full grid-cols-5 bg-[#111] border border-white/10 mb-6">
            <TabsTrigger
              value="community"
              className="text-[10px] uppercase tracking-widest data-[state=active]:bg-primary/20 data-[state=active]:text-primary px-1"
            >
              Comms
            </TabsTrigger>
            <TabsTrigger
              value="trending"
              className="text-[10px] uppercase tracking-widest data-[state=active]:bg-blue-500/20 data-[state=active]:text-blue-400 px-1"
            >
              Trending
            </TabsTrigger>
            <TabsTrigger
              value="shakelab"
              className="text-[10px] uppercase tracking-widest data-[state=active]:bg-orange-500/20 data-[state=active]:text-orange-400 px-1"
            >
              Shake Lab
            </TabsTrigger>
            <TabsTrigger
              value="stacks"
              className="text-[10px] uppercase tracking-widest data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-400 px-1"
            >
              Supps
            </TabsTrigger>
            <TabsTrigger
              value="saved"
              className="text-[10px] uppercase tracking-widest data-[state=active]:bg-emerald-500/20 data-[state=active]:text-emerald-400 px-1"
            >
              Saved
            </TabsTrigger>
          </TabsList>

          <TabsContent
            value="community"
            className="space-y-4 animate-in fade-in"
          >
            <div className="flex items-center justify-between px-1">
              <div className="flex items-center gap-2">
                <Radio className="w-4 h-4 text-red-500 animate-pulse" />
                <h3 className="text-xs font-bold uppercase tracking-widest text-red-400">
                  Live Network
                </h3>
              </div>
              <GoLiveDialog onStart={(s) => setStreams([s, ...streams])} />
            </div>

            <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide -mx-1 px-1">
              {streams.map((stream, i) => (
                <Dialog key={i}>
                  <DialogTrigger asChild>
                    <div
                      className="min-w-[200px] relative rounded-xl overflow-hidden border border-white/10 group cursor-pointer"
                      onClick={() => {
                        hapticFeedback(5);
                        toast.success("Connecting to secure stream...");
                      }}
                    >
                      <img
                        src={stream.image}
                        alt={stream.title}
                        className="w-full h-28 object-cover opacity-80 group-hover:opacity-100 transition-opacity"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent pointer-events-none" />
                      <div className="absolute top-2 left-2 bg-red-500 text-white text-[8px] font-bold px-1.5 py-0.5 rounded uppercase tracking-widest flex items-center gap-1 animate-pulse">
                        <span className="w-1.5 h-1.5 rounded-full bg-white"></span>{" "}
                        Live
                      </div>
                      <div className="absolute top-2 right-2 bg-black/60 backdrop-blur-md text-white text-[8px] font-bold px-1.5 py-0.5 rounded flex items-center gap-1">
                        <Users className="w-2 h-2" /> {stream.viewers}
                      </div>
                      <div className="absolute bottom-2 left-2 right-2">
                        <div className="text-xs font-bold truncate">
                          {stream.title}
                        </div>
                        <div className="text-[9px] text-muted-foreground truncate">
                          {stream.user}
                        </div>
                      </div>
                      <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/40">
                        <PlayCircle className="w-8 h-8 text-white" />
                      </div>
                    </div>
                  </DialogTrigger>
                  <DialogContent className="bg-black/95 border-red-500/30 p-0 overflow-hidden max-w-4xl w-[95vw] h-[80vh] flex flex-col justify-center rounded-2xl shadow-[0_0_50px_rgba(239,68,68,0.15)]">
                    <video
                      src="https://assets.mixkit.co/videos/preview/mixkit-man-training-with-battle-ropes-in-the-gym-23131-large.mp4"
                      className="w-full h-full object-contain"
                      controls
                      autoPlay
                      playsInline
                      style={{ filter: "sepia(0.2) contrast(1.1)" }}
                    />
                  </DialogContent>
                </Dialog>
              ))}
            </div>

            <div className="h-px w-full bg-white/5 my-2" />

            {communityPosts.map((post, i) => (
              <FeedPost key={i} {...post} />
            ))}
          </TabsContent>

          <TabsContent
            value="trending"
            className="space-y-6 animate-in fade-in"
          >
            <div className="space-y-4">
              <div className="flex items-center justify-between px-1">
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-primary" />
                  <h3 className="text-xs font-bold uppercase tracking-widest">
                    Trending Creators
                  </h3>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-6 text-[10px] uppercase tracking-widest text-muted-foreground"
                >
                  View All
                </Button>
              </div>

              <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide -mx-1 px-1">
                {trendingCreators.map((creator, i) => (
                  <div
                    key={i}
                    className="flex flex-col items-center gap-2 min-w-[80px] bg-[#111] border border-white/5 p-3 rounded-xl"
                  >
                    <div className="relative">
                      <Avatar className="w-12 h-12 border border-primary/30">
                        <AvatarImage
                          src={`https://i.pravatar.cc/150?u=${creator.user}`}
                        />
                        <AvatarFallback>{creator.user[0]}</AvatarFallback>
                      </Avatar>
                      <div className="absolute -bottom-1 -right-1 bg-primary text-primary-foreground text-[8px] font-bold px-1 rounded-full border border-black">
                        #{i + 1}
                      </div>
                    </div>
                    <div className="text-center">
                      <div className="text-[10px] font-bold truncate w-16">
                        {creator.user}
                      </div>
                      <div className="text-[8px] text-primary font-mono">
                        {creator.points} pts
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-blue-500/10 border border-blue-500/20 rounded-xl p-4 flex items-start justify-between gap-3">
              <div className="flex gap-3">
                <TrendingUp className="w-5 h-5 text-blue-400 shrink-0" />
                <div>
                  <h4 className="text-xs font-bold text-blue-400 uppercase tracking-widest">
                    Trending Protocols
                  </h4>
                  <p className="text-xs text-blue-400/70 mt-1">
                    Top-rated recipes & stacks in the last 24 hours.
                  </p>
                </div>
              </div>
            </div>

            <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide -mx-1 px-1">
              {GOALS.map((goal) => (
                <Badge
                  key={goal}
                  variant="outline"
                  className={cn(
                    "whitespace-nowrap cursor-pointer transition-colors",
                    activeFilter === goal
                      ? "bg-blue-500/20 text-blue-400 border-blue-500/50"
                      : "bg-black/50 text-muted-foreground border-white/10 hover:border-white/30 hover:text-white",
                  )}
                  onClick={() => {
                    hapticFeedback(5);
                    setActiveFilter(goal);
                  }}
                >
                  {goal}
                </Badge>
              ))}
            </div>

            <div className="space-y-4">
              {trendingItems.map((item, i) => (
                <RecipePost
                  key={i}
                  {...item}
                  isSaved={savedItems.includes(item.title)}
                  onSave={handleSave}
                />
              ))}
            </div>
          </TabsContent>

          <TabsContent
            value="shakelab"
            className="space-y-6 animate-in fade-in"
          >
            <div className="bg-orange-500/10 border border-orange-500/20 rounded-xl p-4 flex items-start justify-between gap-3">
              <div className="flex gap-3">
                <Beaker className="w-5 h-5 text-orange-400 shrink-0" />
                <div>
                  <h4 className="text-xs font-bold text-orange-400 uppercase tracking-widest">
                    Shake Lab
                  </h4>
                  <p className="text-xs text-orange-400/70 mt-1">
                    Post your custom nutrition recipes & earn Shake Points.
                  </p>
                </div>
              </div>
              <CreateRecipeDialog
                type="shake"
                onPost={(post) => setShakes([post, ...shakes])}
              />
            </div>

            <div className="space-y-4">
              {shakes.map((shake, i) => (
                <RecipePost
                  key={i}
                  {...shake}
                  isSaved={savedItems.includes(shake.title)}
                  onSave={handleSave}
                />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="stacks" className="space-y-6 animate-in fade-in">
            <div className="bg-purple-500/10 border border-purple-500/20 rounded-xl p-4 flex items-start justify-between gap-3">
              <div className="flex gap-3">
                <Zap className="w-5 h-5 text-purple-400 shrink-0" />
                <div>
                  <h4 className="text-xs font-bold text-purple-400 uppercase tracking-widest">
                    Supp Stacks
                  </h4>
                  <p className="text-xs text-purple-400/70 mt-1">
                    Share your cognitive & physical enhancement protocols.
                  </p>
                </div>
              </div>
              <CreateRecipeDialog
                type="stack"
                onPost={(post) => setStacks([post, ...stacks])}
              />
            </div>

            <div className="space-y-4">
              {stacks.map((stack, i) => (
                <RecipePost
                  key={i}
                  {...stack}
                  isSaved={savedItems.includes(stack.title)}
                  onSave={handleSave}
                />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="saved" className="space-y-6 animate-in fade-in">
            <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-xl p-4 flex items-start justify-between gap-3">
              <div className="flex gap-3">
                <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
                <div>
                  <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-widest">
                    Personal Library
                  </h4>
                  <p className="text-xs text-emerald-400/70 mt-1">
                    Your bookmarked protocols and stacks.
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              {savedProtocols.length === 0 ? (
                <div className="text-center py-12 text-muted-foreground text-sm">
                  No protocols saved yet. Explore the Trending tab to build your
                  library.
                </div>
              ) : (
                savedProtocols.map((item, i) => (
                  <RecipePost
                    key={i}
                    {...item}
                    isSaved={true}
                    onSave={handleSave}
                  />
                ))
              )}
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
