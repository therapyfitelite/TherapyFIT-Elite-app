import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Sun,
  Moon,
  Brain,
  Zap,
  CheckCircle2,
  ChevronRight,
  Activity,
  Droplets,
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import {
  cn,
  hapticFeedback,
  playSuccessChime,
  playVoiceover,
  playNodeTapSound,
} from "@/lib/utils";
import { toast } from "sonner";

const CheckInStep = ({
  title,
  description,
  icon: Icon,
  children,
  onNext,
  nextLabel = "Continue",
  disabled = false,
}: any) => (
  <motion.div
    initial={{ opacity: 0, x: 20 }}
    animate={{ opacity: 1, x: 0 }}
    exit={{ opacity: 0, x: -20 }}
    className="flex flex-col items-center text-center space-y-8 py-8"
  >
    <div className="w-20 h-20 rounded-full bg-primary/10 border border-primary/30 flex items-center justify-center shadow-[0_0_30px_rgba(0,255,255,0.2)]">
      <Icon className="w-10 h-10 text-primary animate-pulse" />
    </div>

    <div className="space-y-2">
      <h2 className="text-3xl font-black uppercase tracking-tighter text-white">
        {title}
      </h2>
      <p className="text-muted-foreground text-sm max-w-xs mx-auto">
        {description}
      </p>
    </div>

    <div className="w-full max-w-sm">{children}</div>

    <Button
      disabled={disabled}
      onClick={onNext}
      className="h-14 px-12 rounded-2xl bg-primary text-primary-foreground font-black uppercase tracking-widest text-sm shadow-[0_0_30px_rgba(0,255,255,0.3)] hover:shadow-[0_0_50px_rgba(0,255,255,0.5)] transition-all"
    >
      {nextLabel}
      <ChevronRight className="w-4 h-4 ml-2" />
    </Button>
  </motion.div>
);

const SelectionGrid = ({ value, onChange, options }: any) => (
  <div className="grid grid-cols-5 gap-3">
    {options.map((opt: any, i: number) => (
      <button
        key={i}
        onClick={() => {
          hapticFeedback(15);
          playNodeTapSound(300 + i * 50);
          onChange(i + 1);
        }}
        className={cn(
          "h-14 rounded-2xl border flex flex-col items-center justify-center transition-all duration-500 relative overflow-hidden group",
          value === i + 1
            ? `bg-primary/20 border-primary shadow-[0_0_30px_rgba(0,255,255,0.4)] scale-110 z-10`
            : "bg-black/40 border-white/5 text-muted-foreground hover:border-primary/40 hover:bg-white/5",
        )}
      >
        {value === i + 1 && (
          <div className="absolute inset-0 bg-primary/10 animate-pulse" />
        )}
        <span
          className={cn(
            "font-black text-lg transition-all duration-300",
            value === i + 1
              ? "text-primary scale-125"
              : "text-muted-foreground",
          )}
        >
          {i + 1}
        </span>
        <div
          className={cn(
            "w-1 h-1 rounded-full mt-1 transition-all",
            value === i + 1 ? "bg-primary scale-150" : "bg-white/10",
          )}
        />
      </button>
    ))}
  </div>
);

export default function MorningCheckIn() {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [streak, setStreak] = useState(() => {
    try {
      return parseInt(localStorage.getItem("tf_morning_streak") || "12");
    } catch (e) {
      return 12;
    }
  });
  const [selections, setSelections] = useState({
    sleep: 0,
    clarity: 0,
    tension: 0,
    hydration: 0,
  });

  useEffect(() => {
    const scripts = [
      "Initiating morning neural audit. Step 1: Assess your subjective sleep architecture.",
      "Step 2: Calibrate cognitive clarity levels.",
      "Step 3: Scan for somatic tension or neural friction.",
      "Step 4: Verify hydration status for optimal conductivity.",
      "Neural Audit complete. All systems calibrated. Mission ready.",
    ];
    if (step <= scripts.length) {
      playVoiceover(scripts[step - 1]);
    }
  }, [step]);

  const handleNext = () => {
    if (step < 5) {
      hapticFeedback(10);
      playNodeTapSound(400 + step * 100);
      setStep(step + 1);
      if (step === 4) {
        const newStreak = streak + 1;
        try {
          localStorage.setItem("tf_morning_streak", newStreak.toString());
        } catch (e) {}
        setStreak(newStreak);
      }
    } else {
      try {
        localStorage.setItem("tf_morning_audit_complete", "true");
      } catch (e) {}
      playSuccessChime();
      toast.success(
        `Morning Audit Synchronized. +50 XP | ${streak} Day Streak!`,
      );
      navigate("/");
    }
  };

  return (
    <div className="min-h-full bg-[#050505] flex items-center justify-center p-6 relative">
      {/* Background elements */}
      <div className="absolute inset-0 z-0">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_50%_50%,rgba(0,255,255,0.05)_0%,transparent_70%)]" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-primary/5 rounded-full blur-[120px] animate-pulse" />
      </div>

      <div className="relative z-10 w-full max-w-lg glass-panel p-8 rounded-[32px] border-primary/20">
        <div className="flex justify-between items-center mb-8">
          <Badge
            variant="outline"
            className="bg-primary/10 text-primary border-primary/20 uppercase tracking-widest text-[9px] font-bold"
          >
            Step {step} of 5
          </Badge>
          <div className="flex gap-1">
            {[1, 2, 3, 4, 5].map((s) => (
              <div
                key={s}
                className={cn(
                  "h-1 w-6 rounded-full transition-all duration-500",
                  s <= step
                    ? "bg-primary shadow-[0_0_10px_rgba(0,255,255,0.5)]"
                    : "bg-white/10",
                )}
              />
            ))}
          </div>
        </div>

        <AnimatePresence mode="wait">
          {step === 1 && (
            <div key="step1" className="relative group">
              <div className="absolute inset-0 bg-primary/5 blur-3xl rounded-full animate-pulse pointer-events-none" />
              <div className="absolute top-0 left-0 w-full h-0.5 bg-primary/30 shadow-[0_0_15px_rgba(0,255,255,0.5)] animate-[scan_3s_linear_infinite] z-50 pointer-events-none" />
              <CheckInStep
                title="Sleep Quality"
                description="Rate your restorative sleep depth from 1 (poor) to 5 (optimal)."
                icon={Moon}
                onNext={handleNext}
                disabled={selections.sleep === 0}
              >
                <SelectionGrid
                  value={selections.sleep}
                  onChange={(val: number) =>
                    setSelections({ ...selections, sleep: val })
                  }
                  options={[1, 2, 3, 4, 5]}
                />
              </CheckInStep>
            </div>
          )}

          {step === 2 && (
            <CheckInStep
              key="step2"
              title="Mental Clarity"
              description="Assess your cognitive focus and neural processing speed."
              icon={Brain}
              onNext={handleNext}
              disabled={selections.clarity === 0}
            >
              <SelectionGrid
                value={selections.clarity}
                onChange={(val: number) =>
                  setSelections({ ...selections, clarity: val })
                }
                options={[1, 2, 3, 4, 5]}
              />
            </CheckInStep>
          )}

          {step === 3 && (
            <CheckInStep
              key="step3"
              title="Physical Load"
              description="Scan for muscle tension, soreness, or CNS fatigue."
              icon={Activity}
              onNext={handleNext}
              disabled={selections.tension === 0}
            >
              <SelectionGrid
                value={selections.tension}
                onChange={(val: number) =>
                  setSelections({ ...selections, tension: val })
                }
                options={[1, 2, 3, 4, 5]}
              />
            </CheckInStep>
          )}

          {step === 4 && (
            <CheckInStep
              key="step4"
              title="Fuel Status"
              description="Verify your current hydration and nutrient conductivity."
              icon={Droplets}
              onNext={handleNext}
              disabled={selections.hydration === 0}
            >
              <SelectionGrid
                value={selections.hydration}
                onChange={(val: number) =>
                  setSelections({ ...selections, hydration: val })
                }
                options={[1, 2, 3, 4, 5]}
              />
            </CheckInStep>
          )}

          {step === 5 && (
            <motion.div
              key="step5"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="flex flex-col items-center text-center space-y-8 py-8"
            >
              <div className="relative">
                <div className="absolute inset-0 bg-primary/20 rounded-full blur-3xl animate-pulse" />
                <div className="w-24 h-24 rounded-full bg-primary flex items-center justify-center shadow-[0_0_50px_rgba(0,255,255,0.5)] border-4 border-white/20">
                  <CheckCircle2 className="w-12 h-12 text-primary-foreground" />
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex justify-center mb-2">
                  <Badge
                    variant="outline"
                    className="bg-orange-500/10 text-orange-400 border-orange-500/30 px-3 py-1 uppercase tracking-widest text-[10px] shadow-[0_0_15px_rgba(249,115,22,0.2)]"
                  >
                    🔥 {streak} Day Neural Streak
                  </Badge>
                </div>
                <h2 className="text-4xl font-black uppercase tracking-tighter text-white">
                  All Systems Go
                </h2>
                <p className="text-muted-foreground text-sm max-w-xs mx-auto">
                  Neural audit complete. Your readiness score is{" "}
                  <span className="text-primary font-bold">
                    {Math.round(
                      ((selections.sleep +
                        selections.clarity +
                        selections.tension +
                        selections.hydration) /
                        20) *
                        100,
                    )}
                    %
                  </span>
                  .
                </p>
              </div>

              <div className="grid grid-cols-2 gap-4 w-full">
                <div className="p-4 rounded-2xl bg-white/5 border border-white/10 text-center flex flex-col items-center justify-center relative overflow-hidden">
                  <div
                    className="absolute bottom-0 left-0 h-1 bg-primary/40 transition-all duration-1000"
                    style={{ width: `${(selections.sleep / 5) * 100}%` }}
                  />
                  <div className="text-[10px] uppercase tracking-widest text-muted-foreground mb-1 flex items-center gap-1">
                    <Moon className="w-3 h-3" /> Sleep
                  </div>
                  <div className="text-2xl font-black text-primary">
                    {selections.sleep}
                    <span className="text-sm text-muted-foreground">/5</span>
                  </div>
                </div>
                <div className="p-4 rounded-2xl bg-white/5 border border-white/10 text-center flex flex-col items-center justify-center relative overflow-hidden">
                  <div
                    className="absolute bottom-0 left-0 h-1 bg-primary/40 transition-all duration-1000"
                    style={{ width: `${(selections.clarity / 5) * 100}%` }}
                  />
                  <div className="text-[10px] uppercase tracking-widest text-muted-foreground mb-1 flex items-center gap-1">
                    <Brain className="w-3 h-3" /> Clarity
                  </div>
                  <div className="text-2xl font-black text-primary">
                    {selections.clarity}
                    <span className="text-sm text-muted-foreground">/5</span>
                  </div>
                </div>
                <div className="p-4 rounded-2xl bg-white/5 border border-white/10 text-center flex flex-col items-center justify-center relative overflow-hidden">
                  <div
                    className="absolute bottom-0 left-0 h-1 bg-primary/40 transition-all duration-1000"
                    style={{ width: `${(selections.tension / 5) * 100}%` }}
                  />
                  <div className="text-[10px] uppercase tracking-widest text-muted-foreground mb-1 flex items-center gap-1">
                    <Activity className="w-3 h-3" /> Tension
                  </div>
                  <div className="text-2xl font-black text-primary">
                    {selections.tension}
                    <span className="text-sm text-muted-foreground">/5</span>
                  </div>
                </div>
                <div className="p-4 rounded-2xl bg-white/5 border border-white/10 text-center flex flex-col items-center justify-center relative overflow-hidden">
                  <div
                    className="absolute bottom-0 left-0 h-1 bg-primary/40 transition-all duration-1000"
                    style={{ width: `${(selections.hydration / 5) * 100}%` }}
                  />
                  <div className="text-[10px] uppercase tracking-widest text-muted-foreground mb-1 flex items-center gap-1">
                    <Droplets className="w-3 h-3" /> Hydration
                  </div>
                  <div className="text-2xl font-black text-primary">
                    {selections.hydration}
                    <span className="text-sm text-muted-foreground">/5</span>
                  </div>
                </div>
              </div>

              <Button
                onClick={handleNext}
                className="w-full h-14 rounded-2xl bg-primary text-primary-foreground font-black uppercase tracking-widest text-sm shadow-[0_0_30px_rgba(0,255,255,0.3)]"
              >
                Initiate Mission
                <Zap className="w-4 h-4 ml-2 fill-current" />
              </Button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
