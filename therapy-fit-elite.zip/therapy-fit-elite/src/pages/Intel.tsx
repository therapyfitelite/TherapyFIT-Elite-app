import { useState } from "react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BrainCircuit, Shield, ChevronRight, FlaskConical } from "lucide-react";
import { hapticFeedback } from "@/lib/utils";

const SupplementCard = ({ name, rating, target }: any) => (
  <Card className="bg-[#111] border-white/5 overflow-hidden">
    <CardContent className="p-4 flex items-center justify-between">
      <div>
        <h4 className="font-bold text-sm mb-1">{name}</h4>
        <div className="flex gap-2">
          <Badge
            variant="outline"
            className="text-[8px] uppercase tracking-widest border-primary/30 text-primary"
          >
            {target}
          </Badge>
          <Badge
            variant="outline"
            className="text-[8px] uppercase tracking-widest border-white/20 text-muted-foreground"
          >
            Science: {rating}/10
          </Badge>
        </div>
      </div>
      <ChevronRight className="w-4 h-4 text-muted-foreground" />
    </CardContent>
  </Card>
);

export default function Intel() {
  const [activeTab, setActiveTab] = useState("debrief");

  return (
    <div className="flex flex-1 flex-col bg-[#0a0a0a] text-foreground">
      <header className="px-4 py-6">
        <h1 className="text-2xl font-bold tracking-tighter">INTEL</h1>
        <p className="text-xs text-muted-foreground uppercase tracking-widest">
          Tactical Knowledge
        </p>
      </header>

      <main className="flex-1 px-4 max-w-md mx-auto w-full">
        <Tabs
          value={activeTab}
          onValueChange={(v) => {
            setActiveTab(v);
            hapticFeedback(5);
          }}
          className="w-full"
        >
          <TabsList className="grid w-full grid-cols-2 bg-[#111] border border-white/10 mb-6">
            <TabsTrigger
              value="debrief"
              className="text-[10px] uppercase tracking-widest data-[state=active]:bg-primary/20 data-[state=active]:text-primary"
            >
              AI Debrief
            </TabsTrigger>
            <TabsTrigger
              value="supplements"
              className="text-[10px] uppercase tracking-widest data-[state=active]:bg-fuchsia-500/20 data-[state=active]:text-fuchsia-400"
            >
              Supplements
            </TabsTrigger>
          </TabsList>

          <TabsContent value="debrief" className="space-y-6 animate-in fade-in">
            <Card className="bg-[#111] border-primary/20 shadow-[0_0_20px_rgba(0,255,255,0.05)]">
              <CardContent className="p-6 space-y-6">
                <div className="flex items-center gap-3 border-b border-white/10 pb-4">
                  <div className="w-10 h-10 rounded-full bg-primary/10 border border-primary/30 flex items-center justify-center">
                    <BrainCircuit className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm">War Room AI</h3>
                    <p className="text-[10px] text-muted-foreground uppercase tracking-widest">
                      Weekly Debrief
                    </p>
                  </div>
                </div>

                <div className="space-y-4 text-sm leading-relaxed text-foreground/90">
                  <p>
                    <span className="text-primary font-bold">
                      Analysis Complete.
                    </span>{" "}
                    Your CNS load remained elevated (+12%) throughout the week,
                    primarily driven by late-night cognitive tasks.
                  </p>
                  <p>
                    HRV baseline dropped by 4ms. This indicates creeping
                    systemic fatigue. Your current protocol is unsustainable
                    without intervention.
                  </p>
                  <div className="bg-black/50 p-4 rounded border border-white/5">
                    <h4 className="text-xs font-bold uppercase tracking-widest text-primary mb-2">
                      Tactical Directive
                    </h4>
                    <ul className="space-y-2 text-xs text-muted-foreground">
                      <li>• Implement 15m somatic reset post-workout.</li>
                      <li>• Hard stop on cognitive load at 20:00.</li>
                      <li>
                        • Increase sodium intake to support adrenal function.
                      </li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent
            value="supplements"
            className="space-y-4 animate-in fade-in"
          >
            <div className="bg-fuchsia-500/10 border border-fuchsia-500/20 rounded-xl p-4 flex items-start gap-3 mb-6">
              <FlaskConical className="w-5 h-5 text-fuchsia-400 shrink-0" />
              <div>
                <h4 className="text-xs font-bold text-fuchsia-400 uppercase tracking-widest">
                  Evidence-Rated Stacks
                </h4>
                <p className="text-xs text-fuchsia-400/70 mt-1">
                  No marketing. Pure clinical efficacy.
                </p>
              </div>
            </div>

            <SupplementCard
              name="L-Theanine"
              rating="9"
              target="Parasympathetic"
            />
            <SupplementCard
              name="Ashwagandha"
              rating="8"
              target="Cortisol Control"
            />
            <SupplementCard
              name="Magnesium Threonate"
              rating="9"
              target="CNS Recovery"
            />
            <SupplementCard
              name="Rhodiola Rosea"
              rating="7"
              target="Adaptogen"
            />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
