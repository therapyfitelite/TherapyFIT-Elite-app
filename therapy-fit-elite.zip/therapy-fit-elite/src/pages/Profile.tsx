import React, { useState, useEffect, useRef } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { Sphere, MeshDistortMaterial, Environment } from "@react-three/drei";
import * as THREE from "three";

const NeuralAvatar3D = ({
  hrv,
  stress,
  color,
}: {
  hrv: number;
  stress: number;
  color: string;
}) => {
  const materialRef = useRef<any>(null);

  useFrame((state) => {
    if (materialRef.current) {
      materialRef.current.distort = THREE.MathUtils.lerp(
        materialRef.current.distort,
        0.2 + (stress / 100) * 0.6,
        0.1,
      );
      materialRef.current.speed = THREE.MathUtils.lerp(
        materialRef.current.speed,
        1 + (hrv / 100) * 3,
        0.1,
      );
    }
  });

  return (
    <Sphere args={[1.2, 64, 64]}>
      <MeshDistortMaterial
        ref={materialRef}
        color={color}
        attach="material"
        distort={0.4}
        speed={2}
        roughness={0.1}
        metalness={0.8}
        wireframe={stress > 80}
      />
    </Sphere>
  );
};
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import {
  Bell,
  Shield,
  ShieldCheck,
  User,
  Activity,
  LogOut,
  Download,
  Target,
  Zap,
  Check,
  Share2,
  Swords,
  Trophy,
  Clock,
  Eye,
  ShoppingCart,
  Plus,
  Flame,
  Calendar as CalendarIcon,
  Inbox,
  X,
  MessageSquare,
  RotateCcw,
  Award,
  Twitter,
  Instagram,
  Youtube,
  Linkedin,
  Crown,
  Sparkles,
  Hexagon,
  Mic,
  MicOff,
  Briefcase,
  BrainCircuit,
  Video,
  PlayCircle,
  Scissors,
  Wand2,
  Subtitles,
  Camera,
} from "lucide-react";
import { Logo } from "@/components/Logo";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  XAxis,
  YAxis,
} from "recharts";
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  ChartLegend,
  ChartLegendContent,
} from "@/components/ui/chart";
import { Slider } from "@/components/ui/slider";
import { Progress } from "@/components/ui/progress";
import { Calendar } from "@/components/ui/calendar";
import { cn, hapticFeedback } from "@/lib/utils";
import { NeuralNotificationCenter } from "@/components/NeuralNotifications";
import { DeviceConnectionModal } from "@/components/DeviceConnectionModal";

const chartConfig = {
  score: {
    label: "Score",
    color: "hsl(var(--primary))",
  },
};
const chartData = [
  { day: "Mon", score: 65 },
  { day: "Tue", score: 72 },
  { day: "Wed", score: 85 },
  { day: "Thu", score: 82 },
  { day: "Fri", score: 90 },
  { day: "Sat", score: 95 },
  { day: "Sun", score: 92 },
];

const historicalChartConfig = {
  cognitiveLoad: {
    label: "Cognitive Load",
    color: "hsl(var(--destructive))",
  },
  recovery: {
    label: "Recovery",
    color: "hsl(var(--primary))",
  },
};
const historicalChartData = [
  { month: "Jul", cognitiveLoad: 80, recovery: 60 },
  { month: "Aug", cognitiveLoad: 75, recovery: 70 },
  { month: "Sep", cognitiveLoad: 60, recovery: 85 },
  { month: "Oct", cognitiveLoad: 45, recovery: 92 },
];

export default function Profile() {
  const navigate = useNavigate();
  const { toast } = useToast();

  const [streakShields, setStreakShields] = useState(0);
  const [streakFreezes, setStreakFreezes] = useState(0);
  const [dailyStreak, setDailyStreak] = useState(14);
  const [isHovered, setIsHovered] = useState(false);
  const [avatarGlow, setAvatarGlow] = useState("animate-glow-cyan");
  const [ripples, setRipples] = useState<
    { id: number; x: number; y: number }[]
  >([]);
  const [activeContract, setActiveContract] = useState<{
    sector: string;
  } | null>(null);
  const [neuralPoints, setNeuralPoints] = useState(1500);
  const [isRecalibrating, setIsRecalibrating] = useState(false);
  const [completedDailyCount, setCompletedDailyCount] = useState(2);
  const [totalDailyCount, setTotalDailyCount] = useState(4);
  const [challengeProgress, setChallengeProgress] = useState(50);
  const [isCertificateOpen, setIsCertificateOpen] = useState(false);
  const [completedDays, setCompletedDays] = useState<Date[]>([]);
  const [missedDays, setMissedDays] = useState<Date[]>([]);
  const [petState, setPetState] = useState({
    level: 2,
    class: "",
    name: "Proto-Core",
    desc: "A basic entity.",
    nextAt: 30,
  });
  const [isARMode, setIsARMode] = useState(false);
  const [isMultiUserAR, setIsMultiUserAR] = useState(false);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [isDuelDialogOpen, setIsDuelDialogOpen] = useState(false);
  const [newDuelWager, setNewDuelWager] = useState("100");
  const [chatDuelId, setChatDuelId] = useState<number | null>(null);
  const [incomingDuels, setIncomingDuels] = useState([
    {
      id: 10,
      challenger: "Elena_Bio",
      time: "1h ago",
      metric: "Recovery Index",
      wager: 500,
    },
  ]);
  const [previewItem, setPreviewItem] = useState<any>(null);
  const [challenges, setChallenges] = useState<any[]>([
    {
      id: 1,
      title: "Morning Scan",
      description: "Complete a Sonic Scan before 9 AM.",
      points: 500,
      completed: true,
      claimed: false,
      isAchievement: false,
    },
    {
      id: 2,
      title: "Deep Work",
      description: "Maintain 90%+ focus for 2 hours.",
      points: 1000,
      completed: false,
      claimed: false,
      isAchievement: false,
    },
  ]);
  const [cognitiveTarget, setCognitiveTarget] = useState([60]);
  const [recoveryTarget, setRecoveryTarget] = useState([85]);
  const [weeklyAuditsTarget, setWeeklyAuditsTarget] = useState("4");
  const [neuralSyncActive, setNeuralSyncActive] = useState(false);
  const [messages, setMessages] = useState<Record<number, any[]>>({});
  const [newMessage, setNewMessage] = useState("");
  const [isListening, setIsListening] = useState(false);
  const [avatarImage, setAvatarImage] = useState(
    () => localStorage.getItem("tf_avatar") || "",
  );
  const [userName, setUserName] = useState(
    () => localStorage.getItem("tf_userName") || "Elias Vance",
  );
  const [isEditingName, setIsEditingName] = useState(false);
  const [is3DAvatar, setIs3DAvatar] = useState(false);
  const [isMinting, setIsMinting] = useState(false);
  const [isMintDialogOpen, setIsMintDialogOpen] = useState(false);
  const [nftMinted, setNftMinted] = useState(false);
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const [showClipCreator, setShowClipCreator] = React.useState(false);
  const [selectedArchiveForClip, setSelectedArchiveForClip] =
    React.useState<any>(null);
  const [clipSpeed, setClipSpeed] = React.useState<number>(1);
  const [audioDucking, setAudioDucking] = React.useState(true);
  const [biometricOverlay, setBiometricOverlay] = React.useState(true);
  const [clipWatermark, setClipWatermark] = React.useState(true);
  const [autoCaptions, setAutoCaptions] = React.useState(true);
  const [captionStyle, setCaptionStyle] = React.useState("dynamic");
  const [ttsEnabled, setTtsEnabled] = React.useState(false);
  const [ttsText, setTtsText] = React.useState("");
  const [ttsVoice, setTtsVoice] = React.useState("neural-male");
  const [isVoiceCloned, setIsVoiceCloned] = React.useState(false);
  const [isCloning, setIsCloning] = React.useState(false);
  const [audioMix, setAudioMix] = React.useState([70]);

  const streamArchives = [
    {
      id: 1,
      title: "Deep Work Focus Session",
      duration: "02:15:00",
      date: "Oct 24, 2026",
      views: 124,
      thumbnail:
        "https://vibe.filesafe.space/1776727899133821812/assets/037cdce9-a7bf-4b9b-8092-9e05d7cd4da3.png",
    },
    {
      id: 2,
      title: "Live Q&A: Flow State Mechanics",
      duration: "00:45:30",
      date: "Oct 20, 2026",
      views: 856,
      thumbnail:
        "https://vibe.filesafe.space/1776727899133821812/assets/59fa3e35-9c5e-46f6-a7a7-7700ae5c7f23.png",
    },
    {
      id: 3,
      title: "Pre-Mission Neural Sync",
      duration: "00:15:45",
      date: "Oct 18, 2026",
      views: 342,
      thumbnail:
        "https://vibe.filesafe.space/1776727899133821812/assets/c085a221-7afa-4fe2-ad28-79063ec39d6b.png",
    },
  ];

  const handleAvatarClick = (e: React.MouseEvent) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    setRipples([...ripples, { id: Date.now(), x, y }]);
    setTimeout(() => setRipples((r) => r.slice(1)), 1000);
    if (!isHovered) {
      // Only open file dialog if not just hovering for ripples, or maybe just open it
      // fileInputRef.current?.click(); // Now handled by the camera badge explicitly
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        setAvatarImage(base64String);
        localStorage.setItem("tf_avatar", base64String);
        hapticFeedback([50, 30, 50]);
        toast({
          title: "Neural Signature Updated",
          description: "Avatar successfully recalibrated and saved.",
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleExportSynthesis = () => {
    toast({
      title: "Exporting",
      description: "Synthesis report is being generated.",
    });
  };

  const handleExportCSV = () => {
    hapticFeedback(10);
    const historyData = [
      {
        date: "Today, 08:00 AM",
        type: "Full Audit",
        status: "Optimal",
        score: 92,
        cognitive: 12,
        recovery: 85,
        hr: 62,
        rr: 14,
      },
      {
        date: "Yesterday, 07:30 AM",
        type: "Full Audit",
        status: "Elevated Friction",
        score: 74,
        cognitive: 45,
        recovery: 60,
        hr: 75,
        rr: 18,
      },
      {
        date: "Oct 24, 08:15 AM",
        type: "Sonic Scan",
        status: "Optimal",
        score: 88,
        cognitive: 20,
        recovery: 80,
        hr: 65,
        rr: 15,
      },
      {
        date: "Oct 23, 09:00 AM",
        type: "Full Audit",
        status: "Recovering",
        score: 65,
        cognitive: 60,
        recovery: 40,
        hr: 80,
        rr: 20,
      },
      {
        date: "Oct 22, 07:45 AM",
        type: "Sonic Scan",
        status: "Optimal",
        score: 95,
        cognitive: 10,
        recovery: 90,
        hr: 58,
        rr: 12,
      },
    ];

    const headers = [
      "Date",
      "Type",
      "Status",
      "Score",
      "Cognitive Load",
      "Recovery",
      "Heart Rate",
      "Resp Rate",
    ];
    const csvContent = [
      headers.join(","),
      ...historyData.map(
        (row) =>
          `"${row.date}","${row.type}","${row.status}",${row.score},${row.cognitive},${row.recovery},${row.hr},${row.rr}`,
      ),
    ].join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `neural_history_${new Date().toISOString().split("T")[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast({
      title: "Export Complete",
      description: "Your history has been downloaded.",
    });
  };

  const playSpatialSync = (pan: number) => {
    // Mock spatial audio
  };

  const handleClaimAll = () => {
    setChallenges(
      challenges.map((c) => (c.completed ? { ...c, claimed: true } : c)),
    );
    toast({ title: "Claimed All", description: "All points claimed." });
  };

  const handleClaimPoints = (id: number, points: number) => {
    setChallenges(
      challenges.map((c) => (c.id === id ? { ...c, claimed: true } : c)),
    );
    setNeuralPoints((p) => p + points);
    toast({
      title: "Points Claimed",
      description: `You earned ${points} PTS.`,
    });
  };

  const handleShareChallenge = (title: string) => {
    toast({ title: "Shared", description: `Challenge ${title} shared.` });
  };

  const handleNotificationChange = (name: string) => (checked: boolean) => {
    toast({
      title: "Preferences Updated",
      description: `${name} is now ${checked ? "enabled" : "disabled"}.`,
    });
  };

  const handlePurchase = (
    name: string,
    price: number,
    style?: string,
    isConsumable?: boolean,
  ) => {
    if (neuralPoints >= price) {
      setNeuralPoints((p) => p - price);
      if (style && !isConsumable) {
        setAvatarGlow(style);
      }
      if (name === "Streak Freeze") setStreakFreezes((f) => f + 1);
      if (name === "Streak Shield") setStreakShields((s) => s + 1);
      toast({
        title: "Purchase Successful",
        description: `You bought ${name}.`,
      });
    } else {
      toast({
        title: "Insufficient Points",
        description: "You need more PTS.",
        variant: "destructive",
      });
    }
  };

  const handleSaveGoals = () => {
    toast({
      title: "Goals Saved",
      description: "Calibration targets updated.",
    });
  };

  const handleCreateDuel = () => {
    setIsDuelDialogOpen(false);
    toast({
      title: "Challenge Sent",
      description: "Your duel request has been sent.",
    });
  };

  const handleAcceptDuel = (id: number, wager: number) => {
    setIncomingDuels((duels) => duels.filter((d) => d.id !== id));
    toast({
      title: "Duel Accepted",
      description: `Wager of ${wager} PTS locked.`,
    });
  };

  const handleDeclineDuel = (id: number) => {
    setIncomingDuels((duels) => duels.filter((d) => d.id !== id));
  };

  const handleShareBiometrics = (duelId: number) => {
    toast({
      title: "Biometrics Shared",
      description: "Telemetry sent to opponent.",
    });
  };

  const handleSendMessage = (duelId: number) => {
    if (!newMessage) return;
    setMessages((prev) => ({
      ...prev,
      [duelId]: [
        ...(prev[duelId] || []),
        { sender: userName, text: newMessage, time: "Just now" },
      ],
    }));
    setNewMessage("");
  };

  const toggleListening = () => {
    setIsListening(!isListening);
  };

  const handleStartAR = () => {
    setIsARMode(true);
  };

  const handleStopAR = () => {
    setIsARMode(false);
  };

  const handleMintNFT = () => {
    setIsMinting(true);
    hapticFeedback([50, 50, 100]);
    toast({
      title: "Initiating Smart Contract",
      description: "Minting neural signature to blockchain...",
    });
    setTimeout(() => {
      setIsMinting(false);
      setNftMinted(true);
      setIsMintDialogOpen(false);
      hapticFeedback([100, 50, 100, 50, 200]);
      toast({
        title: "Minting Complete",
        description: "Your biometric avatar is now locked on-chain.",
      });
    }, 3000);
  };

  return (
    <div className="flex flex-1 flex-col bg-background text-foreground">
      {/* Header Actions */}
      <div className="w-full border-b border-border/40 bg-background/50">
        <div className="w-full flex h-14 items-center justify-end px-4 md:px-8">
          <div className="flex items-center gap-3">
            <Button
              variant="outline"
              size="sm"
              className="hidden sm:flex h-8 border-primary/30 text-primary hover:bg-primary/10 gap-2 animate-pulse hover:animate-none"
              onClick={() => {
                hapticFeedback([30, 50, 30, 50, 100]);
                toast({
                  title: "Global Sync Initiated",
                  description:
                    "All biometric sectors are being recalibrated...",
                });
              }}
            >
              <Zap className="w-3.5 h-3.5" />
              SYNC ALL
            </Button>
            {streakShields > 0 && (
              <div className="flex items-center gap-1 text-primary font-bold bg-primary/10 px-2 py-1 rounded-md border border-primary/20 shadow-[0_0_10px_rgba(0,200,200,0.2)]">
                <ShieldCheck className="w-4 h-4" />
                <span>{streakShields}</span>
              </div>
            )}
            {streakFreezes > 0 && (
              <div className="flex items-center gap-1 text-blue-400 font-bold bg-blue-400/10 px-2 py-1 rounded-md border border-blue-400/20">
                <Shield className="w-4 h-4" />
                <span>{streakFreezes}</span>
              </div>
            )}
            <div className="flex items-center gap-1 text-orange-500 font-bold bg-orange-500/10 px-2 py-1 rounded-md border border-orange-500/20">
              <Flame className="w-4 h-4" />
              <span>{dailyStreak}</span>
            </div>
            <NeuralNotificationCenter />
          </div>
        </div>
      </div>

      <main className="flex-1 w-full px-4 md:px-8 py-8 md:py-12">
        <div className="flex flex-col md:flex-row gap-8 items-start">
          {/* Sidebar / User Info */}
          <div className="w-full md:w-64 flex flex-col gap-6">
            <Card className="bg-card/40 border-border/50 backdrop-blur-sm">
              <CardContent className="pt-6 flex flex-col items-center text-center">
                <div
                  className="relative group w-28 h-28 mb-4 mx-auto"
                  onMouseEnter={() => setIsHovered(true)}
                  onMouseLeave={() => setIsHovered(false)}
                >
                  <input
                    type="file"
                    ref={fileInputRef}
                    className="hidden"
                    accept="image/*"
                    onChange={handleImageUpload}
                  />

                  {is3DAvatar ? (
                    <div
                      className={cn(
                        "w-full h-full rounded-full overflow-hidden border-2 border-primary/50 relative transition-all duration-500 cursor-pointer bg-black/50",
                        avatarGlow,
                        isHovered && "scale-110",
                      )}
                    >
                      <Canvas camera={{ position: [0, 0, 3] }}>
                        <ambientLight intensity={0.5} />
                        <pointLight position={[10, 10, 10]} intensity={1} />
                        <NeuralAvatar3D hrv={75} stress={40} color="#00cccc" />
                        <Environment preset="city" />
                      </Canvas>
                    </div>
                  ) : (
                    <div
                      className="relative h-full w-full"
                      onClick={handleAvatarClick}
                    >
                      <Avatar
                        className={cn(
                          "h-full w-full border-2 border-primary/30 transition-all duration-500 cursor-pointer overflow-hidden relative shadow-[0_0_20px_rgba(0,255,255,0.1)]",
                          avatarGlow,
                          isHovered && "scale-105",
                          !isHovered && "animate-neural-pulse",
                        )}
                      >
                        <AvatarImage
                          src={avatarImage}
                          alt="User"
                          className="object-cover"
                        />
                        <AvatarFallback className="bg-card flex flex-col items-center justify-center text-primary border border-primary/20">
                          <User className="w-12 h-12 opacity-50 mb-1" />
                        </AvatarFallback>

                        {/* Holographic Overlays */}
                        <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-primary/20 via-transparent to-transparent mix-blend-overlay pointer-events-none" />
                        <div className="absolute inset-0 rounded-full bg-[linear-gradient(transparent_50%,rgba(0,255,255,0.05)_50%)] bg-[length:100%_4px] pointer-events-none" />

                        {/* Ripple Effects */}
                        {ripples.map((ripple) => (
                          <span
                            key={ripple.id}
                            className="absolute pointer-events-none rounded-full bg-primary/40 animate-ripple"
                            style={{
                              left: ripple.x,
                              top: ripple.y,
                              width: "20px",
                              height: "20px",
                              marginLeft: "-10px",
                              marginTop: "-10px",
                            }}
                          />
                        ))}
                      </Avatar>

                      {/* Edit Badge */}
                      <div
                        className="absolute bottom-0 right-0 bg-primary text-primary-foreground p-2 rounded-full shadow-[0_0_15px_rgba(0,255,255,0.5)] border-2 border-background z-20 cursor-pointer hover:scale-110 hover:bg-primary/90 transition-all"
                        onClick={(e) => {
                          e.stopPropagation();
                          fileInputRef.current?.click();
                        }}
                      >
                        <Camera className="w-4 h-4" />
                      </div>
                    </div>
                  )}
                  <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 bg-background border border-primary/30 text-primary text-[8px] font-bold px-2 py-0.5 rounded-full opacity-0 group-hover:opacity-100 transition-opacity z-30 shadow-[0_0_10px_rgba(0,255,255,0.2)]">
                    SYNCED
                  </div>
                </div>
                <div className="flex gap-2 items-center mb-1 mt-2 group relative">
                  {isEditingName ? (
                    <Input
                      autoFocus
                      value={userName}
                      onChange={(e) => setUserName(e.target.value)}
                      onBlur={() => {
                        setIsEditingName(false);
                        localStorage.setItem("tf_userName", userName);
                        toast({
                          title: "Profile Updated",
                          description: "Neural identity synchronized.",
                        });
                      }}
                      onKeyDown={(e) =>
                        e.key === "Enter" && e.currentTarget.blur()
                      }
                      className="text-xl font-bold h-8 max-w-[200px] text-center bg-background/50 border-primary/30"
                    />
                  ) : (
                    <h2
                      className="text-xl font-bold cursor-pointer hover:text-primary transition-colors flex items-center gap-2"
                      onClick={() => setIsEditingName(true)}
                      title="Click to edit designation"
                    >
                      {userName}
                    </h2>
                  )}
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6 text-primary hover:bg-primary/20"
                    onClick={(e) => {
                      e.stopPropagation();
                      setIs3DAvatar(!is3DAvatar);
                      hapticFeedback(20);
                    }}
                    title="Toggle 3D Neural Form"
                  >
                    <Activity className="h-4 w-4" />
                  </Button>
                </div>
                <p className="text-sm text-muted-foreground mb-4">
                  Sovereign Optimizer
                </p>
                <div className="w-full bg-secondary rounded-full h-2 mb-2 overflow-hidden">
                  <div className="bg-primary h-full w-[85%] rounded-full shadow-[0_0_10px_rgba(0,200,200,0.5)]"></div>
                </div>
                <p className="text-xs text-primary font-medium tracking-wider mb-4">
                  SYSTEM OPTIMAL (85%)
                </p>
                {activeContract && (
                  <div className="w-full mt-2 animate-in fade-in zoom-in duration-500">
                    <Badge
                      variant="outline"
                      className="w-full bg-yellow-500/10 border-yellow-500/30 text-yellow-500 py-1 flex items-center justify-center gap-2"
                    >
                      <Briefcase className="w-3 h-3" />
                      MERCENARY: {activeContract.sector}
                    </Badge>
                  </div>
                )}
                <Badge
                  variant="outline"
                  className="bg-primary/5 border-primary/20 text-primary font-mono px-3 py-1.5 gap-1.5 shadow-[0_0_10px_rgba(0,200,200,0.1)]"
                >
                  <Zap className="w-3.5 h-3.5 fill-primary" />
                  {neuralPoints.toLocaleString()} PTS
                </Badge>

                <Button
                  variant="outline"
                  size="sm"
                  className="w-full mt-4 border-amber-500/30 text-amber-500 hover:bg-amber-500/10 gap-2 shadow-[0_0_15px_rgba(245,158,11,0.1)]"
                  onClick={() => navigate("/nexus-builder")}
                >
                  <Sparkles className="w-4 h-4" />
                  Customize Nexus Avatar
                </Button>

                <Button
                  variant="outline"
                  size="sm"
                  className={cn(
                    "w-full mt-4 gap-2 transition-all duration-500",
                    nftMinted
                      ? "border-green-500/50 text-green-500 hover:bg-green-500/10 shadow-[0_0_15px_rgba(34,197,94,0.2)]"
                      : "border-primary/50 text-primary hover:bg-primary/10 shadow-[0_0_15px_rgba(0,255,255,0.1)] hover:shadow-[0_0_25px_rgba(0,255,255,0.2)]",
                  )}
                  onClick={() => !nftMinted && setIsMintDialogOpen(true)}
                >
                  {nftMinted ? (
                    <Check className="h-4 w-4" />
                  ) : (
                    <Hexagon className="h-4 w-4" />
                  )}
                  {nftMinted ? "MINTED ON-CHAIN" : "MINT BIOMETRIC NFT"}
                </Button>

                <DeviceConnectionModal />
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <div className="grid grid-cols-3 gap-3 sm:gap-4">
              <Card className="bg-card/40 border-border/50">
                <CardContent className="p-3 sm:p-4 flex flex-col items-center justify-center text-center">
                  <Activity className="h-5 w-5 text-primary mb-2" />
                  <div className="text-xl sm:text-2xl font-bold">14</div>
                  <div className="text-[10px] sm:text-xs text-muted-foreground">
                    Audits Logged
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-card/40 border-border/50">
                <CardContent className="p-3 sm:p-4 flex flex-col items-center justify-center text-center">
                  <BrainCircuit className="h-5 w-5 text-primary mb-2" />
                  <div className="text-xl sm:text-2xl font-bold">92%</div>
                  <div className="text-[10px] sm:text-xs text-muted-foreground">
                    Flow State
                  </div>
                </CardContent>
              </Card>
              <Card
                className={cn(
                  "bg-card/40 border-border/50 relative overflow-hidden group",
                  ([7, 14, 21, 30, 50, 100, 365].includes(dailyStreak) ||
                    dailyStreak % 30 === 0) &&
                    "border-orange-500/50 shadow-[0_0_15px_rgba(249,115,22,0.2)]",
                )}
              >
                <div className="absolute inset-0 bg-gradient-to-t from-orange-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                {([7, 14, 21, 30, 50, 100, 365].includes(dailyStreak) ||
                  dailyStreak % 30 === 0) && (
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-orange-500/20 to-transparent -translate-x-full animate-shimmer" />
                )}
                <CardContent className="p-3 sm:p-4 flex flex-col items-center justify-center text-center relative z-10">
                  <Flame
                    className={cn(
                      "h-5 w-5 text-orange-500 mb-2",
                      [7, 14, 21, 30, 50, 100, 365].includes(dailyStreak) ||
                        dailyStreak % 30 === 0
                        ? "animate-bounce"
                        : "animate-pulse",
                    )}
                  />
                  <div className="text-xl sm:text-2xl font-bold text-orange-500">
                    {dailyStreak}
                  </div>
                  <div className="text-[10px] sm:text-xs text-muted-foreground">
                    Day Streak
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Main Content Area */}
          <div className="flex-1 w-full min-w-0">
            <Tabs defaultValue="overview" className="w-full">
              <TabsList className="flex w-full overflow-x-auto bg-secondary/50 p-1 custom-scrollbar">
                <TabsTrigger
                  value="overview"
                  className="flex-1 min-w-[100px] data-[state=active]:bg-primary/20 data-[state=active]:text-primary"
                >
                  Overview
                </TabsTrigger>
                <TabsTrigger
                  value="devices"
                  className="flex-1 min-w-[100px] data-[state=active]:bg-primary/20 data-[state=active]:text-primary"
                >
                  Devices
                </TabsTrigger>
                <TabsTrigger
                  value="streak"
                  className="flex-1 min-w-[100px] data-[state=active]:bg-primary/20 data-[state=active]:text-primary"
                >
                  Streak
                </TabsTrigger>
                <TabsTrigger
                  value="companion"
                  className="flex-1 min-w-[100px] data-[state=active]:bg-primary/20 data-[state=active]:text-primary"
                >
                  Companion
                </TabsTrigger>
                <TabsTrigger
                  value="duels"
                  className="flex-1 min-w-[100px] data-[state=active]:bg-primary/20 data-[state=active]:text-primary"
                >
                  Duels
                </TabsTrigger>
                <TabsTrigger
                  value="shop"
                  className="flex-1 min-w-[100px] data-[state=active]:bg-primary/20 data-[state=active]:text-primary"
                >
                  Shop
                </TabsTrigger>
                <TabsTrigger
                  value="vault"
                  className="flex-1 min-w-[100px] data-[state=active]:bg-primary/20 data-[state=active]:text-primary"
                >
                  Vault
                </TabsTrigger>
                <TabsTrigger
                  value="simulator"
                  className="flex-1 min-w-[100px] data-[state=active]:bg-primary/20 data-[state=active]:text-primary"
                >
                  Simulator
                </TabsTrigger>
                <TabsTrigger
                  value="goals"
                  className="flex-1 min-w-[100px] data-[state=active]:bg-primary/20 data-[state=active]:text-primary"
                >
                  Goals
                </TabsTrigger>
                <TabsTrigger
                  value="challenges"
                  className="flex-1 min-w-[100px] data-[state=active]:bg-primary/20 data-[state=active]:text-primary"
                >
                  Challenges
                </TabsTrigger>
                <TabsTrigger
                  value="history"
                  className="flex-1 min-w-[100px] data-[state=active]:bg-primary/20 data-[state=active]:text-primary"
                >
                  History
                </TabsTrigger>
                <TabsTrigger
                  value="archives"
                  className="flex-1 min-w-[100px] data-[state=active]:bg-primary/20 data-[state=active]:text-primary"
                >
                  Archives
                </TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="space-y-6 mt-6">
                <Card
                  className={cn(
                    "bg-card/40 border-primary/30 backdrop-blur-sm relative overflow-hidden group transition-all duration-500",
                    isRecalibrating &&
                      "border-primary shadow-[0_0_30px_rgba(0,255,255,0.3)] scale-[1.02]",
                  )}
                >
                  <div
                    className={cn(
                      "absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-transparent opacity-50 transition-opacity duration-500",
                      isRecalibrating && "opacity-100 from-primary/20",
                    )}
                  />
                  <div className="absolute top-0 right-0 p-4">
                    <div className="relative flex h-3 w-3">
                      <span
                        className={cn(
                          "absolute inline-flex h-full w-full rounded-full bg-primary opacity-75",
                          isRecalibrating ? "animate-ping" : "animate-pulse",
                        )}
                      ></span>
                      <span className="relative inline-flex rounded-full h-3 w-3 bg-primary"></span>
                    </div>
                  </div>
                  <CardHeader className="pb-2">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg flex items-center gap-2">
                        <Activity
                          className={cn(
                            "h-5 w-5 text-primary",
                            isRecalibrating ? "animate-spin" : "animate-pulse",
                          )}
                        />
                        Neural Sync Status
                      </CardTitle>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          className="h-8 border-fuchsia-500/50 text-fuchsia-500 hover:bg-fuchsia-500/10 gap-2 relative overflow-hidden group"
                          onClick={() => {
                            hapticFeedback([100, 50, 200]);
                            toast({
                              title: "NEURAL OVERDRIVE ENGAGED",
                              description:
                                "Redirecting to extreme focus protocols.",
                            });
                            navigate("/flow");
                          }}
                        >
                          <Zap className="h-3 w-3 group-hover:animate-ping" />
                          OVERDRIVE
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="h-8 border-primary/50 text-primary hover:bg-primary/10 gap-2 relative overflow-hidden group"
                          onClick={() => {
                            if (isRecalibrating) return;
                            setIsRecalibrating(true);
                            hapticFeedback([30, 50, 30, 50, 100]);
                            toast({
                              title: "Recalibrating",
                              description: "Synchronizing neural telemetry...",
                            });
                            setTimeout(() => {
                              setIsRecalibrating(false);
                              hapticFeedback([100, 50, 100]);
                              toast({
                                title: "Sync Complete",
                                description: "Recovery stats updated.",
                              });
                            }, 2000);
                          }}
                          disabled={isRecalibrating}
                        >
                          <RotateCcw
                            className={cn(
                              "h-3 w-3",
                              isRecalibrating
                                ? "animate-spin"
                                : "group-hover:rotate-180 transition-transform",
                            )}
                          />
                          {isRecalibrating ? "SYNCING..." : "RECALIBRATE"}
                        </Button>
                      </div>
                    </div>
                    <CardDescription>
                      Real-time physiological recovery architecture.
                    </CardDescription>
                  </CardHeader>
                  <CardContent
                    className={cn(
                      "transition-opacity duration-500",
                      isRecalibrating && "opacity-50 blur-sm",
                    )}
                  >
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-6">
                      <div className="space-y-2">
                        <div className="text-[10px] text-muted-foreground uppercase tracking-widest font-bold">
                          Recovery Index
                        </div>
                        <div className="flex items-baseline gap-1">
                          <span className="text-3xl font-bold text-primary">
                            85
                          </span>
                          <span className="text-xs text-primary/70">%</span>
                        </div>
                        <Progress
                          value={85}
                          className="h-1.5 bg-secondary/50"
                        />
                      </div>
                      <div className="space-y-2">
                        <div className="text-[10px] text-muted-foreground uppercase tracking-widest font-bold">
                          HRV (msec)
                        </div>
                        <div className="flex items-baseline gap-1">
                          <span className="text-3xl font-bold text-foreground">
                            62
                          </span>
                          <span className="text-xs text-muted-foreground">
                            ms
                          </span>
                        </div>
                        <div className="flex items-center gap-1 text-[10px] text-primary font-bold">
                          <Zap className="h-3 w-3 fill-primary" />
                          +4% VS BASELINE
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="text-[10px] text-muted-foreground uppercase tracking-widest font-bold">
                          Sleep Depth
                        </div>
                        <div className="flex items-baseline gap-1">
                          <span className="text-3xl font-bold text-foreground">
                            88
                          </span>
                          <span className="text-xs text-muted-foreground">
                            %
                          </span>
                        </div>
                        <Progress
                          value={88}
                          className="h-1.5 bg-secondary/50"
                        />
                      </div>
                      <div className="space-y-2">
                        <div className="text-[10px] text-muted-foreground uppercase tracking-widest font-bold">
                          Neural Load
                        </div>
                        <div className="flex items-baseline gap-1">
                          <span className="text-3xl font-bold text-destructive">
                            12
                          </span>
                          <span className="text-xs text-destructive/70">%</span>
                        </div>
                        <div className="flex items-center gap-1 text-[10px] text-destructive font-bold">
                          <Activity className="h-3 w-3" />
                          OPTIMAL SYNC
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <Card className="bg-card/40 border-primary/20 backdrop-blur-sm relative overflow-hidden group hover:border-primary/50 transition-all">
                  <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-transparent" />
                  <CardHeader className="pb-2">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-sm font-bold flex items-center gap-2">
                        <Zap className="h-4 w-4 text-primary" />
                        DAILY CALIBRATION PROGRESS
                      </CardTitle>
                      <span className="text-[10px] font-mono text-primary font-bold">
                        {completedDailyCount}/{totalDailyCount}
                      </span>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between text-[10px] text-muted-foreground uppercase tracking-widest">
                        <span>Calibration Status</span>
                        <span className="text-primary">
                          {Math.round(challengeProgress)}%
                        </span>
                      </div>
                      <Progress value={challengeProgress} className="h-2" />
                    </div>
                    <p className="text-[10px] text-muted-foreground italic">
                      {challengeProgress === 100
                        ? "All systems optimized for today."
                        : "Complete remaining protocols to reach peak sync."}
                    </p>
                  </CardContent>
                </Card>

                {/* Achievements Section */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <Card className="bg-card/40 border-primary/20 backdrop-blur-sm relative overflow-hidden group hover:border-primary/50 transition-all">
                    <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-transparent" />
                    <CardHeader className="pb-2">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-sm font-bold flex items-center gap-2">
                          <Trophy className="h-4 w-4 text-primary" />
                          LATEST ACHIEVEMENT
                        </CardTitle>
                        <Badge
                          variant="outline"
                          className="bg-primary/10 text-primary border-primary/20 text-[8px] animate-pulse"
                        >
                          NEW
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="flex flex-col gap-4">
                      <div className="flex items-center gap-4">
                        <div className="h-12 w-12 rounded-full bg-primary/10 border border-primary/30 flex items-center justify-center text-primary shadow-[0_0_15px_rgba(0,255,255,0.2)]">
                          <Award className="h-6 w-6" />
                        </div>
                        <div>
                          <div className="font-bold text-sm">
                            Neural Sync Master
                          </div>
                          <div className="text-[10px] text-muted-foreground">
                            60m High Intensity Focus
                          </div>
                        </div>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        className="w-full text-xs border-primary/30 text-primary hover:bg-primary/10 gap-2"
                        onClick={() => setIsCertificateOpen(true)}
                      >
                        <Share2 className="h-3 w-3" />
                        View Certificate
                      </Button>
                    </CardContent>
                  </Card>

                  <Card className="bg-card/40 border-border/50 backdrop-blur-sm">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-bold flex items-center gap-2">
                        <Target className="h-4 w-4 text-primary" />
                        NEXT MILESTONE
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center gap-4">
                        <div className="h-12 w-12 rounded-full bg-secondary border border-border/50 flex items-center justify-center text-muted-foreground">
                          <Clock className="h-6 w-6" />
                        </div>
                        <div className="flex-1">
                          <div className="font-bold text-sm">
                            Ultradian Master
                          </div>
                          <div className="text-[10px] text-muted-foreground mb-1">
                            90m Session (45% Complete)
                          </div>
                          <Progress value={45} className="h-1" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <Card className="bg-card/40 border-border/50 backdrop-blur-sm">
                  <CardHeader className="flex flex-row items-center justify-between pb-2">
                    <div className="space-y-1">
                      <CardTitle>Weekly Synthesis Report</CardTitle>
                      <CardDescription>
                        Your 7-day biometric weather report.
                      </CardDescription>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-8 border-primary/30 text-primary hover:bg-primary/10 gap-2"
                        onClick={() =>
                          toast({
                            title: "Neural Sync",
                            description: "Recalibrating heatmap data...",
                          })
                        }
                      >
                        <Zap className="h-3 w-3" />
                        Sync
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-8 border-primary/50 text-primary hover:bg-primary/10 gap-2"
                        onClick={handleExportSynthesis}
                      >
                        <Download className="h-3.5 w-3.5" />
                        Export
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent className="min-w-0 overflow-hidden">
                    <ChartContainer
                      config={chartConfig}
                      className="h-[250px] w-full"
                    >
                      <AreaChart
                        data={chartData}
                        margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
                      >
                        <defs>
                          <linearGradient
                            id="fillScore"
                            x1="0"
                            y1="0"
                            x2="0"
                            y2="1"
                          >
                            <stop
                              offset="5%"
                              stopColor="var(--color-score)"
                              stopOpacity={0.3}
                            />
                            <stop
                              offset="95%"
                              stopColor="var(--color-score)"
                              stopOpacity={0}
                            />
                          </linearGradient>
                        </defs>
                        <CartesianGrid
                          strokeDasharray="3 3"
                          vertical={false}
                          stroke="hsl(var(--border)/0.5)"
                        />
                        <XAxis
                          dataKey="day"
                          axisLine={false}
                          tickLine={false}
                          tick={{ fill: "hsl(var(--muted-foreground))" }}
                          tickMargin={10}
                        />
                        <YAxis
                          axisLine={false}
                          tickLine={false}
                          tick={{ fill: "hsl(var(--muted-foreground))" }}
                          domain={[0, 100]}
                        />
                        <ChartTooltip
                          cursor={{
                            stroke: "hsl(var(--primary)/0.2)",
                            strokeWidth: 2,
                          }}
                          content={
                            <ChartTooltipContent
                              indicator="line"
                              labelFormatter={(value) =>
                                `Daily Synthesis: ${value}`
                              }
                              formatter={(value) => (
                                <div className="flex items-center gap-2">
                                  <div className="h-2 w-2 rounded-full bg-primary animate-pulse" />
                                  <span className="font-bold text-primary">
                                    {value}%
                                  </span>
                                  <span className="text-[10px] text-muted-foreground uppercase tracking-tighter">
                                    {Number(value) >= 90
                                      ? "Peak Flow"
                                      : Number(value) >= 80
                                        ? "Optimal"
                                        : "Recovering"}
                                  </span>
                                </div>
                              )}
                            />
                          }
                        />
                        <Area
                          type="monotone"
                          dataKey="score"
                          stroke="var(--color-score)"
                          strokeWidth={2}
                          fillOpacity={1}
                          fill="url(#fillScore)"
                        />
                      </AreaChart>
                    </ChartContainer>
                  </CardContent>
                </Card>

                <Card className="bg-card/40 border-border/50 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle>Historical Comparison</CardTitle>
                    <CardDescription>
                      Monthly average friction vs. recovery.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="min-w-0 overflow-hidden">
                    <ChartContainer
                      config={historicalChartConfig}
                      className="h-[250px] w-full"
                    >
                      <BarChart
                        data={historicalChartData}
                        margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
                      >
                        <CartesianGrid
                          strokeDasharray="3 3"
                          vertical={false}
                          stroke="hsl(var(--border)/0.5)"
                        />
                        <XAxis
                          dataKey="month"
                          axisLine={false}
                          tickLine={false}
                          tick={{ fill: "hsl(var(--muted-foreground))" }}
                          tickMargin={10}
                        />
                        <YAxis
                          axisLine={false}
                          tickLine={false}
                          tick={{ fill: "hsl(var(--muted-foreground))" }}
                        />
                        <ChartTooltip
                          cursor={{ fill: "hsl(var(--muted)/0.3)" }}
                          content={
                            <ChartTooltipContent
                              indicator="dashed"
                              labelFormatter={(value) =>
                                `Monthly Audit: ${value}`
                              }
                              formatter={(value, name) => (
                                <div className="flex items-center justify-between w-full min-w-[120px] gap-4">
                                  <div className="flex items-center gap-2">
                                    <div
                                      className={cn(
                                        "h-1.5 w-1.5 rounded-full",
                                        name === "recovery"
                                          ? "bg-primary"
                                          : "bg-destructive",
                                      )}
                                    />
                                    <span className="text-muted-foreground capitalize">
                                      {name === "recovery"
                                        ? "Recovery"
                                        : "Friction"}
                                    </span>
                                  </div>
                                  <span
                                    className={cn(
                                      "font-mono font-bold",
                                      name === "recovery"
                                        ? "text-primary"
                                        : "text-destructive",
                                    )}
                                  >
                                    {value}%
                                  </span>
                                </div>
                              )}
                            />
                          }
                        />
                        <ChartLegend content={<ChartLegendContent />} />
                        <Bar
                          dataKey="cognitiveLoad"
                          fill="var(--color-cognitiveLoad)"
                          radius={[4, 4, 0, 0]}
                        />
                        <Bar
                          dataKey="recovery"
                          fill="var(--color-recovery)"
                          radius={[4, 4, 0, 0]}
                        />
                      </BarChart>
                    </ChartContainer>
                  </CardContent>
                </Card>

                <Card className="bg-card/40 border-border/50 backdrop-blur-sm">
                  <CardHeader>
                    <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                      <div className="space-y-1">
                        <CardTitle>Neural Friction Heatmap</CardTitle>
                        <CardDescription>
                          Visualizing cognitive load intensity across the
                          circadian cycle.
                        </CardDescription>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <div className="text-[10px] text-muted-foreground uppercase tracking-wider font-bold">
                            Circadian Alignment
                          </div>
                          <div className="text-2xl font-bold text-primary flex items-center justify-end gap-1">
                            94%{" "}
                            <span className="text-[10px] text-primary/70 font-normal">
                              Optimal
                            </span>
                          </div>
                        </div>
                        <Badge
                          variant="outline"
                          className="bg-destructive/10 text-destructive border-destructive/20 gap-1.5 animate-pulse shrink-0"
                        >
                          <Activity className="w-3 h-3" />
                          Live
                        </Badge>
                        <Button
                          variant="outline"
                          size="sm"
                          className="h-8 border-primary/30 text-primary hover:bg-primary/10 gap-2 shrink-0"
                          onClick={() => {
                            hapticFeedback([30, 20, 30, 20, 50]);
                            toast({
                              title: "Neural Sync",
                              description: "Recalibrating heatmap telemetry...",
                            });
                          }}
                        >
                          <Zap className="h-3 w-3" />
                          Sync
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="overflow-x-auto custom-scrollbar">
                    <div className="space-y-6 min-w-[400px]">
                      <div className="flex items-center justify-between text-[10px] text-muted-foreground uppercase tracking-widest px-1">
                        <span>00:00</span>
                        <span>06:00</span>
                        <span>12:00</span>
                        <span>18:00</span>
                        <span>23:59</span>
                      </div>
                      <div className="grid grid-cols-8 gap-1.5">
                        {Array.from({ length: 56 }).map((_, i) => {
                          const intensity = Math.random();
                          const day = [
                            "Mon",
                            "Tue",
                            "Wed",
                            "Thu",
                            "Fri",
                            "Sat",
                            "Sun",
                          ][Math.floor(i / 8)];
                          const hour = (i % 8) * 3;
                          return (
                            <Tooltip key={i}>
                              <TooltipTrigger asChild>
                                <div
                                  onMouseEnter={() => {
                                    hapticFeedback(
                                      intensity > 0.8 ? [15, 10, 15] : 5,
                                    );
                                    // Spatial 3D Audio: Pan based on column position (-1 to 1)
                                    const col = i % 8;
                                    const pan = (col / 7) * 2 - 1;
                                    playSpatialSync(pan);
                                  }}
                                  className={cn(
                                    "h-8 rounded-sm transition-all hover:scale-110 hover:z-10 cursor-crosshair",
                                    intensity > 0.8
                                      ? "bg-destructive shadow-[0_0_10px_rgba(255,0,0,0.4)]"
                                      : intensity > 0.6
                                        ? "bg-orange-500/80"
                                        : intensity > 0.4
                                          ? "bg-primary/60"
                                          : intensity > 0.2
                                            ? "bg-primary/30"
                                            : "bg-secondary/40",
                                  )}
                                />
                              </TooltipTrigger>
                              <TooltipContent className="bg-card/95 border-border/50 backdrop-blur-md">
                                <div className="space-y-1">
                                  <div className="text-[10px] font-bold text-muted-foreground uppercase">
                                    {day} @ {hour}:00
                                  </div>
                                  <div className="flex items-center gap-2">
                                    <div
                                      className={cn(
                                        "h-2 w-2 rounded-full animate-pulse",
                                        intensity > 0.8
                                          ? "bg-destructive"
                                          : "bg-primary",
                                      )}
                                    />
                                    <span className="text-xs font-mono font-bold">
                                      Friction: {Math.floor(intensity * 100)}%
                                    </span>
                                  </div>
                                  <div className="text-[9px] text-muted-foreground italic">
                                    {intensity > 0.8
                                      ? "Critical Red-lining Detected"
                                      : intensity > 0.5
                                        ? "Elevated Neural Load"
                                        : "Optimal Flow State"}
                                  </div>
                                </div>
                              </TooltipContent>
                            </Tooltip>
                          );
                        })}
                      </div>
                      <div className="flex items-center justify-between pt-2 border-t border-border/20">
                        <div className="flex items-center gap-4">
                          <div className="flex items-center gap-1.5">
                            <div className="h-2 w-2 rounded-full bg-secondary/40" />
                            <span className="text-[9px] text-muted-foreground uppercase">
                              Low
                            </span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <div className="h-2 w-2 rounded-full bg-destructive shadow-[0_0_5px_rgba(255,0,0,0.5)]" />
                            <span className="text-[9px] text-muted-foreground uppercase">
                              Critical
                            </span>
                          </div>
                        </div>
                        <div className="text-[9px] text-muted-foreground italic">
                          * Neural sync latency: 14ms
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-card/40 border-border/50 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle>Recent Neural Audits</CardTitle>
                    <CardDescription>
                      Your latest biometric synchronizations.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {[
                      {
                        date: "Today, 08:00 AM",
                        status: "Optimal",
                        score: 92,
                        color: "text-primary",
                        bg: "bg-primary",
                      },
                      {
                        date: "Yesterday, 07:30 AM",
                        status: "Elevated Friction",
                        score: 74,
                        color: "text-orange-500",
                        bg: "bg-orange-500",
                      },
                      {
                        date: "Oct 24, 08:15 AM",
                        status: "Optimal",
                        score: 88,
                        color: "text-primary",
                        bg: "bg-primary",
                      },
                    ].map((audit, i) => (
                      <div
                        key={i}
                        className="flex items-center justify-between p-4 rounded-lg bg-background/50 border border-border/30"
                      >
                        <div>
                          <div className="font-medium">{audit.date}</div>
                          <div className={`text-sm ${audit.color}`}>
                            {audit.status}
                          </div>
                        </div>
                        <div className="flex items-center gap-4">
                          <div className="text-right hidden sm:block">
                            <div className="text-sm font-medium">
                              Recovery Index
                            </div>
                            <div className="text-xs text-muted-foreground">
                              {audit.score}/100
                            </div>
                          </div>
                          <div className="relative flex h-10 w-10 items-center justify-center rounded-full bg-secondary">
                            <svg className="absolute inset-0 h-full w-full -rotate-90">
                              <circle
                                cx="20"
                                cy="20"
                                r="18"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="4"
                                className="text-secondary"
                              />
                              <circle
                                cx="20"
                                cy="20"
                                r="18"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="4"
                                strokeDasharray="113.097"
                                strokeDashoffset={
                                  113.097 - (113.097 * audit.score) / 100
                                }
                                className={`${audit.color} transition-all duration-1000`}
                              />
                            </svg>
                            <span className="text-xs font-bold">
                              {audit.score}
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="devices" className="space-y-6 mt-6">
                <Card className="bg-card/40 border-border/50 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle>Device Hub</CardTitle>
                    <CardDescription>
                      Connect hardware for continuous biometric telemetry.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {[
                      { name: "Oura Ring", status: "Connected" },
                      { name: "WHOOP", status: "Disconnected" },
                      { name: "Garmin", status: "Disconnected" },
                      { name: "Apple Health", status: "Connected" },
                      { name: "Polar H10", status: "Disconnected" },
                    ].map((device, i) => (
                      <div
                        key={i}
                        className="flex items-center justify-between p-4 rounded-lg bg-background/50 border border-border/30"
                      >
                        <div>
                          <div className="font-bold text-sm">{device.name}</div>
                          <div
                            className={cn(
                              "text-xs font-mono",
                              device.status === "Connected"
                                ? "text-primary"
                                : "text-muted-foreground",
                            )}
                          >
                            {device.status}
                          </div>
                        </div>
                        <Button
                          variant={
                            device.status === "Connected"
                              ? "outline"
                              : "default"
                          }
                          size="sm"
                          className={cn(
                            device.status === "Connected" &&
                              "border-destructive/50 text-destructive hover:bg-destructive/10",
                          )}
                          onClick={() =>
                            toast({
                              title:
                                device.status === "Connected"
                                  ? "Disconnected"
                                  : "Connecting...",
                              description: `${device.name} sync updated.`,
                            })
                          }
                        >
                          {device.status === "Connected"
                            ? "Disconnect"
                            : "Connect"}
                        </Button>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="streak" className="space-y-6 mt-6">
                <Card className="bg-card/40 border-border/50 backdrop-blur-sm">
                  <CardHeader>
                    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                      <div className="space-y-1">
                        <CardTitle className="flex items-center gap-2">
                          <Flame className="h-5 w-5 text-orange-500" />
                          Neural Consistency Calendar
                        </CardTitle>
                        <CardDescription>
                          Visualize your daily calibration history.
                        </CardDescription>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="flex items-center gap-1.5">
                          <div className="h-3 w-3 rounded-full bg-primary" />
                          <span className="text-xs text-muted-foreground">
                            Completed
                          </span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <div className="h-3 w-3 rounded-full bg-destructive/50" />
                          <span className="text-xs text-muted-foreground">
                            Missed
                          </span>
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="flex flex-col items-center">
                    <div className="p-4 bg-background/50 rounded-xl border border-border/30 w-full flex justify-center overflow-x-auto">
                      <Calendar
                        mode="multiple"
                        selected={completedDays}
                        modifiers={{
                          completed: completedDays,
                          missed: missedDays,
                        }}
                        modifiersClassNames={{
                          completed:
                            "bg-primary text-primary-foreground font-bold hover:bg-primary/80",
                          missed:
                            "bg-destructive/30 text-destructive-foreground line-through hover:bg-destructive/40",
                        }}
                        className="rounded-md border-none"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 w-full mt-6">
                      <Card className="bg-background/40 border-border/30">
                        <CardHeader className="p-4 pb-2">
                          <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                            <Trophy className="h-4 w-4 text-primary" />
                            Current Momentum
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="p-4 pt-0">
                          <div className="text-2xl font-bold text-primary">
                            {dailyStreak} Days
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">
                            Keep it up to reach your 30-day milestone!
                          </p>
                        </CardContent>
                      </Card>
                      <Card className="bg-background/40 border-border/30">
                        <CardHeader className="p-4 pb-2">
                          <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                            <CalendarIcon className="h-4 w-4 text-primary" />
                            Monthly Adherence
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="p-4 pt-0">
                          <div className="text-2xl font-bold">84%</div>
                          <Progress value={84} className="h-1.5 mt-2" />
                        </CardContent>
                      </Card>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="companion" className="space-y-6 mt-6">
                <Card className="bg-card/40 border-border/50 backdrop-blur-sm overflow-hidden relative">
                  <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary/5 via-transparent to-transparent pointer-events-none" />
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Sparkles className="h-5 w-5 text-primary" />
                      Neural Companion
                    </CardTitle>
                    <CardDescription>
                      Your biometric resonance manifested as a digital entity.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="flex flex-col items-center justify-center py-16 relative">
                    <div className="relative flex items-center justify-center h-48 w-48 mb-8">
                      <div
                        className={cn(
                          "absolute transition-all duration-1000",
                          petState.class,
                        )}
                      />
                      {petState.level >= 3 && (
                        <div className="absolute w-full h-full border border-primary/20 rounded-full animate-[spin_10s_linear_infinite]" />
                      )}
                      {petState.level >= 4 && (
                        <div className="absolute w-full h-full border border-primary/40 rounded-full animate-[spin_7s_linear_infinite_reverse] scale-110" />
                      )}
                      <Hexagon
                        className={cn(
                          "h-8 w-8 text-primary absolute z-10",
                          petState.level >= 2 ? "animate-pulse" : "opacity-50",
                        )}
                      />
                    </div>

                    <div className="text-center space-y-2 relative z-10">
                      <Badge
                        variant="outline"
                        className="bg-primary/10 text-primary border-primary/20 mb-2"
                      >
                        Level {petState.level} Entity
                      </Badge>
                      <h3 className="text-2xl font-bold text-foreground">
                        {petState.name}
                      </h3>
                      <p className="text-muted-foreground max-w-md mx-auto mb-6">
                        {petState.desc}
                      </p>
                      <div className="flex flex-col sm:flex-row gap-3 w-full max-w-md justify-center">
                        <Button
                          onClick={handleStartAR}
                          className="flex-1 gap-2 bg-primary/20 text-primary border border-primary/30 hover:bg-primary/30 animate-pulse"
                        >
                          <Eye className="w-4 h-4" />
                          AR CALIBRATION
                        </Button>
                        <Button
                          onClick={() => {
                            setIsMultiUserAR(!isMultiUserAR);
                            hapticFeedback([20, 10, 20]);
                            toast({
                              title: isMultiUserAR
                                ? "Multi-User Sync Disabled"
                                : "Multi-User Sync Enabled",
                              description: isMultiUserAR
                                ? "Disconnecting from nearby optimizers."
                                : "Scanning for nearby neural signatures...",
                            });
                            if (!isARMode) handleStartAR();
                          }}
                          variant="outline"
                          className={cn(
                            "flex-1 gap-2 border-primary/30",
                            isMultiUserAR
                              ? "bg-primary/20 text-primary animate-glow-cyan"
                              : "text-muted-foreground",
                          )}
                        >
                          <Swords className="w-4 h-4" />
                          MULTI-USER AR
                        </Button>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 w-full max-w-md mt-12">
                      <div className="bg-background/50 border border-border/30 rounded-lg p-4 text-center">
                        <div className="text-[10px] text-muted-foreground uppercase tracking-widest mb-1">
                          Resonance
                        </div>
                        <div className="text-xl font-bold text-primary">
                          {Math.min(100, dailyStreak * 5)}%
                        </div>
                      </div>
                      <div className="bg-background/50 border border-border/30 rounded-lg p-4 text-center">
                        <div className="text-[10px] text-muted-foreground uppercase tracking-widest mb-1">
                          Next Evolution
                        </div>
                        <div className="text-xl font-bold text-foreground">
                          {petState.level === 4
                            ? "MAX"
                            : `${petState.nextAt - dailyStreak} Days`}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="duels" className="space-y-6 mt-6">
                <Card className="bg-card/40 border-border/50 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Swords className="h-5 w-5 text-primary" />
                      Active Neural Duels
                    </CardTitle>
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 w-full">
                      <CardDescription>
                        Real-time performance battles with your network.
                      </CardDescription>
                      <Dialog
                        open={isDuelDialogOpen}
                        onOpenChange={setIsDuelDialogOpen}
                      >
                        <DialogTrigger asChild>
                          <Button size="sm" className="gap-2 shrink-0">
                            <Plus className="h-4 w-4" />
                            Challenge
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="sm:max-w-[425px] bg-card/95 border-border/50 backdrop-blur-md">
                          <DialogHeader>
                            <DialogTitle>Initiate Neural Duel</DialogTitle>
                            <DialogDescription>
                              Challenge a Sovereign Optimizer from your network.
                            </DialogDescription>
                          </DialogHeader>
                          <div className="grid gap-4 py-4">
                            <div className="space-y-2">
                              <Label>Opponent</Label>
                              <Select defaultValue="sarah">
                                <SelectTrigger>
                                  <SelectValue placeholder="Select opponent" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="sarah">
                                    Sarah_Opt
                                  </SelectItem>
                                  <SelectItem value="david">
                                    David_Neural
                                  </SelectItem>
                                  <SelectItem value="elena">
                                    Elena_Bio
                                  </SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                            <div className="space-y-2">
                              <Label>Metric</Label>
                              <Select defaultValue="recovery">
                                <SelectTrigger>
                                  <SelectValue placeholder="Select metric" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="recovery">
                                    Highest Recovery Index
                                  </SelectItem>
                                  <SelectItem value="cognitive">
                                    Lowest Cognitive Load
                                  </SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                            <div className="space-y-2">
                              <Label>Wager (PTS)</Label>
                              <Input
                                type="number"
                                value={newDuelWager}
                                onChange={(e) =>
                                  setNewDuelWager(e.target.value)
                                }
                                className="bg-background/50"
                                min="10"
                                max={neuralPoints}
                              />
                              <p className="text-xs text-muted-foreground">
                                Available balance: {neuralPoints} PTS
                              </p>
                            </div>
                          </div>
                          <DialogFooter>
                            <Button
                              onClick={handleCreateDuel}
                              className="w-full"
                            >
                              Send Challenge
                            </Button>
                          </DialogFooter>
                        </DialogContent>
                      </Dialog>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {[
                      {
                        id: 1,
                        opponent: "Sarah_Opt",
                        metric: "Recovery Index",
                        status: "active",
                        time: "2h remaining",
                        score: "88.2 vs 89.5",
                      },
                      {
                        id: 2,
                        opponent: "David_Neural",
                        metric: "Cognitive Load",
                        status: "pending",
                        time: "Waiting for acceptance",
                        score: "-- vs --",
                      },
                    ].map((duel) => (
                      <div
                        key={duel.id}
                        className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-lg bg-background/50 border border-border/30"
                      >
                        <div className="flex items-center gap-4">
                          <div className="relative">
                            <Avatar className="h-10 w-10 border border-border">
                              <AvatarImage
                                src={`https://api.dicebear.com/7.x/bottts/svg?seed=${duel.opponent}&colors=00cccc`}
                              />
                              <AvatarFallback>
                                <User className="w-5 h-5" />
                              </AvatarFallback>
                            </Avatar>
                            <div
                              className={cn(
                                "absolute -top-1 -right-1 w-3 h-3 rounded-full border-2 border-background",
                                duel.status === "active"
                                  ? "bg-primary animate-pulse"
                                  : "bg-yellow-500",
                              )}
                            />
                          </div>
                          <div>
                            <div className="font-medium">
                              vs. {duel.opponent}
                            </div>
                            <div className="text-xs text-muted-foreground">
                              {duel.metric} Duel
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center justify-between sm:justify-end gap-6 pl-14 sm:pl-0">
                          <div className="text-right">
                            <div className="text-xs font-mono text-primary font-bold">
                              {duel.score}
                            </div>
                            <div className="text-[10px] text-muted-foreground flex items-center justify-end gap-1">
                              <Clock className="h-2.5 w-2.5" />
                              {duel.time}
                            </div>
                          </div>
                          {duel.status === "active" ? (
                            <div className="flex items-center gap-2">
                              <Button
                                variant="outline"
                                size="sm"
                                className="h-8 border-primary/50 text-primary hover:bg-primary/10 gap-1 px-3"
                                onClick={() => setChatDuelId(duel.id)}
                              >
                                <MessageSquare className="h-3 w-3" />
                                <span className="text-[10px] font-bold uppercase tracking-wider">
                                  Chat
                                </span>
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                className="h-8 border-primary/50 text-primary hover:bg-primary/10 gap-1 px-3"
                                onClick={() => navigate("/leaderboard")}
                              >
                                <Eye className="h-3 w-3 animate-pulse" />
                                <span className="text-[10px] font-bold uppercase tracking-wider">
                                  Spectate
                                </span>
                              </Button>
                            </div>
                          ) : (
                            <Badge
                              variant="secondary"
                              className="uppercase text-[10px]"
                            >
                              {duel.status}
                            </Badge>
                          )}
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>

                {incomingDuels.length > 0 && (
                  <Card className="bg-card/40 border-border/50 backdrop-blur-sm shadow-[0_0_15px_rgba(0,200,200,0.1)]">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Inbox className="h-5 w-5 text-primary" />
                        Incoming Challenges
                        <Badge
                          variant="default"
                          className="ml-2 bg-primary text-primary-foreground"
                        >
                          {incomingDuels.length} New
                        </Badge>
                      </CardTitle>
                      <CardDescription>
                        Sovereign Optimizers have challenged your neural
                        supremacy.
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {incomingDuels.map((duel) => (
                        <div
                          key={duel.id}
                          className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-lg bg-background/50 border border-primary/30 relative overflow-hidden group"
                        >
                          <div className="absolute inset-0 bg-gradient-to-r from-primary/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                          <div className="flex items-center gap-4 relative z-10">
                            <Avatar className="h-10 w-10 border border-primary/50 shadow-[0_0_10px_rgba(0,200,200,0.2)]">
                              <AvatarImage
                                src={`https://api.dicebear.com/7.x/bottts/svg?seed=${duel.challenger}&colors=00cccc`}
                              />
                              <AvatarFallback>
                                <User className="w-5 h-5" />
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <div className="font-medium flex items-center gap-2">
                                {duel.challenger}
                                <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                                  <Clock className="h-2.5 w-2.5" />
                                  {duel.time}
                                </span>
                              </div>
                              <div className="text-xs text-muted-foreground">
                                Challenge:{" "}
                                <span className="text-foreground font-medium">
                                  {duel.metric}
                                </span>
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center justify-between sm:justify-end gap-6 pl-14 sm:pl-0 relative z-10">
                            <div className="text-right">
                              <div className="text-xs text-muted-foreground uppercase tracking-wider">
                                Wager
                              </div>
                              <div className="text-sm font-mono text-primary font-bold">
                                {duel.wager} PTS
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <Button
                                variant="outline"
                                size="icon"
                                className="h-8 w-8 border-destructive/50 text-destructive hover:bg-destructive/10"
                                onClick={() => handleDeclineDuel(duel.id)}
                              >
                                <X className="h-4 w-4" />
                              </Button>
                              <Button
                                size="sm"
                                className="h-8 gap-1 px-3 bg-primary text-primary-foreground hover:bg-primary/90 shadow-[0_0_10px_rgba(0,200,200,0.3)]"
                                onClick={() =>
                                  handleAcceptDuel(duel.id, duel.wager)
                                }
                              >
                                <Check className="h-4 w-4" />
                                <span className="text-[10px] font-bold uppercase tracking-wider">
                                  Accept
                                </span>
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                )}

                <Card className="bg-card/40 border-border/50 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Trophy className="h-5 w-5 text-yellow-400" />
                      Duel History
                    </CardTitle>
                    <CardDescription>
                      Your past biometric victories and defeats.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {[
                      {
                        id: 3,
                        opponent: "Elena_Bio",
                        status: "won",
                        date: "Oct 22, 2023",
                        points: "+150",
                        wager: 100,
                      },
                      {
                        id: 4,
                        opponent: "Mike_Flow",
                        status: "lost",
                        date: "Oct 20, 2023",
                        points: "-50",
                        wager: 50,
                      },
                    ].map((history) => (
                      <div
                        key={history.id}
                        className="flex items-center justify-between p-4 rounded-lg bg-background/30 border border-border/20"
                      >
                        <div className="flex items-center gap-3">
                          <div
                            className={cn(
                              "p-2 rounded-full",
                              history.status === "won"
                                ? "bg-green-500/10 text-green-500"
                                : "bg-destructive/10 text-destructive",
                            )}
                          >
                            {history.status === "won" ? (
                              <Trophy className="h-4 w-4" />
                            ) : (
                              <Shield className="h-4 w-4" />
                            )}
                          </div>
                          <div>
                            <div className="text-sm font-medium">
                              Duel with {history.opponent}
                            </div>
                            <div className="text-xs text-muted-foreground">
                              {history.date}
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div
                            className={cn(
                              "font-bold text-sm",
                              history.status === "won"
                                ? "text-green-500"
                                : "text-destructive",
                            )}
                          >
                            {history.status === "won" ? "VICTORY" : "DEFEAT"}
                          </div>
                          <div className="text-xs font-mono">
                            {history.points} XP
                          </div>
                          <div className="text-[10px] text-muted-foreground font-mono">
                            Wager: {history.wager} PTS
                          </div>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="shop" className="space-y-6 mt-6">
                <Card className="bg-card/40 border-border/50 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <ShoppingCart className="h-5 w-5 text-primary" />
                      Neural Shop
                    </CardTitle>
                    <CardDescription>
                      Spend your Neural Points on profile customizations.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-8">
                    <div>
                      <h3 className="text-lg font-semibold mb-4">
                        Consumables
                      </h3>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
                        <div className="p-4 rounded-lg bg-background/50 border border-blue-500/20 flex flex-col items-center text-center gap-3">
                          <div className="w-12 h-12 rounded-full bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
                            <Shield className="h-6 w-6" />
                          </div>
                          <div>
                            <div className="font-medium text-sm">
                              Streak Freeze
                            </div>
                            <div className="text-xs text-muted-foreground font-mono">
                              1500 PTS
                            </div>
                          </div>
                          <Button
                            variant="outline"
                            size="sm"
                            className="w-full text-xs border-blue-500/50 text-blue-400 hover:bg-blue-500/10"
                            onClick={() =>
                              handlePurchase(
                                "Streak Freeze",
                                1500,
                                undefined,
                                true,
                              )
                            }
                          >
                            Purchase
                          </Button>
                        </div>
                        <div className="p-4 rounded-lg bg-background/50 border border-primary/20 flex flex-col items-center text-center gap-3 shadow-[0_0_15px_rgba(0,255,255,0.05)]">
                          <div className="w-12 h-12 rounded-full bg-primary/10 border border-primary/30 flex items-center justify-center text-primary shadow-[0_0_10px_rgba(0,255,255,0.2)]">
                            <ShieldCheck className="h-6 w-6" />
                          </div>
                          <div>
                            <div className="font-medium text-sm">
                              Streak Shield
                            </div>
                            <div className="text-xs text-muted-foreground font-mono">
                              3000 PTS
                            </div>
                          </div>
                          <Button
                            variant="outline"
                            size="sm"
                            className="w-full text-xs border-primary/50 text-primary hover:bg-primary/10"
                            onClick={() =>
                              handlePurchase(
                                "Streak Shield",
                                3000,
                                undefined,
                                true,
                              )
                            }
                          >
                            Purchase
                          </Button>
                        </div>
                      </div>

                      <h3 className="text-lg font-semibold mb-4">
                        Avatar Glows
                      </h3>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                        {[
                          {
                            id: "cyan",
                            name: "Cyan Pulse",
                            price: 500,
                            style: "animate-glow-cyan",
                            color: "bg-cyan-500",
                          },
                          {
                            id: "magenta",
                            name: "Magenta Surge",
                            price: 1000,
                            style: "animate-glow-magenta",
                            color: "bg-fuchsia-500",
                          },
                          {
                            id: "gold",
                            name: "Sovereign Gold",
                            price: 2500,
                            style: "animate-glow-gold",
                            color: "bg-yellow-500",
                          },
                        ].map((item) => (
                          <div
                            key={item.id}
                            className="p-4 rounded-lg bg-background/50 border border-border/30 flex flex-col items-center text-center gap-3"
                          >
                            <div
                              className={`w-12 h-12 rounded-full border-2 border-background ${item.color} ${item.style}`}
                            ></div>
                            <div>
                              <div className="font-medium text-sm">
                                {item.name}
                              </div>
                              <div className="text-xs text-muted-foreground font-mono">
                                {item.price} PTS
                              </div>
                            </div>
                            <div className="flex gap-2 w-full mt-2">
                              <Button
                                variant="ghost"
                                size="sm"
                                className="flex-1 text-xs border border-muted hover:bg-muted"
                                onClick={() =>
                                  setPreviewItem({
                                    type: "glow",
                                    style: item.style,
                                    name: item.name,
                                    color: item.color,
                                  })
                                }
                              >
                                <Eye className="w-3 h-3 mr-1" /> Preview
                              </Button>
                              <Button
                                variant={
                                  avatarGlow === item.style
                                    ? "secondary"
                                    : "outline"
                                }
                                size="sm"
                                className="flex-1 text-xs border-primary/50 text-primary hover:bg-primary/10"
                                disabled={avatarGlow === item.style}
                                onClick={() =>
                                  handlePurchase(
                                    item.name,
                                    item.price,
                                    item.style,
                                  )
                                }
                              >
                                {avatarGlow === item.style ? "Equipped" : "Buy"}
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h3 className="text-lg font-semibold mb-4">
                        Profile Themes
                      </h3>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        {[
                          {
                            id: "dark_matter",
                            name: "Dark Matter",
                            price: 5000,
                            desc: "Deep void aesthetics with subtle particle effects.",
                          },
                          {
                            id: "cyber_flow",
                            name: "Cyber Flow",
                            price: 7500,
                            desc: "High-contrast neon accents and grid patterns.",
                          },
                        ].map((item) => (
                          <div
                            key={item.id}
                            className="p-4 rounded-lg bg-background/50 border border-border/30 flex flex-col items-start gap-3"
                          >
                            <div className="w-full h-16 rounded-md bg-gradient-to-r from-background to-secondary border border-border/50"></div>
                            <div className="w-full flex justify-between items-start">
                              <div>
                                <div className="font-medium text-sm">
                                  {item.name}
                                </div>
                                <div className="text-xs text-muted-foreground">
                                  {item.desc}
                                </div>
                              </div>
                              <div className="text-xs text-primary font-mono font-bold whitespace-nowrap">
                                {item.price} PTS
                              </div>
                            </div>
                            <div className="flex gap-2 w-full mt-2">
                              <Button
                                variant="ghost"
                                size="sm"
                                className="flex-1 text-xs border border-muted hover:bg-muted"
                                onClick={() =>
                                  setPreviewItem({
                                    type: "theme",
                                    style: item.id,
                                    name: item.name,
                                  })
                                }
                              >
                                <Eye className="w-3 h-3 mr-1" /> Preview
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                className="flex-1 text-xs border-primary/50 text-primary hover:bg-primary/10"
                                onClick={() =>
                                  toast({
                                    title: "Coming Soon",
                                    description:
                                      "Profile themes will be unlocked in the next update.",
                                  })
                                }
                              >
                                Unlock
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                        <Flame className="h-4 w-4 text-orange-500" />
                        Streak Rewards
                      </h3>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        {[
                          {
                            id: "bronze_aura",
                            name: "Bronze Aura",
                            streak: 7,
                            style: "animate-glow",
                            desc: "A subtle warmth for early consistency.",
                            color: "bg-orange-700",
                          },
                          {
                            id: "silver_surge",
                            name: "Silver Surge",
                            streak: 14,
                            style: "animate-glow-cyan",
                            desc: "Radiate clinical precision.",
                            color: "bg-slate-400",
                          },
                          {
                            id: "neural_halo",
                            name: "Neural Halo",
                            streak: 30,
                            style: "animate-glow-gold",
                            desc: "The mark of a Sovereign Optimizer.",
                            color: "bg-yellow-500",
                          },
                          {
                            id: "void_walker",
                            name: "Void Walker",
                            streak: 50,
                            style: "animate-glow-magenta",
                            desc: "Master of the deep flow state.",
                            color: "bg-purple-600",
                          },
                          {
                            id: "sector_sync",
                            name: "Neural Sync: Sector Master",
                            achievementId: 6,
                            style:
                              "animate-glow-cyan shadow-[0_0_20px_rgba(0,255,255,0.5)]",
                            desc: "Radiate the energy of a synchronized global sector.",
                            color: "bg-primary",
                          },
                        ].map((reward) => {
                          const isUnlocked = reward.streak
                            ? dailyStreak >= reward.streak
                            : challenges.find(
                                (c) => c.id === reward.achievementId,
                              )?.completed;
                          const isEquipped = avatarGlow === reward.style;

                          return (
                            <div
                              key={reward.id}
                              className={cn(
                                "p-4 rounded-lg bg-background/50 border transition-all flex flex-col gap-3",
                                isUnlocked
                                  ? "border-border/50"
                                  : "border-destructive/20 opacity-60 grayscale",
                              )}
                            >
                              <div className="flex items-center gap-3">
                                <div
                                  className={cn(
                                    "w-10 h-10 rounded-full border border-background",
                                    reward.color,
                                    isUnlocked && reward.style,
                                  )}
                                ></div>
                                <div className="flex-1">
                                  <div className="font-medium text-sm flex items-center justify-between">
                                    {reward.name}
                                    {!isUnlocked && (
                                      <Badge
                                        variant="destructive"
                                        className="text-[10px] h-4 px-1"
                                      >
                                        {reward.streak}D STREAK
                                      </Badge>
                                    )}
                                  </div>
                                  <div className="text-[10px] text-muted-foreground">
                                    {reward.desc}
                                  </div>
                                </div>
                              </div>
                              <div className="flex gap-2 w-full mt-2">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="flex-1 text-xs border border-muted hover:bg-muted"
                                  onClick={() =>
                                    setPreviewItem({
                                      type: "glow",
                                      style: reward.style,
                                      name: reward.name,
                                      color: reward.color,
                                    })
                                  }
                                >
                                  <Eye className="w-3 h-3 mr-1" /> Preview
                                </Button>
                                <Button
                                  variant={isEquipped ? "secondary" : "outline"}
                                  size="sm"
                                  className="flex-1 text-xs"
                                  disabled={!isUnlocked || isEquipped}
                                  onClick={() => {
                                    hapticFeedback([50, 30, 50]);
                                    setAvatarGlow(reward.style);
                                    localStorage.setItem(
                                      "avatar_glow",
                                      reward.style,
                                    );
                                    toast({
                                      title: "Reward Equipped",
                                      description: `You are now radiating ${reward.name}.`,
                                    });
                                  }}
                                >
                                  {isUnlocked
                                    ? isEquipped
                                      ? "Equipped"
                                      : "Equip"
                                    : `${reward.streak}D`}
                                </Button>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="vault" className="space-y-6 mt-6">
                <Card className="bg-card/40 border-primary/50 backdrop-blur-sm relative overflow-hidden group">
                  <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary/10 via-transparent to-transparent pointer-events-none animate-pulse" />
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <ShieldCheck className="h-5 w-5 text-primary" />
                      Biometric Data Vault
                    </CardTitle>
                    <CardDescription>
                      Military-grade AES-256 encryption for your neural
                      telemetry.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6 relative z-10">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="p-4 rounded-lg bg-background/50 border border-primary/30 flex items-center gap-4">
                        <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center text-primary">
                          <Shield className="h-5 w-5" />
                        </div>
                        <div>
                          <div className="font-bold text-sm">
                            End-to-End Encryption
                          </div>
                          <div className="text-xs text-muted-foreground">
                            Active (AES-256 GCM)
                          </div>
                        </div>
                      </div>
                      <div className="p-4 rounded-lg bg-background/50 border border-primary/30 flex items-center gap-4">
                        <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center text-primary">
                          <Activity className="h-5 w-5" />
                        </div>
                        <div>
                          <div className="font-bold text-sm">
                            Zero-Knowledge Proof
                          </div>
                          <div className="text-xs text-muted-foreground">
                            Telemetry isolated.
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-4 pt-4 border-t border-border/50">
                      <h3 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">
                        Vault Operations
                      </h3>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <Button
                          variant="outline"
                          className="h-auto py-3 flex flex-col gap-2 border-primary/30 hover:bg-primary/10"
                        >
                          <Download className="h-5 w-5 text-primary" />
                          <span className="text-xs">
                            Export Encrypted Backup
                          </span>
                        </Button>
                        <Button
                          variant="outline"
                          className="h-auto py-3 flex flex-col gap-2 border-primary/30 hover:bg-primary/10"
                        >
                          <RotateCcw className="h-5 w-5 text-primary" />
                          <span className="text-xs">
                            Rotate Encryption Keys
                          </span>
                        </Button>
                        <Button
                          variant="outline"
                          className="h-auto py-3 flex flex-col gap-2 border-destructive/50 hover:bg-destructive/10 text-destructive"
                        >
                          <X className="h-5 w-5" />
                          <span className="text-xs">Purge Neural Records</span>
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="simulator" className="space-y-6 mt-6">
                <Card className="bg-card/40 border-border/50 backdrop-blur-sm relative overflow-hidden group">
                  <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-fuchsia-500/5 via-transparent to-transparent pointer-events-none" />
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <BrainCircuit className="h-5 w-5 text-fuchsia-500" />
                      Neural Sandbox Simulator
                    </CardTitle>
                    <CardDescription>
                      Predict biometric outcomes by simulating physiological
                      stress variables.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-8 relative z-10">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div className="space-y-6">
                        <div className="space-y-4">
                          <div className="flex justify-between items-center">
                            <Label className="text-sm font-semibold">
                              Simulated Sleep Depth
                            </Label>
                            <span className="text-primary font-mono text-xs">
                              8.5 hrs
                            </span>
                          </div>
                          <Slider
                            defaultValue={[85]}
                            max={100}
                            step={1}
                            className="[&_[role=slider]]:bg-primary"
                          />
                        </div>
                        <div className="space-y-4">
                          <div className="flex justify-between items-center">
                            <Label className="text-sm font-semibold">
                              CNS Load (Workout Intensity)
                            </Label>
                            <span className="text-orange-500 font-mono text-xs">
                              High (80%)
                            </span>
                          </div>
                          <Slider
                            defaultValue={[80]}
                            max={100}
                            step={1}
                            className="[&_[role=slider]]:bg-orange-500"
                          />
                        </div>
                        <div className="space-y-4">
                          <div className="flex justify-between items-center">
                            <Label className="text-sm font-semibold">
                              Caffeine Intake (mg)
                            </Label>
                            <span className="text-yellow-500 font-mono text-xs">
                              200 mg
                            </span>
                          </div>
                          <Slider
                            defaultValue={[40]}
                            max={100}
                            step={1}
                            className="[&_[role=slider]]:bg-yellow-500"
                          />
                        </div>
                      </div>

                      <div className="flex flex-col items-center justify-center p-6 bg-background/50 border border-border/30 rounded-xl relative overflow-hidden">
                        <div className="absolute inset-0 bg-gradient-to-br from-fuchsia-500/10 to-transparent pointer-events-none" />
                        <h3 className="text-xs uppercase tracking-widest text-muted-foreground mb-6">
                          Predicted Outcome
                        </h3>

                        <div className="relative flex h-32 w-32 items-center justify-center rounded-full mb-6">
                          <div className="absolute inset-0 rounded-full border-4 border-fuchsia-500/20" />
                          <div
                            className="absolute inset-0 rounded-full border-4 border-fuchsia-500 border-t-transparent animate-spin"
                            style={{ animationDuration: "3s" }}
                          />
                          <div className="text-center">
                            <div className="text-3xl font-bold text-fuchsia-500">
                              72<span className="text-lg">%</span>
                            </div>
                            <div className="text-[10px] uppercase tracking-widest text-muted-foreground mt-1">
                              Recovery
                            </div>
                          </div>
                        </div>

                        <div className="w-full space-y-3">
                          <div className="flex justify-between items-center text-xs">
                            <span className="text-muted-foreground">
                              HRV Prediction
                            </span>
                            <span className="font-mono font-bold text-white">
                              45 ms
                            </span>
                          </div>
                          <div className="flex justify-between items-center text-xs">
                            <span className="text-muted-foreground">
                              Resting HR
                            </span>
                            <span className="font-mono font-bold text-white">
                              68 BPM
                            </span>
                          </div>
                          <div className="flex justify-between items-center text-xs">
                            <span className="text-muted-foreground">
                              Readiness State
                            </span>
                            <span className="font-mono font-bold text-orange-400">
                              Elevated Friction
                            </span>
                          </div>
                        </div>

                        <Button
                          className="w-full mt-6 bg-fuchsia-500/20 text-fuchsia-400 hover:bg-fuchsia-500/30 border border-fuchsia-500/50"
                          onClick={() => {
                            hapticFeedback([50, 50, 100]);
                            toast({
                              title: "Simulation Complete",
                              description:
                                "Predicted variables logged to temporary memory.",
                            });
                          }}
                        >
                          Run Simulation
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="goals" className="space-y-6 mt-6">
                <Card className="bg-card/40 border-border/50 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Target className="h-5 w-5 text-primary" />
                      Calibration Targets
                    </CardTitle>
                    <CardDescription>
                      Set your baseline thresholds for optimal performance.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-8">
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <Label className="text-base font-semibold">
                          Maximum Cognitive Load
                        </Label>
                        <span className="text-destructive font-bold">
                          {cognitiveTarget[0]}%
                        </span>
                      </div>
                      <Slider
                        defaultValue={[60]}
                        max={100}
                        step={1}
                        value={cognitiveTarget}
                        onValueChange={setCognitiveTarget}
                        className="[&_[role=slider]]:bg-destructive"
                      />
                      <p className="text-sm text-muted-foreground">
                        Alert me if my cognitive load exceeds this threshold.
                      </p>
                    </div>

                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <Label className="text-base font-semibold">
                          Minimum Recovery Index
                        </Label>
                        <span className="text-primary font-bold">
                          {recoveryTarget[0]}%
                        </span>
                      </div>
                      <Slider
                        defaultValue={[85]}
                        max={100}
                        step={1}
                        value={recoveryTarget}
                        onValueChange={setRecoveryTarget}
                      />
                      <p className="text-sm text-muted-foreground">
                        Target baseline for daily recovery score.
                      </p>
                    </div>

                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <Label className="text-base font-semibold">
                          Weekly Audits
                        </Label>
                        <span className="text-foreground font-bold">
                          {weeklyAuditsTarget} / 7
                        </span>
                      </div>
                      <Input
                        type="number"
                        min="1"
                        max="7"
                        value={weeklyAuditsTarget}
                        onChange={(e) => setWeeklyAuditsTarget(e.target.value)}
                        className="bg-background/50 max-w-[100px]"
                      />
                      <p className="text-sm text-muted-foreground">
                        Target number of neural audits to complete per week.
                      </p>
                    </div>

                    <Button
                      onClick={handleSaveGoals}
                      className="w-full sm:w-auto"
                    >
                      Synchronize Targets
                    </Button>
                  </CardContent>
                </Card>

                <Card className="bg-card/40 border-border/50 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle>Current Trajectory</CardTitle>
                    <CardDescription>
                      Your performance against established goals.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm font-medium">
                        <span>Cognitive Load (Avg)</span>
                        <span className="text-muted-foreground">
                          Current: 68% / Target: &lt;{cognitiveTarget[0]}%
                        </span>
                      </div>
                      <div className="h-2 w-full bg-secondary rounded-full overflow-hidden">
                        <div className="h-full bg-destructive w-[68%] rounded-full shadow-[0_0_10px_rgba(255,0,0,0.5)]" />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between text-sm font-medium">
                        <span>Recovery Index (Avg)</span>
                        <span className="text-muted-foreground">
                          Current: 82% / Target: &gt;{recoveryTarget[0]}%
                        </span>
                      </div>
                      <div className="h-2 w-full bg-secondary rounded-full overflow-hidden">
                        <div className="h-full bg-primary w-[82%] rounded-full shadow-[0_0_10px_rgba(0,200,200,0.5)]" />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between text-sm font-medium">
                        <span>Weekly Audits</span>
                        <span className="text-muted-foreground">
                          Current: 4 / Target: {weeklyAuditsTarget}
                        </span>
                      </div>
                      <Progress
                        value={(4 / parseInt(weeklyAuditsTarget || "1")) * 100}
                        className="h-2"
                      />
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="challenges" className="space-y-6 mt-6">
                <Card className="bg-card/40 border-border/50 backdrop-blur-sm">
                  <CardHeader className="flex flex-row items-start sm:items-center justify-between gap-4 pb-4">
                    <div className="space-y-1">
                      <CardTitle className="flex items-center gap-2">
                        <Zap className="h-5 w-5 text-yellow-400" />
                        Daily Calibration Challenges
                      </CardTitle>
                      <CardDescription>
                        Complete these tasks to earn bonus points and boost your
                        global ranking.
                      </CardDescription>
                    </div>
                    {challenges.filter((c) => c.completed && !c.claimed)
                      .length > 1 && (
                      <Button
                        size="sm"
                        onClick={handleClaimAll}
                        className="shrink-0 bg-primary text-primary-foreground hover:bg-primary/90 shadow-[0_0_15px_rgba(0,255,255,0.3)] animate-pulse hover:animate-none gap-2"
                      >
                        <Zap className="h-4 w-4" />
                        Claim All
                      </Button>
                    )}
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {challenges.map((challenge) => (
                      <div
                        key={challenge.id}
                        className={cn(
                          "flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-lg bg-background/50 border border-border/30 transition-all hover:border-primary/50",
                          challenge.isAchievement &&
                            "border-primary/30 bg-primary/5 shadow-[0_0_15px_rgba(0,255,255,0.05)]",
                          challenge.completed &&
                            !challenge.claimed &&
                            "border-yellow-400/50 shadow-[0_0_15px_rgba(250,204,21,0.1)]",
                        )}
                      >
                        <div className="flex items-start gap-4">
                          <div
                            className={cn(
                              "mt-1 shrink-0 h-5 w-5 rounded-full border-2 flex items-center justify-center",
                              challenge.completed
                                ? "border-primary bg-primary/20"
                                : "border-muted-foreground",
                            )}
                          >
                            {challenge.completed && (
                              <Check className="h-3 w-3 text-primary" />
                            )}
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <div className="font-medium text-base">
                                {challenge.title}
                              </div>
                              {challenge.isAchievement && (
                                <Badge
                                  variant="outline"
                                  className="bg-primary/10 text-primary border-primary/20 text-[8px] h-4 px-1 uppercase tracking-widest font-bold"
                                >
                                  Achievement
                                </Badge>
                              )}
                            </div>
                            <div className="text-sm text-muted-foreground">
                              {challenge.description}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center sm:flex-col sm:items-end justify-between gap-2 pl-9 sm:pl-0">
                          <Badge
                            variant={
                              challenge.completed ? "default" : "secondary"
                            }
                            className="font-mono gap-1 shrink-0"
                          >
                            +{challenge.points} PTS
                          </Badge>
                          {!challenge.completed ? (
                            <Button
                              variant="outline"
                              size="sm"
                              className="h-7 text-xs border-primary/50 text-primary hover:bg-primary/10 shrink-0"
                              onClick={() =>
                                challenge.path ? navigate(challenge.path) : null
                              }
                            >
                              Start
                            </Button>
                          ) : !challenge.claimed ? (
                            <Button
                              size="sm"
                              className="h-7 text-xs bg-yellow-400 text-yellow-950 hover:bg-yellow-500 shrink-0 animate-pulse hover:animate-none"
                              onClick={() =>
                                handleClaimPoints(
                                  challenge.id,
                                  challenge.points,
                                )
                              }
                            >
                              Claim
                            </Button>
                          ) : (
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-7 text-xs text-muted-foreground hover:text-primary shrink-0 gap-1"
                              onClick={() =>
                                handleShareChallenge(challenge.title)
                              }
                            >
                              <Share2 className="h-3 w-3" />
                              Share
                            </Button>
                          )}
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="history" className="space-y-6 mt-6">
                <Card className="bg-card/40 border-border/50 backdrop-blur-sm">
                  <CardHeader className="flex flex-row items-start sm:items-center justify-between gap-4">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        <Activity className="h-5 w-5 text-primary" />
                        Neural Feedback History
                      </CardTitle>
                      <CardDescription className="mt-1">
                        Detailed logs of your past biometric audits and
                        calibration sessions.
                      </CardDescription>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      className="shrink-0 border-primary/50 text-primary hover:bg-primary/10 gap-2"
                      onClick={handleExportCSV}
                    >
                      <Download className="h-4 w-4" />
                      Export All
                    </Button>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {[
                      {
                        date: "Today, 08:00 AM",
                        type: "Full Audit",
                        status: "Optimal",
                        score: 92,
                        cognitive: 12,
                        recovery: 85,
                        hr: 62,
                        rr: 14,
                        color: "text-primary",
                        bg: "bg-primary",
                      },
                      {
                        date: "Yesterday, 07:30 AM",
                        type: "Full Audit",
                        status: "Elevated Friction",
                        score: 74,
                        cognitive: 45,
                        recovery: 60,
                        hr: 75,
                        rr: 18,
                        color: "text-orange-500",
                        bg: "bg-orange-500",
                      },
                      {
                        date: "Oct 24, 08:15 AM",
                        type: "Sonic Scan",
                        status: "Optimal",
                        score: 88,
                        cognitive: 20,
                        recovery: 80,
                        hr: 65,
                        rr: 15,
                        color: "text-primary",
                        bg: "bg-primary",
                      },
                      {
                        date: "Oct 23, 09:00 AM",
                        type: "Full Audit",
                        status: "Recovering",
                        score: 65,
                        cognitive: 60,
                        recovery: 40,
                        hr: 80,
                        rr: 20,
                        color: "text-yellow-500",
                        bg: "bg-yellow-500",
                      },
                      {
                        date: "Oct 22, 07:45 AM",
                        type: "Sonic Scan",
                        status: "Optimal",
                        score: 95,
                        cognitive: 10,
                        recovery: 90,
                        hr: 58,
                        rr: 12,
                        color: "text-primary",
                        bg: "bg-primary",
                      },
                    ].map((audit, i) => (
                      <div
                        key={i}
                        className="flex flex-col gap-4 p-4 rounded-lg bg-background/50 border border-border/30 transition-all hover:border-primary/30"
                      >
                        <div className="flex items-start justify-between">
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <Badge
                                variant="outline"
                                className="text-[10px] uppercase tracking-widest"
                              >
                                {audit.type}
                              </Badge>
                              <span className="text-xs text-muted-foreground">
                                {audit.date}
                              </span>
                            </div>
                            <div
                              className={cn(
                                "text-sm font-bold uppercase tracking-wider",
                                audit.color,
                              )}
                            >
                              {audit.status}
                            </div>
                          </div>
                          <div className="flex items-center gap-3">
                            <div className="text-right hidden sm:block">
                              <div className="text-[10px] uppercase tracking-widest text-muted-foreground">
                                Recovery Index
                              </div>
                              <div className="text-lg font-bold">
                                {audit.score}%
                              </div>
                            </div>
                            <div className="relative flex h-12 w-12 items-center justify-center rounded-full bg-secondary shrink-0">
                              <svg className="absolute inset-0 h-full w-full -rotate-90">
                                <circle
                                  cx="24"
                                  cy="24"
                                  r="22"
                                  fill="none"
                                  stroke="currentColor"
                                  strokeWidth="4"
                                  className="text-secondary"
                                />
                                <circle
                                  cx="24"
                                  cy="24"
                                  r="22"
                                  fill="none"
                                  stroke="currentColor"
                                  strokeWidth="4"
                                  strokeDasharray="138.23"
                                  strokeDashoffset={
                                    138.23 - (138.23 * audit.score) / 100
                                  }
                                  className={cn(
                                    audit.color,
                                    "transition-all duration-1000",
                                  )}
                                />
                              </svg>
                              <span className="text-xs font-bold">
                                {audit.score}
                              </span>
                            </div>
                          </div>
                        </div>

                        <div className="grid grid-cols-4 gap-2 pt-3 border-t border-border/20">
                          <div className="space-y-1">
                            <div className="text-[9px] text-muted-foreground uppercase tracking-widest">
                              Cognitive Load
                            </div>
                            <div className="text-xs font-mono font-bold text-destructive">
                              {audit.cognitive}%
                            </div>
                          </div>
                          <div className="space-y-1">
                            <div className="text-[9px] text-muted-foreground uppercase tracking-widest">
                              Recovery
                            </div>
                            <div className="text-xs font-mono font-bold text-primary">
                              {audit.recovery}%
                            </div>
                          </div>
                          <div className="space-y-1">
                            <div className="text-[9px] text-muted-foreground uppercase tracking-widest">
                              Heart Rate
                            </div>
                            <div className="text-xs font-mono font-bold text-foreground">
                              {audit.hr} BPM
                            </div>
                          </div>
                          <div className="space-y-1">
                            <div className="text-[9px] text-muted-foreground uppercase tracking-widest">
                              Resp. Rate
                            </div>
                            <div className="text-xs font-mono font-bold text-foreground">
                              {audit.rr} /min
                            </div>
                          </div>
                        </div>

                        <div className="flex justify-end pt-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-7 text-[10px] text-primary uppercase tracking-widest"
                          >
                            View Full Report
                          </Button>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="archives" className="space-y-6 mt-6">
                <Card className="bg-card/40 border-primary/30 backdrop-blur-sm relative overflow-hidden group">
                  <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-transparent opacity-50" />
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg flex items-center gap-2">
                        <Video className="h-5 w-5 text-primary" />
                        Stream Archives
                      </CardTitle>
                      <Badge
                        variant="outline"
                        className="bg-primary/10 text-primary border-primary/30"
                      >
                        {streamArchives.length} Recordings
                      </Badge>
                    </div>
                    <CardDescription>
                      Review and manage your past live broadcasts and neural
                      sync sessions.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {streamArchives.map((archive, i) => (
                        <div
                          key={i}
                          className="relative rounded-xl overflow-hidden border border-white/10 group"
                        >
                          <div
                            className="cursor-pointer"
                            onClick={() => {
                              hapticFeedback(5);
                              toast({
                                title: "Loading Archive",
                                description: "Decrypting stream data...",
                              });
                            }}
                          >
                            <img
                              src={archive.thumbnail}
                              alt={archive.title}
                              className="w-full h-32 object-cover opacity-60 group-hover:opacity-100 transition-opacity"
                            />
                            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent pointer-events-none" />
                            <div className="absolute top-2 right-2 bg-black/60 backdrop-blur-md text-white text-[10px] font-bold px-2 py-1 rounded flex items-center gap-1 border border-white/10">
                              <Clock className="w-3 h-3" /> {archive.duration}
                            </div>
                            <div className="absolute bottom-3 left-3 right-3">
                              <div className="text-sm font-bold truncate text-white">
                                {archive.title}
                              </div>
                              <div className="flex items-center justify-between mt-1">
                                <div className="text-[10px] text-muted-foreground">
                                  {archive.date}
                                </div>
                                <div className="text-[10px] text-primary flex items-center gap-1">
                                  <Eye className="w-3 h-3" /> {archive.views}
                                </div>
                              </div>
                            </div>
                            <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/40 backdrop-blur-sm">
                              <PlayCircle className="w-10 h-10 text-white" />
                            </div>
                          </div>
                          <Button
                            variant="secondary"
                            size="sm"
                            className="absolute top-2 left-2 h-7 px-2 text-[10px] opacity-0 group-hover:opacity-100 transition-opacity gap-1 bg-black/60 hover:bg-primary hover:text-primary-foreground border border-white/10 backdrop-blur-md"
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedArchiveForClip(archive);
                              setShowClipCreator(true);
                            }}
                          >
                            <Scissors className="h-3 w-3" /> Extract Clip
                          </Button>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>

        <Dialog open={showClipCreator} onOpenChange={setShowClipCreator}>
          <DialogContent className="sm:max-w-md border-primary/20 bg-background/95 backdrop-blur-xl">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Scissors className="h-5 w-5 text-primary" />
                Neural Clip Creator
              </DialogTitle>
              <DialogDescription>
                Extract a 15-second highlight from "
                {selectedArchiveForClip?.title}" to share on the Feed.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-6 py-4">
              <div className="relative w-full h-48 bg-black rounded-lg overflow-hidden border border-white/10 flex items-center justify-center">
                {selectedArchiveForClip && (
                  <img
                    src={selectedArchiveForClip.thumbnail}
                    alt="Preview"
                    className="absolute inset-0 w-full h-full object-cover opacity-40"
                  />
                )}
                <div className="relative z-10 flex flex-col items-center gap-2">
                  <PlayCircle className="h-12 w-12 text-white/50" />
                  <span className="text-xs text-white/50 font-mono">
                    00:12:45 / {selectedArchiveForClip?.duration}
                  </span>
                </div>

                {biometricOverlay && (
                  <div className="absolute top-2 left-2 flex flex-col gap-1 z-10 pointer-events-none">
                    <div className="bg-black/60 backdrop-blur-md px-2 py-1 rounded text-[10px] font-mono text-primary flex items-center gap-1 border border-primary/20">
                      <Activity className="h-3 w-3" /> HRV: 85ms
                    </div>
                    <div className="bg-black/60 backdrop-blur-md px-2 py-1 rounded text-[10px] font-mono text-destructive flex items-center gap-1 border border-destructive/20">
                      <BrainCircuit className="h-3 w-3" /> CNS: 42%
                    </div>
                  </div>
                )}

                {clipWatermark && (
                  <div className="absolute top-2 right-2 flex items-center gap-1.5 z-10 pointer-events-none bg-black/60 backdrop-blur-md px-2 py-1 rounded border border-white/10">
                    <Avatar className="w-4 h-4 border border-primary/30">
                      <AvatarImage src={avatarImage} />
                      <AvatarFallback>
                        <User className="w-3 h-3" />
                      </AvatarFallback>
                    </Avatar>
                    <span className="text-[10px] font-bold text-white uppercase tracking-widest">
                      @You
                    </span>
                  </div>
                )}

                {autoCaptions && (
                  <div className="absolute bottom-6 left-0 right-0 flex justify-center z-10 pointer-events-none px-4">
                    <div
                      className={cn(
                        "text-center font-bold px-3 py-1.5 rounded backdrop-blur-sm",
                        captionStyle === "dynamic"
                          ? "text-white text-lg bg-black/40 uppercase tracking-wide border-b-2 border-primary shadow-[0_0_10px_rgba(0,255,255,0.3)]"
                          : captionStyle === "karaoke"
                            ? "text-yellow-400 text-xl bg-black/60 italic"
                            : "text-white text-sm bg-black/80",
                      )}
                    >
                      <span
                        className={
                          captionStyle === "dynamic" ? "text-primary" : ""
                        }
                      >
                        "Hitting
                      </span>{" "}
                      98% flow state..."
                    </div>
                  </div>
                )}

                {/* Simulated Clip Region */}
                <div className="absolute bottom-0 left-0 right-0 h-1 bg-white/20">
                  <div className="absolute top-0 left-[30%] w-[15%] h-full bg-primary animate-pulse" />
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Clip Duration</span>
                  <span className="font-mono text-primary">15.0s</span>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>Start: 00:12:45</span>
                    <span>End: 00:13:00</span>
                  </div>
                  <Slider
                    defaultValue={[30]}
                    max={100}
                    step={1}
                    className="py-2"
                  />
                </div>
                <Button
                  variant="secondary"
                  className="w-full gap-2 bg-primary/10 text-primary border border-primary/20 hover:bg-primary/20 transition-all duration-300"
                  onClick={(e) => {
                    e.preventDefault();
                    const btn = e.currentTarget;
                    const originalText = btn.innerHTML;
                    btn.innerHTML =
                      '<span class="animate-pulse flex items-center gap-2"><svg class="lucide lucide-wand2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m21.64 3.64-1.28-1.28a1.21 1.21 0 0 0-1.72 0L2.36 18.64a1.21 1.21 0 0 0 0 1.72l1.28 1.28a1.2 1.2 0 0 0 1.72 0L21.64 5.36a1.2 1.2 0 0 0 0-1.72Z"/><path d="m14 7 3 3"/><path d="M5 6v4"/><path d="M19 14v4"/><path d="M10 2v2"/><path d="M7 8H3"/><path d="M21 16h-4"/><path d="M11 3H9"/></svg> Processing...</span>';
                    hapticFeedback([30, 50, 30]);
                    toast({
                      title: "Neural Analysis Active",
                      description:
                        "Scanning for biometric spikes and chat volume...",
                    });
                    setTimeout(() => {
                      btn.innerHTML = originalText;
                      hapticFeedback([100]);
                      toast({
                        title: "Highlight Found",
                        description:
                          "Auto-selected peak flow state moment & generated Smart Tags.",
                      });
                      const tagsContainer = document.getElementById(
                        "smart-tags-container",
                      );
                      if (tagsContainer) {
                        tagsContainer.classList.remove("hidden");
                        tagsContainer.classList.add("flex");
                      }
                    }, 1500);
                  }}
                >
                  <Wand2 className="h-4 w-4" /> Auto-Highlight AI
                </Button>

                <div
                  id="smart-tags-container"
                  className="hidden flex-wrap gap-2 pt-2 border-t border-white/5"
                >
                  <span className="text-[10px] text-muted-foreground uppercase tracking-widest font-bold w-full mb-1">
                    AI Smart Tags
                  </span>
                  <Badge
                    variant="outline"
                    className="bg-blue-500/10 text-blue-400 border-blue-500/30"
                  >
                    #PeakFlow
                  </Badge>
                  <Badge
                    variant="outline"
                    className="bg-purple-500/10 text-purple-400 border-purple-500/30"
                  >
                    #CNS_Spike
                  </Badge>
                  <Badge
                    variant="outline"
                    className="bg-emerald-500/10 text-emerald-400 border-emerald-500/30"
                  >
                    #Zone2
                  </Badge>
                  <Badge
                    variant="outline"
                    className="bg-orange-500/10 text-orange-400 border-orange-500/30"
                  >
                    #HighEngagement
                  </Badge>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Playback Speed</Label>
                <div className="flex items-center gap-2">
                  {[0.5, 0.75, 1, 1.25, 1.5].map((speed) => (
                    <Button
                      key={speed}
                      variant={clipSpeed === speed ? "default" : "outline"}
                      size="sm"
                      className={cn(
                        "flex-1 h-8 text-xs font-mono transition-all",
                        clipSpeed === speed
                          ? "bg-primary text-primary-foreground shadow-[0_0_10px_hsl(var(--primary)/0.3)]"
                          : "text-muted-foreground hover:text-foreground",
                      )}
                      onClick={() => {
                        hapticFeedback(10);
                        setClipSpeed(speed);
                      }}
                    >
                      {speed}x
                    </Button>
                  ))}
                </div>
                <div className="text-[10px] text-muted-foreground italic text-right">
                  {clipSpeed < 1
                    ? "Slow-motion enabled for biometric emphasis"
                    : clipSpeed > 1
                      ? "Time-lapse mode active"
                      : "Standard playback"}
                </div>
              </div>

              <div className="flex items-center justify-between p-3 rounded-md bg-secondary/30 border border-border/50">
                <div className="space-y-0.5">
                  <Label className="text-sm font-medium flex items-center gap-2">
                    <MicOff className="h-4 w-4 text-primary" />
                    Audio Ducking
                  </Label>
                  <p className="text-[10px] text-muted-foreground">
                    Automatically lowers stream volume during biometric alerts.
                  </p>
                </div>
                <Switch
                  checked={audioDucking}
                  onCheckedChange={(checked) => {
                    hapticFeedback(10);
                    setAudioDucking(checked);
                    toast({
                      title: checked
                        ? "Audio Ducking Enabled"
                        : "Audio Ducking Disabled",
                      description: checked
                        ? "Stream volume will duck during alerts."
                        : "Stream volume will remain constant.",
                    });
                  }}
                />
              </div>

              <div className="flex items-center justify-between p-3 rounded-md bg-secondary/30 border border-border/50">
                <div className="space-y-0.5">
                  <Label className="text-sm font-medium flex items-center gap-2">
                    <Activity className="h-4 w-4 text-primary" />
                    Biometric Overlay
                  </Label>
                  <p className="text-[10px] text-muted-foreground">
                    Display HRV and CNS metrics on the exported clip.
                  </p>
                </div>
                <Switch
                  checked={biometricOverlay}
                  onCheckedChange={(checked) => {
                    hapticFeedback(10);
                    setBiometricOverlay(checked);
                    toast({
                      title: checked
                        ? "Biometric Overlay Enabled"
                        : "Biometric Overlay Disabled",
                      description: checked
                        ? "HRV and CNS metrics will be visible on the clip."
                        : "Metrics will be hidden from the clip.",
                    });
                  }}
                />
              </div>

              <div className="flex items-center justify-between p-3 rounded-md bg-secondary/30 border border-border/50">
                <div className="space-y-0.5">
                  <Label className="text-sm font-medium flex items-center gap-2">
                    <User className="h-4 w-4 text-primary" />
                    Clip Watermark
                  </Label>
                  <p className="text-[10px] text-muted-foreground">
                    Add your handle and avatar to the exported clip.
                  </p>
                </div>
                <Switch
                  checked={clipWatermark}
                  onCheckedChange={(checked) => {
                    hapticFeedback(10);
                    setClipWatermark(checked);
                    toast({
                      title: checked
                        ? "Watermark Enabled"
                        : "Watermark Disabled",
                      description: checked
                        ? "Your handle will appear on the clip."
                        : "Clip will be exported without watermark.",
                    });
                  }}
                />
              </div>

              <div className="flex flex-col gap-3 p-3 rounded-md bg-secondary/30 border border-border/50">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-sm font-medium flex items-center gap-2">
                      <Subtitles className="h-4 w-4 text-primary" />
                      Auto-Captions (AI)
                    </Label>
                    <p className="text-[10px] text-muted-foreground">
                      Automatically transcribe and style speech.
                    </p>
                  </div>
                  <Switch
                    checked={autoCaptions}
                    onCheckedChange={(checked) => {
                      hapticFeedback(10);
                      setAutoCaptions(checked);
                      toast({
                        title: checked
                          ? "AI Captions Enabled"
                          : "AI Captions Disabled",
                        description: checked
                          ? "Speech will be automatically transcribed."
                          : "Captions removed from clip.",
                      });
                    }}
                  />
                </div>

                {autoCaptions && (
                  <div className="pt-2 border-t border-border/50 animate-in fade-in slide-in-from-top-2">
                    <Label className="text-xs text-muted-foreground mb-2 block">
                      Caption Style
                    </Label>
                    <div className="grid grid-cols-3 gap-2">
                      <Button
                        variant={
                          captionStyle === "dynamic" ? "default" : "outline"
                        }
                        size="sm"
                        className={cn(
                          "h-8 text-[10px] uppercase tracking-widest",
                          captionStyle === "dynamic"
                            ? "bg-primary text-primary-foreground shadow-[0_0_10px_hsl(var(--primary)/0.3)]"
                            : "",
                        )}
                        onClick={() => {
                          hapticFeedback(5);
                          setCaptionStyle("dynamic");
                        }}
                      >
                        Dynamic
                      </Button>
                      <Button
                        variant={
                          captionStyle === "karaoke" ? "default" : "outline"
                        }
                        size="sm"
                        className={cn(
                          "h-8 text-[10px] uppercase tracking-widest",
                          captionStyle === "karaoke"
                            ? "bg-yellow-500 text-black shadow-[0_0_10px_rgba(234,179,8,0.3)] hover:bg-yellow-600"
                            : "",
                        )}
                        onClick={() => {
                          hapticFeedback(5);
                          setCaptionStyle("karaoke");
                        }}
                      >
                        Karaoke
                      </Button>
                      <Button
                        variant={
                          captionStyle === "minimal" ? "default" : "outline"
                        }
                        size="sm"
                        className={cn(
                          "h-8 text-[10px] uppercase tracking-widest",
                          captionStyle === "minimal"
                            ? "bg-white text-black shadow-[0_0_10px_rgba(255,255,255,0.3)] hover:bg-gray-200"
                            : "",
                        )}
                        onClick={() => {
                          hapticFeedback(5);
                          setCaptionStyle("minimal");
                        }}
                      >
                        Minimal
                      </Button>
                    </div>
                  </div>
                )}
              </div>

              <div className="flex flex-col gap-3 p-3 rounded-md bg-secondary/30 border border-border/50">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-sm font-medium flex items-center gap-2">
                      <Mic className="h-4 w-4 text-primary" />
                      Text-to-Speech (AI)
                    </Label>
                    <p className="text-[10px] text-muted-foreground">
                      Add AI voiceover to clips without audio.
                    </p>
                  </div>
                  <Switch
                    checked={ttsEnabled}
                    onCheckedChange={(checked) => {
                      hapticFeedback(10);
                      setTtsEnabled(checked);
                      toast({
                        title: checked ? "TTS Enabled" : "TTS Disabled",
                        description: checked
                          ? "AI voiceover will be generated."
                          : "AI voiceover removed.",
                      });
                    }}
                  />
                </div>

                {ttsEnabled && (
                  <div className="pt-2 border-t border-border/50 animate-in fade-in slide-in-from-top-2 space-y-3">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label className="text-xs text-muted-foreground block">
                          Voice Selection
                        </Label>
                        {!isVoiceCloned ? (
                          <Button
                            variant="ghost"
                            size="sm"
                            className={cn(
                              "h-5 text-[9px] px-2",
                              isCloning
                                ? "text-destructive animate-pulse"
                                : "text-primary hover:bg-primary/20",
                            )}
                            onClick={() => {
                              if (isCloning) return;
                              setIsCloning(true);
                              hapticFeedback([50, 50, 50]);
                              toast({
                                title: "Calibrating Vocal Biomarkers",
                                description:
                                  "Please speak naturally for 3 seconds...",
                              });
                              setTimeout(() => {
                                setIsCloning(false);
                                setIsVoiceCloned(true);
                                setTtsVoice("cloned");
                                hapticFeedback([100, 50, 100]);
                                toast({
                                  title: "Voice Cloned",
                                  description:
                                    "Your neural voice model is ready.",
                                });
                              }, 3000);
                            }}
                          >
                            {isCloning ? (
                              <>
                                <Mic className="w-3 h-3 mr-1" /> Recording...
                              </>
                            ) : (
                              <>
                                <Mic className="w-3 h-3 mr-1" /> Clone My Voice
                              </>
                            )}
                          </Button>
                        ) : (
                          <Badge
                            variant="outline"
                            className="h-5 text-[9px] bg-primary/10 text-primary border-primary/20"
                          >
                            <Check className="w-3 h-3 mr-1" /> Voice Cloned
                          </Badge>
                        )}
                      </div>
                      <Select value={ttsVoice} onValueChange={setTtsVoice}>
                        <SelectTrigger className="h-8 text-xs bg-background/50 border-white/10">
                          <SelectValue placeholder="Select Voice" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="neural-male">
                            Neural Male (Deep)
                          </SelectItem>
                          <SelectItem value="neural-female">
                            Neural Female (Clear)
                          </SelectItem>
                          <SelectItem value="tactical">Tactical AI</SelectItem>
                          {isVoiceCloned && (
                            <SelectItem value="cloned">
                              My Cloned Voice
                            </SelectItem>
                          )}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-xs text-muted-foreground block">
                        Voiceover Script
                      </Label>
                      <div className="flex gap-2">
                        <Input
                          placeholder="Enter text for AI to speak..."
                          className="h-8 text-xs bg-background/50 border-white/10 flex-1"
                          value={ttsText}
                          onChange={(e) => setTtsText(e.target.value)}
                        />
                        <Button
                          variant="outline"
                          size="sm"
                          id="tts-preview-btn"
                          className="h-8 shrink-0 text-[10px] uppercase tracking-widest gap-1 border-primary/30 text-primary hover:bg-primary/20"
                          onClick={() => {
                            if (!ttsText) {
                              toast({
                                title: "Empty Script",
                                description: "Please enter text to preview.",
                                variant: "destructive",
                              });
                              return;
                            }
                            hapticFeedback([20, 30, 20]);
                            const btn =
                              document.getElementById("tts-preview-btn");
                            if (btn) {
                              const original = btn.innerHTML;
                              btn.innerHTML =
                                '<svg class="lucide lucide-activity h-3 w-3 animate-pulse" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.48 12H2"/></svg> PLAYING...';
                              setTimeout(() => {
                                btn.innerHTML = original;
                              }, 2000);
                            }
                            toast({
                              title: "Playing AI Voice",
                              description: `Previewing script using ${ttsVoice}...`,
                            });
                          }}
                        >
                          <PlayCircle className="h-3 w-3" /> Preview
                        </Button>
                      </div>
                    </div>

                    <div className="space-y-3 pt-3 border-t border-white/5">
                      <div className="flex justify-between items-center text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Video className="w-3 h-3" /> Stream Audio
                        </span>
                        <span className="font-bold text-primary text-[10px] uppercase tracking-widest">
                          Mix Equalizer
                        </span>
                        <span className="flex items-center gap-1">
                          <Mic className="w-3 h-3" /> AI Voice
                        </span>
                      </div>
                      <Slider
                        defaultValue={[70]}
                        max={100}
                        step={1}
                        value={audioMix}
                        onValueChange={(val) => {
                          hapticFeedback(5);
                          setAudioMix(val);
                        }}
                        className="py-2"
                      />
                      <div className="flex justify-between text-[10px] font-mono text-muted-foreground">
                        <span>{100 - audioMix[0]}%</span>
                        <span>{audioMix[0]}%</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <Label>Clip Title</Label>
                <Input
                  placeholder="e.g., Perfect Flow State Entry"
                  className="bg-background/50"
                />
              </div>
            </div>
            <DialogFooter className="flex-col sm:flex-row gap-2">
              <Button
                variant="outline"
                onClick={() => setShowClipCreator(false)}
              >
                Cancel
              </Button>
              <Button
                className="gap-2 bg-blue-500 text-white hover:bg-blue-600"
                onClick={() => {
                  hapticFeedback([50, 50, 100]);
                  toast({
                    title: "Processing Highlight",
                    description: "Extracting and sharing to Feed...",
                  });
                  setTimeout(() => {
                    setShowClipCreator(false);
                    toast({
                      title: "Shared to Feed",
                      description:
                        "Your highlight is now live on the global feed!",
                    });
                  }, 2000);
                }}
              >
                <Share2 className="h-4 w-4" /> Export to Feed
              </Button>
              <Button
                className="gap-2 bg-sky-500 text-white hover:bg-sky-600"
                onClick={() => {
                  hapticFeedback([50, 50, 100]);
                  toast({
                    title: "Auto-Posting",
                    description: "Sharing clip to X/Twitter...",
                  });
                  setTimeout(() => {
                    setShowClipCreator(false);
                    toast({
                      title: "Posted to X",
                      description:
                        "Your highlight is now live on your timeline!",
                    });
                  }, 2000);
                }}
              >
                <Twitter className="h-4 w-4" /> Post to X
              </Button>
              <Button
                className="gap-2 bg-pink-600 text-white hover:bg-pink-700"
                onClick={() => {
                  hapticFeedback([50, 50, 100]);
                  toast({
                    title: "Auto-Posting",
                    description: "Sharing clip to Instagram Reels...",
                  });
                  setTimeout(() => {
                    setShowClipCreator(false);
                    toast({
                      title: "Posted to Reels",
                      description: "Your highlight is now live on Instagram!",
                    });
                  }, 2000);
                }}
              >
                <Instagram className="h-4 w-4" /> Post to Reels
              </Button>
              <Button
                className="gap-2 bg-red-600 text-white hover:bg-red-700"
                onClick={() => {
                  hapticFeedback([50, 50, 100]);
                  toast({
                    title: "Auto-Posting",
                    description: "Sharing clip to YouTube Shorts...",
                  });
                  setTimeout(() => {
                    setShowClipCreator(false);
                    toast({
                      title: "Posted to Shorts",
                      description: "Your highlight is now live on YouTube!",
                    });
                  }, 2000);
                }}
              >
                <Youtube className="h-4 w-4" /> Post to Shorts
              </Button>
              <Button
                className="gap-2"
                onClick={() => {
                  hapticFeedback([50, 50, 100]);
                  toast({
                    title: "Processing Highlight",
                    description: "Extracting and encoding 15s clip...",
                  });
                  setTimeout(() => {
                    setShowClipCreator(false);
                    toast({
                      title: "Clip Extracted",
                      description: "Your highlight is ready to be shared!",
                    });
                  }, 2000);
                }}
              >
                <Scissors className="h-4 w-4" /> Extract & Save
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        <Dialog
          open={!!previewItem}
          onOpenChange={(open) => !open && setPreviewItem(null)}
        >
          <DialogContent className="sm:max-w-[400px] bg-card/95 border-border/50 backdrop-blur-md">
            <DialogHeader>
              <DialogTitle>Preview: {previewItem?.name}</DialogTitle>
              <DialogDescription>
                This is how your profile card will look.
              </DialogDescription>
            </DialogHeader>
            <div className="py-6 flex justify-center">
              {/* Mock Profile Card */}
              <Card
                className={cn(
                  "w-full max-w-[300px] bg-card/40 border-border/50 backdrop-blur-sm relative overflow-hidden",
                  previewItem?.type === "theme" &&
                    previewItem.style === "dark_matter" &&
                    "bg-black border-purple-500/30",
                  previewItem?.type === "theme" &&
                    previewItem.style === "cyber_flow" &&
                    "bg-slate-950 border-cyan-500/50 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px]",
                )}
              >
                {previewItem?.type === "theme" &&
                  previewItem.style === "dark_matter" && (
                    <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-purple-900/20 via-background to-background"></div>
                  )}
                <CardContent className="pt-6 flex flex-col items-center text-center relative z-10">
                  <Avatar
                    className={cn(
                      "h-24 w-24 border-2 border-primary/20 mb-4",
                      previewItem?.type === "glow"
                        ? previewItem.style
                        : avatarGlow,
                      "animate-neural-pulse",
                    )}
                  >
                    <AvatarImage
                      src={avatarImage}
                      alt="User"
                      className="object-cover"
                    />
                    <AvatarFallback className="bg-card flex flex-col items-center justify-center text-primary border border-primary/20">
                      <User className="w-12 h-12 opacity-50" />
                    </AvatarFallback>
                  </Avatar>
                  <h2 className="text-xl font-bold">{userName}</h2>
                  <p className="text-sm text-muted-foreground mb-4">
                    Sovereign Optimizer
                  </p>
                  <div className="w-full bg-secondary rounded-full h-2 mb-2 overflow-hidden">
                    <div className="bg-primary h-full w-[85%] rounded-full shadow-[0_0_10px_rgba(0,200,200,0.5)]"></div>
                  </div>
                  <p className="text-xs text-primary font-medium tracking-wider mb-4">
                    SYSTEM OPTIMAL (85%)
                  </p>
                </CardContent>
              </Card>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setPreviewItem(null)}>
                Close Preview
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Certificate Dialog */}
        <Dialog open={isCertificateOpen} onOpenChange={setIsCertificateOpen}>
          <DialogContent className="sm:max-w-[600px] bg-card/95 border-primary/50 backdrop-blur-md p-0 overflow-hidden shadow-[0_0_50px_rgba(0,255,255,0.15)]">
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary/10 via-transparent to-transparent pointer-events-none" />
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-primary to-transparent" />

            <div className="p-8 sm:p-12 flex flex-col items-center text-center relative z-10">
              <div className="h-16 w-16 rounded-full bg-primary/10 border border-primary/30 flex items-center justify-center text-primary shadow-[0_0_20px_rgba(0,255,255,0.3)] mb-6">
                <BrainCircuit className="h-8 w-8" />
              </div>

              <h2 className="text-sm text-primary tracking-[0.3em] font-bold uppercase mb-2">
                Certificate of Calibration
              </h2>
              <h1 className="text-3xl sm:text-4xl font-extrabold mb-6 text-foreground">
                NEURAL SYNC MASTER
              </h1>

              <p className="text-muted-foreground mb-8 max-w-[400px] leading-relaxed">
                This certifies that{" "}
                <strong className="text-foreground">{userName}</strong> has
                achieved a Peak Flow State of{" "}
                <strong className="text-primary">92%</strong> and is officially
                recognized as a Sovereign Optimizer.
              </p>

              <div className="grid grid-cols-2 gap-8 w-full max-w-[400px] border-t border-border/50 pt-6 mb-8">
                <div>
                  <div className="text-[10px] text-muted-foreground uppercase tracking-widest mb-1">
                    Date Issued
                  </div>
                  <div className="font-mono text-sm font-bold">
                    {new Date().toLocaleDateString("en-US", {
                      month: "short",
                      day: "numeric",
                      year: "numeric",
                    })}
                  </div>
                </div>
                <div>
                  <div className="text-[10px] text-muted-foreground uppercase tracking-widest mb-1">
                    Verification ID
                  </div>
                  <div className="font-mono text-sm text-primary font-bold">
                    NS-884-X9
                  </div>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-4 w-full">
                <Button
                  className="flex-1 gap-2 bg-[#0077b5] hover:bg-[#0077b5]/90 text-white border-none shadow-[0_0_15px_rgba(0,119,181,0.4)]"
                  onClick={() => {
                    hapticFeedback([50, 30, 50]);
                    toast({
                      title: "Shared to LinkedIn",
                      description:
                        "Your neural certification is now live on your profile.",
                    });
                    window.open(
                      "https://linkedin.com/shareArticle?mini=true&url=https://therapyfit-elite.app/cert/NS-884-X9&title=I just achieved Neural Sync Master status on TherapyFIT Elite!",
                      "_blank",
                    );
                  }}
                >
                  <Linkedin className="h-4 w-4" />
                  Share to LinkedIn
                </Button>
                <Button
                  className="flex-1 gap-2 bg-[#1DA1F2] hover:bg-[#1DA1F2]/90 text-white border-none shadow-[0_0_15px_rgba(29,161,242,0.4)]"
                  onClick={() => {
                    hapticFeedback([50, 30, 50]);
                    toast({
                      title: "Shared to Twitter",
                      description:
                        "Your neural certification has been broadcasted.",
                    });
                    window.open(
                      "https://twitter.com/intent/tweet?text=I just achieved Neural Sync Master status on TherapyFIT Elite! My Flow State is at 92% 🧠⚡️&url=https://therapyfit-elite.app/cert/NS-884-X9",
                      "_blank",
                    );
                  }}
                >
                  <Twitter className="h-4 w-4" />
                  Share to Twitter
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Chat Dialog */}
        <Dialog
          open={chatDuelId !== null}
          onOpenChange={(open) => !open && setChatDuelId(null)}
        >
          <DialogContent className="sm:max-w-[425px] h-[500px] flex flex-col bg-card/95 border-border/50 backdrop-blur-md p-0">
            <DialogHeader className="p-6 pb-2 border-b border-border/30">
              <DialogTitle className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5 text-primary" />
                Neural Duel Chat:{" "}
                {chatDuelId === 1 ? "Sarah_Opt" : "David_Neural"}
              </DialogTitle>
              <DialogDescription>
                Coordinate protocols and exchange biometric subtext.
              </DialogDescription>
            </DialogHeader>

            <div className="flex-1 overflow-y-auto p-6 space-y-4 custom-scrollbar relative">
              {/* Custom Chat Background based on Opponent Badge */}
              {(() => {
                const opponentBadge =
                  chatDuelId === 1
                    ? "elite"
                    : chatDuelId === 2
                      ? "pro"
                      : "master";
                return (
                  <div
                    className={cn(
                      "absolute inset-0 opacity-[0.07] pointer-events-none transition-all duration-1000",
                      opponentBadge === "elite" &&
                        "bg-[radial-gradient(circle_at_center,hsl(var(--primary))_0%,transparent_70%)] bg-[size:40px_40px] bg-[radial-gradient(hsl(var(--primary))_0.5px,transparent_0.5px)]",
                      opponentBadge === "pro" &&
                        "bg-[radial-gradient(circle_at_center,hsl(290,100%,50%)_0%,transparent_70%)] bg-[size:40px_40px] bg-[radial-gradient(hsl(290,100%,50%)_0.5px,transparent_0.5px)]",
                      opponentBadge === "master" &&
                        "bg-[radial-gradient(circle_at_center,hsl(45,100%,50%)_0%,transparent_70%)] bg-[size:40px_40px] bg-[radial-gradient(hsl(45,100%,50%)_0.5px,transparent_0.5px)]",
                    )}
                  />
                );
              })()}

              {neuralSyncActive && (
                <div className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-background/80 backdrop-blur-sm animate-in fade-in duration-500">
                  <div className="relative flex items-center justify-center">
                    <div className="absolute w-32 h-32 rounded-full border-4 border-primary/50 animate-ping" />
                    <div className="absolute w-24 h-24 rounded-full border-4 border-primary animate-pulse" />
                    <div className="w-16 h-16 rounded-full bg-primary flex items-center justify-center text-primary-foreground relative z-10 shadow-[0_0_30px_rgba(0,200,200,0.8)]">
                      <Zap className="h-8 w-8" />
                    </div>
                  </div>
                  <div className="mt-8 text-center space-y-2">
                    <h3 className="text-xl font-bold text-primary tracking-widest uppercase animate-pulse">
                      Neural Sync Established
                    </h3>
                    <p className="text-sm text-muted-foreground font-mono">
                      Biometrics aligned. Flow state synchronized.
                    </p>
                  </div>
                </div>
              )}
              {chatDuelId !== null &&
                messages[chatDuelId]?.map((msg, i) => {
                  const badge =
                    msg.sender === userName
                      ? "master"
                      : msg.sender === "Sarah_Opt"
                        ? "elite"
                        : msg.sender === "David_Neural"
                          ? "pro"
                          : "basic";
                  const isCurrentUser = msg.sender === userName;

                  return (
                    <div
                      key={i}
                      className={cn(
                        "flex flex-col max-w-[85%] rounded-lg p-3 text-sm transition-all duration-300 relative overflow-hidden",
                        isCurrentUser ? "ml-auto" : "mr-auto",
                        badge === "master"
                          ? "border border-yellow-400/30 bg-gradient-to-br from-yellow-400/20 via-yellow-400/5 to-transparent text-foreground shadow-[0_0_15px_rgba(250,204,21,0.1)]"
                          : badge === "elite"
                            ? "border border-primary/30 bg-gradient-to-br from-primary/20 via-primary/5 to-transparent text-foreground shadow-[0_0_15px_rgba(0,255,255,0.1)]"
                            : badge === "pro"
                              ? "border border-fuchsia-500/30 bg-gradient-to-br from-fuchsia-500/20 via-fuchsia-500/5 to-transparent text-foreground shadow-[0_0_15px_rgba(217,70,239,0.1)]"
                              : "border border-border/30 bg-secondary/50 text-muted-foreground",
                      )}
                    >
                      {/* Subtle Background Pattern for Bubble */}
                      <div className="absolute inset-0 opacity-[0.03] pointer-events-none bg-[radial-gradient(#fff_1px,transparent_1px)] bg-[size:10px_10px]" />
                      <div className="flex items-center justify-between gap-4 mb-1">
                        <div className="flex items-center gap-1.5">
                          {badge === "master" && (
                            <Crown className="w-3 h-3 text-yellow-400" />
                          )}
                          {badge === "elite" && (
                            <Shield className="w-3 h-3 text-primary" />
                          )}
                          {badge === "pro" && (
                            <Zap className="w-3 h-3 text-fuchsia-400" />
                          )}
                          <span
                            className={cn(
                              "font-bold text-[10px] uppercase tracking-wider",
                              badge === "master"
                                ? "text-yellow-400"
                                : badge === "elite"
                                  ? "text-primary"
                                  : badge === "pro"
                                    ? "text-fuchsia-400"
                                    : "text-muted-foreground",
                            )}
                          >
                            {msg.sender}
                          </span>
                        </div>
                        <span className="text-[10px] opacity-50">
                          {msg.time}
                        </span>
                      </div>

                      {msg.type === "biometric" ? (
                        <div className="space-y-3 mt-1 bg-background/40 p-3 rounded border border-primary/20">
                          <div className="flex items-center gap-2 text-primary">
                            <Activity className="h-3 w-3" />
                            <span className="text-[10px] font-bold uppercase tracking-tighter">
                              Live Neural Sync
                            </span>
                          </div>
                          <div className="grid grid-cols-2 gap-3">
                            <div className="space-y-1">
                              <div className="flex justify-between text-[9px] uppercase font-medium opacity-70">
                                <span>Cognitive</span>
                                <span>{msg.data.cognitive}%</span>
                              </div>
                              <Progress
                                value={msg.data.cognitive}
                                className="h-1 bg-secondary"
                              />
                            </div>
                            <div className="space-y-1">
                              <div className="flex justify-between text-[9px] uppercase font-medium opacity-70">
                                <span>Recovery</span>
                                <span>{msg.data.recovery}%</span>
                              </div>
                              <Progress
                                value={msg.data.recovery}
                                className="h-1 bg-secondary"
                              />
                            </div>
                          </div>
                          <div className="flex justify-between items-center pt-1 border-t border-border/20">
                            <span className="text-[9px] text-muted-foreground">
                              FLOW STATE
                            </span>
                            <span className="text-[10px] font-bold text-primary">
                              {msg.data.flow}%
                            </span>
                          </div>
                        </div>
                      ) : (
                        <p>{msg.text}</p>
                      )}
                    </div>
                  );
                })}
            </div>

            <div className="p-6 pt-4 border-t border-border/30 flex flex-col gap-3">
              <div className="flex gap-2 overflow-x-auto pb-1 custom-scrollbar items-center">
                <Button
                  variant="outline"
                  size="icon"
                  className="h-7 w-7 shrink-0 border-primary/50 text-primary hover:bg-primary/20 rounded-full"
                  onClick={() =>
                    chatDuelId && handleShareBiometrics(chatDuelId)
                  }
                >
                  <Activity className="h-3.5 w-3.5" />
                </Button>
                <div className="w-[1px] h-4 bg-border/50 shrink-0" />
                {[
                  { emoji: "⚡️", label: "Peak Flow" },
                  { emoji: "🔥", label: "Red-lining" },
                  { emoji: "🧊", label: "Deep Chill" },
                  { emoji: "🧠", label: "Hyper Focus" },
                  { emoji: "🔋", label: "Recharging" },
                ].map((ne) => (
                  <Button
                    key={ne.label}
                    type="button"
                    variant="outline"
                    size="sm"
                    className="h-7 text-[10px] border-primary/30 text-primary hover:bg-primary/20 shrink-0 gap-1 rounded-full px-3"
                    onClick={() => {
                      hapticFeedback(10);
                      setNewMessage(
                        (prev) => prev + `${ne.emoji} [${ne.label}] `,
                      );
                    }}
                  >
                    <span>{ne.emoji}</span>
                    <span className="font-medium uppercase tracking-wider">
                      {ne.label}
                    </span>
                  </Button>
                ))}
              </div>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (chatDuelId) handleSendMessage(chatDuelId);
                }}
                className="flex gap-2"
              >
                <div className="relative flex-1">
                  <Input
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    placeholder={
                      isListening ? "Listening..." : "Type biometric subtext..."
                    }
                    className={cn(
                      "bg-background/50 border-border/30 pr-10",
                      isListening &&
                        "border-primary shadow-[0_0_10px_rgba(0,255,255,0.2)]",
                    )}
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className={cn(
                      "absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8 rounded-full",
                      isListening
                        ? "text-primary animate-pulse bg-primary/10"
                        : "text-muted-foreground hover:text-primary",
                    )}
                    onClick={toggleListening}
                  >
                    {isListening ? (
                      <Mic className="h-4 w-4" />
                    ) : (
                      <MicOff className="h-4 w-4" />
                    )}
                  </Button>
                </div>
                <Button
                  type="submit"
                  size="icon"
                  className="shrink-0 bg-primary/20 text-primary hover:bg-primary/30 border border-primary/30"
                >
                  <Zap className="h-4 w-4" />
                </Button>
              </form>
            </div>
          </DialogContent>
        </Dialog>

        {/* AR Overlay */}
        {isARMode && (
          <div className="fixed inset-0 z-[100] bg-black flex flex-col items-center justify-center overflow-hidden animate-in fade-in duration-500">
            <video
              autoPlay
              playsInline
              muted
              ref={(el) => {
                if (el && stream) el.srcObject = stream;
              }}
              className="absolute inset-0 w-full h-full object-cover opacity-60"
            />

            {/* HUD Elements */}
            <div className="absolute inset-0 pointer-events-none border-[20px] border-primary/10">
              <div className="absolute top-8 left-8 flex flex-col gap-1">
                <div className="flex items-center gap-2 text-primary font-mono text-xs">
                  <Activity className="w-4 h-4 animate-pulse" />
                  <span>NEURAL SCAN ACTIVE</span>
                </div>
                {isMultiUserAR && (
                  <div className="flex items-center gap-2 text-fuchsia-500 font-mono text-[10px] animate-pulse">
                    <Swords className="w-3 h-3" />
                    <span>MULTI-USER SYNC: 3 NEARBY</span>
                  </div>
                )}
              </div>
              <div className="absolute top-8 right-8 text-primary font-mono text-[10px] text-right">
                <div>SYNC_LATENCY: {isMultiUserAR ? "24ms" : "12ms"}</div>
                <div>FRAME_RATE: 60FPS</div>
                {isMultiUserAR && (
                  <div className="text-fuchsia-400">
                    NETWORK_ID: ELITE_NODE_7
                  </div>
                )}
              </div>
              <div className="absolute bottom-24 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2">
                <div className="w-48 h-1 bg-secondary rounded-full overflow-hidden">
                  <div className="h-full bg-primary animate-shimmer w-full" />
                </div>
                <span className="text-[10px] text-primary font-bold tracking-widest">
                  RESONANCE_STABLE
                </span>
              </div>

              {/* Crosshair */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 border border-primary/20 rounded-full flex items-center justify-center">
                <div className="w-1 h-8 bg-primary/40 absolute top-0" />
                <div className="w-1 h-8 bg-primary/40 absolute bottom-0" />
                <div className="h-1 w-8 bg-primary/40 absolute left-0" />
                <div className="h-1 w-8 bg-primary/40 absolute right-0" />
              </div>
            </div>

            {/* The Pets */}
            <div className="relative z-10 flex items-center justify-center w-full h-full">
              {/* Main User Companion */}
              <div className="flex flex-col items-center gap-8 animate-in zoom-in duration-700">
                <div
                  className={cn("transition-all duration-1000", petState.class)}
                />
                <div className="text-center space-y-1">
                  <h3 className="text-xl font-bold text-primary tracking-widest uppercase">
                    {petState.name}
                  </h3>
                  <p className="text-[10px] text-primary/70 font-mono">
                    CALIBRATION_PHASE_{petState.level}
                  </p>
                </div>
              </div>

              {/* Nearby Friends' Companions */}
              {isMultiUserAR && (
                <>
                  <div className="absolute top-1/4 left-1/4 flex flex-col items-center gap-4 animate-in fade-in slide-in-from-left-10 duration-1000 delay-300 opacity-60 scale-75">
                    <div className="w-24 h-24 rounded-full bg-fuchsia-500/20 animate-glow-magenta border-2 border-fuchsia-500/50" />
                    <div className="text-center">
                      <div className="text-[10px] font-bold text-fuchsia-400 uppercase tracking-tighter">
                        Sarah_Opt
                      </div>
                      <div className="text-[8px] text-fuchsia-400/70 font-mono">
                        ELITE_WISP
                      </div>
                    </div>
                  </div>
                  <div className="absolute bottom-1/4 right-1/4 flex flex-col items-center gap-4 animate-in fade-in slide-in-from-right-10 duration-1000 delay-500 opacity-40 scale-50">
                    <div className="w-20 h-20 rotate-45 bg-yellow-500/20 animate-glow-gold border border-yellow-500/50" />
                    <div className="text-center">
                      <div className="text-[10px] font-bold text-yellow-400 uppercase tracking-tighter">
                        David_Neural
                      </div>
                      <div className="text-[8px] text-yellow-400/70 font-mono">
                        SENTINEL_V2
                      </div>
                    </div>
                  </div>
                </>
              )}
            </div>

            <Button
              onClick={handleStopAR}
              variant="outline"
              className="absolute bottom-8 z-20 border-primary/50 text-primary hover:bg-primary/10 rounded-full h-12 px-8"
            >
              CLOSE AR SYNC
            </Button>
          </div>
        )}

        {/* NFT Mint Dialog */}
        <Dialog open={isMintDialogOpen} onOpenChange={setIsMintDialogOpen}>
          <DialogContent className="sm:max-w-[425px] bg-card/95 border-primary/50 backdrop-blur-md shadow-[0_0_50px_rgba(0,255,255,0.15)]">
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary/10 via-transparent to-transparent pointer-events-none" />
            <DialogHeader className="relative z-10">
              <DialogTitle className="flex items-center gap-2">
                <Hexagon className="h-5 w-5 text-primary" />
                Biometric NFT Minting
              </DialogTitle>
              <DialogDescription>
                Lock your current neural signature and 3D form onto the
                blockchain.
              </DialogDescription>
            </DialogHeader>
            <div className="py-6 flex flex-col items-center justify-center gap-6 relative z-10">
              <div className="relative w-32 h-32 rounded-full border-2 border-primary/50 overflow-hidden bg-black/50 shadow-[0_0_30px_rgba(0,255,255,0.2)]">
                <Canvas camera={{ position: [0, 0, 3] }}>
                  <ambientLight intensity={0.5} />
                  <pointLight position={[10, 10, 10]} intensity={1} />
                  <NeuralAvatar3D hrv={75} stress={40} color="#00cccc" />
                  <Environment preset="city" />
                </Canvas>
                {isMinting && (
                  <div className="absolute inset-0 bg-primary/20 backdrop-blur-sm flex items-center justify-center">
                    <Activity className="h-8 w-8 text-primary animate-spin" />
                  </div>
                )}
              </div>

              <div className="w-full space-y-3 bg-background/50 p-4 rounded-lg border border-border/50">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Entity Type</span>
                  <span className="font-mono text-primary">
                    Sovereign Optimizer
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Neural Hash</span>
                  <span className="font-mono text-xs opacity-70">
                    0x8f...3a9c
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Network Fee</span>
                  <span className="font-mono text-yellow-500">500 PTS</span>
                </div>
              </div>
            </div>
            <DialogFooter className="relative z-10">
              <Button
                className="w-full gap-2 relative overflow-hidden group"
                onClick={handleMintNFT}
                disabled={isMinting || nftMinted}
              >
                {isMinting ? (
                  <>
                    <Activity className="h-4 w-4 animate-spin" />
                    Minting...
                  </>
                ) : nftMinted ? (
                  <>
                    <Check className="h-4 w-4" />
                    Locked On-Chain
                  </>
                ) : (
                  <>
                    <Hexagon className="h-4 w-4 group-hover:animate-pulse" />
                    Mint to Blockchain
                  </>
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </main>
    </div>
  );
}
