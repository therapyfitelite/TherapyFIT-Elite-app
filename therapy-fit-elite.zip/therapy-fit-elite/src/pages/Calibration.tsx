import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import {
  Mic,
  MicOff,
  Zap,
  Activity,
  ArrowLeft,
  Trophy,
  AlertTriangle,
} from "lucide-react";
import { Logo } from "@/components/Logo";
import { useNavigate } from "react-router-dom";
import { hapticFeedback, cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import confetti from "canvas-confetti";

const MANTRAS = [
  "My neural architecture is optimized for peak performance.",
  "I am mastering my biology through conscious calibration.",
  "Sustaining high-flow states with clinical precision.",
  "Eliminating neural friction to unlock total sovereignty.",
];

export default function Calibration() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [phase, setPhase] = useState<
    | "intro"
    | "testing-audio"
    | "audio-ready"
    | "scanning"
    | "cognitive-intro"
    | "cognitive-test"
    | "complete"
  >("intro");
  const [progress, setProgress] = useState(0);
  const [testProgress, setTestProgress] = useState(0);
  const [currentMantra, setCurrentMantra] = useState(0);
  const [audioLevel, setAudioLevel] = useState(0);
  const [transcript, setTranscript] = useState("");
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const audioIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const reflexTimerRef = useRef<NodeJS.Timeout | null>(null);
  const recognitionRef = useRef<any>(null);
  const [stressLevel, setStressLevel] = useState(0);
  const [stressHistory, setStressHistory] = useState<number[]>([]);

  // Cognitive Test State
  const [reflexState, setReflexState] = useState<"waiting" | "ready" | "early">(
    "waiting",
  );
  const [reflexStartTime, setReflexStartTime] = useState<number>(0);
  const [reflexTimes, setReflexTimes] = useState<number[]>([]);
  const [finalReflex, setFinalReflex] = useState<number | null>(null);
  const [anomalyDetected, setAnomalyDetected] = useState(false);

  const startAudioTest = () => {
    setPhase("testing-audio");
    setTestProgress(0);
    hapticFeedback([30, 50, 30]);

    audioIntervalRef.current = setInterval(() => {
      setAudioLevel(Math.random() * 40); // Lower intensity for ambient noise
    }, 100);

    const duration = 3000;
    const interval = 100;
    const step = (interval / duration) * 100;

    timerRef.current = setInterval(() => {
      setTestProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timerRef.current!);
          clearInterval(audioIntervalRef.current!);
          setPhase("audio-ready");
          setAudioLevel(0);
          hapticFeedback([100, 50, 100]);
          return 100;
        }
        return prev + step;
      });
    }, interval);
  };

  const startScan = () => {
    setPhase("scanning");
    setProgress(0);
    setTranscript("");
    setStressLevel(0);
    setStressHistory([]);
    hapticFeedback([50, 30, 50]);

    audioIntervalRef.current = setInterval(() => {
      const level = Math.random() * 100;
      setAudioLevel(level);

      // Simulate stress detection based on audio variation
      setStressLevel((prev) => {
        const target = 20 + Math.random() * 30; // Normal range
        const jitter = Math.random() * 5;
        const newStress = Math.min(
          100,
          Math.max(0, prev + (target - prev) * 0.1 + jitter),
        );
        setStressHistory((h) => [...h.slice(-19), newStress]);
        return newStress;
      });
    }, 100);

    const SpeechRec =
      (window as any).SpeechRecognition ||
      (window as any).webkitSpeechRecognition;

    if (SpeechRec) {
      const recognition = new SpeechRec();
      recognition.continuous = true;
      recognition.interimResults = true;

      recognition.onresult = (event: any) => {
        let currentTranscript = "";
        for (let i = event.resultIndex; i < event.results.length; i++) {
          currentTranscript += event.results[i][0].transcript;
        }
        setTranscript(currentTranscript);

        const targetWords = MANTRAS[currentMantra]
          .toLowerCase()
          .replace(/[.,]/g, "")
          .split(" ");
        const spokenWords = currentTranscript.toLowerCase().split(" ");

        let matchCount = 0;
        targetWords.forEach((word) => {
          if (
            word.length > 2 &&
            spokenWords.some((sw) => sw.includes(word) || word.includes(sw))
          ) {
            matchCount++;
          }
        });

        const targetSignificantWords = targetWords.filter(
          (w) => w.length > 2,
        ).length;
        const matchPercentage =
          targetSignificantWords > 0
            ? Math.min(100, (matchCount / targetSignificantWords) * 100 + 10)
            : 100;

        setProgress((prev) => {
          const newProg = Math.max(prev, matchPercentage);
          if (newProg >= 90 && prev < 90) {
            setTimeout(() => {
              if (recognitionRef.current) {
                recognitionRef.current.stop();
              }
              if (timerRef.current) clearTimeout(timerRef.current as any);
              clearInterval(audioIntervalRef.current!);
              handleScanComplete();
            }, 1000);
          }
          return newProg;
        });
      };

      recognition.onerror = (event: any) => {
        console.error("Speech recognition error", event.error);
        if (event.error !== "no-speech") {
          startTimerFallback();
        }
      };

      recognition.start();
      recognitionRef.current = recognition;

      timerRef.current = setTimeout(() => {
        if (recognitionRef.current) recognitionRef.current.stop();
        clearInterval(audioIntervalRef.current!);
        handleScanComplete();
      }, 15000) as any;
    } else {
      startTimerFallback();
    }
  };

  const startTimerFallback = () => {
    if (timerRef.current) clearTimeout(timerRef.current as any);
    const duration = 10000;
    const interval = 100;
    const step = (interval / duration) * 100;

    timerRef.current = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timerRef.current as any);
          clearInterval(audioIntervalRef.current!);
          handleScanComplete();
          return 100;
        }
        return prev + step;
      });
    }, interval) as any;
  };

  const handleScanComplete = () => {
    setPhase("cognitive-intro");
    setAudioLevel(0);
    hapticFeedback([100, 50, 100]);
    toast({
      title: "Vocal Calibration Successful",
      description: "Proceeding to Cognitive Reflex Test.",
    });
  };

  const startCognitiveTest = () => {
    setPhase("cognitive-test");
    setReflexTimes([]);
    triggerNextReflex();
  };

  const triggerNextReflex = () => {
    setReflexState("waiting");
    const delay = 1500 + Math.random() * 2500; // 1.5s to 4s
    if (reflexTimerRef.current) clearTimeout(reflexTimerRef.current);
    reflexTimerRef.current = setTimeout(() => {
      setReflexState("ready");
      setReflexStartTime(Date.now());
      hapticFeedback(100);
    }, delay);
  };

  const handleReflexClick = () => {
    if (reflexState === "waiting") {
      setReflexState("early");
      if (reflexTimerRef.current) clearTimeout(reflexTimerRef.current);
      hapticFeedback([50, 50, 50]);
      setTimeout(() => {
        triggerNextReflex();
      }, 1500);
    } else if (reflexState === "ready") {
      const rt = Date.now() - reflexStartTime;
      const newTimes = [...reflexTimes, rt];
      setReflexTimes(newTimes);
      hapticFeedback(50);

      if (newTimes.length >= 3) {
        setTimeout(() => {
          handleFinalComplete(newTimes);
        }, 500);
      } else {
        triggerNextReflex();
      }
    }
  };

  const handleFinalComplete = (times: number[]) => {
    setPhase("complete");
    hapticFeedback([100, 50, 100, 50, 200]);

    const avgRt = Math.round(times.reduce((a, b) => a + b, 0) / times.length);
    setFinalReflex(avgRt);

    const currentPoints = parseInt(
      localStorage.getItem("neural_points") || "2500",
    );
    const bonus = 500;
    localStorage.setItem("neural_points", (currentPoints + bonus).toString());

    let isAnomaly = false;
    const baseline = localStorage.getItem("baseline_reflex");
    if (!baseline) {
      localStorage.setItem("baseline_reflex", avgRt.toString());
    } else {
      const baselineVal = parseInt(baseline);
      if (avgRt > baselineVal * 1.15) {
        isAnomaly = true;
        setAnomalyDetected(true);
      } else if (avgRt < baselineVal) {
        localStorage.setItem("baseline_reflex", avgRt.toString());
      }
    }

    confetti({
      particleCount: 150,
      spread: 80,
      origin: { y: 0.6 },
      colors: ["#00ffff", "#ff00ff", "#ffd700"],
    });

    if (isAnomaly) {
      toast({
        title: "⚠️ Neural Anomaly Detected",
        description: `Reflex time (${avgRt}ms) is >15% slower than baseline. High CNS fatigue probable.`,
        variant: "destructive",
      });
    } else {
      toast({
        title: "Calibration Complete",
        description: `Avg Reflex: ${avgRt}ms. +${bonus} PTS awarded.`,
      });
    }
  };

  const stopCalibration = () => {
    if (timerRef.current) clearTimeout(timerRef.current as any);
    if (timerRef.current) clearInterval(timerRef.current as any);
    if (audioIntervalRef.current) clearInterval(audioIntervalRef.current);
    if (reflexTimerRef.current) clearTimeout(reflexTimerRef.current);
    if (recognitionRef.current) {
      recognitionRef.current.stop();
      recognitionRef.current = null;
    }
    setPhase("intro");
    setProgress(0);
    setTestProgress(0);
    setAudioLevel(0);
    setTranscript("");
    setReflexTimes([]);
    setFinalReflex(null);
    setAnomalyDetected(false);
    hapticFeedback(50);
  };

  useEffect(() => {
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current as any);
      if (timerRef.current) clearInterval(timerRef.current as any);
      if (audioIntervalRef.current) clearInterval(audioIntervalRef.current);
      if (reflexTimerRef.current) clearTimeout(reflexTimerRef.current);
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, []);

  return (
    <div className="flex flex-1 flex-col bg-background text-foreground selection:bg-primary/30 selection:text-primary relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none z-0">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] rounded-full bg-primary/5 blur-[100px]"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] rounded-full bg-blue-500/5 blur-[100px]"></div>
      </div>

      <main className="flex-1 container max-w-2xl px-4 py-8 md:py-12 z-10">
        <div className="flex justify-end mb-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate("/profile")}
            className="text-muted-foreground hover:text-foreground gap-2"
          >
            <ArrowLeft className="h-4 w-4" /> Back to Profile
          </Button>
        </div>
        {phase !== "complete" ? (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="text-center space-y-4">
              <div className="inline-block rounded-lg bg-primary/10 px-3 py-1 text-sm text-primary font-medium border border-primary/20">
                Sonic Scan Mini-Game
              </div>
              <h1 className="text-3xl font-extrabold tracking-tight sm:text-4xl">
                {phase === "cognitive-intro" || phase === "cognitive-test"
                  ? "Cognitive Reflex"
                  : "Voice Calibration"}
              </h1>
              <p className="text-muted-foreground max-w-md mx-auto">
                {phase === "intro" &&
                  "First, we will test your ambient noise levels. Then, read the neural mantra aloud for 10 seconds."}
                {phase === "testing-audio" &&
                  "Analyzing environmental acoustics and microphone sensitivity..."}
                {phase === "audio-ready" &&
                  "Environment optimal. Ready to begin biometric scan."}
                {phase === "scanning" &&
                  "Read the neural mantra aloud to calibrate your vocal biomarkers."}
                {phase === "cognitive-intro" &&
                  "Vocal biomarkers verified. Proceeding to Cognitive Reflex Calibration to measure CNS fatigue."}
                {phase === "cognitive-test" &&
                  "Tap the circle as soon as it turns GREEN. We will measure 3 attempts."}
              </p>
            </div>

            <Card className="bg-card/40 border-border/50 backdrop-blur-md shadow-xl overflow-hidden">
              <CardContent className="p-8 space-y-8 text-center">
                {(phase === "intro" ||
                  phase === "testing-audio" ||
                  phase === "audio-ready" ||
                  phase === "scanning") && (
                  <>
                    <div className="relative flex items-center justify-center py-12">
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div
                          className={cn(
                            "rounded-full border-2 transition-all duration-100",
                            phase === "testing-audio"
                              ? "border-blue-500/20"
                              : "border-primary/20",
                          )}
                          style={{
                            width: `${150 + audioLevel}px`,
                            height: `${150 + audioLevel}px`,
                          }}
                        />
                        <div
                          className={cn(
                            "absolute rounded-full border-2 transition-all duration-150",
                            phase === "testing-audio"
                              ? "border-blue-500/10"
                              : "border-primary/10",
                          )}
                          style={{
                            width: `${200 + audioLevel * 1.5}px`,
                            height: `${200 + audioLevel * 1.5}px`,
                          }}
                        />
                      </div>

                      <div
                        className={cn(
                          "relative z-10 w-24 h-24 rounded-full flex items-center justify-center transition-all duration-300",
                          phase === "scanning" || phase === "testing-audio"
                            ? "scale-110"
                            : "bg-secondary text-muted-foreground",
                          phase === "scanning" &&
                            "bg-primary text-primary-foreground shadow-[0_0_30px_rgba(0,255,255,0.5)]",
                          phase === "testing-audio" &&
                            "bg-blue-500 text-white shadow-[0_0_30px_rgba(59,130,246,0.5)]",
                          phase === "audio-ready" &&
                            "bg-green-500/20 text-green-500 border border-green-500/50 shadow-[0_0_30px_rgba(34,197,94,0.2)]",
                        )}
                      >
                        {phase === "scanning" || phase === "testing-audio" ? (
                          <Mic className="w-10 h-10 animate-pulse" />
                        ) : (
                          <MicOff className="w-10 h-10" />
                        )}
                      </div>
                    </div>
                  </>
                )}

                {phase === "cognitive-test" && (
                  <div className="relative flex flex-col items-center justify-center py-8 space-y-6">
                    <div className="flex gap-2 justify-center mb-4">
                      {[0, 1, 2].map((i) => (
                        <div
                          key={i}
                          className={cn(
                            "w-3 h-3 rounded-full transition-all",
                            i < reflexTimes.length
                              ? "bg-primary shadow-[0_0_10px_rgba(0,255,255,0.8)]"
                              : "bg-secondary border border-border",
                          )}
                        />
                      ))}
                    </div>

                    <div
                      onClick={handleReflexClick}
                      className={cn(
                        "w-48 h-48 rounded-full flex items-center justify-center cursor-pointer transition-all duration-150 select-none shadow-2xl active:scale-95",
                        reflexState === "waiting" &&
                          "bg-destructive/80 text-white border-4 border-destructive/50 shadow-[0_0_40px_rgba(255,0,0,0.4)]",
                        reflexState === "ready" &&
                          "bg-green-500 text-white border-4 border-green-400 shadow-[0_0_60px_rgba(34,197,94,0.6)] scale-105",
                        reflexState === "early" &&
                          "bg-orange-500 text-white border-4 border-orange-400 shadow-[0_0_40px_rgba(249,115,22,0.4)]",
                      )}
                    >
                      <span className="text-2xl font-black tracking-widest uppercase">
                        {reflexState === "waiting"
                          ? "WAIT"
                          : reflexState === "ready"
                            ? "TAP NOW"
                            : "TOO EARLY"}
                      </span>
                    </div>

                    {reflexTimes.length > 0 && (
                      <div className="text-sm font-mono text-muted-foreground mt-4">
                        Last:{" "}
                        <span className="text-primary font-bold">
                          {reflexTimes[reflexTimes.length - 1]}ms
                        </span>
                      </div>
                    )}
                  </div>
                )}

                <div className="space-y-6">
                  {phase === "testing-audio" && (
                    <div className="space-y-2">
                      <div className="flex justify-between text-xs font-mono text-blue-400">
                        <span>CALIBRATING ENVIRONMENT</span>
                        <span>{Math.floor(testProgress)}%</span>
                      </div>
                      <Progress
                        value={testProgress}
                        className="h-2 [&>div]:bg-blue-500"
                      />
                    </div>
                  )}

                  {phase === "audio-ready" && (
                    <div className="p-4 bg-green-500/10 rounded-xl border border-green-500/30 text-green-500 text-sm font-medium animate-in fade-in zoom-in duration-300">
                      Audio Environment Verified. Proceed to Sonic Scan.
                    </div>
                  )}

                  {(phase === "intro" ||
                    phase === "scanning" ||
                    phase === "audio-ready") && (
                    <div
                      className={cn(
                        "p-6 bg-secondary/30 rounded-xl border border-border/50 min-h-[100px] flex items-center justify-center italic text-lg leading-relaxed transition-opacity",
                        (phase === "intro" || phase === "audio-ready") &&
                          "opacity-50",
                      )}
                    >
                      "{MANTRAS[currentMantra]}"
                    </div>
                  )}

                  {phase === "scanning" && (
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <div className="flex justify-between text-xs font-mono text-primary/70">
                          <span>BIOMETRIC SYNC</span>
                          <span>{Math.floor(progress)}%</span>
                        </div>
                        <Progress value={progress} className="h-2" />
                      </div>
                      {transcript && (
                        <div className="text-xs text-muted-foreground italic bg-background/50 p-3 rounded-md border border-border/30 text-left h-16 overflow-y-auto">
                          <span className="text-primary font-mono mr-2">
                            TRANSCRIPT:
                          </span>
                          {transcript}
                        </div>
                      )}
                      <div className="space-y-3 pt-2">
                        <div className="flex justify-between items-center text-[10px] font-mono">
                          <span className="text-muted-foreground uppercase tracking-widest">
                            Voice Tone Stress Analysis
                          </span>
                          <span
                            className={cn(
                              "font-bold",
                              stressLevel > 60
                                ? "text-destructive"
                                : stressLevel > 30
                                  ? "text-orange-500"
                                  : "text-primary",
                            )}
                          >
                            {stressLevel > 60
                              ? "HIGH TENSION"
                              : stressLevel > 30
                                ? "MODERATE"
                                : "OPTIMAL"}
                          </span>
                        </div>
                        <div className="flex gap-1 h-8 items-end">
                          {stressHistory.map((val, i) => (
                            <div
                              key={i}
                              className={cn(
                                "flex-1 rounded-t-sm transition-all duration-300",
                                val > 60
                                  ? "bg-destructive/60"
                                  : val > 30
                                    ? "bg-orange-500/60"
                                    : "bg-primary/60",
                              )}
                              style={{ height: `${Math.max(10, val)}%` }}
                            />
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                <div className="pt-4">
                  {phase === "intro" && (
                    <Button
                      size="lg"
                      className="w-full h-14 text-lg gap-2 shadow-[0_0_20px_rgba(0,255,255,0.2)]"
                      onClick={startAudioTest}
                    >
                      <Mic className="w-5 h-5" />
                      START AUDIO CALIBRATION
                    </Button>
                  )}
                  {phase === "testing-audio" && (
                    <Button
                      size="lg"
                      variant="outline"
                      className="w-full h-14 text-lg gap-2 border-blue-500/50 text-blue-400"
                      disabled
                    >
                      <Mic className="w-5 h-5 animate-pulse" />
                      TESTING AMBIENT NOISE...
                    </Button>
                  )}
                  {phase === "audio-ready" && (
                    <Button
                      size="lg"
                      className="w-full h-14 text-lg gap-2 shadow-[0_0_20px_rgba(0,255,255,0.2)]"
                      onClick={startScan}
                    >
                      <Mic className="w-5 h-5" />
                      START SONIC SCAN
                    </Button>
                  )}
                  {phase === "scanning" && (
                    <Button
                      size="lg"
                      variant="destructive"
                      className="w-full h-14 text-lg gap-2"
                      onClick={stopCalibration}
                    >
                      <MicOff className="w-5 h-5" />
                      ABORT SCAN
                    </Button>
                  )}
                  {phase === "cognitive-intro" && (
                    <Button
                      size="lg"
                      className="w-full h-14 text-lg gap-2 shadow-[0_0_20px_rgba(0,255,255,0.2)]"
                      onClick={startCognitiveTest}
                    >
                      <Zap className="w-5 h-5" />
                      START REFLEX TEST
                    </Button>
                  )}
                  {phase === "cognitive-test" && (
                    <Button
                      size="lg"
                      variant="destructive"
                      className="w-full h-14 text-lg gap-2"
                      onClick={stopCalibration}
                    >
                      ABORT TEST
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>

            {(phase === "intro" ||
              phase === "testing-audio" ||
              phase === "audio-ready" ||
              phase === "scanning") && (
              <Card className="bg-card/40 border-border/50 p-6 max-w-sm mx-auto">
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-xs font-mono text-muted-foreground uppercase tracking-widest">
                    <Activity className="w-3 h-3 text-primary" />
                    Voice Tone Synthesis
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-left">
                      <div className="text-[10px] text-muted-foreground uppercase">
                        Mean Stress
                      </div>
                      <div className="text-xl font-bold text-primary">24%</div>
                    </div>
                    <div className="text-left">
                      <div className="text-[10px] text-muted-foreground uppercase">
                        Stability
                      </div>
                      <div className="text-xl font-bold text-primary">98%</div>
                    </div>
                  </div>
                  <div className="pt-2 border-t border-border/20 text-[10px] text-muted-foreground italic">
                    "No micro-tremors detected. Vocal biomarkers indicate high
                    cognitive readiness."
                  </div>
                </div>
              </Card>
            )}

            <div className="grid grid-cols-2 gap-4">
              <Card className="bg-card/40 border-border/50 p-4 flex items-center gap-3">
                <div className="bg-primary/10 p-2 rounded-lg text-primary">
                  <Zap className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-sm font-bold">500 PTS</div>
                  <div className="text-[10px] text-muted-foreground">
                    Reward Pool
                  </div>
                </div>
              </Card>
              <Card className="bg-card/40 border-border/50 p-4 flex items-center gap-3">
                <div className="bg-primary/10 p-2 rounded-lg text-primary">
                  <Activity className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-sm font-bold">Sonic Scan</div>
                  <div className="text-[10px] text-muted-foreground">
                    Calibration Mode
                  </div>
                </div>
              </Card>
            </div>
          </div>
        ) : (
          <div className="space-y-8 animate-in zoom-in-95 duration-500 py-12 text-center">
            <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-primary/20 mb-4 border border-primary/50 shadow-[0_0_40px_rgba(0,255,255,0.3)]">
              <Trophy className="w-12 h-12 text-primary" />
            </div>

            <div className="space-y-4">
              <h2 className="text-4xl font-extrabold tracking-tight">
                CALIBRATION COMPLETE
              </h2>
              <p className="text-muted-foreground text-lg max-w-md mx-auto">
                Vocal biomarkers and cognitive reflex have been calibrated
                successfully. Your system is now synchronized with the
                TherapyFIT Elite protocol.
              </p>
            </div>

            {anomalyDetected && (
              <div className="p-4 bg-destructive/10 border border-destructive/30 rounded-lg text-left space-y-2 max-w-sm mx-auto mb-6">
                <div className="flex items-center gap-2 text-destructive font-bold">
                  <AlertTriangle className="w-5 h-5" />
                  <span>Neural Anomaly Alert</span>
                </div>
                <p className="text-sm text-destructive/90">
                  Your cognitive reflex has dropped {">"}15% below your
                  baseline. High CNS fatigue probable. We recommend prioritizing
                  recovery protocols.
                </p>
              </div>
            )}

            <Card className="bg-card/40 border-border/50 p-6 max-w-sm mx-auto space-y-4">
              <div className="flex justify-between items-center">
                <div className="text-left">
                  <div className="text-sm text-muted-foreground">
                    Points Earned
                  </div>
                  <div className="text-2xl font-bold text-primary">
                    +500 PTS
                  </div>
                </div>
                <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <Zap className="w-6 h-6 text-primary fill-primary" />
                </div>
              </div>
              {finalReflex !== null && (
                <div className="flex justify-between items-center pt-4 border-t border-border/50">
                  <div className="text-left">
                    <div className="text-sm text-muted-foreground">
                      Avg Reflex Time
                    </div>
                    <div
                      className={cn(
                        "text-2xl font-bold font-mono",
                        anomalyDetected ? "text-destructive" : "text-primary",
                      )}
                    >
                      {finalReflex}ms
                    </div>
                  </div>
                  <div className="h-12 w-12 rounded-full bg-secondary flex items-center justify-center">
                    <Activity className="w-6 h-6 text-muted-foreground" />
                  </div>
                </div>
              )}
            </Card>

            <div className="pt-8 flex flex-col gap-4">
              <Button
                size="lg"
                className="h-14 px-10 text-lg w-full shadow-[0_0_20px_rgba(0,200,200,0.2)]"
                onClick={() => navigate("/profile")}
              >
                RETURN TO PROFILE
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="h-14 px-10 text-lg w-full border-primary/50 text-primary hover:bg-primary/10"
                onClick={() => {
                  setPhase("intro");
                  setCurrentMantra((prev) => (prev + 1) % MANTRAS.length);
                }}
              >
                CALIBRATE AGAIN
              </Button>
            </div>
          </div>
        )}
      </main>
      <div className="fixed bottom-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-primary/50 to-transparent opacity-30"></div>
    </div>
  );
}
