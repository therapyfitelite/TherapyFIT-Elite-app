import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Slider } from "@/components/ui/slider";
import { Progress } from "@/components/ui/progress";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  ArrowRight,
  ArrowLeft,
  ShieldCheck,
  Activity,
  Download,
  Flame,
  Trophy,
  Volume2,
  VolumeX,
  Wind,
  HeartPulse,
} from "lucide-react";
import { Logo } from "@/components/Logo";
import { useNavigate } from "react-router-dom";
import { cn, hapticFeedback } from "@/lib/utils";
import confetti from "canvas-confetti";
import { useToast } from "@/hooks/use-toast";

const TOTAL_STEPS = 6;

const formSchema = z.object({
  cognitiveLoad: z.array(z.number()),
  sleepQuality: z.enum(["optimal", "average", "fragmented", "depleted"], {
    required_error: "Please select your sleep quality.",
  }),
  physicalSymptoms: z.enum(["jaw", "shoulders", "breath", "none"], {
    required_error: "Please select a physical symptom.",
  }),
  heartRate: z.number().optional(),
  respiratoryRate: z.number().optional(),
  name: z.string().min(2, "Name must be at least 2 characters."),
  email: z.string().email("Please enter a valid email address."),
});

type FormValues = z.infer<typeof formSchema>;

export default function Audit() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [step, setStep] = useState(1);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analyzeProgress, setAnalyzeProgress] = useState(0);
  const [milestoneReached, setMilestoneReached] = useState<number | null>(null);
  const [isNarrating, setIsNarrating] = useState(false);
  const [isScanningHR, setIsScanningHR] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [isScanningResp, setIsScanningResp] = useState(false);
  const [scanRespProgress, setScanRespProgress] = useState(0);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      cognitiveLoad: [50],
      sleepQuality: "average",
      physicalSymptoms: "none",
      name: "",
      email: "",
    },
  });

  const handleNext = async () => {
    let isValid = false;

    if (step === 1) {
      isValid = await form.trigger(["cognitiveLoad"]);
    } else if (step === 2) {
      isValid = await form.trigger(["sleepQuality"]);
    } else if (step === 3) {
      isValid = await form.trigger(["physicalSymptoms"]);
    } else if (step === 4) {
      if (!form.getValues("heartRate")) {
        toast({
          title: "Calibration Required",
          description: "Please complete the biometric pulse scan to continue.",
          variant: "destructive",
        });
        isValid = false;
      } else {
        isValid = true;
      }
    } else if (step === 5) {
      if (!form.getValues("respiratoryRate")) {
        toast({
          title: "Calibration Required",
          description: "Please complete the respiratory rate scan to continue.",
          variant: "destructive",
        });
        isValid = false;
      } else {
        isValid = true;
      }
    } else if (step === 6) {
      isValid = await form.trigger(["name", "email"]);
    }

    if (isValid) {
      hapticFeedback(10);
      if (step < TOTAL_STEPS) {
        setStep(step + 1);
      } else if (step === TOTAL_STEPS) {
        hapticFeedback([50, 30, 50]);
        startAnalysis(form.getValues());
      }
    } else {
      hapticFeedback(100);
    }
  };

  const startHRScan = () => {
    setIsScanningHR(true);
    setScanProgress(0);
    hapticFeedback([30, 50, 30]);

    let progress = 0;
    const interval = setInterval(() => {
      progress += 2;
      setScanProgress(progress);

      if (progress % 20 === 0) {
        hapticFeedback([20, 30, 20]);
      }

      if (progress >= 100) {
        clearInterval(interval);
        setIsScanningHR(false);
        hapticFeedback([100, 50, 100]);
        const hr = Math.floor(Math.random() * 30) + 55;
        form.setValue("heartRate", hr);
      }
    }, 100);
  };

  const startRespScan = () => {
    setIsScanningResp(true);
    setScanRespProgress(0);
    hapticFeedback([30, 50, 30]);

    let progress = 0;
    const interval = setInterval(() => {
      progress += 1.5;
      setScanRespProgress(progress);

      if (Math.floor(progress) % 25 === 0) {
        hapticFeedback([20, 50, 20]);
      }

      if (progress >= 100) {
        clearInterval(interval);
        setIsScanningResp(false);
        hapticFeedback([100, 50, 100]);
        const rr = Math.floor(Math.random() * 10) + 12;
        form.setValue("respiratoryRate", rr);
      }
    }, 100);
  };

  const handleBack = () => {
    hapticFeedback(10);
    if (step > 1) {
      setStep(step - 1);
    } else {
      navigate("/");
    }
  };

  const startAnalysis = (data: FormValues) => {
    setIsAnalyzing(true);
    let progress = 0;

    const trackingPayload = {
      type: "external_form_submission",
      timestamp: Date.now(),
      formId: "Neural Audit Form",
      formData: {
        first_name: data.name,
        email: data.email,
        "contact.cognitive_load": data.cognitiveLoad[0].toString(),
        "contact.sleep_quality": data.sleepQuality,
        "contact.physical_symptoms": data.physicalSymptoms,
        "contact.heart_rate": data.heartRate?.toString() || "",
        "contact.respiratory_rate": data.respiratoryRate?.toString() || "",
      },
      formLabels: {
        first_name: "Full Name",
        email: "Email",
        "contact.cognitive_load": "Cognitive Load",
        "contact.sleep_quality": "Sleep Quality",
        "contact.physical_symptoms": "Physical Symptoms",
        "contact.heart_rate": "Heart Rate",
        "contact.respiratory_rate": "Respiratory Rate",
      },
      url: window.location.href,
      title: document.title,
      path: window.location.pathname,
      userAgent: navigator.userAgent,
      trackingId: "tk_203929da611c498eae0b8678a61b5230",
      locationId: "qhFuzmkiP99Jv4XH26ce",
      sessionId:
        typeof crypto !== "undefined" && crypto.randomUUID
          ? crypto.randomUUID()
          : Math.random().toString(36).substring(2),
      properties: {
        deviceType: /Mobile|Android|iPhone/i.test(navigator.userAgent)
          ? "mobile"
          : "desktop",
      },
    };

    fetch("https://backend.leadconnectorhq.com/external-tracking/events", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        version: "2021-07-28",
      },
      body: JSON.stringify(trackingPayload),
    }).catch(() => {});

    const interval = setInterval(() => {
      progress += 5;
      setAnalyzeProgress(progress);
      if (progress >= 100) {
        clearInterval(interval);
        hapticFeedback([100, 50, 100]);

        try {
          const lastAuditDate = localStorage.getItem("last_audit_date");
          const today = new Date().toISOString().split("T")[0];
          let newStreak = parseInt(localStorage.getItem("daily_streak") || "0");

          if (lastAuditDate !== today) {
            newStreak += 1;
            localStorage.setItem("daily_streak", newStreak.toString());
            localStorage.setItem("last_audit_date", today);
          }

          const milestones = [7, 14, 21, 30, 50, 100, 365];
          if (milestones.includes(newStreak) || newStreak % 30 === 0) {
            setMilestoneReached(newStreak);
          }
        } catch (e) {
          console.warn("Storage access denied", e);
        }

        setTimeout(() => {
          setIsAnalyzing(false);
          setStep(7); // Results step
        }, 500);
      }
    }, 150);
  };

  const handleExport = () => {
    hapticFeedback(10);
    const data = form.getValues();
    const reportContent = `THERAPYFIT ELITE - NEURAL AUDIT REPORT
--------------------------------------
Date: ${new Date().toLocaleDateString()}
Name: ${data.name}
Email: ${data.email}

DIAGNOSTICS:
- Cognitive Load: ${data.cognitiveLoad[0]}/100
- Sleep Architecture: ${data.sleepQuality}
- Physical Friction: ${data.physicalSymptoms}
- Resting Heart Rate: ${data.heartRate} BPM
- Respiratory Rate: ${data.respiratoryRate} Breaths/Min

STATUS: Analysis Complete
RECOMMENDATION: Proceed to Protocol integration.
`;

    const blob = new Blob([reportContent], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `Neural_Audit_${data.name.replace(/\s+/g, "_") || "Report"}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const narrateResults = () => {
    if (typeof window === "undefined" || !window.speechSynthesis) return;

    if (isNarrating) {
      window.speechSynthesis.cancel();
      setIsNarrating(false);
      return;
    }

    hapticFeedback(10);
    const data = form.getValues();
    const text = `Neural Audit for ${data.name} is complete. Your cognitive load is calibrated at ${data.cognitiveLoad[0]} percent. Your recovery architecture is classified as ${data.sleepQuality}. Your physical friction is manifesting as ${data.physicalSymptoms}. Your resting heart rate is ${data.heartRate} beats per minute. Your respiratory rate is ${data.respiratoryRate} breaths per minute. Your neural profile is now synchronized. Proceed to protocol integration.`;

    const utterance = new SpeechSynthesisUtterance(text);

    // Attempt to find a high-quality "Neural" sounding voice
    const voices = window.speechSynthesis.getVoices();
    const preferredVoice = voices.find(
      (v) =>
        v.name.includes("Google UK English Male") ||
        v.name.includes("Samantha") ||
        v.name.includes("Daniel"),
    );

    if (preferredVoice) utterance.voice = preferredVoice;
    utterance.pitch = 0.9; // Slightly deeper for clinical tone
    utterance.rate = 0.95; // Slightly slower for authoritative tone

    utterance.onstart = () => setIsNarrating(true);
    utterance.onend = () => setIsNarrating(false);
    utterance.onerror = () => setIsNarrating(false);

    window.speechSynthesis.speak(utterance);
  };

  const renderStep = () => {
    if (isAnalyzing) {
      return (
        <div className="flex flex-col items-center justify-center py-12 space-y-8 text-center">
          <div className="relative flex items-center justify-center w-24 h-24">
            <div className="absolute inset-0 rounded-full border-4 border-primary/20 border-t-primary animate-spin"></div>
            <Logo
              iconClassName="w-10 h-10"
              showText={false}
              className="animate-pulse"
            />
          </div>
          <div className="space-y-4 w-full max-w-sm">
            <h3 className="text-2xl font-bold tracking-tight text-primary">
              Calibrating Neural Profile...
            </h3>
            <p className="text-muted-foreground text-sm">
              Analyzing biometric inputs and calculating friction index.
            </p>
            <Progress
              value={analyzeProgress}
              className="h-2 w-full bg-secondary"
            />
            <p className="text-xs text-primary/70 font-mono">
              {analyzeProgress}% COMPLETE
            </p>
          </div>
        </div>
      );
    }

    switch (step) {
      case 1:
        return (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="space-y-4">
              <h2 className="text-2xl font-bold tracking-tight">
                Phase 1: Cognitive Load
              </h2>
              <p className="text-muted-foreground">
                On an average day, how would you rate your mental fatigue by
                3:00 PM?
              </p>
            </div>
            <div className="space-y-6 pt-4">
              <FormField
                control={form.control}
                name="cognitiveLoad"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <Slider
                        value={field.value}
                        onValueChange={field.onChange}
                        max={100}
                        step={1}
                        className="[&_[role=slider]]:h-5 [&_[role=slider]]:w-5 [&_[role=slider]]:border-primary"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="flex justify-between text-sm text-muted-foreground font-medium">
                <span>Sharp & Focused (0)</span>
                <span>Complete Brain Fog (100)</span>
              </div>
              <div className="flex items-center justify-center mt-8">
                <div className="inline-flex items-center justify-center rounded-full bg-secondary px-6 py-4 border border-border/50">
                  <span className="text-3xl font-bold text-primary">
                    {form.watch("cognitiveLoad")[0]}
                  </span>
                  <span className="text-muted-foreground ml-2">/ 100</span>
                </div>
              </div>
            </div>
          </div>
        );
      case 2:
        return (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="space-y-4">
              <h2 className="text-2xl font-bold tracking-tight">
                Phase 2: Recovery Architecture
              </h2>
              <p className="text-muted-foreground">
                How would you describe your sleep architecture over the last 7
                days?
              </p>
            </div>
            <FormField
              control={form.control}
              name="sleepQuality"
              render={({ field }) => (
                <FormItem className="space-y-3">
                  <FormControl>
                    <RadioGroup
                      onValueChange={field.onChange}
                      value={field.value}
                      className="space-y-3"
                    >
                      {[
                        {
                          value: "optimal",
                          label: "Optimal (7-8 hours, wake up fully restored)",
                          color: "text-green-500",
                        },
                        {
                          value: "average",
                          label: "Average (6-7 hours, slight grogginess)",
                          color: "text-yellow-500",
                        },
                        {
                          value: "fragmented",
                          label: "Fragmented (Frequent waking, restless)",
                          color: "text-orange-500",
                        },
                        {
                          value: "depleted",
                          label: "Depleted (<5 hours, wake up exhausted)",
                          color: "text-destructive",
                        },
                      ].map((option) => (
                        <FormItem
                          key={option.value}
                          className="flex items-center space-x-3 border border-border/50 p-4 rounded-lg hover:bg-secondary/50 transition-colors cursor-pointer"
                          onClick={() => field.onChange(option.value)}
                        >
                          <FormControl>
                            <RadioGroupItem value={option.value} />
                          </FormControl>
                          <FormLabel className="flex-1 cursor-pointer font-medium text-base !mt-0">
                            {option.label}
                          </FormLabel>
                        </FormItem>
                      ))}
                    </RadioGroup>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        );
      case 3:
        return (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="space-y-4">
              <h2 className="text-2xl font-bold tracking-tight">
                Phase 3: Physical Friction
              </h2>
              <p className="text-muted-foreground">
                Which subconscious physical symptom do you notice most during
                high-stress periods?
              </p>
            </div>
            <FormField
              control={form.control}
              name="physicalSymptoms"
              render={({ field }) => (
                <FormItem className="space-y-3">
                  <FormControl>
                    <RadioGroup
                      onValueChange={field.onChange}
                      value={field.value}
                      className="space-y-3"
                    >
                      {[
                        {
                          value: "jaw",
                          label: "Jaw clenching / Teeth grinding",
                        },
                        {
                          value: "shoulders",
                          label: "Elevated shoulders / Neck tension",
                        },
                        {
                          value: "breath",
                          label: "Shallow breathing / Breath holding",
                        },
                        {
                          value: "none",
                          label: "No noticeable physical symptoms",
                        },
                      ].map((option) => (
                        <FormItem
                          key={option.value}
                          className="flex items-center space-x-3 border border-border/50 p-4 rounded-lg hover:bg-secondary/50 transition-colors cursor-pointer"
                          onClick={() => field.onChange(option.value)}
                        >
                          <FormControl>
                            <RadioGroupItem value={option.value} />
                          </FormControl>
                          <FormLabel className="flex-1 cursor-pointer font-medium text-base !mt-0">
                            {option.label}
                          </FormLabel>
                        </FormItem>
                      ))}
                    </RadioGroup>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        );
      case 4:
        return (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="space-y-4">
              <h2 className="text-2xl font-bold tracking-tight">
                Phase 4: Biometric Pulse
              </h2>
              <p className="text-muted-foreground">
                Place your index finger over the camera lens to simulate
                capillary pulse detection.
              </p>
            </div>
            <div className="flex flex-col items-center justify-center py-8 space-y-8">
              <div className="relative flex items-center justify-center w-48 h-48">
                {isScanningHR && (
                  <>
                    <div
                      className="absolute inset-0 rounded-full border-4 border-destructive/20 border-t-destructive animate-spin"
                      style={{ animationDuration: "1.5s" }}
                    ></div>
                    <div className="absolute inset-4 rounded-full border border-destructive/30 animate-ping"></div>
                  </>
                )}
                <Button
                  type="button"
                  onClick={startHRScan}
                  disabled={isScanningHR || !!form.getValues("heartRate")}
                  className={cn(
                    "w-32 h-32 rounded-full flex flex-col items-center justify-center gap-2 transition-all duration-500",
                    form.getValues("heartRate")
                      ? "bg-cyan-500/20 text-cyan-500 border-2 border-cyan-500"
                      : isScanningHR
                        ? "bg-destructive/10 text-destructive"
                        : "bg-secondary text-muted-foreground hover:bg-secondary/80 hover:text-foreground",
                  )}
                >
                  <HeartPulse
                    className={cn("w-10 h-10", isScanningHR && "animate-pulse")}
                  />
                  <span className="text-sm font-bold uppercase tracking-wider">
                    {form.getValues("heartRate")
                      ? "Synced"
                      : isScanningHR
                        ? "Scanning..."
                        : "Start Scan"}
                  </span>
                </Button>
              </div>

              {isScanningHR && (
                <div className="w-full max-w-xs space-y-2">
                  <div className="flex justify-between text-xs font-mono text-destructive">
                    <span>CAPILLARY DETECTION</span>
                    <span>{scanProgress}%</span>
                  </div>
                  <Progress
                    value={scanProgress}
                    className="h-1 bg-secondary [&>div]:bg-destructive"
                  />
                </div>
              )}

              {form.getValues("heartRate") && !isScanningHR && (
                <div className="animate-in fade-in slide-in-from-bottom-4 flex flex-col items-center gap-2">
                  <div className="text-5xl font-bold text-cyan-500 drop-shadow-[0_0_15px_rgba(0,255,255,0.5)]">
                    {form.getValues("heartRate")}{" "}
                    <span className="text-xl text-muted-foreground">BPM</span>
                  </div>
                  <p className="text-sm font-medium text-cyan-500/80 uppercase tracking-widest">
                    Baseline Calibrated
                  </p>
                </div>
              )}
            </div>
          </div>
        );
      case 5:
        return (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="space-y-4">
              <h2 className="text-2xl font-bold tracking-tight">
                Phase 5: Respiratory Rate
              </h2>
              <p className="text-muted-foreground">
                Please remain quiet and breathe normally. The system will
                analyze ambient audio to detect your respiratory rate.
              </p>
            </div>
            <div className="flex flex-col items-center justify-center py-8 space-y-8">
              <div className="relative flex items-center justify-center w-48 h-48">
                {isScanningResp && (
                  <>
                    <div
                      className="absolute inset-0 rounded-full border-4 border-cyan-500/20 border-t-cyan-500 animate-spin"
                      style={{ animationDuration: "3s" }}
                    ></div>
                    <div
                      className="absolute inset-4 rounded-full border border-cyan-500/30 animate-ping"
                      style={{ animationDuration: "2s" }}
                    ></div>
                  </>
                )}
                <Button
                  type="button"
                  onClick={startRespScan}
                  disabled={
                    isScanningResp || !!form.getValues("respiratoryRate")
                  }
                  className={cn(
                    "w-32 h-32 rounded-full flex flex-col items-center justify-center gap-2 transition-all duration-500",
                    form.getValues("respiratoryRate")
                      ? "bg-cyan-500/20 text-cyan-500 border-2 border-cyan-500"
                      : isScanningResp
                        ? "bg-cyan-500/10 text-cyan-500"
                        : "bg-secondary text-muted-foreground hover:bg-secondary/80 hover:text-foreground",
                  )}
                >
                  <Wind
                    className={cn(
                      "w-10 h-10",
                      isScanningResp && "animate-pulse",
                    )}
                  />
                  <span className="text-sm font-bold uppercase tracking-wider">
                    {form.getValues("respiratoryRate")
                      ? "Synced"
                      : isScanningResp
                        ? "Listening..."
                        : "Start Scan"}
                  </span>
                </Button>
              </div>

              {isScanningResp && (
                <div className="w-full max-w-xs space-y-2">
                  <div className="flex justify-between text-xs font-mono text-cyan-500">
                    <span>AUDIO ANALYSIS</span>
                    <span>{Math.floor(scanRespProgress)}%</span>
                  </div>
                  <Progress
                    value={scanRespProgress}
                    className="h-1 bg-secondary [&>div]:bg-cyan-500"
                  />
                </div>
              )}

              {form.getValues("respiratoryRate") && !isScanningResp && (
                <div className="animate-in fade-in slide-in-from-bottom-4 flex flex-col items-center gap-2">
                  <div className="text-5xl font-bold text-cyan-500 drop-shadow-[0_0_15px_rgba(0,255,255,0.5)]">
                    {form.getValues("respiratoryRate")}{" "}
                    <span className="text-xl text-muted-foreground">
                      Breaths/Min
                    </span>
                  </div>
                  <p className="text-sm font-medium text-cyan-500/80 uppercase tracking-widest">
                    Baseline Calibrated
                  </p>
                </div>
              )}
            </div>
          </div>
        );
      case 6:
        return (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="space-y-4">
              <h2 className="text-2xl font-bold tracking-tight">
                Final Phase: Secure Your Report
              </h2>
              <p className="text-muted-foreground">
                Enter your details to generate your personalized Neural Friction
                Index and baseline protocol.
              </p>
            </div>
            <div className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem className="space-y-2">
                    <FormLabel>Full Name</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="John Doe"
                        className="h-12 bg-secondary/30"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem className="space-y-2">
                    <FormLabel>Secure Email</FormLabel>
                    <FormControl>
                      <Input
                        type="email"
                        placeholder="john@example.com"
                        className="h-12 bg-secondary/30"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="flex items-center gap-2 text-xs text-muted-foreground mt-4 bg-primary/5 p-3 rounded-md border border-primary/10">
                <ShieldCheck className="w-4 h-4 text-primary" />
                <span>Your data is encrypted and strictly confidential.</span>
              </div>
            </div>
          </div>
        );
      case 7:
        if (milestoneReached) {
          setTimeout(() => {
            const end = Date.now() + 3 * 1000;
            const colors = ["#00ffff", "#ff00ff", "#ffd700"];

            (function frame() {
              confetti({
                particleCount: 3,
                angle: 60,
                spread: 55,
                origin: { x: 0 },
                colors: colors,
              });
              confetti({
                particleCount: 3,
                angle: 120,
                spread: 55,
                origin: { x: 1 },
                colors: colors,
              });

              if (Date.now() < end) {
                requestAnimationFrame(frame);
              }
            })();
          }, 100);
        }

        return (
          <div className="space-y-8 animate-in fade-in zoom-in-95 duration-500 py-8 text-center">
            {milestoneReached ? (
              <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-orange-500/20 mb-4 border border-orange-500/50 shadow-[0_0_30px_rgba(249,115,22,0.4)] animate-pulse">
                <Trophy className="w-12 h-12 text-orange-500" />
              </div>
            ) : (
              <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-primary/10 mb-4">
                <Activity className="w-10 h-10 text-primary" />
              </div>
            )}

            <div className="space-y-4">
              <h2 className="text-3xl font-extrabold tracking-tight">
                {milestoneReached
                  ? `${milestoneReached} DAY STREAK!`
                  : "Audit Complete"}
              </h2>
              <p className="text-muted-foreground text-lg max-w-md mx-auto">
                {milestoneReached
                  ? "Incredible dedication. You've reached a major neural calibration milestone. Your commitment to peak performance is paying off."
                  : `Your Neural Friction Index has been calculated. We've sent the full diagnostic report and baseline protocol to `}
                {!milestoneReached && (
                  <strong className="text-foreground">
                    {form.getValues("email")}
                  </strong>
                )}
              </p>
            </div>
            <div className="pt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button
                size="lg"
                className="h-14 px-10 text-lg w-full sm:w-auto shadow-[0_0_20px_rgba(0,200,200,0.2)]"
                onClick={() => navigate("/")}
              >
                RETURN TO DASHBOARD
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="h-14 px-10 text-lg w-full sm:w-auto border-primary/50 text-primary hover:bg-primary/10 gap-2"
                onClick={() => navigate("/breathing")}
              >
                <Wind className="h-5 w-5" />
                NEURAL BREATH RECOVERY
              </Button>
              <Button
                size="lg"
                variant="outline"
                className={cn(
                  "h-14 px-10 text-lg w-full sm:w-auto border-primary/50 text-primary hover:bg-primary/10 gap-2",
                  isNarrating && "bg-primary/10 animate-pulse",
                )}
                onClick={narrateResults}
              >
                {isNarrating ? (
                  <VolumeX className="h-5 w-5" />
                ) : (
                  <Volume2 className="h-5 w-5" />
                )}
                {isNarrating ? "STOP NARRATION" : "LISTEN TO ANALYSIS"}
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="h-14 px-10 text-lg w-full sm:w-auto border-primary/50 text-primary hover:bg-primary/10 gap-2"
                onClick={handleExport}
              >
                <Download className="h-5 w-5" />
                EXPORT REPORT
              </Button>
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="flex-1 bg-background flex flex-col items-center py-6 md:py-12 px-4 sm:px-6 lg:px-8 selection:bg-primary/30 selection:text-primary relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none z-0">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] rounded-full bg-primary/5 blur-[100px]"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] rounded-full bg-blue-500/5 blur-[100px]"></div>
      </div>

      <div className="w-full max-w-2xl z-10 flex-1 flex flex-col">
        <div className="flex items-center justify-between mb-8 md:mb-12">
          <div
            className="flex items-center gap-2 cursor-pointer"
            onClick={() => navigate("/")}
          >
            <Logo iconClassName="h-7 w-7 md:h-8 md:w-8" />
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1 text-orange-500 font-bold bg-orange-500/10 px-2 py-1 rounded-md border border-orange-500/20">
              <Flame className="w-4 h-4" />
              <span>
                {parseInt(localStorage.getItem("daily_streak") || "7")}
              </span>
            </div>
            {step < 7 && !isAnalyzing && (
              <div className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <span className="text-primary">Phase {step}</span> /{" "}
                {TOTAL_STEPS}
              </div>
            )}
          </div>
        </div>

        <Card className="border-border/50 bg-card/40 backdrop-blur-md shadow-xl overflow-hidden relative flex-1 flex flex-col">
          {step < 7 && !isAnalyzing && (
            <div className="absolute top-0 left-0 w-full h-1.5 bg-secondary overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-primary via-blue-400 to-primary bg-[length:200%_auto] animate-[pulse_3s_ease-in-out_infinite] transition-all duration-700 ease-out relative"
                style={{ width: `${(step / TOTAL_STEPS) * 100}%` }}
              >
                <div className="absolute inset-0 -translate-x-full animate-shimmer bg-gradient-to-r from-transparent via-white/40 to-transparent"></div>
              </div>
            </div>
          )}

          <Form {...form}>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleNext();
              }}
              className="flex-1 flex flex-col"
            >
              <CardContent className="p-6 sm:p-10 flex-1">
                {renderStep()}
              </CardContent>

              {step < 7 && !isAnalyzing && (
                <CardFooter className="px-6 pb-6 sm:px-10 flex justify-between border-t border-border/30 pt-6 mt-auto">
                  <Button
                    type="button"
                    variant="ghost"
                    onClick={handleBack}
                    className="text-muted-foreground hover:text-foreground"
                  >
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    <span className="hidden sm:inline">
                      {step === 1 ? "Cancel" : "Back"}
                    </span>
                  </Button>
                  <Button
                    type="submit"
                    className="shadow-[0_0_15px_rgba(0,200,200,0.2)] hover:shadow-[0_0_25px_rgba(0,200,200,0.4)] transition-all"
                  >
                    {step === TOTAL_STEPS ? "Generate Report" : "Continue"}
                    {step !== TOTAL_STEPS && (
                      <ArrowRight className="w-4 h-4 ml-2" />
                    )}
                  </Button>
                </CardFooter>
              )}
            </form>
          </Form>
        </Card>
      </div>
    </div>
  );
}
