import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Shield,
  Zap,
  Network,
  Activity,
  ArrowLeft,
  Lock,
  Unlock,
  Cpu,
  Target,
  Sparkles,
} from "lucide-react";
import { Logo } from "@/components/Logo";
import { hapticFeedback, cn } from "@/lib/utils";
import { toast } from "sonner";

const INITIAL_NODES = [
  {
    id: "t1_1",
    tier: 1,
    name: "Basic Dampeners",
    desc: "-5% Sector Friction",
    cost: 0,
    unlocked: true,
    icon: Shield,
    color: "text-blue-400",
  },
  {
    id: "t1_2",
    tier: 1,
    name: "Localized Sync",
    desc: "+10% Node Range",
    cost: 0,
    unlocked: true,
    icon: Activity,
    color: "text-primary",
  },
  {
    id: "t1_3",
    tier: 1,
    name: "Nano-Repair",
    desc: "Passively heals sector sync over time",
    cost: 800,
    unlocked: false,
    icon: Sparkles,
    color: "text-green-400",
  },

  {
    id: "t2_1",
    tier: 2,
    name: "Advanced Shielding",
    desc: "Unlocks Neural Shield Minigame",
    cost: 1500,
    req: ["t1_1"],
    unlocked: false,
    icon: Shield,
    color: "text-blue-400",
  },
  {
    id: "t2_2",
    tier: 2,
    name: "Overclocked Relays",
    desc: "Satellites +20% Efficiency",
    cost: 2000,
    req: ["t1_2"],
    unlocked: false,
    icon: Zap,
    color: "text-primary",
  },
  {
    id: "t2_3",
    tier: 2,
    name: "Neural Relay",
    desc: "Satellite Deployment Speed +30%",
    cost: 1800,
    req: ["t1_2"],
    unlocked: false,
    icon: Network,
    color: "text-cyan-400",
  },

  {
    id: "t3_1",
    tier: 3,
    name: "Quantum Resonance",
    desc: "Global Override Cooldown -50%",
    cost: 5000,
    req: ["t2_1", "t2_2"],
    unlocked: false,
    icon: Network,
    color: "text-fuchsia-400",
  },
  {
    id: "t3_2",
    tier: 3,
    name: "Orbital Strike",
    desc: "Unlocks Neural Strike on Global Map",
    cost: 4500,
    req: ["t2_2"],
    unlocked: false,
    icon: Target,
    color: "text-red-400",
  },
  {
    id: "t3_3",
    tier: 3,
    name: "Quantum Sync",
    desc: "Double all active biometric buffs across all sectors",
    cost: 6000,
    req: ["t2_2", "t2_3"],
    unlocked: false,
    icon: Zap,
    color: "text-yellow-400",
  },
  {
    id: "t3_4",
    tier: 3,
    name: "Neural Overclock",
    desc: "Triple all buffs temporarily (Costs +20% Friction)",
    cost: 7500,
    req: ["t3_3"],
    unlocked: false,
    icon: Cpu,
    color: "text-orange-500",
  },
];

export default function TechTree() {
  const navigate = useNavigate();
  const [nodes, setNodes] = useState(INITIAL_NODES);
  const [points, setPoints] = useState(8500);

  const handleUnlock = (nodeId: string) => {
    const node = nodes.find((n) => n.id === nodeId);
    if (!node || node.unlocked) return;

    const canUnlock = node.req?.every(
      (reqId) => nodes.find((n) => n.id === reqId)?.unlocked,
    );
    if (!canUnlock) {
      hapticFeedback(100);
      toast.error("Prerequisites not met", {
        description: "Unlock previous tier technologies first.",
      });
      return;
    }

    if (points < node.cost) {
      hapticFeedback(100);
      toast.error("Insufficient Points", {
        description: `You need ${node.cost} Neural Points.`,
      });
      return;
    }

    hapticFeedback([50, 100, 50, 100, 200]);
    setPoints((p) => p - node.cost);
    setNodes(
      nodes.map((n) => (n.id === nodeId ? { ...n, unlocked: true } : n)),
    );

    toast.success("Technology Unlocked", {
      description: `${node.name} has been integrated into your sector capabilities.`,
    });
  };

  const renderNode = (node: (typeof INITIAL_NODES)[0]) => {
    const canUnlock =
      node.req?.every((reqId) => nodes.find((n) => n.id === reqId)?.unlocked) ??
      true;
    const isAffordable = points >= node.cost;

    return (
      <Card
        key={node.id}
        className={cn(
          "w-64 relative overflow-hidden transition-all duration-500",
          node.unlocked
            ? "border-primary/50 bg-primary/5"
            : canUnlock
              ? "border-border/50 bg-card/40 hover:border-primary/30"
              : "border-border/20 bg-background/50 opacity-60",
        )}
      >
        {node.unlocked && (
          <div className="absolute inset-0 bg-primary/10 animate-pulse pointer-events-none" />
        )}
        <CardHeader className="p-4 pb-2">
          <div className="flex justify-between items-start mb-2">
            <div
              className={cn(
                "p-2 rounded-md",
                node.unlocked ? "bg-primary/20" : "bg-secondary",
              )}
            >
              <node.icon
                className={cn(
                  "h-5 w-5",
                  node.unlocked ? node.color : "text-muted-foreground",
                )}
              />
            </div>
            {node.unlocked ? (
              <Badge
                variant="outline"
                className="bg-primary/10 text-primary border-primary/20"
              >
                Unlocked
              </Badge>
            ) : (
              <Badge
                variant="outline"
                className="bg-secondary text-muted-foreground"
              >
                <Lock className="h-3 w-3 mr-1" /> {node.cost} PTS
              </Badge>
            )}
          </div>
          <CardTitle className="text-lg">{node.name}</CardTitle>
          <CardDescription className="text-xs">{node.desc}</CardDescription>
        </CardHeader>
        <CardContent className="p-4 pt-0 mt-4">
          {!node.unlocked && (
            <Button
              className="w-full text-xs h-8"
              variant={canUnlock ? "default" : "secondary"}
              disabled={!canUnlock || (!isAffordable && canUnlock)}
              onClick={() => handleUnlock(node.id)}
            >
              {canUnlock ? (isAffordable ? "RESEARCH" : "NEED PTS") : "LOCKED"}
            </Button>
          )}
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="flex flex-1 flex-col bg-background text-foreground">
      <main className="flex-1 container px-4 md:px-6 py-12 flex flex-col items-center">
        <div className="w-full flex justify-between items-center mb-8">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate("/war-room")}
            className="gap-2"
          >
            <ArrowLeft className="h-4 w-4" /> Back
          </Button>
          <Badge
            variant="outline"
            className="bg-primary/10 text-primary border-primary/20 text-sm py-1"
          >
            {points.toLocaleString()} PTS
          </Badge>
        </div>
        <div className="text-center mb-12 space-y-4 max-w-2xl">
          <h1 className="text-4xl font-extrabold tracking-tighter">
            Research & Development
          </h1>
          <p className="text-muted-foreground">
            Invest Neural Points to unlock advanced sector abilities and global
            strategic advantages. Upgrades apply permanently to your faction's
            capabilities.
          </p>
        </div>

        <div className="relative flex flex-col items-center gap-12 w-full max-w-4xl">
          {/* Background connecting lines could go here, but using flex gap for simplicity */}

          {/* Tier 1 */}
          <div className="flex flex-col items-center gap-4">
            <Badge
              variant="outline"
              className="text-xs uppercase tracking-widest text-muted-foreground mb-2"
            >
              Tier 1: Foundations
            </Badge>
            <div className="flex flex-wrap justify-center gap-8 relative z-10">
              {nodes.filter((n) => n.tier === 1).map(renderNode)}
            </div>
          </div>

          {/* Tier 2 */}
          <div className="flex flex-col items-center gap-4">
            <Badge
              variant="outline"
              className="text-xs uppercase tracking-widest text-muted-foreground mb-2"
            >
              Tier 2: Enhancements
            </Badge>
            <div className="flex flex-wrap justify-center gap-8 relative z-10">
              {nodes.filter((n) => n.tier === 2).map(renderNode)}
            </div>
          </div>

          {/* Tier 3 */}
          <div className="flex flex-col items-center gap-4">
            <Badge
              variant="outline"
              className="text-xs uppercase tracking-widest text-fuchsia-400 border-fuchsia-400/30 mb-2"
            >
              Tier 3: Mastery
            </Badge>
            <div className="flex flex-wrap justify-center gap-8 relative z-10">
              {nodes.filter((n) => n.tier === 3).map(renderNode)}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
