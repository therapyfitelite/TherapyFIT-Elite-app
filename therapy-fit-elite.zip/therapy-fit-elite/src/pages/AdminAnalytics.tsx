import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  ChevronLeft,
  Users,
  Activity,
  ShieldAlert,
  Zap,
  TrendingUp,
  Terminal,
} from "lucide-react";
import {
  AreaChart,
  Area,
  XAxis,
  Tooltip as RechartsTooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import NeuralBackground from "@/components/NeuralBackground";

const growthData = [
  { day: "01", users: 4200, active: 3100 },
  { day: "05", users: 5100, active: 3800 },
  { day: "10", users: 6800, active: 5200 },
  { day: "15", users: 8900, active: 7100 },
  { day: "20", users: 12500, active: 9800 },
  { day: "25", users: 18000, active: 14200 },
  { day: "30", users: 24500, active: 19500 },
];

const anomalyData = [
  { name: "CNS Fatigue", value: 45, color: "#dc2626" },
  { name: "HRV Strain", value: 35, color: "#ea580c" },
  { name: "Vocal Stress", value: 20, color: "#eab308" },
];

const missionData = [
  { name: "Neural Sync", completions: 12400 },
  { name: "Deep Delta", completions: 8900 },
  { name: "Vagal Tone", completions: 15200 },
  { name: "Flow State", completions: 11000 },
];

export default function AdminAnalytics() {
  const navigate = useNavigate();
  const [timeframe, setTimeframe] = useState("30D");

  return (
    <div className="relative flex flex-1 flex-col bg-black text-foreground overflow-x-hidden">
      <div className="absolute inset-0 z-0 opacity-40 pointer-events-none mix-blend-screen">
        <NeuralBackground />
      </div>

      <div className="relative z-10 flex flex-col w-full h-full max-w-5xl mx-auto px-4">
        <header className="py-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate(-1)}
              className="text-muted-foreground hover:text-foreground transition-colors"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
            <div>
              <h1 className="text-2xl font-bold tracking-tighter text-white flex items-center gap-2">
                <Terminal className="w-5 h-5 text-primary" /> OVERSEER
              </h1>
              <p className="text-xs text-primary uppercase tracking-widest">
                Global Telemetry & Analytics
              </p>
            </div>
          </div>
          <div className="flex gap-2">
            {["7D", "30D", "90D", "ALL"].map((t) => (
              <Badge
                key={t}
                variant="outline"
                className={`cursor-pointer border-white/10 transition-all ${timeframe === t ? "bg-primary/20 text-primary border-primary/50" : "text-muted-foreground hover:text-white"}`}
                onClick={() => setTimeframe(t)}
              >
                {t}
              </Badge>
            ))}
          </div>
        </header>

        <main className="flex-1 space-y-6 animate-in fade-in slide-in-from-bottom-4">
          {/* Top Stats Row */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-[#111] border border-white/5 p-5 rounded-2xl relative overflow-hidden group">
              <div className="absolute inset-0 bg-primary/5 opacity-0 group-hover:opacity-100 transition-opacity" />
              <Users className="w-5 h-5 text-primary mb-3" />
              <div className="text-xs text-muted-foreground uppercase tracking-wider mb-1">
                Total Operatives
              </div>
              <div className="text-3xl font-bold text-white">24,500</div>
              <div className="text-[10px] text-emerald-400 mt-2 flex items-center gap-1">
                <TrendingUp className="w-3 h-3" /> +12.4% this month
              </div>
            </div>

            <div className="bg-[#111] border border-white/5 p-5 rounded-2xl relative overflow-hidden group">
              <div className="absolute inset-0 bg-blue-500/5 opacity-0 group-hover:opacity-100 transition-opacity" />
              <Activity className="w-5 h-5 text-blue-400 mb-3" />
              <div className="text-xs text-muted-foreground uppercase tracking-wider mb-1">
                Active Readiness
              </div>
              <div className="text-3xl font-bold text-white">82%</div>
              <div className="text-[10px] text-emerald-400 mt-2 flex items-center gap-1">
                <TrendingUp className="w-3 h-3" /> +2.1% avg baseline
              </div>
            </div>

            <div className="bg-[#111] border border-white/5 p-5 rounded-2xl relative overflow-hidden group">
              <div className="absolute inset-0 bg-red-500/5 opacity-0 group-hover:opacity-100 transition-opacity" />
              <ShieldAlert className="w-5 h-5 text-red-500 mb-3" />
              <div className="text-xs text-muted-foreground uppercase tracking-wider mb-1">
                Anomalies Detected
              </div>
              <div className="text-3xl font-bold text-white">1,402</div>
              <div className="text-[10px] text-red-400 mt-2 flex items-center gap-1">
                <TrendingUp className="w-3 h-3" /> +5.2% vs last week
              </div>
            </div>

            <div className="bg-[#111] border border-white/5 p-5 rounded-2xl relative overflow-hidden group">
              <div className="absolute inset-0 bg-orange-500/5 opacity-0 group-hover:opacity-100 transition-opacity" />
              <Zap className="w-5 h-5 text-orange-400 mb-3" />
              <div className="text-xs text-muted-foreground uppercase tracking-wider mb-1">
                Missions Executed
              </div>
              <div className="text-3xl font-bold text-white">47.5k</div>
              <div className="text-[10px] text-emerald-400 mt-2 flex items-center gap-1">
                <TrendingUp className="w-3 h-3" /> +18.9% completion rate
              </div>
            </div>
          </div>

          {/* Charts Row 1 */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="bg-[#111] border border-white/5 p-6 rounded-2xl lg:col-span-2">
              <h3 className="text-sm font-bold text-white uppercase tracking-widest mb-1">
                Network Growth
              </h3>
              <p className="text-xs text-muted-foreground mb-6">
                Total vs Active Operatives ({timeframe})
              </p>
              <div className="h-[250px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart
                    data={growthData}
                    margin={{ top: 5, right: 0, left: 0, bottom: 0 }}
                  >
                    <defs>
                      <linearGradient
                        id="colorUsers"
                        x1="0"
                        y1="0"
                        x2="0"
                        y2="1"
                      >
                        <stop
                          offset="5%"
                          stopColor="hsl(var(--primary))"
                          stopOpacity={0.3}
                        />
                        <stop
                          offset="95%"
                          stopColor="hsl(var(--primary))"
                          stopOpacity={0}
                        />
                      </linearGradient>
                      <linearGradient
                        id="colorActive"
                        x1="0"
                        y1="0"
                        x2="0"
                        y2="1"
                      >
                        <stop
                          offset="5%"
                          stopColor="#3b82f6"
                          stopOpacity={0.3}
                        />
                        <stop
                          offset="95%"
                          stopColor="#3b82f6"
                          stopOpacity={0}
                        />
                      </linearGradient>
                    </defs>
                    <XAxis
                      dataKey="day"
                      stroke="#555"
                      fontSize={10}
                      tickLine={false}
                      axisLine={false}
                    />
                    <RechartsTooltip
                      contentStyle={{
                        backgroundColor: "#111",
                        border: "1px solid rgba(255,255,255,0.1)",
                        borderRadius: "8px",
                      }}
                      itemStyle={{ color: "#fff", fontSize: "12px" }}
                      labelStyle={{
                        color: "#888",
                        fontSize: "10px",
                        marginBottom: "4px",
                      }}
                    />
                    <Area
                      type="monotone"
                      dataKey="users"
                      stroke="hsl(var(--primary))"
                      strokeWidth={2}
                      fillOpacity={1}
                      fill="url(#colorUsers)"
                    />
                    <Area
                      type="monotone"
                      dataKey="active"
                      stroke="#3b82f6"
                      strokeWidth={2}
                      fillOpacity={1}
                      fill="url(#colorActive)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="bg-[#111] border border-white/5 p-6 rounded-2xl flex flex-col">
              <h3 className="text-sm font-bold text-white uppercase tracking-widest mb-1">
                Global Anomalies
              </h3>
              <p className="text-xs text-muted-foreground mb-2">
                Distribution by Type
              </p>
              <div className="flex-1 min-h-[200px] w-full relative">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={anomalyData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="value"
                      stroke="none"
                    >
                      {anomalyData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <RechartsTooltip
                      contentStyle={{
                        backgroundColor: "#111",
                        border: "1px solid rgba(255,255,255,0.1)",
                        borderRadius: "8px",
                      }}
                      itemStyle={{ color: "#fff", fontSize: "12px" }}
                    />
                  </PieChart>
                </ResponsiveContainer>
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-white">1.4k</div>
                    <div className="text-[10px] text-muted-foreground uppercase">
                      Total
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex flex-wrap justify-center gap-3 mt-4">
                {anomalyData.map((a, i) => (
                  <div
                    key={i}
                    className="flex items-center gap-1.5 text-[10px] uppercase tracking-wider text-muted-foreground"
                  >
                    <div
                      className="w-2 h-2 rounded-full"
                      style={{ backgroundColor: a.color }}
                    />
                    {a.name}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Charts Row 2 */}
          <div className="bg-[#111] border border-white/5 p-6 rounded-2xl">
            <h3 className="text-sm font-bold text-white uppercase tracking-widest mb-1">
              Mission Execution Volume
            </h3>
            <p className="text-xs text-muted-foreground mb-6">
              Top performing protocols across the network
            </p>
            <div className="h-[200px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={missionData}
                  margin={{ top: 0, right: 0, left: -20, bottom: 0 }}
                >
                  <XAxis
                    dataKey="name"
                    stroke="#555"
                    fontSize={10}
                    tickLine={false}
                    axisLine={false}
                  />
                  <RechartsTooltip
                    cursor={{ fill: "rgba(255,255,255,0.05)" }}
                    contentStyle={{
                      backgroundColor: "#111",
                      border: "1px solid rgba(255,255,255,0.1)",
                      borderRadius: "8px",
                    }}
                    itemStyle={{ color: "#fff", fontSize: "12px" }}
                  />
                  <Bar
                    dataKey="completions"
                    fill="hsl(var(--primary))"
                    radius={[4, 4, 0, 0]}
                    barSize={40}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
