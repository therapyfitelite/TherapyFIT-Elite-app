import { useMemo, useRef, useState, useEffect, useCallback } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { OrbitControls, Stars, Text } from "@react-three/drei";
import {
  ChevronLeft,
  Moon,
  Activity,
  Clock,
  Zap,
  Headphones,
  Play,
  Pause,
  Bell,
  Sun,
  Sunset,
  Sunrise,
  Mic,
  Wind,
  AlertCircle,
  Sparkles,
  Loader2,
  BrainCircuit,
  Image as ImageIcon,
  PieChart,
  Battery,
  Thermometer,
  Droplets,
  LightbulbOff,
  CheckCircle2,
  Coffee,
  Eye,
  EyeOff,
  Waves,
  ShieldAlert,
  TrendingUp,
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import * as THREE from "three";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { hapticFeedback, cn } from "@/lib/utils";
import {
  AreaChart,
  Area,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Tooltip,
  ReferenceLine,
} from "recharts";

// Sleep stages: 0 = Deep, 1 = Light, 2 = REM, 3 = Awake
const sleepData = [
  { time: "22:00", stage: 3, label: "Awake" },
  { time: "22:30", stage: 1, label: "Light" },
  { time: "23:00", stage: 0, label: "Deep" },
  { time: "00:00", stage: 0, label: "Deep" },
  { time: "00:30", stage: 1, label: "Light" },
  { time: "01:00", stage: 2, label: "REM" },
  { time: "01:30", stage: 1, label: "Light" },
  { time: "02:00", stage: 0, label: "Deep" },
  { time: "03:00", stage: 1, label: "Light" },
  { time: "03:30", stage: 2, label: "REM" },
  { time: "04:00", stage: 1, label: "Light" },
  { time: "05:00", stage: 2, label: "REM" },
  { time: "05:30", stage: 1, label: "Light" },
  { time: "06:00", stage: 3, label: "Awake" },
];

function SleepLandscape() {
  const meshRef = useRef<THREE.Group>(null);
  const geometry = useMemo(() => {
    const segmentsX = 60;
    const segmentsY = 20;
    const geo = new THREE.PlaneGeometry(24, 12, segmentsX, segmentsY);
    const pos = geo.attributes.position;
    const colors = [];
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const y = pos.getY(i);
      const normalizedX = (x + 12) / 24;
      const exactIndex = normalizedX * (sleepData.length - 1);
      const index = Math.min(Math.floor(exactIndex), sleepData.length - 2);
      const t = exactIndex - index;
      const stage1 = sleepData[index].stage;
      const stage2 = sleepData[index + 1].stage;
      const smoothT = t * t * (3 - 2 * t);
      const stage = THREE.MathUtils.lerp(stage1, stage2, smoothT);
      const noise =
        Math.sin(x * 3) * Math.cos(y * 2) * 0.3 + Math.sin(x * 8 + y * 4) * 0.1;
      const edgeFade = 1 - Math.pow(Math.abs(y) / 6, 2);
      const z = (stage * 1.5 - 2) * edgeFade + noise * edgeFade;
      pos.setZ(i, z);
      const color = new THREE.Color();
      if (stage > 2.5) color.setHSL(0.08, 0.9, 0.5);
      else if (stage > 1.5) color.setHSL(0.75, 0.8, 0.6);
      else if (stage > 0.5) color.setHSL(0.6, 0.8, 0.3);
      else color.setHSL(0.5, 1.0, 0.2);
      colors.push(color.r, color.g, color.b);
    }
    geo.setAttribute("color", new THREE.Float32BufferAttribute(colors, 3));
    geo.computeVertexNormals();
    return geo;
  }, []);
  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.position.y =
        Math.sin(state.clock.elapsedTime * 0.5) * 0.2 - 1;
      meshRef.current.rotation.z =
        Math.sin(state.clock.elapsedTime * 0.2) * 0.05;
    }
  });
  return (
    <group
      ref={meshRef}
      position={[0, -1, -5]}
      rotation={[-Math.PI / 2.2, 0, 0]}
    >
      <mesh geometry={geometry}>
        <meshStandardMaterial
          vertexColors
          roughness={0.6}
          metalness={0.4}
          side={THREE.DoubleSide}
        />
      </mesh>
      <mesh geometry={geometry}>
        <meshBasicMaterial
          color="#ffffff"
          wireframe
          transparent
          opacity={0.05}
          blending={THREE.AdditiveBlending}
        />
      </mesh>
      {sleepData.map((d, i) => {
        if (i % 2 !== 0) return null;
        const x = (i / (sleepData.length - 1)) * 24 - 12;
        return (
          <group key={i} position={[x, 6, 2]}>
            <Text
              position={[0, 0, 0]}
              rotation={[Math.PI / 2.2, 0, 0]}
              fontSize={0.4}
              color="rgba(255,255,255,0.5)"
              anchorX="center"
              anchorY="middle"
            >
              {d.time}
            </Text>
            <mesh position={[0, -0.5, 0]}>
              <sphereGeometry args={[0.05]} />
              <meshBasicMaterial color="rgba(255,255,255,0.5)" />
            </mesh>
          </group>
        );
      })}
    </group>
  );
}

const AUDIO_PROTOCOLS = [
  {
    id: "delta",
    name: "Delta Wave (Deep Sleep)",
    baseFreq: 100,
    beatFreq: 2,
    desc: "Promotes deep, restorative NREM sleep and physical recovery.",
  },
  {
    id: "theta",
    name: "Theta Wave (REM/Dream)",
    baseFreq: 150,
    beatFreq: 6,
    desc: "Enhances REM sleep, memory consolidation, and vivid dreaming.",
  },
  {
    id: "alpha",
    name: "Alpha Wave (Wind-down)",
    baseFreq: 200,
    beatFreq: 10,
    desc: "Reduces pre-sleep anxiety and facilitates the transition to sleep.",
  },
];

const AudioVisualizer = ({ analyser }: { analyser: AnalyserNode | null }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    if (!analyser || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const bufferLength = analyser.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);
    let animationId: number;
    const draw = () => {
      animationId = requestAnimationFrame(draw);
      analyser.getByteTimeDomainData(dataArray);
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.lineWidth = 2;
      ctx.strokeStyle = "hsl(var(--primary))";
      ctx.beginPath();
      const sliceWidth = (canvas.width * 1.0) / bufferLength;
      let x = 0;
      for (let i = 0; i < bufferLength; i++) {
        const v = dataArray[i] / 128.0;
        const y = (v * canvas.height) / 2;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
        x += sliceWidth;
      }
      ctx.lineTo(canvas.width, canvas.height / 2);
      ctx.stroke();
    };
    draw();
    return () => cancelAnimationFrame(animationId);
  }, [analyser]);
  return (
    <canvas
      ref={canvasRef}
      className="w-full h-12 mt-3 rounded-lg border border-primary/20 bg-black/40"
      width={300}
      height={48}
    />
  );
};

const RespirationMonitor = () => {
  const [isMonitoring, setIsMonitoring] = useState(false);
  const [anomalies, setAnomalies] = useState(0);
  const [dbLevel, setDbLevel] = useState(-100);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animFrameRef = useRef<number>(0);
  const silenceStartRef = useRef<number | null>(null);
  const toggleMonitoring = async () => {
    hapticFeedback(10);
    if (isMonitoring) {
      setIsMonitoring(false);
      if (streamRef.current)
        streamRef.current.getTracks().forEach((t) => t.stop());
      if (audioCtxRef.current) audioCtxRef.current.close();
      cancelAnimationFrame(animFrameRef.current);
      setDbLevel(-100);
    } else {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          audio: true,
          video: false,
        });
        streamRef.current = stream;
        const ctx = new (
          window.AudioContext || (window as any).webkitAudioContext
        )();
        audioCtxRef.current = ctx;
        const source = ctx.createMediaStreamSource(stream);
        const analyser = ctx.createAnalyser();
        analyser.fftSize = 1024;
        analyser.smoothingTimeConstant = 0.8;
        source.connect(analyser);
        analyserRef.current = analyser;
        setIsMonitoring(true);
        setAnomalies(0);
        silenceStartRef.current = null;
        draw();
      } catch (err) {
        console.error("Mic access denied", err);
      }
    }
  };
  useEffect(() => {
    return () => {
      if (streamRef.current)
        streamRef.current.getTracks().forEach((t) => t.stop());
      if (audioCtxRef.current) audioCtxRef.current.close();
      cancelAnimationFrame(animFrameRef.current);
    };
  }, []);
  const draw = () => {
    if (!analyserRef.current || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    animFrameRef.current = requestAnimationFrame(draw);
    const bufferLength = analyserRef.current.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);
    analyserRef.current.getByteTimeDomainData(dataArray);
    let sum = 0;
    for (let i = 0; i < bufferLength; i++) {
      const val = (dataArray[i] - 128) / 128;
      sum += val * val;
    }
    const rms = Math.sqrt(sum / bufferLength);
    const db = 20 * Math.log10(Math.max(rms, 0.0001));
    setDbLevel(Math.round(db));
    if (db < -40) {
      if (!silenceStartRef.current) silenceStartRef.current = Date.now();
      else if (Date.now() - silenceStartRef.current > 3000) {
        if (Math.random() > 0.98) {
          setAnomalies((prev) => prev + 1);
          hapticFeedback([50, 50, 50]);
          silenceStartRef.current = Date.now();
        }
      }
    } else {
      silenceStartRef.current = null;
    }
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.lineWidth = 2;
    ctx.strokeStyle =
      db > -20 ? "hsl(var(--destructive))" : "hsl(var(--primary))";
    ctx.beginPath();
    const sliceWidth = (canvas.width * 1.0) / bufferLength;
    let x = 0;
    for (let i = 0; i < bufferLength; i++) {
      const v = dataArray[i] / 128.0;
      const y = (v * canvas.height) / 2;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
      x += sliceWidth;
    }
    ctx.lineTo(canvas.width, canvas.height / 2);
    ctx.stroke();
  };
  return (
    <div className="bg-black/60 backdrop-blur-md border border-white/10 rounded-xl p-4 mt-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Mic className="w-4 h-4 text-primary" />
          <h3 className="text-sm font-bold text-white uppercase tracking-widest">
            Respiration Monitor
          </h3>
        </div>
        <Badge
          variant="outline"
          className="text-[9px] bg-destructive/20 text-destructive border-destructive/30"
        >
          APNEA DETECT
        </Badge>
      </div>
      <div className="grid grid-cols-2 gap-3 mb-4">
        <div className="bg-white/5 border border-white/10 rounded-lg p-3 text-center">
          <div className="text-[9px] text-muted-foreground uppercase tracking-widest mb-1 flex justify-center items-center gap-1">
            <Wind className="w-3 h-3" /> Ambient Noise
          </div>
          <div className="text-lg font-bold font-mono">
            {isMonitoring ? `${dbLevel} dB` : "-- dB"}
          </div>
        </div>
        <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-3 text-center">
          <div className="text-[9px] text-destructive uppercase tracking-widest mb-1 flex justify-center items-center gap-1">
            <AlertCircle className="w-3 h-3" /> Anomalies
          </div>
          <div className="text-lg font-bold text-destructive font-mono">
            {anomalies}
          </div>
        </div>
      </div>
      <canvas
        ref={canvasRef}
        className="w-full h-16 bg-black/40 rounded-lg border border-white/10 mb-4"
        width={300}
        height={64}
      />
      <Button
        className={`w-full h-12 font-bold tracking-widest transition-all duration-300 ${isMonitoring ? "bg-destructive/20 text-destructive border border-destructive/50 hover:bg-destructive/30" : "bg-primary text-black shadow-[0_0_20px_rgba(0,255,255,0.4)] hover:bg-primary/90"}`}
        onClick={toggleMonitoring}
      >
        {isMonitoring ? "STOP MONITORING" : "START MIC ANALYSIS"}
      </Button>
      <p className="text-[10px] text-muted-foreground mt-3 text-center leading-relaxed">
        Uses local microphone processing to detect breathing interruptions.
        Audio data never leaves your device.
      </p>
    </div>
  );
};

const BrainNetworkVisualizer = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const nodes = [
      {
        id: "pfc",
        x: 50,
        y: 80,
        label: "Prefrontal",
        active: false,
        color: "hsl(215.4 16.3% 56.9%)",
      },
      {
        id: "motor",
        x: 130,
        y: 40,
        label: "Motor Cortex",
        active: true,
        color: "hsl(180 100% 40%)",
      },
      {
        id: "amygdala",
        x: 160,
        y: 100,
        label: "Amygdala",
        active: true,
        color: "hsl(0 62.8% 50.6%)",
      },
      {
        id: "hippo",
        x: 120,
        y: 130,
        label: "Hippocampus",
        active: true,
        color: "hsl(270 60% 60%)",
      },
      {
        id: "visual",
        x: 250,
        y: 100,
        label: "Visual Cortex",
        active: true,
        color: "hsl(30 90% 60%)",
      },
    ];
    const edges = [
      { from: "visual", to: "amygdala" },
      { from: "amygdala", to: "motor" },
      { from: "hippo", to: "visual" },
      { from: "hippo", to: "amygdala" },
      { from: "pfc", to: "amygdala", dashed: true },
      { from: "pfc", to: "motor", dashed: true },
    ];
    let animFrame: number;
    let time = 0;
    const draw = () => {
      animFrame = requestAnimationFrame(draw);
      time += 0.03;
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      edges.forEach((edge) => {
        const fromNode = nodes.find((n) => n.id === edge.from)!;
        const toNode = nodes.find((n) => n.id === edge.to)!;
        ctx.beginPath();
        ctx.moveTo(fromNode.x, fromNode.y);
        ctx.lineTo(toNode.x, toNode.y);
        if (edge.dashed) {
          ctx.setLineDash([4, 4]);
          ctx.strokeStyle = "rgba(255,255,255,0.1)";
          ctx.lineWidth = 1;
        } else {
          ctx.setLineDash([]);
          const grad = ctx.createLinearGradient(
            fromNode.x,
            fromNode.y,
            toNode.x,
            toNode.y,
          );
          grad.addColorStop(0, fromNode.color);
          grad.addColorStop(1, toNode.color);
          ctx.strokeStyle = grad;
          ctx.globalAlpha = 0.4 + Math.sin(time * 3 + fromNode.x) * 0.2;
          ctx.lineWidth = 2;
        }
        ctx.stroke();
        ctx.globalAlpha = 1.0;
        if (!edge.dashed) {
          const progress = (time + fromNode.x * 0.01) % 1;
          const px = fromNode.x + (toNode.x - fromNode.x) * progress;
          const py = fromNode.y + (toNode.y - fromNode.y) * progress;
          ctx.beginPath();
          ctx.arc(px, py, 1.5, 0, Math.PI * 2);
          ctx.fillStyle = "#fff";
          ctx.shadowBlur = 8;
          ctx.shadowColor = "#fff";
          ctx.fill();
          ctx.shadowBlur = 0;
        }
      });
      nodes.forEach((node) => {
        ctx.beginPath();
        ctx.arc(node.x, node.y, 5, 0, Math.PI * 2);
        ctx.fillStyle = "#111";
        ctx.fill();
        ctx.lineWidth = 2;
        ctx.strokeStyle = node.color;
        if (node.active) {
          ctx.shadowBlur = 12 + Math.sin(time * 4 + node.x) * 4;
          ctx.shadowColor = node.color;
        }
        ctx.stroke();
        ctx.shadowBlur = 0;
        ctx.font = "bold 9px monospace";
        ctx.fillStyle = node.active ? "#fff" : "rgba(255,255,255,0.4)";
        ctx.textAlign = "center";
        ctx.fillText(node.label, node.x, node.y + 16);
      });
    };
    draw();
    return () => cancelAnimationFrame(animFrame);
  }, []);
  return (
    <div className="mt-4 border border-white/10 rounded-lg bg-black/40 overflow-hidden relative">
      <div className="absolute top-2 left-2 text-[9px] text-muted-foreground uppercase tracking-widest flex items-center gap-1 z-10">
        <Activity className="w-3 h-3" /> Neural Activation Map
      </div>
      <canvas
        ref={canvasRef}
        width={300}
        height={160}
        className="w-full h-[160px] block"
      />
    </div>
  );
};

const DreamJournal = () => {
  const [dream, setDream] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [interpretation, setInterpretation] = useState<string | null>(null);
  const [isGeneratingReplay, setIsGeneratingReplay] = useState(false);
  const [replayImage, setReplayImage] = useState<string | null>(null);
  const analyzeDream = () => {
    if (!dream.trim()) return;
    hapticFeedback(10);
    setIsAnalyzing(true);
    setTimeout(() => {
      setIsAnalyzing(false);
      setInterpretation(
        "Neural pattern analysis indicates elevated cognitive processing during REM phase. The imagery of falling or flying often correlates with recent high-stress CNS loads. Your brain is actively consolidating procedural memory from yesterday's tactical protocols. Recommendation: Increase Theta Wave audio exposure tonight to smooth REM transitions.",
      );
      hapticFeedback([20, 50, 20]);
    }, 2500);
  };
  const generateReplay = () => {
    hapticFeedback(10);
    setIsGeneratingReplay(true);
    setTimeout(() => {
      setIsGeneratingReplay(false);
      setReplayImage(
        "https://vibe.filesafe.space/1776727899133821812/assets/e56272fc-7485-4c3f-b84e-3abf9a113f86.png",
      );
      hapticFeedback([50, 50, 50]);
    }, 3000);
  };
  return (
    <div className="bg-black/60 backdrop-blur-md border border-white/10 rounded-xl p-4 mt-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <BrainCircuit className="w-4 h-4 text-purple-400" />
          <h3 className="text-sm font-bold text-white uppercase tracking-widest">
            Neural Dream Log
          </h3>
        </div>
        <Badge
          variant="outline"
          className="text-[9px] bg-purple-500/20 text-purple-400 border-purple-500/30"
        >
          AI ANALYSIS
        </Badge>
      </div>
      <Textarea
        placeholder="Log your REM phase imagery..."
        className="min-h-[100px] bg-white/5 border-white/10 text-white placeholder:text-muted-foreground resize-none focus-visible:ring-purple-500/50"
        value={dream}
        onChange={(e) => setDream(e.target.value)}
      />
      <Button
        className={`w-full h-12 mt-4 font-bold tracking-widest transition-all duration-300 ${dream.trim() && !isAnalyzing ? "bg-purple-500 text-white shadow-[0_0_20px_rgba(168,85,247,0.4)] hover:bg-purple-400" : "bg-white/5 text-muted-foreground border border-white/10"}`}
        onClick={analyzeDream}
        disabled={!dream.trim() || isAnalyzing}
      >
        {isAnalyzing ? (
          <>
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            DECRYPTING NEURAL IMAGERY...
          </>
        ) : (
          <>
            <Sparkles className="w-4 h-4 mr-2" />
            ANALYZE DREAM
          </>
        )}
      </Button>
      {interpretation && (
        <div className="mt-4 p-4 rounded-lg bg-purple-500/10 border border-purple-500/20">
          <div className="text-[10px] text-purple-400 uppercase tracking-widest mb-2 font-bold flex items-center gap-2">
            <Sparkles className="w-3 h-3" /> AI Interpretation
          </div>
          <p className="text-xs text-purple-100/90 leading-relaxed">
            {interpretation}
          </p>
          <BrainNetworkVisualizer />
          <div className="mt-6 border-t border-purple-500/20 pt-4">
            <div className="flex items-center justify-between mb-3">
              <div className="text-[10px] text-purple-400 uppercase tracking-widest font-bold flex items-center gap-2">
                <ImageIcon className="w-3 h-3" /> Interactive Dream Replay
              </div>
            </div>
            {!replayImage ? (
              <Button
                className="w-full h-10 bg-purple-500/20 text-purple-300 hover:bg-purple-500/30 border border-purple-500/30 text-xs tracking-widest"
                onClick={generateReplay}
                disabled={isGeneratingReplay}
              >
                {isGeneratingReplay ? (
                  <>
                    <Loader2 className="w-3 h-3 mr-2 animate-spin" />
                    SYNTHESIZING IMAGERY...
                  </>
                ) : (
                  <>
                    <ImageIcon className="w-3 h-3 mr-2" />
                    GENERATE VISUAL REPLAY
                  </>
                )}
              </Button>
            ) : (
              <div className="relative rounded-lg overflow-hidden border border-purple-500/30 group">
                <img
                  src={replayImage}
                  alt="Dream Replay"
                  className="w-full h-auto aspect-video object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent pointer-events-none" />
                <div className="absolute bottom-2 left-2 text-[8px] text-purple-300/80 uppercase tracking-widest">
                  AI Synthesized Neural Construct
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

const DreamThemesTracker = () => {
  const themes = [
    { symbol: "Freefall", frequency: 84, color: "bg-blue-500" },
    { symbol: "Flight", frequency: 62, color: "bg-purple-500" },
    { symbol: "Submersion", frequency: 45, color: "bg-teal-500" },
    { symbol: "Shadow Entities", frequency: 30, color: "bg-indigo-500" },
    { symbol: "Infinite Architecture", frequency: 15, color: "bg-orange-500" },
  ];
  return (
    <div className="bg-black/60 backdrop-blur-md border border-white/10 rounded-xl p-4 mt-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <PieChart className="w-4 h-4 text-purple-400" />
          <h3 className="text-sm font-bold text-white uppercase tracking-widest">
            Recurring Symbols
          </h3>
        </div>
        <Badge
          variant="outline"
          className="text-[9px] bg-purple-500/20 text-purple-400 border-purple-500/30"
        >
          THEME TRACKER
        </Badge>
      </div>
      <div className="space-y-3">
        {themes.map((theme, i) => (
          <div key={i} className="space-y-1">
            <div className="flex justify-between text-[10px] uppercase tracking-widest">
              <span className="text-white font-bold">{theme.symbol}</span>
              <span className="text-muted-foreground">{theme.frequency}%</span>
            </div>
            <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
              <div
                className={`h-full ${theme.color} rounded-full`}
                style={{ width: `${theme.frequency}%` }}
              />
            </div>
          </div>
        ))}
      </div>
      <p className="text-[10px] text-muted-foreground mt-4 text-center leading-relaxed">
        AI aggregates and classifies your REM imagery to identify dominant
        psychological themes over a 30-day window.
      </p>
    </div>
  );
};

const SleepDebtCalculator = () => {
  const debtData = [
    { day: "Mon", deficit: 1.5 },
    { day: "Tue", deficit: 0.5 },
    { day: "Wed", deficit: 2.0 },
    { day: "Thu", deficit: 0.0 },
    { day: "Fri", deficit: 1.0 },
    { day: "Sat", deficit: -1.0 },
    { day: "Sun", deficit: 0.5 },
  ];
  const totalDebt = 4.5;
  return (
    <div className="bg-black/60 backdrop-blur-md border border-white/10 rounded-xl p-4 mt-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Battery className="w-4 h-4 text-orange-400" />
          <h3 className="text-sm font-bold text-white uppercase tracking-widest">
            Sleep Debt
          </h3>
        </div>
        <Badge
          variant="outline"
          className="text-[9px] bg-orange-500/20 text-orange-400 border-orange-500/30"
        >
          DEFICIT TRACKER
        </Badge>
      </div>
      <div className="flex items-end gap-2 mb-4">
        <span className="text-4xl font-bold text-orange-400">{totalDebt}h</span>
        <span className="text-xs text-muted-foreground mb-1 uppercase tracking-widest">
          Cumulative Deficit
        </span>
      </div>
      <div className="space-y-3 mb-4">
        <div className="flex items-end justify-between h-20 gap-1">
          {debtData.map((d, i) => (
            <div
              key={i}
              className="flex flex-col items-center flex-1 gap-1 h-full"
            >
              <div className="w-full relative flex-1 flex items-end justify-center bg-white/5 rounded-t-sm overflow-hidden">
                {d.deficit > 0 && (
                  <div
                    className="w-full bg-orange-500/80 rounded-t-sm transition-all"
                    style={{ height: `${(d.deficit / 2) * 100}%` }}
                  />
                )}
                {d.deficit < 0 && (
                  <div
                    className="w-full bg-teal-500/80 rounded-t-sm transition-all"
                    style={{ height: `${(Math.abs(d.deficit) / 2) * 100}%` }}
                  />
                )}
              </div>
              <span className="text-[8px] text-muted-foreground uppercase">
                {d.day}
              </span>
            </div>
          ))}
        </div>
      </div>
      <p className="text-[10px] text-orange-200/80 leading-relaxed bg-orange-500/10 p-3 rounded-lg border border-orange-500/20">
        <strong className="text-orange-400">Tactical Advisory:</strong> You have
        accumulated 4.5 hours of sleep debt over the last 7 days. Add 45 minutes
        to your sleep window for the next 6 nights to restore optimal baseline.
      </p>
    </div>
  );
};

const SleepEnvironmentChecklist = ({
  onFadeUpdate,
}: {
  onFadeUpdate: (opacity: number) => void;
}) => {
  const [temperature, setTemperature] = useState(68);
  const [humidity, setHumidity] = useState(52);
  const [lightLevel, setLightLevel] = useState(0);
  const [noiseLevel, setNoiseLevel] = useState(28);
  const [checks, setChecks] = useState({ light: false, noise: false });
  const [isLocked, setIsLocked] = useState(false);
  const [sleepTime, setSleepTime] = useState("22:30");
  const [timeLeft, setTimeLeft] = useState<string | null>(null);

  const windDownAudioRef = useRef<{
    ctx: AudioContext;
    oscillators: OscillatorNode[];
    gain: GainNode;
  } | null>(null);

  const startWindDownAudio = () => {
    try {
      const ctx = new (
        window.AudioContext || (window as any).webkitAudioContext
      )();
      const merger = ctx.createChannelMerger(2);
      const left = ctx.createOscillator();
      const right = ctx.createOscillator();
      const gain = ctx.createGain();

      left.frequency.value = 120;
      right.frequency.value = 120 + 15; // Start with 15Hz beat

      left.connect(merger, 0, 0);
      right.connect(merger, 0, 1);
      merger.connect(gain);
      gain.connect(ctx.destination);

      gain.gain.value = 0;
      gain.gain.setTargetAtTime(0.25, ctx.currentTime, 3);

      left.start();
      right.start();

      windDownAudioRef.current = { ctx, oscillators: [left, right], gain };
    } catch (e) {
      console.error("Audio init failed", e);
    }
  };

  const stopWindDownAudio = () => {
    if (windDownAudioRef.current) {
      const { ctx, gain, oscillators } = windDownAudioRef.current;
      gain.gain.setTargetAtTime(0, ctx.currentTime, 1);
      setTimeout(() => {
        oscillators.forEach((o) => {
          try {
            o.stop();
            o.disconnect();
          } catch (e) {}
        });
        try {
          ctx.close();
        } catch (e) {}
        windDownAudioRef.current = null;
      }, 1200);
    }
  };

  useEffect(() => {
    if (!isLocked) {
      stopWindDownAudio();
      onFadeUpdate(0);
      return;
    }

    const timer = setInterval(() => {
      const [h, m] = sleepTime.split(":").map(Number);
      const target = new Date();
      target.setHours(h, m, 0);
      if (target.getTime() < Date.now()) target.setDate(target.getDate() + 1);

      const now = new Date();
      const windDownStart = new Date(target.getTime() - 30 * 60000);

      if (now < windDownStart) {
        const diff = windDownStart.getTime() - now.getTime();
        const hours = Math.floor(diff / 3600000);
        const mins = Math.floor((diff % 3600000) / 60000);
        const secs = Math.floor((diff % 60000) / 1000);
        setTimeLeft(
          `${hours.toString().padStart(2, "0")}:${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`,
        );
        onFadeUpdate(0);
      } else if (now < target) {
        setTimeLeft("WIND-DOWN ACTIVE");
        const progress =
          (now.getTime() - windDownStart.getTime()) / (30 * 60000);
        if (!windDownAudioRef.current) startWindDownAudio();
        if (windDownAudioRef.current) {
          const currentBeat = 15 - progress * (15 - 1.5);
          windDownAudioRef.current.oscillators[1].frequency.setTargetAtTime(
            120 + currentBeat,
            windDownAudioRef.current.ctx.currentTime,
            1,
          );
        }
        onFadeUpdate(progress * 0.75);
      } else {
        setIsLocked(false);
        setTimeLeft(null);
        stopWindDownAudio();
        onFadeUpdate(0);
      }
    }, 1000);

    return () => {
      clearInterval(timer);
      stopWindDownAudio();
    };
  }, [isLocked, sleepTime]);

  const toggleCheck = (key: keyof typeof checks) => {
    hapticFeedback(10);
    setChecks((prev) => ({ ...prev, [key]: !prev[key] }));
  };
  const tempScore =
    temperature >= 60 && temperature <= 68
      ? 100
      : temperature >= 55 && temperature <= 72
        ? 60
        : 20;
  const humidScore =
    humidity >= 40 && humidity <= 60
      ? 100
      : humidity >= 30 && humidity <= 70
        ? 60
        : 20;
  const lightScore = lightLevel <= 5 ? 100 : lightLevel <= 15 ? 55 : 10;
  const noiseScore = noiseLevel <= 30 ? 100 : noiseLevel <= 45 ? 55 : 10;
  const overallScore = Math.round(
    (tempScore + humidScore + lightScore + noiseScore) / 4,
  );
  const scoreColor =
    overallScore >= 80
      ? "text-emerald-400"
      : overallScore >= 55
        ? "text-amber-400"
        : "text-rose-400";
  const scoreBg =
    overallScore >= 80
      ? "bg-emerald-500"
      : overallScore >= 55
        ? "bg-amber-500"
        : "bg-rose-500";

  return (
    <div className="bg-black/60 backdrop-blur-md border border-white/10 rounded-xl p-4 mt-4 space-y-5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Thermometer className="w-4 h-4 text-blue-400" />
          <h3 className="text-sm font-bold text-white uppercase tracking-widest">
            Sleep Environment
          </h3>
        </div>
        <div className="flex items-center gap-2">
          {isLocked && (
            <Badge
              variant="outline"
              className="text-[9px] bg-primary/20 text-primary border-primary/30 animate-pulse"
            >
              LOCKED
            </Badge>
          )}
          <Badge
            variant="outline"
            className="text-[9px] bg-blue-500/20 text-blue-400 border-blue-500/30"
          >
            LIVE SENSORS
          </Badge>
        </div>
      </div>
      <div
        className={cn(
          "p-4 rounded-xl border transition-all duration-500",
          isLocked
            ? "bg-primary/10 border-primary/30"
            : "bg-white/5 border-white/10",
        )}
      >
        <div className="flex items-center justify-between mb-4">
          <div className="space-y-1">
            <div className="text-[10px] text-muted-foreground uppercase tracking-widest font-bold">
              Target Sleep Time
            </div>
            <input
              type="time"
              value={sleepTime}
              onChange={(e) => setSleepTime(e.target.value)}
              disabled={isLocked}
              className="bg-transparent text-xl font-black text-white outline-none disabled:opacity-50 [color-scheme:dark]"
            />
          </div>
          <div className="text-right">
            <div className="text-[10px] text-muted-foreground uppercase tracking-widest font-bold">
              Wind-down Countdown
            </div>
            <div
              className={cn(
                "text-xl font-mono font-black",
                timeLeft === "WIND-DOWN ACTIVE"
                  ? "text-primary animate-pulse"
                  : "text-white",
              )}
            >
              {isLocked ? timeLeft || "--:--:--" : "OFFLINE"}
            </div>
          </div>
        </div>
        <Button
          onClick={() => {
            hapticFeedback(isLocked ? 10 : 50);
            setIsLocked(!isLocked);
          }}
          className={cn(
            "w-full h-10 font-bold tracking-widest transition-all",
            isLocked
              ? "bg-white/5 text-white hover:bg-white/10 border border-white/10"
              : "bg-primary text-black shadow-[0_0_20px_rgba(0,255,255,0.4)] hover:shadow-[0_0_30px_rgba(0,255,255,0.6)]",
          )}
        >
          {isLocked ? "UNLOCK SETTINGS" : "LOCK & START COUNTDOWN"}
        </Button>
        {timeLeft === "WIND-DOWN ACTIVE" && (
          <div className="mt-3 space-y-2">
            <div className="flex items-center gap-2 text-[10px] text-primary font-bold uppercase tracking-widest animate-pulse">
              <Sparkles className="w-3 h-3" /> Guided Wind-down Sequence
              Initialized
            </div>
            <div className="flex items-center gap-2 text-[9px] text-muted-foreground uppercase tracking-widest">
              <Headphones className="w-3 h-3" /> Neural Audio: Focus → Delta
              Transition Active
            </div>
          </div>
        )}
      </div>
      <div className="flex items-center gap-4 p-3 bg-white/5 border border-white/10 rounded-xl">
        <div className="relative w-16 h-16 shrink-0">
          <svg viewBox="0 0 60 60" className="w-full h-full -rotate-90">
            <circle
              cx="30"
              cy="30"
              r="24"
              fill="none"
              stroke="rgba(255,255,255,0.08)"
              strokeWidth="5"
            />
            <circle
              cx="30"
              cy="30"
              r="24"
              fill="none"
              stroke={
                overallScore >= 80
                  ? "#34d399"
                  : overallScore >= 55
                    ? "#fbbf24"
                    : "#f87171"
              }
              strokeWidth="5"
              strokeLinecap="round"
              strokeDasharray={`${2 * Math.PI * 24}`}
              strokeDashoffset={`${2 * Math.PI * 24 * (1 - overallScore / 100)}`}
              style={{
                transition: "stroke-dashoffset 0.6s ease, stroke 0.4s ease",
              }}
            />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <span className={`text-sm font-black ${scoreColor}`}>
              {overallScore}
            </span>
          </div>
        </div>
        <div>
          <div className="text-xs font-bold text-white mb-0.5">
            {overallScore >= 80
              ? "Elite Sleep Environment"
              : overallScore >= 55
                ? "Needs Adjustment"
                : "Poor Conditions Detected"}
          </div>
          <div className="text-[10px] text-muted-foreground leading-relaxed">
            {overallScore >= 80
              ? "All critical parameters within optimal range."
              : "Some parameters need adjustment."}
          </div>
        </div>
      </div>
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Thermometer className="w-4 h-4 text-blue-400" />
            <span className="text-xs font-bold text-white">Temp</span>
          </div>
          <div className="text-right">
            <span
              className={`text-base font-black ${tempScore === 100 ? "text-emerald-400" : "text-rose-400"}`}
            >
              {temperature}°F
            </span>
          </div>
        </div>
        <input
          type="range"
          min={50}
          max={85}
          value={temperature}
          onChange={(e) => {
            setTemperature(Number(e.target.value));
            hapticFeedback(2);
          }}
          disabled={isLocked}
          className="w-full h-2 bg-white/10 rounded-lg appearance-none cursor-pointer accent-primary"
        />
      </div>
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Droplets className="w-4 h-4 text-blue-400" />
            <span className="text-xs font-bold text-white">Humidity</span>
          </div>
          <span
            className={`text-base font-black ${humidScore === 100 ? "text-emerald-400" : "text-rose-400"}`}
          >
            {humidity}%
          </span>
        </div>
        <input
          type="range"
          min={10}
          max={90}
          value={humidity}
          onChange={(e) => {
            setHumidity(Number(e.target.value));
            hapticFeedback(2);
          }}
          disabled={isLocked}
          className="w-full h-2 bg-white/10 rounded-lg appearance-none cursor-pointer accent-primary"
        />
      </div>
      <div className="space-y-2 pt-2 border-t border-white/5">
        {[
          {
            id: "light" as const,
            icon: LightbulbOff,
            title: "Blackout Curtains",
            desc: "Zero ambient light",
          },
          {
            id: "noise" as const,
            icon: Wind,
            title: "Pink Noise",
            desc: "Acoustic masking",
          },
        ].map((item) => {
          const isChecked = checks[item.id];
          return (
            <div
              key={item.id}
              onClick={() => !isLocked && toggleCheck(item.id)}
              className={`flex items-center justify-between p-3 rounded-lg border transition-all ${isLocked ? "opacity-50 cursor-not-allowed" : "cursor-pointer"} ${isChecked ? "bg-emerald-500/10 border-emerald-500/30" : "bg-white/5 border-white/10 hover:bg-white/10"}`}
            >
              <div className="flex items-center gap-3">
                <item.icon className="w-3.5 h-3.5" />
                <div>
                  <div className="text-xs font-bold">{item.title}</div>
                  <div className="text-[9px] text-muted-foreground uppercase">
                    {item.desc}
                  </div>
                </div>
              </div>
              <div
                className={`w-5 h-5 rounded-full border flex items-center justify-center ${isChecked ? "bg-emerald-500 border-emerald-500" : "border-white/20"}`}
              >
                {isChecked && <CheckCircle2 className="w-3 h-3 text-black" />}
              </div>
            </div>
          );
        })}
      </div>
      <div>
        <div className="flex justify-between items-center mb-1.5">
          <span className="text-[10px] text-muted-foreground uppercase tracking-widest">
            Environment Score
          </span>
          <span className={`text-[10px] font-black ${scoreColor}`}>
            {overallScore}/100
          </span>
        </div>
        <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden">
          <div
            className={`h-full ${scoreBg} rounded-full transition-all duration-700`}
            style={{ width: `${overallScore}%` }}
          />
        </div>
      </div>
    </div>
  );
};

const CaffeineTracker = () => {
  const [intakes, setIntakes] = useState<{ time: number; amount: number }[]>(
    [],
  );
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const interval = setInterval(() => setNow(Date.now()), 60000);
    return () => clearInterval(interval);
  }, []);
  const halfLifeMs = 5.5 * 60 * 60 * 1000;
  const calculateRemaining = (timeMs: number) =>
    intakes.reduce((total, intake) => {
      const elapsed = timeMs - intake.time;
      if (elapsed < 0) return total;
      return total + intake.amount * Math.pow(0.5, elapsed / halfLifeMs);
    }, 0);
  const currentLevel = Math.round(calculateRemaining(now));
  const chartData = Array.from({ length: 12 }).map((_, i) => {
    const futureTime = now + i * 60 * 60 * 1000;
    const d = new Date(futureTime);
    return {
      time: `${d.getHours()}:00`,
      amount: Math.round(calculateRemaining(futureTime)),
    };
  });
  const logCaffeine = (amount: number) => {
    hapticFeedback(10);
    setIntakes((prev) => [...prev, { time: Date.now(), amount }]);
  };
  return (
    <div className="bg-black/60 backdrop-blur-md border border-white/10 rounded-xl p-4 mt-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Coffee className="w-4 h-4 text-amber-500" />
          <h3 className="text-sm font-bold text-white uppercase tracking-widest">
            Caffeine Kinetics
          </h3>
        </div>
        <Badge
          variant="outline"
          className="text-[9px] bg-amber-500/20 text-amber-500 border-amber-500/30"
        >
          HALF-LIFE
        </Badge>
      </div>
      <div className="flex justify-between items-end mb-6">
        <div>
          <div className="text-[10px] text-muted-foreground uppercase tracking-widest mb-1">
            Active Serum Level
          </div>
          <div className="text-3xl font-black text-amber-500">
            {currentLevel}
            <span className="text-sm text-amber-500/50">mg</span>
          </div>
        </div>
        <div className="flex gap-2">
          <Button
            size="sm"
            variant="outline"
            className="h-8 bg-white/5 border-white/10 text-xs"
            onClick={() => logCaffeine(63)}
          >
            +63mg
          </Button>
          <Button
            size="sm"
            variant="outline"
            className="h-8 bg-white/5 border-white/10 text-xs"
            onClick={() => logCaffeine(150)}
          >
            +150mg
          </Button>
        </div>
      </div>
      <div className="h-32 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart
            data={chartData}
            margin={{ top: 15, right: 0, left: 0, bottom: 0 }}
          >
            <defs>
              <linearGradient id="caffGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.3} />
                <stop offset="95%" stopColor="#f59e0b" stopOpacity={0.0} />
              </linearGradient>
            </defs>
            <XAxis
              dataKey="time"
              stroke="rgba(255,255,255,0.2)"
              fontSize={10}
              tickLine={false}
              axisLine={false}
            />
            <ReferenceLine
              y={50}
              stroke="rgba(239, 68, 68, 0.5)"
              strokeDasharray="3 3"
            />
            <Area
              type="monotone"
              dataKey="amount"
              stroke="#f59e0b"
              strokeWidth={2}
              fill="url(#caffGrad)"
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

// ─── Blue Light Budget ────────────────────────────────────────────────────────
const DAILY_BUDGET = 3000; // arbitrary lux-sample units per day

const getTodayKey = () => new Date().toISOString().slice(0, 10); // "YYYY-MM-DD"

interface BudgetStore {
  date: string;
  total: number;
  weekly: { day: string; total: number }[];
}

const loadBudget = (): BudgetStore => {
  try {
    const raw = localStorage.getItem("blBudget");
    if (raw) {
      const parsed: BudgetStore = JSON.parse(raw);
      // If date rolled over, reset today's total but keep weekly
      if (parsed.date !== getTodayKey()) {
        const dayLabel = new Date(parsed.date).toLocaleDateString("en-US", {
          weekday: "short",
        });
        const weekly = [
          ...(parsed.weekly || []),
          { day: dayLabel, total: parsed.total },
        ].slice(-7);
        return { date: getTodayKey(), total: 0, weekly };
      }
      return parsed;
    }
  } catch {}
  return { date: getTodayKey(), total: 0, weekly: [] };
};

const saveBudget = (store: BudgetStore) => {
  try {
    localStorage.setItem("blBudget", JSON.stringify(store));
  } catch {}
};

const BlueLightBudget = ({ latestLux }: { latestLux: number }) => {
  const [store, setStore] = useState<BudgetStore>(loadBudget);
  const prevLux = useRef(0);

  // Accumulate whenever a new non-zero lux reading arrives
  useEffect(() => {
    if (latestLux > 0 && latestLux !== prevLux.current) {
      prevLux.current = latestLux;
      setStore((prev) => {
        // Check midnight rollover
        const today = getTodayKey();
        let next: BudgetStore;
        if (prev.date !== today) {
          const dayLabel = new Date(prev.date).toLocaleDateString("en-US", {
            weekday: "short",
          });
          const weekly = [
            ...(prev.weekly || []),
            { day: dayLabel, total: prev.total },
          ].slice(-7);
          next = { date: today, total: latestLux, weekly };
        } else {
          next = { ...prev, total: prev.total + latestLux };
        }
        saveBudget(next);
        return next;
      });
    }
  }, [latestLux]);

  const usedPercent = Math.min(
    100,
    Math.round((store.total / DAILY_BUDGET) * 100),
  );
  const budgetColor =
    usedPercent >= 90
      ? "text-destructive"
      : usedPercent >= 65
        ? "text-orange-400"
        : "text-emerald-400";
  const barColor =
    usedPercent >= 90
      ? "bg-destructive"
      : usedPercent >= 65
        ? "bg-orange-500"
        : "bg-emerald-500";
  const remaining = Math.max(0, DAILY_BUDGET - store.total);

  // Build chart data: weekly history + today
  const todayLabel = new Date().toLocaleDateString("en-US", {
    weekday: "short",
  });
  const chartData = [
    ...(store.weekly || []),
    { day: todayLabel, total: store.total },
  ].slice(-7);
  const weeklyMax = Math.max(
    ...chartData.map((d) => d.total),
    DAILY_BUDGET * 0.5,
  );

  return (
    <div className="bg-black/60 backdrop-blur-md border border-blue-500/20 rounded-xl p-4 mt-4">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-blue-400" />
          <h3 className="text-sm font-bold text-foreground uppercase tracking-widest">
            Blue Light Budget
          </h3>
        </div>
        <Badge
          variant="outline"
          className="text-[9px] bg-blue-500/20 text-blue-400 border-blue-500/30"
        >
          DAILY RESET
        </Badge>
      </div>

      {/* Gauge row */}
      <div className="flex items-center gap-4 mb-4">
        {/* Arc gauge */}
        <div className="relative w-20 h-20 shrink-0">
          <svg viewBox="0 0 80 80" className="w-full h-full -rotate-90">
            <circle
              cx="40"
              cy="40"
              r="32"
              fill="none"
              stroke="rgba(255,255,255,0.06)"
              strokeWidth="6"
            />
            <circle
              cx="40"
              cy="40"
              r="32"
              fill="none"
              stroke={
                usedPercent >= 90
                  ? "hsl(var(--destructive))"
                  : usedPercent >= 65
                    ? "#f97316"
                    : "#34d399"
              }
              strokeWidth="6"
              strokeLinecap="round"
              strokeDasharray={`${2 * Math.PI * 32}`}
              strokeDashoffset={`${2 * Math.PI * 32 * (1 - usedPercent / 100)}`}
              style={{
                transition: "stroke-dashoffset 0.7s ease, stroke 0.4s ease",
              }}
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span
              className={`text-base font-black leading-none ${budgetColor}`}
            >
              {usedPercent}%
            </span>
            <span className="text-[7px] text-muted-foreground uppercase tracking-widest">
              used
            </span>
          </div>
        </div>

        {/* Stats */}
        <div className="flex-1 space-y-2">
          <div>
            <div className="flex justify-between text-[9px] uppercase tracking-widest text-muted-foreground mb-1">
              <span>Today's Exposure</span>
              <span className={budgetColor}>
                {store.total.toLocaleString()} / {DAILY_BUDGET.toLocaleString()}
              </span>
            </div>
            <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden">
              <div
                className={`h-full ${barColor} rounded-full transition-all duration-700`}
                style={{ width: `${usedPercent}%` }}
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div className="bg-white/5 border border-white/5 rounded-lg p-2 text-center">
              <div className="text-[8px] text-muted-foreground uppercase tracking-widest">
                Remaining
              </div>
              <div className={`text-xs font-bold font-mono ${budgetColor}`}>
                {remaining.toLocaleString()}
              </div>
            </div>
            <div className="bg-white/5 border border-white/5 rounded-lg p-2 text-center">
              <div className="text-[8px] text-muted-foreground uppercase tracking-widest">
                Resets In
              </div>
              <div className="text-xs font-bold font-mono text-foreground">
                {(() => {
                  const now = new Date();
                  const midnight = new Date(now);
                  midnight.setHours(24, 0, 0, 0);
                  const diff = midnight.getTime() - now.getTime();
                  const h = Math.floor(diff / 3600000);
                  const m = Math.floor((diff % 3600000) / 60000);
                  return `${h}h ${m}m`;
                })()}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Advisory banner */}
      {usedPercent >= 90 && (
        <div className="flex items-start gap-2 p-3 rounded-lg bg-destructive/10 border border-destructive/30 mb-4">
          <ShieldAlert className="w-3.5 h-3.5 text-destructive shrink-0 mt-0.5" />
          <p className="text-[10px] text-destructive/90 leading-relaxed">
            Daily blue light budget exhausted. Melatonin suppression risk is
            high. Enable maximum night filter and avoid all screens for the next
            2 hours.
          </p>
        </div>
      )}
      {usedPercent >= 65 && usedPercent < 90 && (
        <div className="flex items-start gap-2 p-3 rounded-lg bg-orange-500/10 border border-orange-500/30 mb-4">
          <AlertCircle className="w-3.5 h-3.5 text-orange-400 shrink-0 mt-0.5" />
          <p className="text-[10px] text-orange-300/90 leading-relaxed">
            Approaching daily limit. Activate amber filter and reduce screen
            brightness to protect circadian rhythm.
          </p>
        </div>
      )}

      {/* 7-day weekly trend chart */}
      {chartData.length >= 2 && (
        <div>
          <div className="flex items-center gap-1.5 mb-2">
            <TrendingUp className="w-3 h-3 text-blue-400" />
            <span className="text-[9px] text-muted-foreground uppercase tracking-widest">
              7-Day Weekly Trend
            </span>
          </div>
          <div className="h-20 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart
                data={chartData}
                margin={{ top: 4, right: 2, left: -30, bottom: 0 }}
              >
                <defs>
                  <linearGradient id="budgetGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#60a5fa" stopOpacity={0.35} />
                    <stop offset="95%" stopColor="#60a5fa" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis
                  dataKey="day"
                  stroke="rgba(255,255,255,0.1)"
                  fontSize={8}
                  tickLine={false}
                  axisLine={false}
                />
                <YAxis domain={[0, Math.ceil(weeklyMax * 1.1)]} hide />
                <ReferenceLine
                  y={DAILY_BUDGET}
                  stroke="rgba(239,68,68,0.25)"
                  strokeDasharray="3 3"
                />
                <Tooltip
                  content={({ active, payload, label }) => {
                    if (!active || !payload?.length) return null;
                    const val = payload[0].value as number;
                    const pct = Math.min(
                      100,
                      Math.round((val / DAILY_BUDGET) * 100),
                    );
                    return (
                      <div className="bg-[#111] border border-white/10 rounded-lg px-2.5 py-1.5 text-[9px]">
                        <div className="text-muted-foreground font-mono">
                          {label}
                        </div>
                        <div className="text-blue-300 font-bold">
                          {val.toLocaleString()} lux
                        </div>
                        <div className="text-muted-foreground">
                          {pct}% of budget
                        </div>
                      </div>
                    );
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="total"
                  stroke="#60a5fa"
                  strokeWidth={1.5}
                  fill="url(#budgetGrad)"
                  dot={(props: any) => {
                    const isLast = props.index === chartData.length - 1;
                    if (!isLast)
                      return (
                        <circle
                          key={props.key}
                          cx={props.cx}
                          cy={props.cy}
                          r={2}
                          fill="#60a5fa"
                          fillOpacity={0.4}
                          stroke="none"
                        />
                      );
                    return (
                      <g key={props.key}>
                        <circle
                          cx={props.cx}
                          cy={props.cy}
                          r={4}
                          fill="#60a5fa"
                          fillOpacity={0.2}
                          stroke="#60a5fa"
                          strokeWidth={1}
                        />
                        <circle
                          cx={props.cx}
                          cy={props.cy}
                          r={2.5}
                          fill="#60a5fa"
                        />
                      </g>
                    );
                  }}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          {/* Day labels */}
          <p className="text-[8px] text-muted-foreground text-center mt-1">
            Red dashed line = daily budget cap ({DAILY_BUDGET.toLocaleString()}{" "}
            units)
          </p>
        </div>
      )}
    </div>
  );
};

// ─── Circadian Anchor Widget ─────────────────────────────────────────────────
type FilterRecommendation = {
  label: string;
  value: string;
  intensity: number;
  color: string;
  reason: string;
};

const getFilterRecommendation = (
  blueLux: number,
  hour: number,
): FilterRecommendation => {
  const isEvening = hour >= 18 || hour < 6;
  if (blueLux > 180 && isEvening)
    return {
      label: "Night Shield",
      value: "90%",
      intensity: 90,
      color: "text-destructive",
      reason:
        "Critical blue light exposure detected. Activate maximum filter immediately to protect melatonin.",
    };
  if (blueLux > 120 && isEvening)
    return {
      label: "Amber Guard",
      value: "70%",
      intensity: 70,
      color: "text-orange-400",
      reason:
        "High evening exposure. Switch to warm amber tone to begin melatonin priming.",
    };
  if (blueLux > 70 && isEvening)
    return {
      label: "Twilight Mode",
      value: "45%",
      intensity: 45,
      color: "text-yellow-400",
      reason:
        "Moderate evening light. Enable twilight filter to ease into sleep phase.",
    };
  if (blueLux > 120)
    return {
      label: "Daytime Limit",
      value: "20%",
      intensity: 20,
      color: "text-primary",
      reason:
        "Daytime levels are elevated. Light filter maintains circadian integrity.",
    };
  return {
    label: "Clear – Optimal",
    value: "0%",
    intensity: 0,
    color: "text-emerald-400",
    reason:
      "Blue light exposure is within healthy circadian range. No filter required.",
  };
};

const CircadianAnchor = () => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const hiddenCanvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const sampleIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const animFrameRef = useRef<number>(0);

  const [isActive, setIsActive] = useState(false);
  const [permission, setPermission] = useState<"idle" | "granted" | "denied">(
    "idle",
  );
  const [blueLux, setBlueLux] = useState(0);
  const [rawR, setRawR] = useState(0);
  const [rawG, setRawG] = useState(0);
  const [rawB, setRawB] = useState(0);
  const [exposureLog, setExposureLog] = useState<
    { time: string; lux: number }[]
  >([]);
  const hour = new Date().getHours();
  const isEvening = hour >= 18 || hour < 6;

  const rec = getFilterRecommendation(blueLux, hour);

  const sampleFrame = useCallback(() => {
    if (!videoRef.current || !hiddenCanvasRef.current) return;
    const video = videoRef.current;
    const canvas = hiddenCanvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx || video.readyState < 2) return;
    canvas.width = 64;
    canvas.height = 64;
    ctx.drawImage(video, 0, 0, 64, 64);
    const data = ctx.getImageData(0, 0, 64, 64).data;
    let r = 0,
      g = 0,
      b = 0;
    const pixels = data.length / 4;
    for (let i = 0; i < data.length; i += 4) {
      r += data[i];
      g += data[i + 1];
      b += data[i + 2];
    }
    r = Math.round(r / pixels);
    g = Math.round(g / pixels);
    b = Math.round(b / pixels);
    setRawR(r);
    setRawG(g);
    setRawB(b);
    // Weighted blue-light lux estimate (blue channel weighted, corrected for perceived brightness)
    const estimatedLux = Math.round(b * 1.6 - r * 0.3 - g * 0.2);
    const clampedLux = Math.max(0, Math.min(255, estimatedLux));
    setBlueLux(clampedLux);
    const now = new Date();
    const label = `${now.getHours().toString().padStart(2, "0")}:${now.getMinutes().toString().padStart(2, "0")}`;
    setExposureLog((prev) => {
      const next = [...prev, { time: label, lux: clampedLux }];
      return next.slice(-12); // keep last 12 samples
    });
  }, []);

  const drawVisualizer = useCallback(() => {
    if (!canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    animFrameRef.current = requestAnimationFrame(drawVisualizer);
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    const t = Date.now() / 1000;
    // Draw ripple circles representing blue light intensity
    const cx = canvas.width / 2;
    const cy = canvas.height / 2;
    const maxR = Math.min(cx, cy) - 4;
    const rings = 4;
    for (let i = 0; i < rings; i++) {
      const phase = (t * 0.8 + i * (1 / rings)) % 1;
      const r = phase * maxR;
      const alpha = (1 - phase) * 0.5 * (isActive ? 1 : 0.2);
      const blueRatio = Math.min(1, blueLux / 200);
      const red = Math.round(10 + (1 - blueRatio) * 20);
      const grnC = Math.round(10 + (1 - blueRatio) * 30);
      const blu = Math.round(180 + blueRatio * 75);
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.strokeStyle = `rgba(${red},${grnC},${blu},${alpha})`;
      ctx.lineWidth = 1.5;
      ctx.stroke();
    }
    // Center glow
    const grad = ctx.createRadialGradient(cx, cy, 0, cx, cy, 30);
    const blueRatioC = Math.min(1, blueLux / 200);
    const alpha = isActive ? 0.6 : 0.15;
    grad.addColorStop(
      0,
      `rgba(${Math.round(20 + (1 - blueRatioC) * 40)}, ${Math.round(20 + (1 - blueRatioC) * 60)}, ${Math.round(200 + blueRatioC * 55)}, ${alpha})`,
    );
    grad.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(cx, cy, 30, 0, Math.PI * 2);
    ctx.fill();
  }, [isActive, blueLux]);

  useEffect(() => {
    drawVisualizer();
    return () => cancelAnimationFrame(animFrameRef.current);
  }, [drawVisualizer]);

  const startCamera = async () => {
    hapticFeedback(20);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "user", width: 320, height: 240 },
        audio: false,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play().catch(() => {});
      }
      setPermission("granted");
      setIsActive(true);
      sampleIntervalRef.current = setInterval(sampleFrame, 5000); // sample every 5s
      setTimeout(sampleFrame, 800); // immediate first sample
    } catch {
      setPermission("denied");
    }
  };

  const stopCamera = () => {
    hapticFeedback(10);
    setIsActive(false);
    if (streamRef.current)
      streamRef.current.getTracks().forEach((t) => t.stop());
    if (sampleIntervalRef.current) clearInterval(sampleIntervalRef.current);
    streamRef.current = null;
  };

  useEffect(
    () => () => {
      if (streamRef.current)
        streamRef.current.getTracks().forEach((t) => t.stop());
      if (sampleIntervalRef.current) clearInterval(sampleIntervalRef.current);
      cancelAnimationFrame(animFrameRef.current);
    },
    [],
  );

  const luxPercent = Math.min(100, (blueLux / 255) * 100);
  const luxBarColor =
    blueLux > 180
      ? "bg-destructive"
      : blueLux > 120
        ? "bg-orange-500"
        : blueLux > 70
          ? "bg-yellow-500"
          : "bg-emerald-500";

  return (
    <div className="bg-black/60 backdrop-blur-md border border-blue-500/20 rounded-xl p-4 mt-4">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Eye className="w-4 h-4 text-blue-400" />
          <h3 className="text-sm font-bold text-white uppercase tracking-widest">
            Circadian Anchor
          </h3>
        </div>
        <div className="flex items-center gap-2">
          {isEvening && (
            <span className="text-[9px] font-bold text-orange-400 uppercase tracking-widest animate-pulse border border-orange-400/30 bg-orange-400/10 rounded-full px-2 py-0.5">
              Evening Mode
            </span>
          )}
          <span className="text-[9px] text-muted-foreground uppercase tracking-widest border border-blue-500/20 bg-blue-500/10 rounded-full px-2 py-0.5">
            BLUE LIGHT
          </span>
        </div>
      </div>

      {/* Description */}
      <p className="text-[11px] text-muted-foreground leading-relaxed mb-4">
        Uses your front camera to measure ambient blue light exposure in
        real-time. Data is processed on-device and never stored or transmitted.
      </p>

      {/* Visualizer + live video layout */}
      <div className="flex gap-3 items-center mb-4">
        {/* Ripple canvas */}
        <div className="relative shrink-0">
          <canvas
            ref={canvasRef}
            width={90}
            height={90}
            className="rounded-full border border-blue-500/20 bg-black/60"
          />
          {isActive && (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="text-center">
                <div className="text-[11px] font-black text-blue-300 font-mono leading-none">
                  {blueLux}
                </div>
                <div className="text-[8px] text-blue-400/60 uppercase tracking-widest">
                  lux
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Live RGB readout */}
        <div className="flex-1 space-y-2">
          {isActive ? (
            <>
              <div>
                <div className="flex justify-between mb-0.5">
                  <span className="text-[9px] text-muted-foreground uppercase tracking-widest">
                    Blue Exposure
                  </span>
                  <span
                    className="text-[9px] font-bold"
                    style={{
                      color:
                        blueLux > 180
                          ? "hsl(var(--destructive))"
                          : blueLux > 70
                            ? "#fb923c"
                            : "#34d399",
                    }}
                  >
                    {isEvening ? "Evening High" : "Daytime"}
                  </span>
                </div>
                <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden">
                  <div
                    className={`h-full ${luxBarColor} rounded-full transition-all duration-700`}
                    style={{ width: `${luxPercent}%` }}
                  />
                </div>
              </div>
              <div className="grid grid-cols-3 gap-1">
                {[
                  { label: "R", val: rawR, color: "#f87171" },
                  { label: "G", val: rawG, color: "#4ade80" },
                  { label: "B", val: rawB, color: "#60a5fa" },
                ].map((ch) => (
                  <div
                    key={ch.label}
                    className="bg-white/5 rounded-lg p-1.5 text-center border border-white/5"
                  >
                    <div
                      className="text-[8px] uppercase font-bold mb-0.5"
                      style={{ color: ch.color }}
                    >
                      {ch.label}
                    </div>
                    <div className="text-xs font-mono font-bold text-foreground">
                      {ch.val}
                    </div>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <div className="text-[11px] text-muted-foreground leading-relaxed">
              {permission === "denied"
                ? "Camera access was denied. Enable camera permissions in your browser settings."
                : "Start the sensor to begin tracking your blue light exposure throughout the day."}
            </div>
          )}
        </div>
      </div>

      {/* Hidden camera elements */}
      <video
        ref={videoRef}
        className="absolute opacity-0 pointer-events-none w-1 h-1"
        playsInline
        muted
      />
      <canvas
        ref={hiddenCanvasRef}
        className="absolute opacity-0 pointer-events-none w-1 h-1"
      />

      {/* Filter Recommendation */}
      {isActive && (
        <div
          className={`rounded-xl border p-3 mb-4 transition-all duration-500 ${
            rec.intensity > 70
              ? "bg-destructive/10 border-destructive/30"
              : rec.intensity > 40
                ? "bg-orange-500/10 border-orange-500/30"
                : rec.intensity > 0
                  ? "bg-yellow-500/10 border-yellow-500/30"
                  : "bg-emerald-500/10 border-emerald-500/30"
          }`}
        >
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <ShieldAlert className={`w-4 h-4 ${rec.color}`} />
              <span
                className={`text-xs font-bold uppercase tracking-widest ${rec.color}`}
              >
                {rec.label}
              </span>
            </div>
            <span className={`text-lg font-black font-mono ${rec.color}`}>
              {rec.value}
            </span>
          </div>
          <p className="text-[10px] text-muted-foreground leading-relaxed">
            {rec.reason}
          </p>
          {rec.intensity > 0 && (
            <div className="mt-2 h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
              <div
                className="h-full rounded-full transition-all duration-1000"
                style={{
                  width: `${rec.intensity}%`,
                  background:
                    rec.intensity > 70
                      ? "hsl(var(--destructive))"
                      : rec.intensity > 40
                        ? "#f97316"
                        : "#eab308",
                }}
              />
            </div>
          )}
        </div>
      )}

      {/* Exposure log sparkline */}
      {exposureLog.length > 2 && (
        <div className="mb-4">
          <div className="flex items-center gap-1.5 mb-2">
            <TrendingUp className="w-3 h-3 text-blue-400" />
            <span className="text-[9px] text-muted-foreground uppercase tracking-widest">
              Today's Exposure Log
            </span>
          </div>
          <div className="h-16 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart
                data={exposureLog}
                margin={{ top: 4, right: 2, left: -30, bottom: 0 }}
              >
                <defs>
                  <linearGradient id="blueGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#60a5fa" stopOpacity={0.35} />
                    <stop offset="95%" stopColor="#60a5fa" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis
                  dataKey="time"
                  stroke="rgba(255,255,255,0.1)"
                  fontSize={8}
                  tickLine={false}
                  axisLine={false}
                />
                <YAxis domain={[0, 255]} hide />
                <ReferenceLine
                  y={120}
                  stroke="rgba(249,115,22,0.3)"
                  strokeDasharray="3 3"
                />
                <Tooltip
                  content={({ active, payload }) => {
                    if (!active || !payload?.length) return null;
                    return (
                      <div className="bg-[#111] border border-white/10 rounded px-2 py-1 text-[9px] text-blue-300 font-mono">
                        {payload[0].value} lux
                      </div>
                    );
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="lux"
                  stroke="#60a5fa"
                  strokeWidth={1.5}
                  fill="url(#blueGrad)"
                  dot={false}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* Tips */}
      {isActive && isEvening && (
        <div className="grid grid-cols-1 gap-2 mb-4">
          {[
            {
              icon: Waves,
              tip: "Enable Night Shift / Blue Light filter on your device",
              active: rec.intensity > 0,
            },
            {
              icon: LightbulbOff,
              tip: "Switch overhead lights to warm (2700K) bulbs in the evening",
              active: true,
            },
            {
              icon: Moon,
              tip: "Limit screen exposure to under 30 min before sleep target time",
              active: true,
            },
          ].map(({ icon: Icon, tip, active }) => (
            <div
              key={tip}
              className={`flex items-start gap-2 p-2 rounded-lg border text-[10px] transition-colors ${active ? "bg-blue-500/5 border-blue-500/20 text-foreground" : "bg-white/3 border-white/5 text-muted-foreground"}`}
            >
              <Icon className="w-3 h-3 text-blue-400 shrink-0 mt-0.5" />
              <span className="leading-relaxed">{tip}</span>
            </div>
          ))}
        </div>
      )}

      {/* Toggle Button */}
      <Button
        onClick={isActive ? stopCamera : startCamera}
        className={`w-full h-11 font-bold tracking-widest transition-all duration-300 ${
          isActive
            ? "bg-white/5 text-foreground border border-white/10 hover:bg-white/10"
            : "bg-blue-500/20 text-blue-300 border border-blue-500/40 hover:bg-blue-500/30 shadow-[0_0_20px_rgba(96,165,250,0.25)]"
        }`}
      >
        <div className="flex items-center gap-2">
          {isActive ? (
            <EyeOff className="w-4 h-4" />
          ) : (
            <Eye className="w-4 h-4" />
          )}
          {isActive ? "STOP SENSOR" : "ACTIVATE CIRCADIAN ANCHOR"}
        </div>
      </Button>

      <p className="text-[9px] text-muted-foreground mt-2 text-center">
        Camera frames are processed locally. Zero data leaves your device.
      </p>

      {/* Blue Light Budget — tracks daily total & 7-day trend */}
      <BlueLightBudget latestLux={blueLux} />
    </div>
  );
};
// ─────────────────────────────────────────────────────────────────────────────

export default function SleepArchitecture() {
  const navigate = useNavigate();
  const [activeProtocol, setActiveProtocol] = useState<string | null>(null);
  const [alarmArmed, setAlarmArmed] = useState(false);
  const [wakeTime, setWakeTime] = useState("06:30");
  const [wakeWindow, setWakeWindow] = useState("30m");
  const [harmonicsEnabled, setHarmonicsEnabled] = useState(false);
  const [lucidInduction, setLucidInduction] = useState(false);
  const [analyser, setAnalyser] = useState<AnalyserNode | null>(null);
  const [fadeOpacity, setFadeOpacity] = useState(0);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const leftOscRef = useRef<OscillatorNode | null>(null);
  const rightOscRef = useRef<OscillatorNode | null>(null);
  const harmonicLeftOscRef = useRef<OscillatorNode | null>(null);
  const harmonicRightOscRef = useRef<OscillatorNode | null>(null);
  const mergerRef = useRef<ChannelMergerNode | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);
  const stopAudio = () => {
    if (gainNodeRef.current && audioCtxRef.current) {
      gainNodeRef.current.gain.setTargetAtTime(
        0,
        audioCtxRef.current.currentTime,
        0.1,
      );
      setTimeout(() => {
        if (leftOscRef.current) {
          leftOscRef.current.stop();
          leftOscRef.current.disconnect();
          leftOscRef.current = null;
        }
        if (rightOscRef.current) {
          rightOscRef.current.stop();
          rightOscRef.current.disconnect();
          rightOscRef.current = null;
        }
        if (harmonicLeftOscRef.current) {
          harmonicLeftOscRef.current.stop();
          harmonicLeftOscRef.current.disconnect();
          harmonicLeftOscRef.current = null;
        }
        if (harmonicRightOscRef.current) {
          harmonicRightOscRef.current.stop();
          harmonicRightOscRef.current.disconnect();
          harmonicRightOscRef.current = null;
        }
        if (mergerRef.current) {
          mergerRef.current.disconnect();
          mergerRef.current = null;
        }
        setAnalyser(null);
      }, 200);
    } else {
      setAnalyser(null);
    }
  };
  const playAudio = (
    baseFreq: number,
    beatFreq: number,
    withHarmonics: boolean = harmonicsEnabled,
  ) => {
    if (!audioCtxRef.current)
      audioCtxRef.current = new (
        window.AudioContext || (window as any).webkitAudioContext
      )();
    stopAudio();
    setTimeout(() => {
      if (!audioCtxRef.current) return;
      mergerRef.current = audioCtxRef.current.createChannelMerger(2);
      leftOscRef.current = audioCtxRef.current.createOscillator();
      leftOscRef.current.type = "sine";
      leftOscRef.current.frequency.value = baseFreq;
      leftOscRef.current.connect(mergerRef.current, 0, 0);
      rightOscRef.current = audioCtxRef.current.createOscillator();
      rightOscRef.current.type = "sine";
      rightOscRef.current.frequency.value = baseFreq + beatFreq;
      rightOscRef.current.connect(mergerRef.current, 0, 1);
      if (withHarmonics) {
        harmonicLeftOscRef.current = audioCtxRef.current.createOscillator();
        harmonicLeftOscRef.current.type = "sine";
        harmonicLeftOscRef.current.frequency.value = baseFreq * 1.5;
        harmonicLeftOscRef.current.connect(mergerRef.current, 0, 0);
        harmonicRightOscRef.current = audioCtxRef.current.createOscillator();
        harmonicRightOscRef.current.type = "sine";
        harmonicRightOscRef.current.frequency.value =
          (baseFreq + beatFreq) * 1.5;
        harmonicRightOscRef.current.connect(mergerRef.current, 0, 1);
      }
      gainNodeRef.current = audioCtxRef.current.createGain();
      gainNodeRef.current.gain.value = 0;
      gainNodeRef.current.gain.setTargetAtTime(
        0.5,
        audioCtxRef.current.currentTime,
        2,
      );
      const newAnalyser = audioCtxRef.current.createAnalyser();
      newAnalyser.fftSize = 2048;
      mergerRef.current.connect(gainNodeRef.current);
      gainNodeRef.current.connect(newAnalyser);
      newAnalyser.connect(audioCtxRef.current.destination);
      setAnalyser(newAnalyser);
      leftOscRef.current.start();
      rightOscRef.current.start();
      if (withHarmonics) {
        harmonicLeftOscRef.current?.start();
        harmonicRightOscRef.current?.start();
      }
    }, 250);
  };
  const toggleProtocol = (id: string, baseFreq: number, beatFreq: number) => {
    hapticFeedback(10);
    if (activeProtocol === id) {
      setActiveProtocol(null);
      stopAudio();
    } else {
      setActiveProtocol(id);
      playAudio(baseFreq, beatFreq, harmonicsEnabled);
    }
  };
  const handleHarmonicsToggle = (enabled: boolean) => {
    hapticFeedback(10);
    setHarmonicsEnabled(enabled);
    if (activeProtocol) {
      const protocol = AUDIO_PROTOCOLS.find((p) => p.id === activeProtocol);
      if (protocol) playAudio(protocol.baseFreq, protocol.beatFreq, enabled);
    }
  };
  useEffect(() => {
    return () => {
      stopAudio();
      if (audioCtxRef.current) audioCtxRef.current.close();
    };
  }, []);
  const hour = new Date().getHours();
  let phase = "",
    PhaseIcon = Sun,
    color = "text-yellow-400",
    bg = "bg-yellow-400/10",
    border = "border-yellow-400/20",
    action = "";
  if (hour >= 5 && hour < 10) {
    phase = "Morning Anchor";
    PhaseIcon = Sunrise;
    color = "text-amber-400";
    bg = "bg-amber-400/10";
    border = "border-amber-400/20";
    action = "Seek sunlight exposure.";
  } else if (hour >= 10 && hour < 17) {
    phase = "Mid-Day Peak";
    PhaseIcon = Sun;
    color = "text-yellow-400";
    bg = "bg-yellow-400/10";
    border = "border-yellow-400/20";
    action = "Avoid caffeine after 14:00.";
  } else if (hour >= 17 && hour < 21) {
    phase = "Evening Wind-Down";
    PhaseIcon = Sunset;
    color = "text-orange-400";
    bg = "bg-orange-400/10";
    border = "border-orange-400/20";
    action = "Dim overhead lights.";
  } else {
    phase = "Night / Recovery";
    PhaseIcon = Moon;
    color = "text-indigo-400";
    bg = "bg-indigo-400/10";
    border = "border-indigo-400/20";
    action = "Maintain total darkness.";
  }

  return (
    <div className="relative flex flex-col w-full h-[100dvh] bg-black text-foreground overflow-hidden">
      <div className="absolute inset-0 z-0">
        <Canvas camera={{ position: [0, 3, 5], fov: 60 }}>
          <color attach="background" args={["#050505"]} />
          <fog attach="fog" args={["#050505", 5, 15]} />
          <ambientLight intensity={0.5} />
          <directionalLight position={[10, 10, 5]} intensity={1} />
          <pointLight position={[0, 5, 0]} intensity={2} color="#00ffff" />
          <Stars
            radius={50}
            depth={50}
            count={2000}
            factor={4}
            saturation={0}
            fade
            speed={1}
          />
          <SleepLandscape />
          <OrbitControls
            enableZoom={false}
            enablePan={false}
            minPolarAngle={Math.PI / 3}
            maxPolarAngle={Math.PI / 2}
            autoRotate
            autoRotateSpeed={0.5}
          />
        </Canvas>
      </div>
      <div className="relative z-10 flex flex-col h-full pointer-events-none">
        <header className="px-4 py-6 flex items-center justify-between pointer-events-auto bg-gradient-to-b from-black/80 to-transparent">
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                hapticFeedback(10);
                navigate(-1);
              }}
              className="text-muted-foreground hover:text-foreground transition-colors bg-black/40 p-2 rounded-full border border-white/10 backdrop-blur-md"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-xl font-bold tracking-tighter">
                SLEEP ARCHITECTURE
              </h1>
              <p className="text-[10px] text-muted-foreground uppercase tracking-widest">
                3D Cycle Mapping
              </p>
            </div>
          </div>
          <Badge
            variant="outline"
            className="bg-primary/10 text-primary border-primary/30"
          >
            SCORE: 92
          </Badge>
        </header>
        <div className="flex-1" />
        <div className="p-4 bg-gradient-to-t from-black via-black/90 to-transparent pointer-events-auto overflow-y-auto max-h-[60vh] pb-8">
          <div className="grid grid-cols-4 gap-2 mb-4">
            <div className="bg-black/60 backdrop-blur-md border border-white/10 rounded-xl p-3 text-center">
              <div className="text-[9px] text-muted-foreground uppercase tracking-widest mb-1 flex justify-center items-center gap-1">
                <Clock className="w-3 h-3" /> Total
              </div>
              <div className="text-sm font-bold">7h 45m</div>
            </div>
            <div className="bg-teal-900/20 backdrop-blur-md border border-teal-500/20 rounded-xl p-3 text-center">
              <div className="text-[9px] text-teal-400 uppercase tracking-widest mb-1">
                Deep
              </div>
              <div className="text-sm font-bold text-teal-100">2h 10m</div>
            </div>
            <div className="bg-purple-900/20 backdrop-blur-md border border-purple-500/20 rounded-xl p-3 text-center">
              <div className="text-[9px] text-purple-400 uppercase tracking-widest mb-1">
                REM
              </div>
              <div className="text-sm font-bold text-purple-100">1h 45m</div>
            </div>
            <div className="bg-orange-900/20 backdrop-blur-md border border-orange-500/20 rounded-xl p-3 text-center">
              <div className="text-[9px] text-orange-400 uppercase tracking-widest mb-1">
                Awake
              </div>
              <div className="text-sm font-bold text-orange-100">15m</div>
            </div>
          </div>
          <div className="bg-black/60 backdrop-blur-md border border-white/10 rounded-xl p-4 flex gap-4 items-start mb-4">
            <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center shrink-0 border border-primary/30">
              <Zap className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white mb-1">
                Optimal Recovery Detected
              </h3>
              <p className="text-xs text-muted-foreground leading-relaxed">
                Your deep sleep phase was 18% higher than baseline.
              </p>
            </div>
          </div>
          <div className="bg-black/60 backdrop-blur-md border border-white/10 rounded-xl p-4">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Headphones className="w-4 h-4 text-primary" />
                <h3 className="text-sm font-bold text-white uppercase tracking-widest">
                  Deep Sleep Enhancer
                </h3>
              </div>
              <Badge
                variant="outline"
                className="text-[9px] bg-primary/10 text-primary border-primary/20"
              >
                BINAURAL AUDIO
              </Badge>
            </div>
            <div className="space-y-3">
              {AUDIO_PROTOCOLS.map((protocol) => {
                const isActive = activeProtocol === protocol.id;
                return (
                  <div
                    key={protocol.id}
                    className={`p-3 rounded-lg border transition-all duration-300 ${isActive ? "bg-primary/10 border-primary/40" : "bg-white/5 border-white/10"}`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <div className="text-sm font-bold text-white">
                          {protocol.name}
                        </div>
                        <div className="text-[10px] text-muted-foreground font-mono">
                          {protocol.baseFreq}Hz / {protocol.beatFreq}Hz
                        </div>
                      </div>
                      <Button
                        size="icon"
                        variant="secondary"
                        className="w-8 h-8 rounded-full"
                        onClick={() =>
                          toggleProtocol(
                            protocol.id,
                            protocol.baseFreq,
                            protocol.beatFreq,
                          )
                        }
                      >
                        {isActive ? (
                          <Pause className="w-4 h-4" />
                        ) : (
                          <Play className="w-4 h-4 ml-0.5" />
                        )}
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
          <RespirationMonitor />
          <DreamJournal />
          <DreamThemesTracker />
          <SleepDebtCalculator />
          <SleepEnvironmentChecklist onFadeUpdate={setFadeOpacity} />
          <CaffeineTracker />
          <CircadianAnchor />
          <div className="bg-black/60 backdrop-blur-md border border-white/10 rounded-xl p-4 mt-4 mb-4">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Sun className="w-4 h-4 text-primary" />
                <h3 className="text-sm font-bold text-white uppercase tracking-widest">
                  Circadian Optimizer
                </h3>
              </div>
            </div>
            <div
              className={`p-4 rounded-lg border ${border} ${bg} flex gap-4 items-start mb-4 transition-colors`}
            >
              <div
                className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 border ${border} bg-black/50`}
              >
                <PhaseIcon className={`w-5 h-5 ${color}`} />
              </div>
              <div>
                <div className="flex justify-between items-center mb-1">
                  <h3 className={`text-sm font-bold ${color}`}>{phase}</h3>
                </div>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  {action}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Neural Fade Overlay */}
      <div
        className="fixed inset-0 bg-black pointer-events-none z-[100] transition-opacity duration-1000"
        style={{ opacity: fadeOpacity }}
      />
    </div>
  );
}
