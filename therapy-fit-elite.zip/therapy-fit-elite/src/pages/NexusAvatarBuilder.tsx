import React, { useState, useRef } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import {
  Sphere,
  MeshDistortMaterial,
  Environment,
  Float,
  Sparkles as ThreeSparkles,
} from "@react-three/drei";
import * as THREE from "three";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  CardFooter,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Slider } from "@/components/ui/slider";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Logo } from "@/components/Logo";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";
import {
  ArrowLeft,
  Sparkles,
  Brain,
  Mic,
  Settings,
  Activity,
  Zap,
  Save,
  RefreshCw,
  Volume2,
} from "lucide-react";
import { hapticFeedback } from "@/lib/utils";
import { NeuralNotificationCenter } from "@/components/NeuralNotifications";

const CoreConsciousness = ({
  color,
  distort,
  speed,
  scale,
  wireframe,
}: {
  color: string;
  distort: number;
  speed: number;
  scale: number;
  wireframe: boolean;
}) => {
  const materialRef = useRef<any>(null);

  useFrame(() => {
    if (materialRef.current) {
      materialRef.current.distort = THREE.MathUtils.lerp(
        materialRef.current.distort,
        distort,
        0.1,
      );
      materialRef.current.speed = THREE.MathUtils.lerp(
        materialRef.current.speed,
        speed,
        0.1,
      );
    }
  });

  return (
    <Float speed={2} rotationIntensity={0.5} floatIntensity={1}>
      <Sphere args={[scale, 64, 64]}>
        <MeshDistortMaterial
          ref={materialRef}
          color={color}
          attach="material"
          distort={distort}
          speed={speed}
          roughness={0.2}
          metalness={0.8}
          clearcoat={1}
          clearcoatRoughness={0.1}
          envMapIntensity={2}
          wireframe={wireframe}
        />
      </Sphere>
      <ThreeSparkles
        count={80}
        scale={scale * 3}
        size={2}
        speed={0.4}
        opacity={0.6}
        color={color}
      />
    </Float>
  );
};

export default function NexusAvatarBuilder() {
  const navigate = useNavigate();
  const { toast } = useToast();

  const [theme, setTheme] = useState("amber");
  const [distort, setDistort] = useState([0.4]);
  const [speed, setSpeed] = useState([2]);
  const [wireframe, setWireframe] = useState(false);
  const [coachingStyle, setCoachingStyle] = useState("aggressive");
  const [voicePitch, setVoicePitch] = useState([50]);
  const [voiceSpeed, setVoiceSpeed] = useState([50]);
  const [specialization, setSpecialization] = useState("cns_recovery");
  const [autoSync, setAutoSync] = useState(true);
  const [memoryEnabled, setMemoryEnabled] = useState(true);
  const [feedIntegration, setFeedIntegration] = useState(true);
  const [voiceCommandsEnabled, setVoiceCommandsEnabled] = useState(false);
  const [isListening, setIsListening] = useState(false);

  const themeColors: Record<string, string> = {
    amber: "#f59e0b",
    cyan: "#00cccc",
    emerald: "#10b981",
    magenta: "#d946ef",
    rose: "#f43f5e",
  };

  const handleSave = () => {
    hapticFeedback([50, 100, 50]);
    toast({
      title: "Nexus Avatar Synthesized",
      description:
        "Your personalized AI coach is now active and monitoring your telemetry.",
    });
    setTimeout(() => {
      navigate("/profile");
    }, 1500);
  };

  return (
    <div className="flex flex-1 flex-col bg-background text-foreground min-h-screen">
      <main className="flex-1 container max-w-6xl px-4 py-8 mx-auto">
        <div className="flex justify-between items-center mb-6">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate(-1)}
            className="gap-2"
          >
            <ArrowLeft className="h-4 w-4" /> Back
          </Button>
          <div className="flex items-center gap-3">
            <Badge
              variant="outline"
              className="hidden sm:flex border-amber-500/30 text-amber-500 bg-amber-500/10"
            >
              <Sparkles className="w-3 h-3 mr-1" /> Nexus Tier Active
            </Badge>
            <NeuralNotificationCenter />
          </div>
        </div>
        <div className="mb-8 flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 bg-amber-500/10 rounded-lg text-amber-500">
                <Brain className="h-6 w-6" />
              </div>
              <h1 className="text-3xl font-bold tracking-tight text-amber-500">
                Nexus Avatar Builder
              </h1>
            </div>
            <p className="text-muted-foreground mt-2">
              Sculpt your exclusive AI coaching entity. Adjust personality,
              vocal synthesis, and visual manifestation.
            </p>
          </div>
          <Button
            className="bg-amber-500 text-black hover:bg-amber-600 gap-2"
            onClick={handleSave}
          >
            <Save className="h-4 w-4" />
            Synthesize Avatar
          </Button>
        </div>

        <div className="grid gap-8 lg:grid-cols-5 h-[calc(100vh-250px)] min-h-[600px]">
          {/* 3D Preview Panel */}
          <Card className="lg:col-span-2 bg-card/40 border-amber-500/20 backdrop-blur-sm flex flex-col relative overflow-hidden shadow-[0_0_30px_rgba(245,158,11,0.05)]">
            <div className="absolute inset-0 bg-gradient-to-b from-transparent to-background/80 z-10 pointer-events-none" />
            <CardHeader className="relative z-20">
              <div className="flex justify-between items-center">
                <CardTitle className="text-sm text-amber-500 flex items-center gap-2">
                  <Activity className="h-4 w-4" />
                  Live Holographic Preview
                </CardTitle>
                <Badge
                  variant="outline"
                  className="border-amber-500/50 text-amber-500 bg-amber-500/10 animate-pulse"
                >
                  ONLINE
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="flex-1 p-0 relative">
              <div className="absolute inset-0 z-0">
                <Canvas camera={{ position: [0, 0, 4] }}>
                  <ambientLight intensity={0.5} />
                  <pointLight
                    position={[10, 10, 10]}
                    intensity={1}
                    color={themeColors[theme]}
                  />
                  <pointLight position={[-10, -10, -10]} intensity={0.5} />
                  <CoreConsciousness
                    color={themeColors[theme]}
                    distort={distort[0]}
                    speed={speed[0]}
                    scale={1.2}
                    wireframe={wireframe}
                  />
                  <Environment preset="city" />
                </Canvas>
              </div>
              <div className="absolute bottom-4 left-4 right-4 z-20">
                <div className="bg-background/80 backdrop-blur-md border border-border/50 rounded-lg p-3 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Button
                      variant="outline"
                      size="icon"
                      className="h-8 w-8 rounded-full border-amber-500/50 text-amber-500 hover:bg-amber-500/10"
                      onClick={() => {
                        hapticFeedback(20);
                        toast({
                          title: "Previewing Voice",
                          description: "Playing synthesis sample...",
                        });
                      }}
                    >
                      <Volume2 className="h-4 w-4" />
                    </Button>
                    <div className="space-y-1">
                      <div className="flex gap-1 h-2 items-end">
                        {[40, 70, 40, 90, 60, 80, 30].map((h, i) => (
                          <div
                            key={i}
                            className="w-1 bg-amber-500 rounded-t-sm animate-pulse"
                            style={{
                              height: `${h}%`,
                              animationDelay: `${i * 0.1}s`,
                            }}
                          />
                        ))}
                      </div>
                      <p className="text-[10px] text-muted-foreground uppercase tracking-widest font-bold">
                        Acoustic Signature
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] text-amber-500 font-mono">
                      Sync: {autoSync ? "Auto" : "Manual"}
                    </p>
                    <p className="text-[10px] text-muted-foreground font-mono">
                      Resonance: {Math.round(distort[0] * 100)}%
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Configuration Panel */}
          <Card className="lg:col-span-3 bg-card/40 border-border/50 backdrop-blur-sm flex flex-col">
            <Tabs defaultValue="personality" className="flex-1 flex flex-col">
              <CardHeader className="pb-0 border-b border-border/50">
                <TabsList className="w-full justify-start bg-transparent border-b-0 rounded-none h-auto p-0 mb-4 gap-6">
                  <TabsTrigger
                    value="personality"
                    className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-amber-500 data-[state=active]:text-amber-500 rounded-none px-0 pb-2"
                  >
                    <Brain className="h-4 w-4 mr-2" />
                    Core Personality
                  </TabsTrigger>
                  <TabsTrigger
                    value="voice"
                    className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-amber-500 data-[state=active]:text-amber-500 rounded-none px-0 pb-2"
                  >
                    <Mic className="h-4 w-4 mr-2" />
                    Vocal Synthesis
                  </TabsTrigger>
                  <TabsTrigger
                    value="visual"
                    className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-amber-500 data-[state=active]:text-amber-500 rounded-none px-0 pb-2"
                  >
                    <Sparkles className="h-4 w-4 mr-2" />
                    Visual Manifestation
                  </TabsTrigger>
                </TabsList>
              </CardHeader>

              <CardContent className="flex-1 pt-6 overflow-y-auto">
                <TabsContent value="personality" className="space-y-6 mt-0">
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label className="text-base text-foreground flex items-center gap-2">
                        Coaching Archetype
                      </Label>
                      <p className="text-xs text-muted-foreground">
                        Define how your AI interacts with you during protocols.
                      </p>
                      <Select
                        value={coachingStyle}
                        onValueChange={setCoachingStyle}
                      >
                        <SelectTrigger className="bg-background/50 h-12">
                          <SelectValue placeholder="Select archetype" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="aggressive">
                            <div className="flex flex-col">
                              <span className="font-bold text-red-500">
                                Drill Sergeant (Aggressive)
                              </span>
                              <span className="text-[10px] text-muted-foreground">
                                High accountability, zero excuses, blunt
                                delivery.
                              </span>
                            </div>
                          </SelectItem>
                          <SelectItem value="analytical">
                            <div className="flex flex-col">
                              <span className="font-bold text-blue-400">
                                Data Scientist (Analytical)
                              </span>
                              <span className="text-[10px] text-muted-foreground">
                                Focuses purely on biometric data and objective
                                metrics.
                              </span>
                            </div>
                          </SelectItem>
                          <SelectItem value="empathetic">
                            <div className="flex flex-col">
                              <span className="font-bold text-emerald-500">
                                Zen Guide (Empathetic)
                              </span>
                              <span className="text-[10px] text-muted-foreground">
                                Focuses on recovery, mindfulness, and gentle
                                nudges.
                              </span>
                            </div>
                          </SelectItem>
                          <SelectItem value="stoic">
                            <div className="flex flex-col">
                              <span className="font-bold text-amber-500">
                                The Stoic (Philosophical)
                              </span>
                              <span className="text-[10px] text-muted-foreground">
                                Calm, resolute, focused on enduring and
                                overcoming.
                              </span>
                            </div>
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2 pt-4">
                      <Label className="text-base text-foreground flex items-center gap-2">
                        Primary Specialization
                      </Label>
                      <p className="text-xs text-muted-foreground">
                        The AI's primary domain of expertise for daily intel.
                      </p>
                      <Select
                        value={specialization}
                        onValueChange={setSpecialization}
                      >
                        <SelectTrigger className="bg-background/50 h-10">
                          <SelectValue placeholder="Select focus" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="cns_recovery">
                            CNS & Parasympathetic Recovery
                          </SelectItem>
                          <SelectItem value="hypertrophy">
                            Muscle Hypertrophy & Nutrition
                          </SelectItem>
                          <SelectItem value="flow_state">
                            Cognitive Flow & Deep Work
                          </SelectItem>
                          <SelectItem value="endurance">
                            Cardiovascular Endurance
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="flex items-center justify-between pt-6 border-t border-border/50">
                      <div className="space-y-1">
                        <Label className="text-base">
                          Auto-Sync with Biometrics
                        </Label>
                        <p className="text-xs text-muted-foreground">
                          AI will autonomously adjust its tone based on your
                          real-time HRV and stress load.
                        </p>
                      </div>
                      <Switch
                        checked={autoSync}
                        onCheckedChange={setAutoSync}
                        className="data-[state=checked]:bg-amber-500"
                      />
                    </div>

                    <div className="flex items-center justify-between pt-6 border-t border-border/50">
                      <div className="space-y-1">
                        <Label className="text-base">
                          Long-Term Memory Engine
                        </Label>
                        <p className="text-xs text-muted-foreground">
                          The AI remembers past sessions, struggles, and PRs to
                          build a continuous coaching narrative.
                        </p>
                      </div>
                      <Switch
                        checked={memoryEnabled}
                        onCheckedChange={setMemoryEnabled}
                        className="data-[state=checked]:bg-amber-500"
                      />
                    </div>

                    <div className="flex items-center justify-between pt-6 border-t border-border/50">
                      <div className="space-y-1">
                        <Label className="text-base flex items-center gap-2">
                          Global Feed Integration
                        </Label>
                        <p className="text-xs text-muted-foreground">
                          Automatically broadcast your AI coach's milestones,
                          PRs, and unlocked achievements to the global network.
                        </p>
                      </div>
                      <Switch
                        checked={feedIntegration}
                        onCheckedChange={(val) => {
                          setFeedIntegration(val);
                          if (val) {
                            toast({
                              title: "Feed Link Established",
                              description:
                                "Avatar achievements will now sync to the Global Feed.",
                            });
                          }
                        }}
                        className="data-[state=checked]:bg-amber-500"
                      />
                    </div>

                    {feedIntegration && (
                      <div className="pt-2">
                        <Button
                          variant="outline"
                          className="w-full gap-2 border-amber-500/30 text-amber-500 hover:bg-amber-500/10"
                          onClick={() => {
                            hapticFeedback([20, 50, 20]);
                            toast({
                              title: "Achievement Broadcasted",
                              description:
                                "Simulated milestone successfully posted to the Global Feed.",
                            });
                          }}
                        >
                          <Sparkles className="h-4 w-4" />
                          Simulate Feed Broadcast
                        </Button>
                      </div>
                    )}
                  </div>
                </TabsContent>

                <TabsContent value="voice" className="space-y-8 mt-0">
                  <div className="space-y-6">
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <Label className="text-sm">Vocal Pitch</Label>
                        <span className="text-xs text-muted-foreground font-mono">
                          {voicePitch[0]}%
                        </span>
                      </div>
                      <Slider
                        value={voicePitch}
                        onValueChange={setVoicePitch}
                        max={100}
                        step={1}
                        className="[&>span:first-child]:bg-amber-500/20 [&_[role=slider]]:border-amber-500 [&_[role=slider]]:bg-amber-500"
                      />
                      <div className="flex justify-between text-[10px] text-muted-foreground uppercase tracking-widest">
                        <span>Deep / Resonant</span>
                        <span>High / Crisp</span>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <Label className="text-sm">Cadence Speed</Label>
                        <span className="text-xs text-muted-foreground font-mono">
                          {voiceSpeed[0]}%
                        </span>
                      </div>
                      <Slider
                        value={voiceSpeed}
                        onValueChange={setVoiceSpeed}
                        max={100}
                        step={1}
                        className="[&>span:first-child]:bg-amber-500/20 [&_[role=slider]]:border-amber-500 [&_[role=slider]]:bg-amber-500"
                      />
                      <div className="flex justify-between text-[10px] text-muted-foreground uppercase tracking-widest">
                        <span>Deliberate</span>
                        <span>Rapid</span>
                      </div>
                    </div>

                    <div className="pt-4 border-t border-border/50">
                      <Button
                        variant="outline"
                        className="w-full gap-2 border-amber-500/30 text-amber-500 hover:bg-amber-500/10"
                        onClick={() => {
                          hapticFeedback([20, 30, 20]);
                          toast({
                            title: "Generating Sample",
                            description:
                              "Applying pitch and cadence to synthesis engine...",
                          });
                        }}
                      >
                        <RefreshCw className="h-4 w-4" />
                        Regenerate Voice Sample
                      </Button>
                    </div>

                    <div className="flex items-center justify-between pt-6 border-t border-border/50">
                      <div className="space-y-1">
                        <Label className="text-base flex items-center gap-2">
                          Voice Command Recognition
                        </Label>
                        <p className="text-xs text-muted-foreground">
                          Trigger specific neural protocols via voice (e.g.,
                          "Initiate Neural Reset").
                        </p>
                      </div>
                      <Switch
                        checked={voiceCommandsEnabled}
                        onCheckedChange={(val) => {
                          setVoiceCommandsEnabled(val);
                          if (val) {
                            toast({
                              title: "Voice Recognition Active",
                              description:
                                "Avatar is now listening for command triggers.",
                            });
                          }
                        }}
                        className="data-[state=checked]:bg-amber-500"
                      />
                    </div>

                    {voiceCommandsEnabled && (
                      <div className="space-y-4 pt-2">
                        <div className="bg-background/50 border border-border/50 rounded-lg p-4 space-y-3">
                          <Label className="text-xs text-muted-foreground uppercase tracking-widest font-bold">
                            Active Triggers
                          </Label>
                          <div className="space-y-2">
                            <div className="flex items-center justify-between bg-card/50 p-2 rounded border border-border/30">
                              <span className="text-sm font-medium">
                                "Initiate Neural Reset"
                              </span>
                              <Badge
                                variant="outline"
                                className="text-[10px] text-cyan-500 border-cyan-500/30"
                              >
                                CNS Protocol
                              </Badge>
                            </div>
                            <div className="flex items-center justify-between bg-card/50 p-2 rounded border border-border/30">
                              <span className="text-sm font-medium">
                                "Start Focus Mode"
                              </span>
                              <Badge
                                variant="outline"
                                className="text-[10px] text-amber-500 border-amber-500/30"
                              >
                                Flow State
                              </Badge>
                            </div>
                            <div className="flex items-center justify-between bg-card/50 p-2 rounded border border-border/30">
                              <span className="text-sm font-medium">
                                "Log Hydration"
                              </span>
                              <Badge
                                variant="outline"
                                className="text-[10px] text-blue-500 border-blue-500/30"
                              >
                                Somatic
                              </Badge>
                            </div>
                          </div>
                        </div>
                        <Button
                          variant={isListening ? "default" : "outline"}
                          className={`w-full gap-2 ${isListening ? "bg-red-500 hover:bg-red-600 text-white border-transparent" : "border-amber-500/30 text-amber-500 hover:bg-amber-500/10"}`}
                          onClick={() => {
                            if (isListening) return;
                            hapticFeedback([20, 50, 20]);
                            setIsListening(true);
                            toast({
                              title: "Listening...",
                              description: "Speak your command now.",
                            });
                            setTimeout(() => {
                              setIsListening(false);
                              hapticFeedback([50, 100, 50]);
                              toast({
                                title: "Command Recognized",
                                description:
                                  "Triggered: 'Initiate Neural Reset'",
                              });
                            }, 3000);
                          }}
                        >
                          <Mic
                            className={`h-4 w-4 ${isListening ? "animate-pulse" : ""}`}
                          />
                          {isListening
                            ? "Listening for Command..."
                            : "Test Voice Command"}
                        </Button>
                      </div>
                    )}
                  </div>
                </TabsContent>

                <TabsContent value="visual" className="space-y-8 mt-0">
                  <div className="space-y-6">
                    <div className="space-y-3">
                      <Label className="text-sm">Aura Color Theme</Label>
                      <div className="grid grid-cols-5 gap-2">
                        {Object.entries(themeColors).map(([key, hex]) => (
                          <div
                            key={key}
                            className={`h-12 rounded-lg cursor-pointer transition-all border-2 flex items-center justify-center ${theme === key ? "border-foreground scale-105 shadow-lg" : "border-transparent opacity-50 hover:opacity-100"}`}
                            style={{ backgroundColor: hex }}
                            onClick={() => {
                              setTheme(key);
                              hapticFeedback(10);
                            }}
                          >
                            {theme === key && (
                              <Sparkles className="h-5 w-5 text-white/80" />
                            )}
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-4 pt-4">
                      <div className="flex justify-between items-center">
                        <Label className="text-sm">
                          Consciousness Resonance (Distortion)
                        </Label>
                        <span className="text-xs text-muted-foreground font-mono">
                          {distort[0].toFixed(2)}
                        </span>
                      </div>
                      <Slider
                        value={distort}
                        onValueChange={setDistort}
                        max={1}
                        step={0.01}
                        className="[&>span:first-child]:bg-amber-500/20 [&_[role=slider]]:border-amber-500 [&_[role=slider]]:bg-amber-500"
                      />
                    </div>

                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <Label className="text-sm">Synaptic Speed</Label>
                        <span className="text-xs text-muted-foreground font-mono">
                          {speed[0].toFixed(1)}x
                        </span>
                      </div>
                      <Slider
                        value={speed}
                        onValueChange={setSpeed}
                        max={5}
                        min={0.1}
                        step={0.1}
                        className="[&>span:first-child]:bg-amber-500/20 [&_[role=slider]]:border-amber-500 [&_[role=slider]]:bg-amber-500"
                      />
                    </div>

                    <div className="flex items-center justify-between pt-6 border-t border-border/50">
                      <div className="space-y-1">
                        <Label className="text-base">Wireframe Mode</Label>
                        <p className="text-xs text-muted-foreground">
                          Expose the underlying neural mesh of the avatar.
                        </p>
                      </div>
                      <Switch
                        checked={wireframe}
                        onCheckedChange={setWireframe}
                        className="data-[state=checked]:bg-amber-500"
                      />
                    </div>
                  </div>
                </TabsContent>
              </CardContent>
            </Tabs>
          </Card>
        </div>
      </main>
    </div>
  );
}
