import React, { useState, useRef } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { Sphere, MeshDistortMaterial, Environment } from "@react-three/drei";
import * as THREE from "three";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  CardFooter,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Hexagon,
  Activity,
  Zap,
  TrendingUp,
  Search,
  Filter,
  ShieldCheck,
  Clock,
  ArrowRightLeft,
  History,
  CheckCircle2,
  ExternalLink,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { hapticFeedback, cn } from "@/lib/utils";

const NFTAvatar3D = ({
  hrv,
  stress,
  color,
}: {
  hrv: number;
  stress: number;
  color: string;
}) => {
  const materialRef = useRef<any>(null);

  useFrame((state) => {
    if (materialRef.current) {
      materialRef.current.distort = THREE.MathUtils.lerp(
        materialRef.current.distort,
        0.2 + (stress / 100) * 0.6,
        0.1,
      );
      materialRef.current.speed = THREE.MathUtils.lerp(
        materialRef.current.speed,
        1 + (hrv / 100) * 3,
        0.1,
      );
    }
  });

  return (
    <Sphere args={[1.2, 32, 32]}>
      <MeshDistortMaterial
        ref={materialRef}
        color={color}
        attach="material"
        distort={0.4}
        speed={2}
        roughness={0.2}
        metalness={0.8}
        wireframe={stress > 70}
      />
    </Sphere>
  );
};

const MARKET_LISTINGS = [
  {
    id: "nft-001",
    seller: "Sarah_Opt",
    name: "Sovereign Wisp",
    price: 15000,
    hrv: 85,
    stress: 20,
    color: "#00cccc",
    rarity: "Legendary",
  },
  {
    id: "nft-002",
    seller: "David_Neural",
    name: "Crimson Overdrive",
    price: 8500,
    hrv: 60,
    stress: 85,
    color: "#ef4444",
    rarity: "Epic",
  },
  {
    id: "nft-003",
    seller: "Elena_Bio",
    name: "Deep Void Sync",
    price: 22000,
    hrv: 95,
    stress: 10,
    color: "#d946ef",
    rarity: "Mythic",
  },
  {
    id: "nft-004",
    seller: "Vance_Prime",
    name: "Golden Mean",
    price: 12000,
    hrv: 75,
    stress: 45,
    color: "#eab308",
    rarity: "Rare",
  },
];

export default function Marketplace() {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [isProcessing, setIsProcessing] = useState<string | null>(null);

  const handleTrade = (id: string, name: string) => {
    setIsProcessing(id);
    hapticFeedback([50, 50, 100]);
    toast({
      title: "Initiating Smart Contract",
      description: `Negotiating transfer for ${name}...`,
    });

    setTimeout(() => {
      setIsProcessing(null);
      hapticFeedback([100, 50, 100, 50, 200]);
      toast({
        title: "Transfer Complete",
        description: `${name} has been added to your Neural Vault.`,
      });
    }, 2500);
  };

  return (
    <div className="flex flex-1 flex-col bg-background text-foreground">
      <main className="flex-1 container max-w-6xl px-4 py-8 mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
          <div>
            <h2 className="text-3xl font-bold tracking-tight">
              Biometric NFT Market
            </h2>
            <p className="text-muted-foreground mt-1">
              Trade immutable neural signatures on the blockchain.
            </p>
          </div>

          <div className="flex items-center gap-2 w-full md:w-auto">
            <div className="relative flex-1 md:w-64">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search signatures..."
                className="pl-9 bg-background/50"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Button
              variant="outline"
              size="icon"
              className="shrink-0 border-border/50"
            >
              <Filter className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <Tabs defaultValue="market" className="w-full">
          <TabsList className="mb-6 bg-secondary/50 p-1">
            <TabsTrigger
              value="market"
              className="data-[state=active]:bg-primary/20 data-[state=active]:text-primary"
            >
              Live Market
            </TabsTrigger>
            <TabsTrigger
              value="vault"
              className="data-[state=active]:bg-primary/20 data-[state=active]:text-primary"
            >
              My Vault
            </TabsTrigger>
            <TabsTrigger
              value="activity"
              className="data-[state=active]:bg-primary/20 data-[state=active]:text-primary"
            >
              Activity
            </TabsTrigger>
          </TabsList>

          <TabsContent value="market" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {MARKET_LISTINGS.map((nft) => (
                <Card
                  key={nft.id}
                  className="bg-card/40 border-border/50 backdrop-blur-sm overflow-hidden group hover:border-primary/50 transition-all duration-300"
                >
                  <div className="relative h-48 w-full bg-black/50 border-b border-border/50">
                    <Canvas
                      camera={{ position: [0, 0, 3] }}
                      className="absolute inset-0 pointer-events-none"
                    >
                      <ambientLight intensity={0.5} />
                      <pointLight position={[10, 10, 10]} intensity={1} />
                      <NFTAvatar3D
                        hrv={nft.hrv}
                        stress={nft.stress}
                        color={nft.color}
                      />
                      <Environment preset="city" />
                    </Canvas>
                    <div className="absolute top-2 right-2">
                      <Badge
                        variant="outline"
                        className={cn(
                          "bg-background/80 backdrop-blur-md font-bold text-[10px] uppercase tracking-widest border-0",
                          nft.rarity === "Legendary"
                            ? "text-yellow-400"
                            : nft.rarity === "Mythic"
                              ? "text-fuchsia-400"
                              : nft.rarity === "Epic"
                                ? "text-purple-400"
                                : "text-blue-400",
                        )}
                      >
                        {nft.rarity}
                      </Badge>
                    </div>
                    <div className="absolute bottom-2 left-2 flex gap-2">
                      <Badge
                        variant="outline"
                        className="bg-background/80 backdrop-blur-md text-[10px] border-primary/30 text-primary gap-1"
                      >
                        <Activity className="h-3 w-3" /> {nft.hrv} HRV
                      </Badge>
                    </div>
                  </div>
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg">{nft.name}</CardTitle>
                        <CardDescription className="text-xs mt-1">
                          Minted by @{nft.seller}
                        </CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="pb-2">
                    <div className="flex items-center justify-between p-2 rounded-md bg-secondary/30 border border-border/30">
                      <span className="text-xs text-muted-foreground uppercase tracking-widest">
                        Price
                      </span>
                      <span className="font-mono font-bold text-primary flex items-center gap-1">
                        <Zap className="h-3 w-3" /> {nft.price.toLocaleString()}{" "}
                        PTS
                      </span>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button
                      className="w-full gap-2 relative overflow-hidden group-hover:bg-primary group-hover:text-primary-foreground transition-all"
                      variant="outline"
                      disabled={isProcessing === nft.id}
                      onClick={() => handleTrade(nft.id, nft.name)}
                    >
                      {isProcessing === nft.id ? (
                        <Activity className="h-4 w-4 animate-spin" />
                      ) : (
                        <ArrowRightLeft className="h-4 w-4" />
                      )}
                      {isProcessing === nft.id
                        ? "Negotiating..."
                        : "Acquire Signature"}
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="vault" className="space-y-6">
            <div className="flex justify-between items-center mb-4">
              <div>
                <h3 className="text-xl font-bold">Neural Vault</h3>
                <p className="text-sm text-muted-foreground">
                  Manage your acquired biometric signatures.
                </p>
              </div>
              <Button
                variant="outline"
                className="border-primary/50 text-primary gap-2"
                onClick={() => {
                  hapticFeedback([50, 50]);
                  toast({
                    title: "Cross-Platform Sync",
                    description: "Connecting to external dApp gateways...",
                  });
                }}
              >
                <ArrowRightLeft className="h-4 w-4" /> Cross-Platform Sync
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="bg-card/40 border-border/50 backdrop-blur-sm overflow-hidden group hover:border-primary/50 transition-all duration-300">
                <div className="relative h-48 w-full bg-black/50 border-b border-border/50">
                  <Canvas
                    camera={{ position: [0, 0, 3] }}
                    className="absolute inset-0 pointer-events-none"
                  >
                    <ambientLight intensity={0.5} />
                    <pointLight position={[10, 10, 10]} intensity={1} />
                    <NFTAvatar3D hrv={85} stress={20} color="#00cccc" />
                    <Environment preset="city" />
                  </Canvas>
                  <div className="absolute top-2 right-2">
                    <Badge
                      variant="outline"
                      className="bg-background/80 backdrop-blur-md font-bold text-[10px] uppercase tracking-widest border-0 text-yellow-400"
                    >
                      Legendary
                    </Badge>
                  </div>
                </div>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Sovereign Wisp</CardTitle>
                  <CardDescription className="text-xs mt-1">
                    Acquired: Oct 25, 2026
                  </CardDescription>
                </CardHeader>
                <CardContent className="pb-2">
                  <div className="flex items-center justify-between p-2 rounded-md bg-secondary/30 border border-border/30">
                    <span className="text-xs text-muted-foreground uppercase tracking-widest">
                      Status
                    </span>
                    <span className="font-mono font-bold text-green-400 flex items-center gap-1">
                      <ShieldCheck className="h-3 w-3" /> Secured
                    </span>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button
                    className="w-full gap-2 relative overflow-hidden group-hover:bg-primary group-hover:text-primary-foreground transition-all"
                    variant="outline"
                    onClick={() => {
                      hapticFeedback([50]);
                      toast({
                        title: "Sync Initiated",
                        description:
                          "Exporting signature to connected Web3 wallet.",
                      });
                    }}
                  >
                    <ArrowRightLeft className="h-4 w-4" /> Sync to dApp
                  </Button>
                </CardFooter>
              </Card>
            </div>

            <div className="mt-12">
              <div className="flex items-center gap-2 mb-4">
                <History className="h-5 w-5 text-primary" />
                <h3 className="text-xl font-bold">Sync History</h3>
              </div>
              <Card className="bg-card/40 border-border/50 backdrop-blur-sm overflow-hidden">
                <CardContent className="p-0">
                  <div className="divide-y divide-border/30">
                    {[
                      {
                        date: "Oct 26, 2026 - 14:32",
                        item: "Sovereign Wisp",
                        destination: "Ethereum Mainnet",
                        wallet: "0x7a...3f92",
                        status: "Verified",
                      },
                      {
                        date: "Oct 24, 2026 - 09:15",
                        item: "Crimson Overdrive",
                        destination: "Solana",
                        wallet: "8xK...p2M",
                        status: "Verified",
                      },
                    ].map((log, i) => (
                      <div
                        key={i}
                        className="flex flex-col md:flex-row md:items-center justify-between p-4 hover:bg-secondary/20 transition-colors gap-4"
                      >
                        <div className="flex flex-col md:flex-row md:items-center gap-2 md:gap-6">
                          <div className="flex items-center gap-2 text-sm text-muted-foreground w-40">
                            <Clock className="h-3 w-3" />
                            {log.date}
                          </div>
                          <div className="font-bold text-primary w-40">
                            {log.item}
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <span className="text-muted-foreground">to</span>
                            <Badge
                              variant="outline"
                              className="bg-background/50 border-border/50"
                            >
                              {log.destination}
                            </Badge>
                            <span className="font-mono text-xs text-muted-foreground">
                              {log.wallet}
                            </span>
                          </div>
                        </div>
                        <div className="flex items-center gap-4 self-end md:self-auto">
                          <span className="text-xs font-bold text-green-400 flex items-center gap-1">
                            <CheckCircle2 className="h-3 w-3" /> {log.status}
                          </span>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-muted-foreground hover:text-primary shrink-0"
                          >
                            <ExternalLink className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="activity">
            <Card className="bg-card/40 border-border/50 backdrop-blur-sm">
              <CardHeader>
                <CardTitle>Network Activity</CardTitle>
                <CardDescription>
                  Recent transactions across the global neural network.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    {
                      action: "Purchased",
                      item: "Sovereign Wisp",
                      user: "Alex_Prime",
                      price: 15000,
                      time: "2m ago",
                    },
                    {
                      action: "Minted",
                      item: "Deep Void Sync",
                      user: "Elena_Bio",
                      price: null,
                      time: "15m ago",
                    },
                    {
                      action: "Listed",
                      item: "Crimson Overdrive",
                      user: "David_Neural",
                      price: 8500,
                      time: "1h ago",
                    },
                  ].map((event, i) => (
                    <div
                      key={i}
                      className="flex items-center justify-between p-4 rounded-lg bg-background/50 border border-border/30"
                    >
                      <div className="flex items-center gap-4">
                        <div className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center border border-border/50">
                          {event.action === "Purchased" ? (
                            <ArrowRightLeft className="h-4 w-4 text-green-400" />
                          ) : event.action === "Minted" ? (
                            <Hexagon className="h-4 w-4 text-primary" />
                          ) : (
                            <TrendingUp className="h-4 w-4 text-yellow-400" />
                          )}
                        </div>
                        <div>
                          <div className="text-sm">
                            <span className="font-bold">{event.user}</span>{" "}
                            {event.action.toLowerCase()}{" "}
                            <span className="font-bold text-primary">
                              {event.item}
                            </span>
                          </div>
                          <div className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                            <Clock className="h-3 w-3" /> {event.time}
                          </div>
                        </div>
                      </div>
                      {event.price && (
                        <div className="font-mono font-bold text-sm flex items-center gap-1">
                          <Zap className="h-3 w-3 text-muted-foreground" />{" "}
                          {event.price.toLocaleString()}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
