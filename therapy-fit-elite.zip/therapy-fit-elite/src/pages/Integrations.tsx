import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  CardFooter,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { Logo } from "@/components/Logo";
import { useNavigate } from "react-router-dom";
import { NeuralNotificationCenter } from "@/components/NeuralNotifications";
import {
  Plug,
  Activity,
  Watch,
  BrainCircuit,
  Database,
  Key,
  Webhook,
  FileJson,
  ShieldCheck,
  Copy,
  RefreshCw,
  Repeat,
  CheckCircle2,
  XCircle,
  Clock,
  Trash2,
  Download,
  Eye,
  Search,
  ShieldAlert,
  Lock,
  Server,
  Bell,
  Globe,
  MapPin,
  GitBranch,
  ArrowRightLeft,
  Plus,
  History,
  BarChart4,
  Mail,
} from "lucide-react";
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from "@/components/ui/chart";
import { Area, AreaChart, CartesianGrid, XAxis, YAxis } from "recharts";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  TooltipProvider,
  Tooltip,
  TooltipTrigger,
  TooltipContent,
} from "@/components/ui/tooltip";
import { hapticFeedback } from "@/lib/utils";

export default function Integrations() {
  const { toast } = useToast();
  const navigate = useNavigate();

  const [connections, setConnections] = useState<Record<string, boolean>>({
    oura: true,
    whoop: false,
    appleHealth: false,
    neuralEngine: false,
    webhook: false,
  });

  const [apiKeys, setApiKeys] = useState<Record<string, string>>({
    neuralEngine: "",
    webhookUrl: "",
    webhookIps: "",
  });

  const [webhookTemplate, setWebhookTemplate] = useState("default");
  const [customPayload, setCustomPayload] = useState(
    '{\n  "event": "{{event_type}}",\n  "data": {{telemetry_data}}\n}',
  );
  const [signatureEnabled, setSignatureEnabled] = useState(false);
  const [webhookSecret, setWebhookSecret] = useState(
    "whsec_elite_" + Math.random().toString(36).substring(2, 10),
  );
  const [notifyOnRotation, setNotifyOnRotation] = useState(true);
  const [encryptionEnabled, setEncryptionEnabled] = useState(false);
  const [encryptionKey, setEncryptionKey] = useState(
    "whe_elite_" + Math.random().toString(36).substring(2, 10),
  );
  const [mTLSEnabled, setMTLSEnabled] = useState(false);
  const [clientCertificate, setClientCertificate] = useState(
    "-----BEGIN CERTIFICATE-----\nMII... (Elite Client Cert)\n-----END CERTIFICATE-----",
  );
  const [retryEnabled, setRetryEnabled] = useState(false);
  const [maxRetries, setMaxRetries] = useState("3");
  const [compressionEnabled, setCompressionEnabled] = useState(false);
  const [rateLimitEnabled, setRateLimitEnabled] = useState(false);
  const [rateLimitMaxRequests, setRateLimitMaxRequests] = useState("100");
  const [rateLimitWindow, setRateLimitWindow] = useState("60");
  const [autoDisableEnabled, setAutoDisableEnabled] = useState(false);
  const [autoDisableThreshold, setAutoDisableThreshold] = useState("5");
  const [alertRulesEnabled, setAlertRulesEnabled] = useState(false);
  const [latencyThreshold, setLatencyThreshold] = useState("500");
  const [errorRateThreshold, setErrorRateThreshold] = useState("5");
  const [logFilter, setLogFilter] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [liveMonitoring, setLiveMonitoring] = useState(false);
  const [routingRules, setRoutingRules] = useState<
    Array<{
      id: string;
      source: string;
      failover: string;
      priority: string;
      status: "active" | "inactive";
    }>
  >([
    {
      id: "1",
      source: "North America",
      failover: "Europe",
      priority: "High",
      status: "active",
    },
    {
      id: "2",
      source: "Asia Pacific",
      failover: "North America",
      priority: "Medium",
      status: "active",
    },
  ]);
  const [isPreviewModalOpen, setIsPreviewModalOpen] = useState(false);
  const [isAddRuleOpen, setIsAddRuleOpen] = useState(false);
  const [newRule, setNewRule] = useState({
    source: "",
    failover: "",
    priority: "Medium",
  });
  const [isSimulatingFailover, setIsSimulatingFailover] = useState(false);
  const [simulationLog, setSimulationLog] = useState<string[]>([]);
  const [autoTestingEnabled, setAutoTestingEnabled] = useState(false);
  const [autoTestingInterval, setAutoTestingInterval] = useState("15");
  const [autoDeliveryEnabled, setAutoDeliveryEnabled] = useState(false);
  const [deliveryEmails, setDeliveryEmails] = useState("");
  const [deliverySchedule, setDeliverySchedule] = useState("1st");
  const [failoverHistory, setFailoverHistory] = useState<
    Array<{
      id: string;
      timestamp: Date;
      source: string;
      failover: string;
      status: "success" | "failed";
      duration: string;
    }>
  >([
    {
      id: "1",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2),
      source: "Asia Pacific",
      failover: "North America",
      status: "success",
      duration: "2.8s",
    },
    {
      id: "2",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24),
      source: "North America",
      failover: "Europe",
      status: "success",
      duration: "3.1s",
    },
  ]);

  React.useEffect(() => {
    if (!autoTestingEnabled || routingRules.length === 0) return;
    const interval = setInterval(() => {
      if (!isSimulatingFailover) {
        toast({
          title: "Automated Route Test",
          description: "Periodic failover simulation initiated.",
        });
        runFailoverSimulation();
      }
    }, 30000); // Demo: runs every 30s instead of minutes so it's visible
    return () => clearInterval(interval);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    autoTestingEnabled,
    autoTestingInterval,
    routingRules.length,
    isSimulatingFailover,
  ]);

  const runFailoverSimulation = () => {
    if (routingRules.length === 0) {
      toast({
        variant: "destructive",
        title: "Simulation Failed",
        description: "No active routing rules configured.",
      });
      return;
    }

    setIsSimulatingFailover(true);
    setSimulationLog([]);
    hapticFeedback([20, 50, 20]);
    toast({
      title: "Simulation Initiated",
      description: "Testing global failover logic...",
    });

    const rule = routingRules[0];

    setTimeout(() => {
      setSimulationLog((prev) => [
        ...prev,
        `[0.0s] Simulating critical failure in ${rule.source} node...`,
      ]);
      hapticFeedback(20);
    }, 500);

    setTimeout(() => {
      setSimulationLog((prev) => [
        ...prev,
        `[0.8s] Failure detected. Latency spiked to >5000ms.`,
      ]);
      hapticFeedback(20);
    }, 1300);

    setTimeout(() => {
      setSimulationLog((prev) => [
        ...prev,
        `[1.2s] Evaluating routing rules... Match found (Priority: ${rule.priority}).`,
      ]);
      hapticFeedback(20);
    }, 1700);

    setTimeout(() => {
      setSimulationLog((prev) => [
        ...prev,
        `[1.8s] Redirecting telemetry stream to ${rule.failover} node...`,
      ]);
      hapticFeedback([50, 50]);
    }, 2300);

    setTimeout(() => {
      setSimulationLog((prev) => [
        ...prev,
        `[2.5s] Connection established. Telemetry flow restored.`,
      ]);
      hapticFeedback([50, 100, 50]);
      toast({
        title: "Simulation Complete",
        description: `Failover to ${rule.failover} successful.`,
      });

      setFailoverHistory((prev) =>
        [
          {
            id: Math.random().toString(36).substring(2, 9),
            timestamp: new Date(),
            source: rule.source,
            failover: rule.failover,
            status: "success" as const,
            duration: "2.5s",
          },
          ...prev,
        ].slice(0, 10),
      );

      setTimeout(() => {
        setIsSimulatingFailover(false);
      }, 4000);
    }, 3000);
  };

  const [deliveryLogs, setDeliveryLogs] = useState<
    Array<{
      id: string;
      timestamp: Date;
      status: number;
      payload: string;
      data: string;
      encrypted?: boolean;
      compressed?: boolean;
    }>
  >([
    {
      id: "1",
      timestamp: new Date(Date.now() - 1000 * 60 * 5),
      status: 200,
      payload: "Standard Telemetry",
      data: '{\n  "event": "telemetry_sync",\n  "data": {\n    "cognitiveLoad": 45,\n    "recoveryIndex": 82\n  }\n}',
    },
    {
      id: "2",
      timestamp: new Date(Date.now() - 1000 * 60 * 60),
      status: 200,
      payload: "Minimal Ping",
      data: '{\n  "event": "ping",\n  "status": "online"\n}',
    },
    {
      id: "3",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24),
      status: 500,
      payload: "Full Audit Export",
      data: '{\n  "event": "audit_export",\n  "data": null,\n  "error": "timeout"\n}',
    },
  ]);
  const [selectedLog, setSelectedLog] = useState<{
    id: string;
    timestamp: Date;
    status: number;
    payload: string;
    data: string;
    encrypted?: boolean;
    compressed?: boolean;
  } | null>(null);
  const [selectedMapNode, setSelectedMapNode] = useState<{
    region: string;
    latency: number;
    status: string;
  } | null>(null);
  const [healthStatus, setHealthStatus] = useState<"operational" | "degraded">(
    "operational",
  );
  const [healthMetrics, setHealthMetrics] = useState({
    uptime: 99.98,
    latency: 132,
    p99Latency: 245,
    errorRate: 0.02,
    requestCount: 14280,
  });
  const [healthData, setHealthData] = useState([
    { time: "00:00:00", latency: 120, uptime: 100 },
    { time: "00:00:03", latency: 135, uptime: 100 },
    { time: "00:00:06", latency: 110, uptime: 100 },
    { time: "00:00:09", latency: 145, uptime: 100 },
    { time: "00:00:12", latency: 160, uptime: 98 },
    { time: "00:00:15", latency: 125, uptime: 100 },
    { time: "00:00:18", latency: 130, uptime: 100 },
  ]);

  React.useEffect(() => {
    if (!liveMonitoring) return;
    const interval = setInterval(() => {
      setHealthData((prev) => {
        const isOperational = healthStatus === "operational";
        const newLatency = isOperational
          ? Math.max(
              50,
              Math.min(
                300,
                prev[prev.length - 1].latency + (Math.random() * 40 - 20),
              ),
            )
          : Math.max(
              500,
              Math.min(
                1200,
                prev[prev.length - 1].latency + (Math.random() * 200 - 100),
              ),
            );

        const newUptime = isOperational
          ? Math.max(
              99,
              Math.min(
                100,
                (prev[prev.length - 1].uptime || 100) +
                  (Math.random() * 0.2 - 0.1),
              ),
            )
          : Math.max(
              80,
              Math.min(
                95,
                (prev[prev.length - 1].uptime || 90) - Math.random() * 2,
              ),
            );

        return [
          ...prev.slice(1),
          {
            time: new Date().toLocaleTimeString([], {
              hour: "2-digit",
              minute: "2-digit",
              second: "2-digit",
            }),
            latency: Math.round(newLatency),
            uptime: Number(newUptime.toFixed(2)),
          },
        ];
      });
    }, 3000);
    return () => clearInterval(interval);
  }, [liveMonitoring, healthStatus]);

  const filteredLogs = deliveryLogs.filter((log) => {
    const matchesFilter =
      logFilter === "all" ||
      (logFilter === "success" && log.status === 200) ||
      (logFilter === "error" && log.status !== 200);

    const matchesSearch =
      log.payload.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.data.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesFilter && matchesSearch;
  });

  const toggleConnection = (id: string, name: string) => {
    hapticFeedback([20, 50, 20]);
    if (connections[id]) {
      setConnections((prev) => ({ ...prev, [id]: false }));
      toast({
        title: "Connection Terminated",
        description: `${name} telemetry stream disconnected.`,
      });
    } else {
      toast({
        title: "Initiating Handshake",
        description: `Establishing secure connection to ${name}...`,
      });
      setTimeout(() => {
        hapticFeedback([50, 100, 50]);
        setConnections((prev) => ({ ...prev, [id]: true }));
        toast({
          title: "Sync Established",
          description: `${name} is now streaming biometric data.`,
        });
      }, 1500);
    }
  };

  const saveApiKey = (id: string, name: string) => {
    hapticFeedback([30, 50, 30]);
    toast({
      title: "Key Verified",
      description: `${name} API key securely encrypted and stored.`,
    });
    setConnections((prev) => ({ ...prev, [id]: true }));
  };

  const saveWebhook = (id: string, name: string) => {
    hapticFeedback([30, 50, 30]);
    toast({
      title: "Endpoint Verified",
      description: `${name} endpoint saved and active.`,
    });
    setConnections((prev) => ({ ...prev, [id]: true }));
  };

  const testWebhook = () => {
    hapticFeedback([20, 30, 20]);
    toast({
      title: "Dispatching Payload",
      description: `Sending ${encryptionEnabled ? "encrypted" : "mock"} telemetry data to endpoint...`,
    });
    setTimeout(() => {
      hapticFeedback([50]);

      let rawData = '{\n  "event": "test_dispatch",\n  "status": "success"\n}';
      let payloadName = "Standard Telemetry";

      if (webhookTemplate === "custom") {
        rawData = customPayload;
        payloadName = "Custom Payload";
      } else if (webhookTemplate === "minimal") {
        rawData = '{\n  "status": "online"\n}';
        payloadName = "Minimal Ping";
      } else if (webhookTemplate === "audit") {
        rawData = '{\n  "event": "audit_export",\n  "data": { "score": 95 }\n}';
        payloadName = "Full Audit Export";
      } else if (webhookTemplate === "slack") {
        rawData =
          '{\n  "text": "🧠 TherapyFIT Alert: New neural telemetry synced successfully. Recovery Index: 82%"\n}';
        payloadName = "Slack Notification";
      } else if (webhookTemplate === "discord") {
        rawData =
          '{\n  "content": "🧠 **TherapyFIT Alert**: New neural telemetry synced successfully.\\n**Recovery Index**: 82%"\n}';
        payloadName = "Discord Webhook";
      }

      let finalData = encryptionEnabled
        ? btoa(rawData).substring(0, 64) + "..."
        : rawData;

      if (compressionEnabled) {
        finalData = "[Gzip Compressed Binary Data]";
      }

      toast({
        title: "Webhook Delivered",
        description: `Successfully dispatched ${payloadName} payload. Response: 200 OK`,
      });
      setDeliveryLogs((prev) =>
        [
          {
            id: Math.random().toString(36).substring(2, 9),
            timestamp: new Date(),
            status: 200,
            payload: payloadName,
            data: finalData,
            encrypted: encryptionEnabled,
            compressed: compressionEnabled,
          },
          ...prev,
        ].slice(0, 20),
      );
    }, 1000);
  };

  const handleRegenerateSecret = () => {
    hapticFeedback([20, 30, 20]);
    const newSecret =
      "whsec_elite_" + Math.random().toString(36).substring(2, 10);
    setWebhookSecret(newSecret);

    if (notifyOnRotation && apiKeys.webhookUrl) {
      toast({
        title: "Secret Rotated",
        description: "New secret generated and dispatched to endpoint.",
      });
      const rawData = JSON.stringify(
        {
          event: "secret.rotated",
          data: { new_secret: newSecret, timestamp: new Date().toISOString() },
        },
        null,
        2,
      );
      let finalData = encryptionEnabled
        ? btoa(rawData).substring(0, 64) + "..."
        : rawData;

      if (compressionEnabled) {
        finalData = "[Gzip Compressed Binary Data]";
      }

      setDeliveryLogs((prev) =>
        [
          {
            id: Math.random().toString(36).substring(2, 9),
            timestamp: new Date(),
            status: 200,
            payload: "Secret Rotation Notice",
            data: finalData,
            encrypted: encryptionEnabled,
            compressed: compressionEnabled,
          },
          ...prev,
        ].slice(0, 20),
      );
    } else {
      toast({
        title: "Secret Regenerated",
        description: "New webhook secret generated locally.",
      });
    }
  };

  const handleRegenerateEncryptionKey = () => {
    hapticFeedback([20, 30, 20]);
    const newKey = "whe_elite_" + Math.random().toString(36).substring(2, 10);
    setEncryptionKey(newKey);
    toast({
      title: "Encryption Key Rotated",
      description: "New AES-256 GCM key generated.",
    });
  };

  const simulateRotationFailure = () => {
    hapticFeedback([20, 30, 20]);
    toast({
      title: "Dispatching Rotation Payload",
      description: "Simulating rotation failure...",
    });

    setTimeout(() => {
      hapticFeedback([50, 10, 50]);
      toast({
        variant: "destructive",
        title: "Delivery Failed",
        description: "Endpoint returned 503 Service Unavailable",
      });

      const newLogId = Math.random().toString(36).substring(2, 9);
      const failedLog = {
        id: newLogId,
        timestamp: new Date(),
        status: 503,
        payload: "Secret Rotation Notice",
        data: '{\n  "event": "secret.rotated",\n  "error": "Connection timeout"\n}',
      };

      setDeliveryLogs((prev) => [failedLog, ...prev].slice(0, 20));

      if (retryEnabled) {
        setTimeout(() => {
          toast({
            title: "Retry Protocol Engaged",
            description: `Initiating exponential backoff (Max ${maxRetries} attempts)...`,
          });
        }, 500);

        let attempt = 1;
        const max = parseInt(maxRetries);
        const retryInterval = setInterval(() => {
          if (attempt <= max) {
            hapticFeedback([20]);
            const isSuccess = !autoDisableEnabled && attempt === max;
            const retryLog = {
              id: Math.random().toString(36).substring(2, 9),
              timestamp: new Date(),
              status: isSuccess ? 200 : 503,
              payload: `Secret Rotation (Retry ${attempt}/${max})`,
              data: isSuccess
                ? '{\n  "event": "secret.rotated",\n  "status": "success"\n}'
                : '{\n  "event": "secret.rotated",\n  "error": "Connection timeout"\n}',
            };
            setDeliveryLogs((prev) => [retryLog, ...prev].slice(0, 20));

            if (isSuccess) {
              toast({
                title: "Delivery Recovered",
                description: `Payload delivered successfully on attempt ${attempt}.`,
              });
              clearInterval(retryInterval);
            } else {
              toast({
                variant: "destructive",
                title: "Retry Failed",
                description: `Attempt ${attempt}/${max} failed. Backing off...`,
              });
            }
            attempt++;
          } else {
            clearInterval(retryInterval);
            if (autoDisableEnabled) {
              const threshold = parseInt(autoDisableThreshold);
              if (max >= threshold || max === parseInt(maxRetries)) {
                setConnections((prev) => ({ ...prev, webhook: false }));
                toast({
                  variant: "destructive",
                  title: "Webhook Auto-Disabled",
                  description: `Endpoint disabled after consecutive failures.`,
                });
                setDeliveryLogs((prev) =>
                  [
                    {
                      id: Math.random().toString(36).substring(2, 9),
                      timestamp: new Date(),
                      status: 503,
                      payload: "System Alert",
                      data: '{\n  "event": "system.alert",\n  "message": "Webhook automatically disabled due to consecutive delivery failures."\n}',
                    },
                    ...prev,
                  ].slice(0, 20),
                );
              }
            }
          }
        }, 2000);
      }
    }, 1000);
  };

  const refreshHealth = () => {
    hapticFeedback([20, 30, 20]);
    setHealthStatus("operational");
    setHealthMetrics({
      uptime: 99.98,
      latency: 132,
      p99Latency: 245,
      errorRate: 0.02,
      requestCount: 14280,
    });
    setHealthData((prev) => [
      ...prev.slice(1),
      {
        time: new Date().toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
          second: "2-digit",
        }),
        latency: 128,
        uptime: 100,
      },
    ]);
    toast({
      title: "Telemetry Refreshed",
      description: "Health metrics updated. Systems operational.",
    });
  };

  const simulateOutage = () => {
    hapticFeedback([50, 100, 50]);
    setHealthStatus("degraded");
    setHealthMetrics({
      uptime: 98.45,
      latency: 845,
      p99Latency: 1200,
      errorRate: 4.2,
      requestCount: 14280,
    });
    setHealthData((prev) => [
      ...prev.slice(1),
      {
        time: new Date().toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
          second: "2-digit",
        }),
        latency: 845,
        uptime: 85,
      },
    ]);
    toast({
      variant: "destructive",
      title: "Endpoint Degraded",
      description: "External server is experiencing high latency and errors.",
    });
  };

  const clearLogs = () => {
    hapticFeedback([20, 50, 20]);
    setDeliveryLogs([]);
    toast({
      title: "Logs Cleared",
      description: "Webhook delivery history has been wiped.",
    });
  };

  const exportLogs = () => {
    hapticFeedback([20, 30, 20]);
    const csvContent =
      "ID,Timestamp,Status,Payload\n" +
      filteredLogs
        .map(
          (log) =>
            `${log.id},${log.timestamp.toISOString()},${log.status},"${log.payload}"`,
        )
        .join("\n");

    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `webhook_delivery_logs_${new Date().toISOString().split("T")[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    toast({
      title: "Logs Exported",
      description: "Webhook delivery history has been downloaded.",
    });
  };

  return (
    <div className="flex flex-1 flex-col bg-background text-foreground">
      <main className="flex-1 container max-w-4xl px-4 py-8 md:py-12 mx-auto">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-primary/10 rounded-lg text-primary">
              <Plug className="h-6 w-6" />
            </div>
            <h1 className="text-3xl font-bold tracking-tight">
              Integration Hub
            </h1>
            <div className="ml-auto">
              <NeuralNotificationCenter />
            </div>
          </div>
          <p className="text-muted-foreground mt-2">
            Connect external APIs and biometric hardware to your neural command
            center.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          {/* Oura Ring */}
          <Card className="bg-card/40 border-border/50 backdrop-blur-sm flex flex-col">
            <CardHeader>
              <div className="flex justify-between items-start">
                <div className="p-2 bg-blue-500/10 text-blue-500 rounded-lg mb-4">
                  <Activity className="h-6 w-6" />
                </div>
                {connections.oura ? (
                  <Badge
                    variant="outline"
                    className="border-primary text-primary bg-primary/10"
                  >
                    Connected
                  </Badge>
                ) : (
                  <Badge variant="outline" className="text-muted-foreground">
                    Disconnected
                  </Badge>
                )}
              </div>
              <CardTitle>Oura Ring API</CardTitle>
              <CardDescription>
                Continuous sleep architecture and readiness telemetry.
              </CardDescription>
            </CardHeader>
            <CardFooter className="mt-auto pt-6">
              <Button
                variant={connections.oura ? "outline" : "default"}
                className="w-full"
                onClick={() => toggleConnection("oura", "Oura Ring")}
              >
                {connections.oura ? "Disconnect" : "Connect Account"}
              </Button>
            </CardFooter>
          </Card>

          {/* Whoop */}
          <Card className="bg-card/40 border-border/50 backdrop-blur-sm flex flex-col">
            <CardHeader>
              <div className="flex justify-between items-start">
                <div className="p-2 bg-foreground/10 text-foreground rounded-lg mb-4">
                  <Watch className="h-6 w-6" />
                </div>
                {connections.whoop ? (
                  <Badge
                    variant="outline"
                    className="border-primary text-primary bg-primary/10"
                  >
                    Connected
                  </Badge>
                ) : (
                  <Badge variant="outline" className="text-muted-foreground">
                    Disconnected
                  </Badge>
                )}
              </div>
              <CardTitle>Whoop API</CardTitle>
              <CardDescription>
                Strain, recovery, and HRV synchronization.
              </CardDescription>
            </CardHeader>
            <CardFooter className="mt-auto pt-6">
              <Button
                variant={connections.whoop ? "outline" : "default"}
                className="w-full"
                onClick={() => toggleConnection("whoop", "Whoop")}
              >
                {connections.whoop ? "Disconnect" : "Connect Account"}
              </Button>
            </CardFooter>
          </Card>

          {/* Apple Health */}
          <Card className="bg-card/40 border-border/50 backdrop-blur-sm flex flex-col">
            <CardHeader>
              <div className="flex justify-between items-start">
                <div className="p-2 bg-destructive/10 text-destructive rounded-lg mb-4">
                  <Database className="h-6 w-6" />
                </div>
                {connections.appleHealth ? (
                  <Badge
                    variant="outline"
                    className="border-primary text-primary bg-primary/10"
                  >
                    Connected
                  </Badge>
                ) : (
                  <Badge variant="outline" className="text-muted-foreground">
                    Disconnected
                  </Badge>
                )}
              </div>
              <CardTitle>Apple HealthKit</CardTitle>
              <CardDescription>
                Aggregate local device telemetry and activity rings.
              </CardDescription>
            </CardHeader>
            <CardFooter className="mt-auto pt-6">
              <Button
                variant={connections.appleHealth ? "outline" : "default"}
                className="w-full"
                onClick={() =>
                  toggleConnection("appleHealth", "Apple HealthKit")
                }
              >
                {connections.appleHealth ? "Disconnect" : "Request Access"}
              </Button>
            </CardFooter>
          </Card>

          {/* Neural Engine (Custom API Key) */}
          <Card className="bg-card/40 border-border/50 backdrop-blur-sm flex flex-col">
            <CardHeader>
              <div className="flex justify-between items-start">
                <div className="p-2 bg-primary/10 text-primary rounded-lg mb-4">
                  <BrainCircuit className="h-6 w-6" />
                </div>
                {connections.neuralEngine ? (
                  <Badge
                    variant="outline"
                    className="border-primary text-primary bg-primary/10"
                  >
                    Active
                  </Badge>
                ) : (
                  <Badge variant="outline" className="text-muted-foreground">
                    Requires Key
                  </Badge>
                )}
              </div>
              <CardTitle>Custom Neural Engine</CardTitle>
              <CardDescription>
                Connect your own LLM API key for advanced synthesis.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="api-key" className="flex items-center gap-2">
                  <Key className="h-3 w-3" /> API Key
                </Label>
                <Input
                  id="api-key"
                  type="password"
                  placeholder="sk-..."
                  className="bg-background/50 font-mono text-xs"
                  value={apiKeys.neuralEngine}
                  onChange={(e) =>
                    setApiKeys((prev) => ({
                      ...prev,
                      neuralEngine: e.target.value,
                    }))
                  }
                />
              </div>
            </CardContent>
            <CardFooter className="mt-auto">
              <Button
                variant={connections.neuralEngine ? "outline" : "default"}
                className="w-full"
                onClick={() =>
                  saveApiKey("neuralEngine", "Custom Neural Engine")
                }
                disabled={!apiKeys.neuralEngine && !connections.neuralEngine}
              >
                {connections.neuralEngine ? "Update Key" : "Verify & Save Key"}
              </Button>
            </CardFooter>
          </Card>

          {/* Custom Webhooks */}
          <Card className="bg-card/40 border-border/50 backdrop-blur-sm flex flex-col">
            <CardHeader>
              <div className="flex justify-between items-start">
                <div className="p-2 bg-emerald-500/10 text-emerald-500 rounded-lg mb-4">
                  <Webhook className="h-6 w-6" />
                </div>
                {connections.webhook ? (
                  <Badge
                    variant="outline"
                    className="border-primary text-primary bg-primary/10"
                  >
                    Active
                  </Badge>
                ) : (
                  <Badge variant="outline" className="text-muted-foreground">
                    Inactive
                  </Badge>
                )}
              </div>
              <CardTitle>Custom Webhooks</CardTitle>
              <CardDescription>
                Stream real-time biometric events to your external endpoints.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label
                  htmlFor="webhook-url"
                  className="flex items-center gap-2"
                >
                  <Plug className="h-3 w-3" /> Endpoint URL
                </Label>
                <Input
                  id="webhook-url"
                  type="url"
                  placeholder="https://your-server.com/webhook"
                  className="bg-background/50 font-mono text-xs"
                  value={apiKeys.webhookUrl}
                  onChange={(e) =>
                    setApiKeys((prev) => ({
                      ...prev,
                      webhookUrl: e.target.value,
                    }))
                  }
                />
              </div>
              <div className="space-y-2 pt-4 border-t border-border/50">
                <Label className="flex items-center gap-2">
                  <FileJson className="h-3 w-3" /> Payload Template
                </Label>
                <Select
                  value={webhookTemplate}
                  onValueChange={setWebhookTemplate}
                >
                  <SelectTrigger className="bg-background/50">
                    <SelectValue placeholder="Select template" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="default">
                      Standard Telemetry (JSON)
                    </SelectItem>
                    <SelectItem value="minimal">
                      Minimal Ping (Status Only)
                    </SelectItem>
                    <SelectItem value="audit">Full Audit Export</SelectItem>
                    <SelectItem value="slack">Slack Notification</SelectItem>
                    <SelectItem value="discord">Discord Webhook</SelectItem>
                    <SelectItem value="custom">Custom Payload</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {webhookTemplate === "custom" && (
                <div className="space-y-2 pt-2">
                  <Label className="text-xs text-muted-foreground">
                    Custom JSON Template
                  </Label>
                  <Textarea
                    className="bg-background/50 font-mono text-xs min-h-[100px]"
                    value={customPayload}
                    onChange={(e) => setCustomPayload(e.target.value)}
                  />
                </div>
              )}
              {/* Signature Verification */}
              <div className="space-y-4 pt-4 border-t border-border/50">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base flex items-center gap-2">
                      <ShieldCheck className="h-4 w-4 text-emerald-500" />{" "}
                      Signature Verification
                    </Label>
                    <p className="text-xs text-muted-foreground">
                      Sign payloads with HMAC SHA-256.
                    </p>
                  </div>
                  <Switch
                    checked={signatureEnabled}
                    onCheckedChange={setSignatureEnabled}
                  />
                </div>
                {signatureEnabled && (
                  <div className="space-y-4 pt-2">
                    <div className="space-y-2">
                      <Label className="text-xs text-muted-foreground">
                        Webhook Secret
                      </Label>
                      <div className="flex gap-2">
                        <Input
                          type="text"
                          readOnly
                          value={webhookSecret}
                          className="bg-background/50 font-mono text-xs"
                        />
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={() => {
                            navigator.clipboard.writeText(webhookSecret);
                            toast({
                              title: "Secret Copied",
                              description:
                                "Webhook secret copied to clipboard.",
                            });
                            hapticFeedback(20);
                          }}
                        >
                          <Copy className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={handleRegenerateSecret}
                        >
                          <RefreshCw className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    <div className="flex items-center justify-between border-t border-border/50 pt-3">
                      <div className="space-y-0.5">
                        <Label className="text-xs flex items-center gap-2">
                          Auto-Notify Endpoint
                        </Label>
                        <p className="text-[10px] text-muted-foreground">
                          Dispatch new secret to endpoint upon rotation.
                        </p>
                      </div>
                      <Switch
                        checked={notifyOnRotation}
                        onCheckedChange={setNotifyOnRotation}
                        className="scale-75 data-[state=checked]:bg-emerald-500"
                      />
                    </div>
                  </div>
                )}
              </div>
              {/* Payload Encryption */}
              <div className="space-y-4 pt-4 border-t border-border/50">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base flex items-center gap-2">
                      <Lock className="h-4 w-4 text-emerald-500" /> Payload
                      Encryption
                    </Label>
                    <p className="text-xs text-muted-foreground">
                      Encrypt sensitive telemetry data using AES-256 GCM.
                    </p>
                  </div>
                  <Switch
                    checked={encryptionEnabled}
                    onCheckedChange={setEncryptionEnabled}
                  />
                </div>
                {encryptionEnabled && (
                  <div className="space-y-4 pt-2">
                    <div className="space-y-2">
                      <Label className="text-xs text-muted-foreground">
                        Encryption Key
                      </Label>
                      <div className="flex gap-2">
                        <Input
                          type="text"
                          readOnly
                          value={encryptionKey}
                          className="bg-background/50 font-mono text-xs"
                        />
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={() => {
                            navigator.clipboard.writeText(encryptionKey);
                            toast({
                              title: "Key Copied",
                              description:
                                "Encryption key copied to clipboard.",
                            });
                            hapticFeedback(20);
                          }}
                        >
                          <Copy className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={handleRegenerateEncryptionKey}
                        >
                          <RefreshCw className="h-4 w-4" />
                        </Button>
                      </div>
                      <p className="text-[10px] text-muted-foreground italic">
                        * Securely transmit this key to your server for
                        decryption.
                      </p>
                    </div>
                  </div>
                )}
              </div>
              {/* Mutual TLS (mTLS) */}
              <div className="space-y-4 pt-4 border-t border-border/50">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base flex items-center gap-2">
                      <Lock className="h-4 w-4 text-emerald-500" /> Mutual TLS
                      (mTLS)
                    </Label>
                    <p className="text-xs text-muted-foreground">
                      Authenticate client requests using an SSL certificate.
                    </p>
                  </div>
                  <Switch
                    checked={mTLSEnabled}
                    onCheckedChange={setMTLSEnabled}
                  />
                </div>
                {mTLSEnabled && (
                  <div className="space-y-4 pt-2">
                    <div className="space-y-2">
                      <Label className="text-xs text-muted-foreground">
                        Client Certificate
                      </Label>
                      <div className="flex gap-2">
                        <Input
                          type="text"
                          readOnly
                          value={clientCertificate}
                          className="bg-background/50 font-mono text-xs"
                        />
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={() => {
                            navigator.clipboard.writeText(clientCertificate);
                            toast({
                              title: "Certificate Copied",
                              description:
                                "Client certificate copied to clipboard.",
                            });
                            hapticFeedback(20);
                          }}
                        >
                          <Copy className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={() => {
                            hapticFeedback([20, 30, 20]);
                            setClientCertificate(
                              "-----BEGIN CERTIFICATE-----\nMIID... (New Elite Client Cert " +
                                Math.random().toString(36).substring(2, 6) +
                                ")\n-----END CERTIFICATE-----",
                            );
                            toast({
                              title: "Certificate Rotated",
                              description:
                                "New mTLS client certificate generated.",
                            });
                          }}
                        >
                          <RefreshCw className="h-4 w-4" />
                        </Button>
                      </div>
                      <p className="text-[10px] text-muted-foreground italic">
                        * Add this certificate to your server's trust store.
                      </p>
                    </div>
                  </div>
                )}
              </div>
              {/* Delivery Retry Protocol */}
              <div className="space-y-4 pt-4 border-t border-border/50">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base flex items-center gap-2">
                      <Repeat className="h-4 w-4 text-emerald-500" /> Delivery
                      Retry Protocol
                    </Label>
                    <p className="text-xs text-muted-foreground">
                      Automatically retry failed webhook deliveries with
                      exponential backoff.
                    </p>
                  </div>
                  <Switch
                    checked={retryEnabled}
                    onCheckedChange={setRetryEnabled}
                  />
                </div>
                {retryEnabled && (
                  <div className="space-y-2">
                    <Label className="text-xs text-muted-foreground">
                      Maximum Retry Attempts
                    </Label>
                    <Select value={maxRetries} onValueChange={setMaxRetries}>
                      <SelectTrigger className="bg-background/50 text-xs h-8">
                        <SelectValue placeholder="Select max retries" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1 Attempt</SelectItem>
                        <SelectItem value="3">3 Attempts</SelectItem>
                        <SelectItem value="5">5 Attempts</SelectItem>
                        <SelectItem value="10">10 Attempts (Max)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </div>
              {/* Payload Compression */}
              <div className="space-y-4 pt-4 border-t border-border/50">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base flex items-center gap-2">
                      <Database className="h-4 w-4 text-emerald-500" /> Payload
                      Compression
                    </Label>
                    <p className="text-xs text-muted-foreground">
                      Compress outgoing payloads using Gzip to reduce bandwidth.
                    </p>
                  </div>
                  <Switch
                    checked={compressionEnabled}
                    onCheckedChange={setCompressionEnabled}
                  />
                </div>
              </div>
              {/* Rate Limiting */}
              <div className="space-y-4 pt-4 border-t border-border/50">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base flex items-center gap-2">
                      <Activity className="h-4 w-4 text-emerald-500" /> Rate
                      Limiting
                    </Label>
                    <p className="text-xs text-muted-foreground">
                      Control the maximum number of requests sent to your
                      endpoint.
                    </p>
                  </div>
                  <Switch
                    checked={rateLimitEnabled}
                    onCheckedChange={setRateLimitEnabled}
                  />
                </div>
                {rateLimitEnabled && (
                  <div className="grid gap-4 sm:grid-cols-2 pt-2">
                    <div className="space-y-2">
                      <Label className="text-xs text-muted-foreground">
                        Max Requests
                      </Label>
                      <Input
                        type="number"
                        value={rateLimitMaxRequests}
                        onChange={(e) =>
                          setRateLimitMaxRequests(e.target.value)
                        }
                        className="bg-background/50 font-mono text-xs"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-xs text-muted-foreground">
                        Time Window (seconds)
                      </Label>
                      <Input
                        type="number"
                        value={rateLimitWindow}
                        onChange={(e) => setRateLimitWindow(e.target.value)}
                        className="bg-background/50 font-mono text-xs"
                      />
                    </div>
                  </div>
                )}
              </div>
              {/* Auto-Disable Webhook */}
              <div className="space-y-4 pt-4 border-t border-border/50">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base flex items-center gap-2">
                      <ShieldAlert className="h-4 w-4 text-destructive" />{" "}
                      Auto-Disable Endpoint
                    </Label>
                    <p className="text-xs text-muted-foreground">
                      Automatically disable webhook after consecutive delivery
                      failures.
                    </p>
                  </div>
                  <Switch
                    checked={autoDisableEnabled}
                    onCheckedChange={setAutoDisableEnabled}
                  />
                </div>
                {autoDisableEnabled && (
                  <div className="space-y-2">
                    <Label className="text-xs text-muted-foreground">
                      Failure Threshold
                    </Label>
                    <Select
                      value={autoDisableThreshold}
                      onValueChange={setAutoDisableThreshold}
                    >
                      <SelectTrigger className="bg-background/50 text-xs h-8">
                        <SelectValue placeholder="Select failure threshold" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="3">
                          3 Consecutive Failures
                        </SelectItem>
                        <SelectItem value="5">
                          5 Consecutive Failures
                        </SelectItem>
                        <SelectItem value="10">
                          10 Consecutive Failures
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </div>
              {/* Webhook Alert Rules */}
              <div className="space-y-4 pt-4 border-t border-border/50">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base flex items-center gap-2">
                      <Bell className="h-4 w-4 text-emerald-500" /> Alert Rules
                    </Label>
                    <p className="text-xs text-muted-foreground">
                      Get notified when endpoints experience high latency or
                      errors.
                    </p>
                  </div>
                  <Switch
                    checked={alertRulesEnabled}
                    onCheckedChange={setAlertRulesEnabled}
                  />
                </div>
                {alertRulesEnabled && (
                  <div className="space-y-4 pt-2">
                    <div className="grid gap-4 sm:grid-cols-2">
                      <div className="space-y-2">
                        <Label className="text-xs text-muted-foreground">
                          Latency Threshold (ms)
                        </Label>
                        <Input
                          type="number"
                          value={latencyThreshold}
                          onChange={(e) => setLatencyThreshold(e.target.value)}
                          className="bg-background/50 font-mono text-xs"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label className="text-xs text-muted-foreground">
                          Error Rate Threshold (%)
                        </Label>
                        <Input
                          type="number"
                          value={errorRateThreshold}
                          onChange={(e) =>
                            setErrorRateThreshold(e.target.value)
                          }
                          className="bg-background/50 font-mono text-xs"
                        />
                      </div>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full text-xs text-destructive border-destructive/50 hover:bg-destructive/10"
                      onClick={() => {
                        hapticFeedback([20, 50, 20]);
                        toast({
                          variant: "destructive",
                          title: "System Alert: High Latency",
                          description: `Endpoint latency exceeded ${latencyThreshold}ms threshold.`,
                        });
                      }}
                    >
                      Simulate Alert Trigger
                    </Button>
                  </div>
                )}
              </div>
              {/* IP Allowlisting */}
              <div className="space-y-4 pt-4 border-t border-border/50">
                <div className="space-y-0.5">
                  <Label className="text-base flex items-center gap-2">
                    <ShieldCheck className="h-4 w-4 text-emerald-500" /> IP
                    Allowlisting
                  </Label>
                  <p className="text-xs text-muted-foreground">
                    Restrict webhook delivery to specific IP addresses
                    (comma-separated).
                  </p>
                </div>
                <Input
                  placeholder="e.g., 192.168.1.1, 10.0.0.0/24"
                  className="bg-background/50 font-mono text-xs"
                  value={apiKeys.webhookIps || ""}
                  onChange={(e) =>
                    setApiKeys((prev) => ({
                      ...prev,
                      webhookIps: e.target.value,
                    }))
                  }
                />
              </div>
            </CardContent>
            <CardFooter className="mt-auto flex-col gap-2">
              <Button
                variant={connections.webhook ? "outline" : "default"}
                className="w-full"
                onClick={() => saveWebhook("webhook", "Custom Webhooks")}
                disabled={!apiKeys.webhookUrl && !connections.webhook}
              >
                {connections.webhook ? "Update Endpoint" : "Save Endpoint"}
              </Button>
              <div className="flex gap-2 w-full">
                <Button
                  variant="secondary"
                  className="w-full"
                  onClick={testWebhook}
                  disabled={!connections.webhook}
                >
                  Test Webhook
                </Button>
                <Button
                  variant="outline"
                  className="w-full text-destructive border-destructive/50 hover:bg-destructive/10"
                  onClick={simulateRotationFailure}
                  disabled={!connections.webhook}
                >
                  Simulate Rotation Failure
                </Button>
              </div>
            </CardFooter>
          </Card>

          {/* Webhook Health Dashboard */}
          <Card className="bg-card/40 border-border/50 backdrop-blur-sm flex flex-col md:col-span-2">
            <CardHeader>
              <div className="flex justify-between items-start">
                <div className="p-2 bg-emerald-500/10 text-emerald-500 rounded-lg mb-4">
                  <Server className="h-6 w-6" />
                </div>
                <div className="flex flex-wrap items-center gap-3">
                  <div className="flex items-center gap-2 mr-2">
                    <Switch
                      checked={liveMonitoring}
                      onCheckedChange={setLiveMonitoring}
                      id="live-monitoring"
                    />
                    <Label
                      htmlFor="live-monitoring"
                      className="text-xs cursor-pointer"
                    >
                      Live Monitoring
                    </Label>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-8 text-xs hover:bg-secondary"
                    onClick={() => {
                      hapticFeedback([20]);
                      toast({
                        title: "Pinging Endpoint",
                        description: "Measuring current latency...",
                      });
                      setTimeout(() => refreshHealth(), 800);
                    }}
                  >
                    <Activity className="h-3 w-3 mr-1" />
                    Ping
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-8 text-xs text-destructive hover:text-destructive hover:bg-destructive/10"
                    onClick={simulateOutage}
                  >
                    Simulate Outage
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-8 text-xs hover:bg-secondary"
                    onClick={refreshHealth}
                  >
                    <RefreshCw className="h-3 w-3 mr-1" />
                    Refresh
                  </Button>
                  {healthStatus === "operational" ? (
                    <Badge
                      variant="outline"
                      className="border-emerald-500 text-emerald-500 bg-emerald-500/10"
                    >
                      Operational
                    </Badge>
                  ) : (
                    <Badge
                      variant="outline"
                      className="border-destructive text-destructive bg-destructive/10"
                    >
                      Degraded
                    </Badge>
                  )}
                </div>
              </div>
              <CardTitle>Webhook Health</CardTitle>
              <CardDescription>
                Real-time endpoint uptime and latency metrics.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-4 mb-6">
                <div className="bg-background/40 border border-border/50 rounded-lg p-3 space-y-1">
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">
                    Uptime (30d)
                  </p>
                  <p
                    className={`text-xl font-bold ${healthStatus === "operational" ? "text-emerald-500" : "text-orange-500"}`}
                  >
                    {healthMetrics.uptime}%
                  </p>
                </div>
                <div className="bg-background/40 border border-border/50 rounded-lg p-3 space-y-1">
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">
                    Avg Latency
                  </p>
                  <p
                    className={`text-xl font-bold ${healthStatus === "operational" ? "text-primary" : "text-destructive"}`}
                  >
                    {healthMetrics.latency}ms
                  </p>
                </div>
                <div className="bg-background/40 border border-border/50 rounded-lg p-3 space-y-1">
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">
                    P99 Latency
                  </p>
                  <p
                    className={`text-xl font-bold ${healthStatus === "operational" ? "text-primary" : "text-destructive"}`}
                  >
                    {healthMetrics.p99Latency}ms
                  </p>
                </div>
                <div className="bg-background/40 border border-border/50 rounded-lg p-3 space-y-1">
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">
                    Requests (24h)
                  </p>
                  <p className="text-xl font-bold text-foreground">
                    {healthMetrics.requestCount.toLocaleString()}
                  </p>
                </div>
              </div>
              <div className="h-[200px] w-full">
                <ChartContainer
                  config={{
                    latency: {
                      label: "Latency (ms)",
                      color: "hsl(var(--primary))",
                    },
                    uptime: {
                      label: "Uptime (%)",
                      color: "#10b981",
                    },
                  }}
                  className="h-full w-full"
                >
                  <AreaChart
                    data={healthData}
                    margin={{ top: 5, right: 0, left: -20, bottom: 0 }}
                  >
                    <defs>
                      <linearGradient
                        id="colorLatency"
                        x1="0"
                        y1="0"
                        x2="0"
                        y2="1"
                      >
                        <stop
                          offset="5%"
                          stopColor={
                            healthStatus === "operational"
                              ? "hsl(var(--primary))"
                              : "hsl(var(--destructive))"
                          }
                          stopOpacity={0.3}
                        />
                        <stop
                          offset="95%"
                          stopColor={
                            healthStatus === "operational"
                              ? "hsl(var(--primary))"
                              : "hsl(var(--destructive))"
                          }
                          stopOpacity={0}
                        />
                      </linearGradient>
                      <linearGradient
                        id="colorUptime"
                        x1="0"
                        y1="0"
                        x2="0"
                        y2="1"
                      >
                        <stop
                          offset="5%"
                          stopColor="#10b981"
                          stopOpacity={0.3}
                        />
                        <stop
                          offset="95%"
                          stopColor="#10b981"
                          stopOpacity={0}
                        />
                      </linearGradient>
                    </defs>
                    <CartesianGrid
                      strokeDasharray="3 3"
                      vertical={false}
                      stroke="hsl(var(--border))"
                    />
                    <XAxis
                      dataKey="time"
                      stroke="hsl(var(--muted-foreground))"
                      fontSize={12}
                      tickLine={false}
                      axisLine={false}
                    />
                    <YAxis
                      yAxisId="left"
                      stroke="hsl(var(--muted-foreground))"
                      fontSize={12}
                      tickLine={false}
                      axisLine={false}
                      tickFormatter={(value) => `${value}ms`}
                    />
                    <YAxis
                      yAxisId="right"
                      orientation="right"
                      stroke="hsl(var(--muted-foreground))"
                      fontSize={12}
                      tickLine={false}
                      axisLine={false}
                      tickFormatter={(value) => `${value}%`}
                    />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Area
                      yAxisId="left"
                      type="monotone"
                      dataKey="latency"
                      stroke={
                        healthStatus === "operational"
                          ? "hsl(var(--primary))"
                          : "hsl(var(--destructive))"
                      }
                      strokeWidth={2}
                      fillOpacity={1}
                      fill="url(#colorLatency)"
                    />
                    <Area
                      yAxisId="right"
                      type="monotone"
                      dataKey="uptime"
                      stroke="#10b981"
                      strokeWidth={2}
                      fillOpacity={1}
                      fill="url(#colorUptime)"
                    />
                  </AreaChart>
                </ChartContainer>
              </div>
              <div className="mt-6 space-y-2">
                <div className="flex items-center justify-between text-[10px] text-muted-foreground font-bold uppercase tracking-wider">
                  <span>90 days ago</span>
                  <span className="text-emerald-500">99.98% uptime</span>
                  <span>Today</span>
                </div>
                <div className="flex h-8 w-full items-center gap-[2px]">
                  {Array.from({ length: 90 }).map((_, i) => {
                    const isDegraded = i === 45 || i === 72;
                    const isDowntime = i === 12;
                    return (
                      <div
                        key={i}
                        className={`h-full flex-1 rounded-sm transition-all hover:opacity-80 cursor-pointer ${
                          isDowntime
                            ? "bg-destructive"
                            : isDegraded
                              ? "bg-orange-500"
                              : "bg-emerald-500"
                        }`}
                        title={
                          isDowntime
                            ? "Major Outage"
                            : isDegraded
                              ? "Degraded Performance"
                              : "Operational"
                        }
                      />
                    );
                  })}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Latency Heatmap */}
          <Card className="bg-card/40 border-border/50 backdrop-blur-sm flex flex-col md:col-span-2">
            <CardHeader>
              <div className="flex justify-between items-start">
                <div className="p-2 bg-blue-500/10 text-blue-500 rounded-lg mb-4">
                  <Globe className="h-6 w-6" />
                </div>
                <Badge
                  variant="outline"
                  className="border-primary text-primary bg-primary/10"
                >
                  Global Telemetry
                </Badge>
              </div>
              <CardTitle>Latency Heatmap</CardTitle>
              <CardDescription>
                Visualize endpoint performance by global region.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Interactive Map */}
              <div className="relative h-[250px] sm:h-[300px] w-full bg-background/40 border border-border/50 rounded-lg overflow-hidden flex items-center justify-center">
                {/* Grid Overlay */}
                <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:20px_20px] pointer-events-none" />

                {/* SVG World Map */}
                <svg
                  viewBox="0 0 800 400"
                  className="absolute inset-0 w-full h-full opacity-20 stroke-primary/30 fill-none"
                >
                  <path d="M150,100 Q200,80 250,100 T350,120 T450,100 T550,120 T650,100 T750,120" />
                  <path d="M100,200 Q200,180 300,200 T500,220 T700,200" />
                  <path d="M200,300 Q300,280 400,300 T600,320" />
                </svg>

                {/* Nodes */}
                <TooltipProvider>
                  {[
                    {
                      region: "North America",
                      latency: 45,
                      status: "optimal",
                      x: 20,
                      y: 30,
                    },
                    {
                      region: "Europe",
                      latency: 120,
                      status: "stable",
                      x: 48,
                      y: 25,
                    },
                    {
                      region: "Asia Pacific",
                      latency: 280,
                      status: "degraded",
                      x: 80,
                      y: 40,
                    },
                    {
                      region: "South America",
                      latency: 150,
                      status: "stable",
                      x: 30,
                      y: 70,
                    },
                    {
                      region: "Africa",
                      latency: 310,
                      status: "degraded",
                      x: 52,
                      y: 60,
                    },
                    {
                      region: "Middle East",
                      latency: 180,
                      status: "stable",
                      x: 60,
                      y: 45,
                    },
                  ].map((node) => (
                    <Tooltip key={node.region}>
                      <TooltipTrigger asChild>
                        <div
                          className="absolute w-4 h-4 -ml-2 -mt-2 rounded-full cursor-crosshair transition-transform hover:scale-150 z-10"
                          style={{ left: `${node.x}%`, top: `${node.y}%` }}
                          onMouseEnter={() => hapticFeedback(5)}
                          onClick={() => {
                            hapticFeedback(20);
                            setSelectedMapNode(node);
                          }}
                        >
                          <div
                            className={`absolute inset-0 rounded-full animate-ping opacity-50 ${node.status === "optimal" ? "bg-emerald-500" : node.status === "stable" ? "bg-blue-400" : "bg-destructive"}`}
                            style={{ animationDuration: "2s" }}
                          />
                          <div
                            className={`relative w-full h-full rounded-full border-2 border-background shadow-lg ${node.status === "optimal" ? "bg-emerald-500" : node.status === "stable" ? "bg-blue-400" : "bg-destructive"}`}
                          />
                        </div>
                      </TooltipTrigger>
                      <TooltipContent className="bg-card/95 border-primary/30 backdrop-blur-md p-3">
                        <div className="space-y-1">
                          <div className="flex items-center justify-between gap-4">
                            <span className="text-xs font-bold text-foreground">
                              {node.region}
                            </span>
                            <div
                              className={`h-2 w-2 rounded-full ${node.status === "optimal" ? "bg-emerald-500" : node.status === "stable" ? "bg-blue-400" : "bg-destructive"}`}
                            />
                          </div>
                          <div className="flex items-end gap-2">
                            <span
                              className={`text-lg font-bold ${node.status === "optimal" ? "text-emerald-500" : node.status === "stable" ? "text-blue-400" : "text-destructive"}`}
                            >
                              {node.latency}ms
                            </span>
                            <span className="text-[10px] text-muted-foreground uppercase tracking-widest mb-1">
                              {node.status}
                            </span>
                          </div>
                        </div>
                      </TooltipContent>
                    </Tooltip>
                  ))}
                </TooltipProvider>
              </div>

              <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3">
                {[
                  { region: "North America", latency: 45, status: "optimal" },
                  { region: "Europe", latency: 120, status: "stable" },
                  { region: "Asia Pacific", latency: 280, status: "degraded" },
                  { region: "South America", latency: 150, status: "stable" },
                  { region: "Africa", latency: 310, status: "degraded" },
                  { region: "Middle East", latency: 180, status: "stable" },
                ].map((node) => (
                  <div
                    key={node.region}
                    className="bg-background/40 border border-border/50 rounded-lg p-4 flex flex-col gap-2 transition-colors hover:bg-background/60"
                  >
                    <div className="flex justify-between items-center">
                      <span className="text-xs font-bold text-muted-foreground flex items-center gap-1">
                        <MapPin className="h-3 w-3" /> {node.region}
                      </span>
                      <div
                        className={`h-2 w-2 rounded-full ${node.status === "optimal" ? "bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]" : node.status === "stable" ? "bg-blue-400 shadow-[0_0_8px_rgba(96,165,250,0.5)]" : "bg-destructive shadow-[0_0_8px_rgba(255,0,0,0.5)]"}`}
                      />
                    </div>
                    <div className="flex items-end gap-2">
                      <span
                        className={`text-2xl font-bold ${node.status === "optimal" ? "text-emerald-500" : node.status === "stable" ? "text-blue-400" : "text-destructive"}`}
                      >
                        {node.latency}ms
                      </span>
                      <span className="text-[10px] text-muted-foreground uppercase tracking-widest mb-1">
                        {node.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Node Routing Rules */}
          <Card className="bg-card/40 border-border/50 backdrop-blur-sm flex flex-col">
            <CardHeader>
              <div className="flex justify-between items-start">
                <div className="p-2 bg-primary/10 text-primary rounded-lg mb-4">
                  <GitBranch className="h-6 w-6" />
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-8 text-xs gap-1.5 border-orange-500/30 text-orange-500 hover:bg-orange-500/10"
                    onClick={runFailoverSimulation}
                    disabled={isSimulatingFailover}
                  >
                    <Activity className="h-3.5 w-3.5" />
                    Simulate Rules
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-8 text-xs gap-1.5 border-primary/30 text-primary hover:bg-primary/10"
                    onClick={() => {
                      hapticFeedback(20);
                      setIsAddRuleOpen(true);
                    }}
                  >
                    <Plus className="h-3.5 w-3.5" />
                    Add Rule
                  </Button>
                </div>
              </div>
              <CardTitle>Node Routing Rules</CardTitle>
              <CardDescription>
                Configure intelligent failover paths for global telemetry
                routing.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {isSimulatingFailover && (
                  <div className="p-3 rounded-lg bg-orange-500/10 border border-orange-500/30 space-y-2 mb-4">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold text-orange-500 uppercase tracking-widest flex items-center gap-2">
                        <RefreshCw className="h-3 w-3 animate-spin" /> Failover
                        Simulation Active
                      </span>
                    </div>
                    <div className="space-y-1 font-mono text-[10px]">
                      {simulationLog.map((log, i) => (
                        <div
                          key={i}
                          className={
                            i === simulationLog.length - 1
                              ? "text-foreground animate-pulse"
                              : "text-muted-foreground"
                          }
                        >
                          {log}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                {routingRules.map((rule) => (
                  <div
                    key={rule.id}
                    className="bg-background/40 border border-border/50 rounded-lg p-4 space-y-3 transition-colors hover:bg-background/60"
                  >
                    <div className="flex justify-between items-center">
                      <Badge
                        variant="outline"
                        className={
                          rule.status === "active"
                            ? "text-emerald-500 border-emerald-500/20 bg-emerald-500/10"
                            : "text-muted-foreground"
                        }
                      >
                        {rule.status.toUpperCase()}
                      </Badge>
                      <div className="flex items-center gap-1 text-[10px] text-muted-foreground uppercase tracking-widest font-bold">
                        Priority:{" "}
                        <span className="text-primary">{rule.priority}</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between gap-4">
                      <div className="flex flex-col gap-1 flex-1">
                        <span className="text-[10px] text-muted-foreground uppercase tracking-wider font-bold">
                          Source
                        </span>
                        <div className="flex items-center gap-2 text-sm font-medium">
                          <Server className="h-3.5 w-3.5 text-primary" />
                          {rule.source}
                        </div>
                      </div>
                      <ArrowRightLeft className="h-4 w-4 text-muted-foreground/50" />
                      <div className="flex flex-col gap-1 flex-1 text-right">
                        <span className="text-[10px] text-muted-foreground uppercase tracking-wider font-bold">
                          Failover
                        </span>
                        <div className="flex items-center gap-2 text-sm font-medium justify-end">
                          {rule.failover}
                          <Globe className="h-3.5 w-3.5 text-blue-400" />
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="space-y-4 pt-4 mt-4 border-t border-border/50">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base flex items-center gap-2">
                      <Repeat className="h-4 w-4 text-emerald-500" /> Automated
                      Route Testing
                    </Label>
                    <p className="text-xs text-muted-foreground">
                      Periodically simulate node failures to verify failover
                      logic.
                    </p>
                  </div>
                  <Switch
                    checked={autoTestingEnabled}
                    onCheckedChange={setAutoTestingEnabled}
                  />
                </div>
                {autoTestingEnabled && (
                  <div className="space-y-2">
                    <Label className="text-xs text-muted-foreground">
                      Testing Interval
                    </Label>
                    <Select
                      value={autoTestingInterval}
                      onValueChange={setAutoTestingInterval}
                    >
                      <SelectTrigger className="bg-background/50 text-xs h-8">
                        <SelectValue placeholder="Select interval" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="5">Every 5 minutes</SelectItem>
                        <SelectItem value="15">Every 15 minutes</SelectItem>
                        <SelectItem value="60">Every hour</SelectItem>
                        <SelectItem value="1440">Every 24 hours</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Failover History */}
          <Card className="bg-card/40 border-border/50 backdrop-blur-sm flex flex-col">
            <CardHeader>
              <div className="flex justify-between items-start">
                <div className="p-2 bg-primary/10 text-primary rounded-lg mb-4">
                  <History className="h-6 w-6" />
                </div>
                <Badge
                  variant="outline"
                  className="border-primary/30 text-primary bg-primary/10 uppercase tracking-widest text-[10px]"
                >
                  Registry
                </Badge>
              </div>
              <CardTitle>Failover History</CardTitle>
              <CardDescription>
                Log of automated route tests and failover events.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[350px] w-full pr-4">
                {failoverHistory.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-40 text-muted-foreground">
                    <Clock className="h-8 w-8 mb-2 opacity-20" />
                    <p className="text-sm">No failover events recorded.</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {failoverHistory.map((event) => (
                      <div
                        key={event.id}
                        className="bg-background/30 border border-border/40 rounded-lg p-3 space-y-2 transition-colors hover:bg-background/50"
                      >
                        <div className="flex justify-between items-center">
                          <div className="flex items-center gap-2">
                            {event.status === "success" ? (
                              <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500" />
                            ) : (
                              <XCircle className="h-3.5 w-3.5 text-destructive" />
                            )}
                            <span className="text-[10px] font-bold uppercase tracking-wider">
                              {event.status === "success"
                                ? "Failover Resolved"
                                : "Failover Failed"}
                            </span>
                          </div>
                          <span className="text-[10px] text-muted-foreground font-mono">
                            {event.timestamp.toLocaleTimeString()}
                          </span>
                        </div>
                        <div className="flex items-center justify-between gap-2 text-xs">
                          <div className="flex flex-col gap-0.5">
                            <span className="text-[10px] text-muted-foreground uppercase tracking-widest font-bold">
                              From
                            </span>
                            <span className="font-medium text-primary">
                              {event.source}
                            </span>
                          </div>
                          <ArrowRightLeft className="h-3 w-3 text-muted-foreground/30" />
                          <div className="flex flex-col gap-0.5 text-right">
                            <span className="text-[10px] text-muted-foreground uppercase tracking-widest font-bold">
                              To
                            </span>
                            <span className="font-medium text-blue-400">
                              {event.failover}
                            </span>
                          </div>
                        </div>
                        <div className="flex justify-between items-center pt-1 border-t border-border/20">
                          <span className="text-[10px] text-muted-foreground italic">
                            {event.timestamp.toLocaleDateString()}
                          </span>
                          <Badge
                            variant="outline"
                            className="text-[9px] h-4 bg-primary/5 text-primary/80 border-primary/20"
                          >
                            Duration: {event.duration}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>

          {/* Historical Failover Reports */}
          <Card className="bg-card/40 border-border/50 backdrop-blur-sm flex flex-col md:col-span-2">
            <CardHeader>
              <div className="flex justify-between items-start">
                <div className="p-2 bg-blue-500/10 text-blue-500 rounded-lg mb-4">
                  <BarChart4 className="h-6 w-6" />
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-8 text-xs hover:bg-secondary"
                    onClick={() => {
                      hapticFeedback([20, 30, 20]);
                      setIsPreviewModalOpen(true);
                    }}
                  >
                    <Download className="h-3 w-3 mr-1" />
                    Export Report
                  </Button>
                  <Badge
                    variant="outline"
                    className="border-blue-500/30 text-blue-400 bg-blue-500/10 uppercase tracking-widest text-[10px]"
                  >
                    Analytics
                  </Badge>
                </div>
              </div>
              <CardTitle>Historical Failover Reports</CardTitle>
              <CardDescription>
                Monthly resilience trends and failover success rates.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[250px] w-full mt-4">
                <ChartContainer
                  config={{
                    success: {
                      label: "Success Rate (%)",
                      color: "hsl(var(--primary))",
                    },
                    failed: {
                      label: "Failure Rate (%)",
                      color: "hsl(var(--destructive))",
                    },
                  }}
                  className="h-full w-full"
                >
                  <AreaChart
                    data={[
                      { month: "Jan", success: 98, failed: 2 },
                      { month: "Feb", success: 95, failed: 5 },
                      { month: "Mar", success: 99, failed: 1 },
                      { month: "Apr", success: 100, failed: 0 },
                      { month: "May", success: 97, failed: 3 },
                      { month: "Jun", success: 99, failed: 1 },
                    ]}
                    margin={{ top: 5, right: 0, left: -20, bottom: 0 }}
                  >
                    <defs>
                      <linearGradient
                        id="fillSuccess"
                        x1="0"
                        y1="0"
                        x2="0"
                        y2="1"
                      >
                        <stop
                          offset="5%"
                          stopColor="var(--color-success)"
                          stopOpacity={0.3}
                        />
                        <stop
                          offset="95%"
                          stopColor="var(--color-success)"
                          stopOpacity={0}
                        />
                      </linearGradient>
                      <linearGradient
                        id="fillFailed"
                        x1="0"
                        y1="0"
                        x2="0"
                        y2="1"
                      >
                        <stop
                          offset="5%"
                          stopColor="var(--color-failed)"
                          stopOpacity={0.3}
                        />
                        <stop
                          offset="95%"
                          stopColor="var(--color-failed)"
                          stopOpacity={0}
                        />
                      </linearGradient>
                    </defs>
                    <CartesianGrid
                      strokeDasharray="3 3"
                      vertical={false}
                      stroke="hsl(var(--border))"
                      opacity={0.5}
                    />
                    <XAxis
                      dataKey="month"
                      tickLine={false}
                      axisLine={false}
                      tickMargin={8}
                      tick={{
                        fill: "hsl(var(--muted-foreground))",
                        fontSize: 12,
                      }}
                    />
                    <YAxis
                      tickLine={false}
                      axisLine={false}
                      tickMargin={8}
                      tick={{
                        fill: "hsl(var(--muted-foreground))",
                        fontSize: 12,
                      }}
                    />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Area
                      type="monotone"
                      dataKey="success"
                      stroke="var(--color-success)"
                      fill="url(#fillSuccess)"
                      strokeWidth={2}
                    />
                    <Area
                      type="monotone"
                      dataKey="failed"
                      stroke="var(--color-failed)"
                      fill="url(#fillFailed)"
                      strokeWidth={2}
                    />
                  </AreaChart>
                </ChartContainer>
              </div>
              <div className="space-y-4 pt-4 mt-4 border-t border-border/50">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base flex items-center gap-2">
                      <Mail className="h-4 w-4 text-emerald-500" /> Automated
                      PDF Delivery
                    </Label>
                    <p className="text-xs text-muted-foreground">
                      Automatically email monthly resilience reports to your
                      team.
                    </p>
                  </div>
                  <Switch
                    checked={autoDeliveryEnabled}
                    onCheckedChange={(checked) => {
                      setAutoDeliveryEnabled(checked);
                      if (checked) {
                        hapticFeedback(20);
                        toast({
                          title: "Automated Delivery Enabled",
                          description:
                            "Configure your recipients and schedule.",
                        });
                      }
                    }}
                  />
                </div>
                {autoDeliveryEnabled && (
                  <div className="space-y-4 pt-2">
                    <div className="space-y-2">
                      <Label className="text-xs text-muted-foreground">
                        Recipient Email Addresses (comma-separated)
                      </Label>
                      <Input
                        placeholder="team@elite.co, admin@elite.co"
                        className="bg-background/50 font-mono text-xs"
                        value={deliveryEmails}
                        onChange={(e) => setDeliveryEmails(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-xs text-muted-foreground">
                        Delivery Schedule
                      </Label>
                      <Select
                        value={deliverySchedule}
                        onValueChange={(val) => {
                          setDeliverySchedule(val);
                          hapticFeedback(10);
                          toast({
                            title: "Schedule Updated",
                            description: `Reports will be sent on the ${val} of every month.`,
                          });
                        }}
                      >
                        <SelectTrigger className="bg-background/50 text-xs h-8">
                          <SelectValue placeholder="Select schedule" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1st">
                            1st of every month
                          </SelectItem>
                          <SelectItem value="15th">
                            15th of every month
                          </SelectItem>
                          <SelectItem value="last">
                            Last day of every month
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full text-xs"
                      onClick={() => {
                        if (!deliveryEmails) {
                          toast({
                            variant: "destructive",
                            title: "Configuration Required",
                            description:
                              "Please enter at least one recipient email.",
                          });
                          return;
                        }
                        hapticFeedback([20, 50, 20]);
                        toast({
                          title: "Test Email Dispatched",
                          description:
                            "A sample PDF report has been sent to the configured addresses.",
                        });
                      }}
                    >
                      Send Test Email
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card/40 border-border/50 backdrop-blur-sm flex flex-col md:col-span-2">
            <CardHeader>
              <div className="flex justify-between items-start">
                <div className="p-2 bg-primary/10 text-primary rounded-lg mb-4">
                  <Activity className="h-6 w-6" />
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-8 text-xs hover:bg-secondary"
                    onClick={exportLogs}
                  >
                    <Download className="h-3 w-3 mr-1" />
                    Export Logs
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-8 text-xs text-destructive hover:text-destructive hover:bg-destructive/10"
                    onClick={clearLogs}
                  >
                    <Trash2 className="h-3 w-3 mr-1" />
                    Clear Logs
                  </Button>
                  <div className="relative">
                    <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-3 w-3 text-muted-foreground" />
                    <Input
                      placeholder="Search payloads..."
                      className="h-8 w-[180px] pl-8 text-xs bg-background/50"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                  <Select value={logFilter} onValueChange={setLogFilter}>
                    <SelectTrigger className="w-[130px] h-8 text-xs bg-background/50">
                      <SelectValue placeholder="Filter Logs" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Logs</SelectItem>
                      <SelectItem value="success">Success (200)</SelectItem>
                      <SelectItem value="error">Errors</SelectItem>
                    </SelectContent>
                  </Select>
                  <Badge
                    variant="outline"
                    className="border-primary text-primary bg-primary/10"
                  >
                    Live
                  </Badge>
                </div>
              </div>
              <CardTitle>Delivery Logs</CardTitle>
              <CardDescription>
                Real-time monitoring of outgoing webhook telemetry.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[300px] w-full rounded-md border border-border/50 bg-background/50 p-4">
                {filteredLogs.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-full text-muted-foreground">
                    <Clock className="h-8 w-8 mb-2 opacity-20" />
                    <p className="text-sm">
                      No telemetry found for current filter.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {filteredLogs.map((log) => (
                      <div
                        key={log.id}
                        className="flex items-center justify-between border-b border-border/50 pb-4 last:border-0 last:pb-0"
                      >
                        <div className="flex items-center gap-3">
                          {log.status === 200 ? (
                            <CheckCircle2 className="h-5 w-5 text-emerald-500" />
                          ) : (
                            <XCircle className="h-5 w-5 text-destructive" />
                          )}
                          <div>
                            <p className="text-sm font-medium">{log.payload}</p>
                            <p className="text-xs text-muted-foreground font-mono">
                              {log.timestamp.toLocaleTimeString()} -{" "}
                              {log.timestamp.toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          {log.compressed && (
                            <Badge
                              variant="outline"
                              className="text-[10px] border-blue-500/50 text-blue-400"
                            >
                              Gzip
                            </Badge>
                          )}
                          <Badge
                            variant="outline"
                            className={
                              log.status === 200
                                ? "text-emerald-500 border-emerald-500/20 bg-emerald-500/10"
                                : "text-destructive border-destructive/20 bg-destructive/10"
                            }
                          >
                            {log.status} {log.status === 200 ? "OK" : "ERROR"}
                          </Badge>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-muted-foreground hover:text-primary"
                            onClick={() => setSelectedLog(log)}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>
        </div>
      </main>

      <Dialog
        open={!!selectedLog}
        onOpenChange={(open) => !open && setSelectedLog(null)}
      >
        <DialogContent className="sm:max-w-[600px] border-primary/20 bg-card/95 backdrop-blur-xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Webhook className="h-5 w-5 text-primary" />
              Log Details
            </DialogTitle>
            <DialogDescription>
              Full payload data for the selected webhook delivery.
            </DialogDescription>
          </DialogHeader>
          {selectedLog && (
            <div className="space-y-4 pt-4">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <p className="text-sm font-medium">{selectedLog.payload}</p>
                  <p className="text-xs text-muted-foreground font-mono">
                    {selectedLog.timestamp.toLocaleString()}
                  </p>
                </div>
                <Badge
                  variant="outline"
                  className={
                    selectedLog.status === 200
                      ? "text-emerald-500 border-emerald-500/20 bg-emerald-500/10"
                      : "text-destructive border-destructive/20 bg-destructive/10"
                  }
                >
                  {selectedLog.status}{" "}
                  {selectedLog.status === 200 ? "OK" : "ERROR"}
                </Badge>
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label className="text-xs text-muted-foreground">
                    Payload Data
                  </Label>
                  {selectedLog.encrypted && (
                    <Badge
                      variant="outline"
                      className="text-[10px] border-emerald-500/50 text-emerald-500 gap-1.5"
                    >
                      <Lock className="h-3 w-3" /> Encrypted
                    </Badge>
                  )}
                  {selectedLog.compressed && (
                    <Badge
                      variant="outline"
                      className="text-[10px] border-blue-500/50 text-blue-400 gap-1.5"
                    >
                      <Database className="h-3 w-3" /> Compressed
                    </Badge>
                  )}
                </div>
                <ScrollArea className="h-[250px] w-full rounded-md border border-border/50 bg-background/80 p-4">
                  <pre className="text-xs font-mono text-primary/90 whitespace-pre-wrap break-all">
                    {selectedLog.data}
                  </pre>
                </ScrollArea>
              </div>
              <div className="flex justify-end">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    navigator.clipboard.writeText(selectedLog.data);
                    toast({
                      title: "Payload Copied",
                      description: "Payload data copied to clipboard.",
                    });
                    hapticFeedback(20);
                  }}
                >
                  <Copy className="h-4 w-4 mr-2" />
                  Copy Payload
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <Dialog
        open={!!selectedMapNode}
        onOpenChange={(open) => !open && setSelectedMapNode(null)}
      >
        <DialogContent className="sm:max-w-[400px] border-primary/20 bg-card/95 backdrop-blur-xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <MapPin className="h-5 w-5 text-primary" />
              Node Latency Details
            </DialogTitle>
            <DialogDescription>
              Real-time performance metrics for {selectedMapNode?.region}.
            </DialogDescription>
          </DialogHeader>
          {selectedMapNode && (
            <div className="space-y-6 pt-4">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <p className="text-sm font-bold text-muted-foreground uppercase tracking-widest">
                    Region
                  </p>
                  <p className="text-xl font-bold text-foreground">
                    {selectedMapNode.region}
                  </p>
                </div>
                <Badge
                  variant="outline"
                  className={
                    selectedMapNode.status === "optimal"
                      ? "text-emerald-500 border-emerald-500/20 bg-emerald-500/10"
                      : selectedMapNode.status === "stable"
                        ? "text-blue-400 border-blue-400/20 bg-blue-400/10"
                        : "text-destructive border-destructive/20 bg-destructive/10"
                  }
                >
                  {selectedMapNode.status.toUpperCase()}
                </Badge>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-background/40 border border-border/50 rounded-lg p-3 space-y-1">
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">
                    Current Latency
                  </p>
                  <p
                    className={`text-2xl font-bold ${
                      selectedMapNode.status === "optimal"
                        ? "text-emerald-500"
                        : selectedMapNode.status === "stable"
                          ? "text-blue-400"
                          : "text-destructive"
                    }`}
                  >
                    {selectedMapNode.latency}ms
                  </p>
                </div>
                <div className="bg-background/40 border border-border/50 rounded-lg p-3 space-y-1">
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">
                    Packet Loss
                  </p>
                  <p className="text-2xl font-bold text-foreground">
                    {selectedMapNode.status === "optimal"
                      ? "0.01%"
                      : selectedMapNode.status === "stable"
                        ? "0.5%"
                        : "2.4%"}
                  </p>
                </div>
                <div className="bg-background/40 border border-border/50 rounded-lg p-3 space-y-1">
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">
                    Throughput
                  </p>
                  <p className="text-xl font-bold text-foreground">
                    {selectedMapNode.status === "optimal"
                      ? "1.2 GB/s"
                      : selectedMapNode.status === "stable"
                        ? "850 MB/s"
                        : "320 MB/s"}
                  </p>
                </div>
                <div className="bg-background/40 border border-border/50 rounded-lg p-3 space-y-1">
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">
                    Active Connections
                  </p>
                  <p className="text-xl font-bold text-foreground">
                    {Math.floor(Math.random() * 5000 + 1000).toLocaleString()}
                  </p>
                </div>
              </div>
              <div className="pt-2">
                <Button
                  variant="outline"
                  className="w-full gap-2 border-primary/30 text-primary hover:bg-primary/10"
                  onClick={() => {
                    hapticFeedback([20, 50, 20]);
                    toast({
                      title: "Diagnostics Initiated",
                      description: `Running deep diagnostic trace on ${selectedMapNode.region} node...`,
                    });
                  }}
                >
                  <Activity className="h-4 w-4" />
                  Run Deep Diagnostics
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
      <Dialog open={isAddRuleOpen} onOpenChange={setIsAddRuleOpen}>
        <DialogContent className="sm:max-w-[450px] border-primary/20 bg-card/95 backdrop-blur-xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <GitBranch className="h-5 w-5 text-primary" />
              Configure Routing Rule
            </DialogTitle>
            <DialogDescription>
              Define a new failover path for neural telemetry.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 pt-4">
            <div className="space-y-2">
              <Label>Source Region</Label>
              <Select
                value={newRule.source}
                onValueChange={(v) => setNewRule((p) => ({ ...p, source: v }))}
              >
                <SelectTrigger className="bg-background/50">
                  <SelectValue placeholder="Select source region" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="North America">North America</SelectItem>
                  <SelectItem value="Europe">Europe</SelectItem>
                  <SelectItem value="Asia Pacific">Asia Pacific</SelectItem>
                  <SelectItem value="South America">South America</SelectItem>
                  <SelectItem value="Africa">Africa</SelectItem>
                  <SelectItem value="Middle East">Middle East</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Failover Region</Label>
              <Select
                value={newRule.failover}
                onValueChange={(v) =>
                  setNewRule((p) => ({ ...p, failover: v }))
                }
              >
                <SelectTrigger className="bg-background/50">
                  <SelectValue placeholder="Select failover region" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="North America">North America</SelectItem>
                  <SelectItem value="Europe">Europe</SelectItem>
                  <SelectItem value="Asia Pacific">Asia Pacific</SelectItem>
                  <SelectItem value="South America">South America</SelectItem>
                  <SelectItem value="Africa">Africa</SelectItem>
                  <SelectItem value="Middle East">Middle East</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Priority Level</Label>
              <Select
                value={newRule.priority}
                onValueChange={(v) =>
                  setNewRule((p) => ({ ...p, priority: v }))
                }
              >
                <SelectTrigger className="bg-background/50">
                  <SelectValue placeholder="Select priority" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="High">High</SelectItem>
                  <SelectItem value="Medium">Medium</SelectItem>
                  <SelectItem value="Low">Low</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="pt-4 flex gap-3">
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => setIsAddRuleOpen(false)}
              >
                Cancel
              </Button>
              <Button
                className="flex-1"
                onClick={() => {
                  if (!newRule.source || !newRule.failover) {
                    toast({
                      variant: "destructive",
                      title: "Configuration Incomplete",
                      description: "Source and failover regions are required.",
                    });
                    return;
                  }
                  const rule = {
                    id: Math.random().toString(36).substring(2, 9),
                    ...newRule,
                    status: "active" as const,
                  };
                  setRoutingRules((p) => [rule, ...p]);
                  setIsAddRuleOpen(false);
                  setNewRule({ source: "", failover: "", priority: "Medium" });
                  hapticFeedback([50, 100, 50]);
                  toast({
                    title: "Rule Established",
                    description: `Failover path from ${newRule.source} to ${newRule.failover} is now active.`,
                  });
                }}
              >
                Establish Path
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={isPreviewModalOpen} onOpenChange={setIsPreviewModalOpen}>
        <DialogContent className="sm:max-w-[700px] border-primary/20 bg-card/95 backdrop-blur-xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <BarChart4 className="h-5 w-5 text-primary" />
              PDF Export Preview
            </DialogTitle>
            <DialogDescription>
              Review the Historical Failover Report before downloading.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 pt-4">
            <div className="flex items-center justify-between border-b border-border/50 pb-4">
              <div className="space-y-1">
                <p className="text-sm font-bold text-foreground">
                  TherapyFIT Elite App
                </p>
                <p className="text-xs text-muted-foreground font-mono">
                  Global Network Resilience Report
                </p>
              </div>
              <div className="text-right space-y-1">
                <p className="text-xs font-bold text-foreground">
                  {new Date().toLocaleDateString()}
                </p>
                <Badge
                  variant="outline"
                  className="text-[10px] border-primary/30 text-primary bg-primary/10"
                >
                  CONFIDENTIAL
                </Badge>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 py-2">
              <div className="bg-background/40 border border-border/50 rounded-lg p-3">
                <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">
                  Avg Success Rate
                </p>
                <p className="text-xl font-bold text-emerald-500">98.1%</p>
              </div>
              <div className="bg-background/40 border border-border/50 rounded-lg p-3">
                <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">
                  Total Failover Events
                </p>
                <p className="text-xl font-bold text-primary">1,248</p>
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-xs text-muted-foreground">
                Monthly Resilience Trends
              </Label>
              <div className="h-[180px] w-full rounded-md border border-border/50 bg-background/80 p-4 flex items-center justify-center">
                <ChartContainer
                  config={{
                    success: {
                      label: "Success Rate (%)",
                      color: "hsl(var(--primary))",
                    },
                    failed: {
                      label: "Failure Rate (%)",
                      color: "hsl(var(--destructive))",
                    },
                  }}
                  className="h-full w-full opacity-80"
                >
                  <AreaChart
                    data={[
                      { month: "Jan", success: 98, failed: 2 },
                      { month: "Feb", success: 95, failed: 5 },
                      { month: "Mar", success: 99, failed: 1 },
                      { month: "Apr", success: 100, failed: 0 },
                      { month: "May", success: 97, failed: 3 },
                      { month: "Jun", success: 99, failed: 1 },
                    ]}
                    margin={{ top: 5, right: 0, left: -20, bottom: 0 }}
                  >
                    <CartesianGrid
                      strokeDasharray="3 3"
                      vertical={false}
                      stroke="hsl(var(--border))"
                      opacity={0.5}
                    />
                    <XAxis
                      dataKey="month"
                      tickLine={false}
                      axisLine={false}
                      tickMargin={8}
                      tick={{
                        fill: "hsl(var(--muted-foreground))",
                        fontSize: 10,
                      }}
                    />
                    <Area
                      type="monotone"
                      dataKey="success"
                      stroke="hsl(var(--primary))"
                      fill="hsl(var(--primary))"
                      fillOpacity={0.2}
                      strokeWidth={2}
                    />
                    <Area
                      type="monotone"
                      dataKey="failed"
                      stroke="hsl(var(--destructive))"
                      fill="hsl(var(--destructive))"
                      fillOpacity={0.2}
                      strokeWidth={2}
                    />
                  </AreaChart>
                </ChartContainer>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-4">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsPreviewModalOpen(false)}
              >
                Cancel
              </Button>
              <Button
                size="sm"
                onClick={() => {
                  setIsPreviewModalOpen(false);
                  hapticFeedback([20, 50, 20]);
                  toast({
                    title: "Report Exported",
                    description:
                      "Historical failover report downloaded as PDF.",
                  });
                }}
              >
                <Download className="h-4 w-4 mr-2" />
                Confirm Export
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
