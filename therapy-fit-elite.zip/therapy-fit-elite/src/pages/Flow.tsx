import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import {
  Play,
  Pause,
  RotateCcw,
  Volume2,
  BrainCircuit,
  Waves,
  Wind,
  Star,
  CheckCircle2,
  Zap,
  TrendingUp,
  Lock,
  Unlock,
} from "lucide-react";
import { hapticFeedback, cn } from "@/lib/utils";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Area, AreaChart, CartesianGrid, XAxis, YAxis } from "recharts";
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from "@/components/ui/chart";

const focusData = [
  { date: "Mon", focus: 3.2 },
  { date: "Tue", focus: 3.5 },
  { date: "Wed", focus: 3.8 },
  { date: "Thu", focus: 4.1 },
  { date: "Fri", focus: 4.5 },
  { date: "Sat", focus: 4.2 },
  { date: "Sun", focus: 4.8 },
];

const chartConfig = {
  focus: {
    label: "Focus Intensity",
    color: "hsl(var(--primary))",
  },
};

const SOUNDSCAPES = [
  {
    id: "theta",
    name: "Deep Theta Waves",
    icon: BrainCircuit,
    color: "text-primary",
  },
  {
    id: "binaural",
    name: "Binaural Focus (40Hz)",
    icon: Waves,
    color: "text-blue-400",
  },
  {
    id: "noise",
    name: "Neural White Noise",
    icon: Wind,
    color: "text-muted-foreground",
  },
  {
    id: "overdrive",
    name: "Gamma Overdrive (100Hz)",
    icon: Zap,
    color: "text-fuchsia-500",
  },
];

const ParticleField = ({
  color = "217, 70, 239",
  intensity = 50,
}: {
  color?: string;
  intensity?: number;
}) => {
  useEffect(() => {
    const canvas = document.getElementById(
      "particle-canvas",
    ) as HTMLCanvasElement;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const particleCount = Math.floor(30 + (intensity / 100) * 150);
    const speedMultiplier = 0.5 + (intensity / 100) * 2.5;

    let particles: {
      x: number;
      y: number;
      vx: number;
      vy: number;
      size: number;
    }[] = [];
    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * speedMultiplier,
        vy: (Math.random() - 0.5) * speedMultiplier,
        size: Math.random() * 2 + 0.5,
      });
    }

    let mouse = { x: width / 2, y: height / 2 };
    const handleMouseMove = (e: MouseEvent) => {
      mouse.x = e.clientX;
      mouse.y = e.clientY;
    };
    window.addEventListener("mousemove", handleMouseMove);

    const handleResize = () => {
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };
    window.addEventListener("resize", handleResize);

    let animationFrameId: number;
    const render = () => {
      ctx.clearRect(0, 0, width, height);
      ctx.fillStyle = `rgba(${color}, 0.6)`;

      particles.forEach((p) => {
        p.x += p.vx;
        p.y += p.vy;

        if (p.x < 0 || p.x > width) p.vx *= -1;
        if (p.y < 0 || p.y > height) p.vy *= -1;

        const dx = mouse.x - p.x;
        const dy = mouse.y - p.y;
        const dist = Math.sqrt(dx * dx + dy * dy);

        if (dist < 200) {
          ctx.beginPath();
          ctx.strokeStyle = `rgba(${color}, ${(1 - dist / 200) * 0.5})`;
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(mouse.x, mouse.y);
          ctx.stroke();

          p.vx += dx * 0.0001 * speedMultiplier;
          p.vy += dy * 0.0001 * speedMultiplier;

          const speed = Math.sqrt(p.vx * p.vx + p.vy * p.vy);
          const maxSpeed = 3 * speedMultiplier;
          if (speed > maxSpeed) {
            p.vx = (p.vx / speed) * maxSpeed;
            p.vy = (p.vy / speed) * maxSpeed;
          }
        }

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      });

      animationFrameId = requestAnimationFrame(render);
    };
    render();

    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("resize", handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, [color, intensity]);

  return (
    <canvas
      id="particle-canvas"
      className="fixed inset-0 pointer-events-none z-0"
    />
  );
};

const NeuralBurst = ({ color = "217, 70, 239" }: { color?: string }) => (
  <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
    {[...Array(5)].map((_, i) => (
      <div
        key={i}
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[100vw] h-[100vw] border-[2px] rounded-full animate-burst"
        style={{
          animationDelay: `${i * 0.6}s`,
          animationDuration: "3s",
          borderColor: `rgba(${color}, 0.2)`,
        }}
      />
    ))}
    <div
      className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] via-transparent to-transparent animate-pulse"
      style={{
        backgroundImage: `radial-gradient(circle at center, rgba(${color}, 0.1), transparent, transparent)`,
      }}
    />
  </div>
);

const FLOW_COLORS: Record<string, string> = {
  theta: "0, 255, 255", // Cyan
  binaural: "96, 165, 250", // Blue 400
  noise: "156, 163, 175", // Gray 400
  overdrive: "217, 70, 239", // Fuchsia 500
};

export default function Flow() {
  const [isActive, setIsActive] = useState(false);
  const [isOverdrive, setIsOverdrive] = useState(false);
  const [timeLeft, setTimeLeft] = useState(25 * 60); // 25 minutes
  const [duration, setDuration] = useState(25 * 60);
  const [soundscape, setSoundscape] = useState("theta");
  const [flowColor, setFlowColor] = useState(FLOW_COLORS.theta);
  const [volume, setVolume] = useState([50]);
  const [showCheckIn, setShowCheckIn] = useState(false);
  const [focusRating, setFocusRating] = useState(3);
  const [isSaving, setIsSaving] = useState(false);
  const [syncIntensity, setSyncIntensity] = useState([50]);
  const [decryptionProgress, setDecryptionProgress] = useState(0);
  const [unlockedLore, setUnlockedLore] = useState<string | null>(null);
  const DECRYPTION_TARGET = 600; // 10 minutes

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isActive && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((time) => time - 1);
        setDecryptionProgress((prev) => {
          const next = prev + 1;
          if (next === DECRYPTION_TARGET && !unlockedLore) {
            hapticFeedback([50, 100, 50]);
            toast.success("CLASSIFIED LORE UNLOCKED: The Genesis Protocol");
            setUnlockedLore(
              "The Genesis Protocol: Initial neural mapping reveals latent cognitive reserves previously thought inaccessible.",
            );
          }
          return next;
        });
      }, 1000);
    } else if (timeLeft === 0 && isActive) {
      setIsActive(false);
      hapticFeedback([100, 50, 100, 50, 100, 50, 200]);
      setShowCheckIn(true);
    }
    return () => clearInterval(interval);
  }, [isActive, timeLeft, unlockedLore]);

  const toggleTimer = () => {
    hapticFeedback(isActive ? 50 : [50, 30, 50]);
    setIsActive(!isActive);
  };

  const resetTimer = () => {
    hapticFeedback(50);
    setIsActive(false);
    setTimeLeft(duration);
  };

  const handleDurationChange = (value: string) => {
    const mins = parseInt(value, 10);
    const newDuration = mins * 60;
    setDuration(newDuration);
    if (!isActive) {
      setTimeLeft(newDuration);
    }
  };

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
  };

  const handleSaveCheckIn = () => {
    setIsSaving(true);
    hapticFeedback([50, 30, 50]);

    // Simulate API call
    setTimeout(() => {
      setIsSaving(false);
      setShowCheckIn(false);
      toast.success("Calibration Saved", {
        description: `Focus rated at ${focusRating}/5. 500 Neural Points awarded.`,
      });
      // Award points (simulated via local storage if we wanted to be persistent)
      const currentPoints = parseInt(
        localStorage.getItem("neural_points") || "2500",
      );
      localStorage.setItem("neural_points", (currentPoints + 500).toString());
    }, 1500);
  };

  const handleSoundscapeChange = (value: string) => {
    setSoundscape(value);
    setFlowColor(FLOW_COLORS[value] || FLOW_COLORS.theta);
    if (value === "overdrive") {
      setIsOverdrive(true);
      hapticFeedback([100, 50, 100, 50, 200]);
      toast.warning("NEURAL OVERDRIVE ACTIVE", {
        description:
          "Extreme focus protocols engaged. Biometric thresholds expanded.",
      });
    } else {
      setIsOverdrive(false);
    }
  };

  const toggleOverdrive = () => {
    const newState = !isOverdrive;
    setIsOverdrive(newState);
    if (newState) {
      setSoundscape("overdrive");
      setFlowColor(FLOW_COLORS.overdrive);
      hapticFeedback([100, 50, 100, 50, 200]);
      toast.warning("NEURAL OVERDRIVE ACTIVE", {
        description:
          "Extreme focus protocols engaged. Biometric thresholds expanded.",
      });
    } else {
      setSoundscape("theta");
      setFlowColor(FLOW_COLORS.theta);
      hapticFeedback(50);
    }
  };

  const progress = ((duration - timeLeft) / duration) * 100;
  const ActiveIcon =
    SOUNDSCAPES.find((s) => s.id === soundscape)?.icon || BrainCircuit;

  return (
    <div
      className={cn(
        "container max-w-md mx-auto p-4 flex-1 flex flex-col transition-colors duration-1000 relative overflow-hidden",
        isOverdrive ? "bg-fuchsia-950/20" : "bg-background",
      )}
    >
      {(isOverdrive || isActive) && (
        <>
          <NeuralBurst color={flowColor} />
          <ParticleField color={flowColor} intensity={syncIntensity[0]} />
        </>
      )}
      <div className="relative z-10 flex flex-col flex-1">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1
              className={cn(
                "text-2xl font-bold tracking-tight transition-colors",
                isOverdrive ? "text-fuchsia-500" : "text-foreground",
              )}
            >
              {isOverdrive ? "Neural Overdrive" : "Flow State"}
            </h1>
            <p className="text-sm text-muted-foreground">
              {isOverdrive
                ? "Extreme focus engaged"
                : "Neural synchronization active"}
            </p>
          </div>
          <div className="flex items-center gap-3">
            <Button
              variant="outline"
              size="sm"
              className={cn(
                "h-8 gap-2 border-fuchsia-500/50 text-fuchsia-500 hover:bg-fuchsia-500/10 transition-all",
                isOverdrive &&
                  "bg-fuchsia-500 text-fuchsia-foreground animate-glow-magenta",
              )}
              onClick={toggleOverdrive}
            >
              <Zap
                className={cn("h-3.5 w-3.5", isOverdrive && "animate-pulse")}
              />
              OVERDRIVE
            </Button>
            <div
              className={cn(
                "h-10 w-10 rounded-full flex items-center justify-center transition-colors overflow-hidden",
                isOverdrive ? "bg-fuchsia-500/20" : "bg-primary/10",
              )}
            >
              <img
                src="https://vibe.filesafe.space/1776727899133821812/assets/751a1db7-dfb8-4825-b5d8-717da38d7b9e.webp"
                alt="TherapyFIT Elite Logo"
                className="h-full w-full object-contain"
              />
            </div>
          </div>
        </div>

        <Tabs defaultValue="session" className="flex-1 flex flex-col">
          <TabsList className="grid w-full grid-cols-2 mb-4 bg-background/50">
            <TabsTrigger value="session">Session</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>
          <TabsContent value="session" className="flex-1 flex flex-col mt-0">
            <Card
              className={cn(
                "flex-1 bg-card/40 border-border/50 backdrop-blur-sm relative overflow-hidden flex flex-col transition-all duration-500",
                isOverdrive &&
                  "border-fuchsia-500/50 shadow-[0_0_30px_rgba(255,0,255,0.2)]",
              )}
            >
              {isActive && (
                <div
                  className={cn(
                    "absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] via-transparent to-transparent animate-neural-pulse",
                    isOverdrive ? "from-fuchsia-500/10" : "from-primary/5",
                  )}
                />
              )}
              <CardContent className="flex-1 flex flex-col items-center justify-center p-8 relative z-10">
                {/* Cognitive Decryption Tracker */}
                <div className="w-full bg-[#111] border border-primary/20 rounded-xl p-4 relative overflow-hidden mb-8">
                  <div className="absolute inset-0 bg-primary/5 pointer-events-none" />
                  <div className="relative z-10 flex flex-col gap-2">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-2">
                        <Lock className="w-4 h-4 text-primary" />
                        <span className="text-xs font-bold text-primary uppercase tracking-widest">
                          Cognitive Decryption
                        </span>
                      </div>
                      <span className="text-xs text-primary font-mono">
                        {Math.min(
                          100,
                          Math.floor(
                            (decryptionProgress / DECRYPTION_TARGET) * 100,
                          ),
                        )}
                        %
                      </span>
                    </div>
                    <p className="text-[10px] text-muted-foreground">
                      Hold perfect flow for 10 minutes to unlock classified Tech
                      Tree nodes.
                    </p>
                    <div className="h-1.5 w-full bg-black/50 rounded-full overflow-hidden mt-1">
                      <div
                        className="h-full bg-primary shadow-[0_0_10px_rgba(0,255,255,0.5)] transition-all duration-1000 ease-linear"
                        style={{
                          width: `${Math.min(100, (decryptionProgress / DECRYPTION_TARGET) * 100)}%`,
                        }}
                      />
                    </div>
                    {unlockedLore && (
                      <div className="mt-3 p-3 bg-primary/10 border border-primary/30 rounded-lg animate-in fade-in slide-in-from-bottom-2">
                        <div className="flex items-center gap-2 mb-1">
                          <Unlock className="w-3 h-3 text-primary" />
                          <span className="text-[10px] font-bold text-primary uppercase tracking-widest">
                            Decrypted File
                          </span>
                        </div>
                        <p className="text-xs text-foreground/90 italic">
                          "{unlockedLore}"
                        </p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Circular Visualizer */}
                <div className="relative w-64 h-64 flex items-center justify-center mb-8 shrink-0">
                  {/* Background ring */}
                  <svg className="absolute inset-0 w-full h-full -rotate-90">
                    <circle
                      cx="128"
                      cy="128"
                      r="120"
                      className={cn(
                        "fill-none transition-all duration-1000",
                        isOverdrive
                          ? "stroke-fuchsia-900/30"
                          : "stroke-secondary",
                      )}
                      strokeWidth="4"
                    />
                    {/* Progress ring */}
                    <circle
                      cx="128"
                      cy="128"
                      r="120"
                      className={cn(
                        "fill-none transition-all duration-1000 ease-linear",
                        isOverdrive ? "stroke-fuchsia-500" : "stroke-primary",
                      )}
                      strokeWidth="4"
                      strokeDasharray={2 * Math.PI * 120}
                      strokeDashoffset={
                        2 * Math.PI * 120 * (1 - progress / 100)
                      }
                      strokeLinecap="round"
                    />
                  </svg>

                  {/* Glowing rings when active */}
                  {isActive && (
                    <>
                      <div
                        className={cn(
                          "absolute inset-4 rounded-full border animate-ping",
                          isOverdrive
                            ? "border-fuchsia-500/20"
                            : "border-primary/20",
                        )}
                        style={{ animationDuration: "3s" }}
                      />
                      <div
                        className={cn(
                          "absolute inset-8 rounded-full border animate-ping",
                          isOverdrive
                            ? "border-fuchsia-500/30"
                            : "border-primary/30",
                        )}
                        style={{
                          animationDuration: "2s",
                          animationDelay: "0.5s",
                        }}
                      />
                    </>
                  )}

                  <div className="text-center relative z-10">
                    <div
                      className={cn(
                        "text-6xl font-bold tracking-tighter tabular-nums transition-all",
                        isOverdrive
                          ? "text-fuchsia-500 drop-shadow-[0_0_20px_rgba(255,0,255,0.5)]"
                          : "text-foreground drop-shadow-[0_0_15px_rgba(0,255,255,0.3)]",
                      )}
                    >
                      {formatTime(timeLeft)}
                    </div>
                    <div
                      className={cn(
                        "text-sm font-medium mt-2 uppercase tracking-widest transition-colors",
                        isOverdrive ? "text-fuchsia-400" : "text-primary",
                      )}
                    >
                      {isActive
                        ? isOverdrive
                          ? "Overdrive Active"
                          : "Syncing..."
                        : "Standby"}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-4 w-full justify-center mb-12">
                  <Button
                    variant="outline"
                    size="icon"
                    className={cn(
                      "h-12 w-12 rounded-full border-primary/20 hover:bg-primary/10 hover:text-primary transition-colors",
                      isOverdrive &&
                        "border-fuchsia-500/20 hover:bg-fuchsia-500/10 hover:text-fuchsia-500",
                    )}
                    onClick={resetTimer}
                  >
                    <RotateCcw className="h-5 w-5" />
                  </Button>
                  <Button
                    size="lg"
                    className={cn(
                      "h-16 w-16 rounded-full transition-all",
                      isActive
                        ? "bg-destructive text-destructive-foreground hover:bg-destructive/90 shadow-[0_0_20px_rgba(255,0,0,0.3)] hover:shadow-[0_0_30px_rgba(255,0,0,0.5)] animate-none"
                        : isOverdrive
                          ? "bg-fuchsia-500 text-fuchsia-foreground hover:bg-fuchsia-600 shadow-[0_0_25px_rgba(255,0,255,0.4)]"
                          : "shadow-[0_0_20px_rgba(0,200,200,0.3)] hover:shadow-[0_0_30px_rgba(0,200,200,0.5)]",
                    )}
                    onClick={toggleTimer}
                  >
                    {isActive ? (
                      <Pause className="h-6 w-6" />
                    ) : (
                      <Play className="h-6 w-6 ml-1" />
                    )}
                  </Button>
                </div>

                <div className="w-full space-y-6">
                  <div className="space-y-3">
                    <div className="flex justify-between items-center text-sm font-medium text-muted-foreground">
                      <span>Duration</span>
                    </div>
                    <Select
                      defaultValue="25"
                      onValueChange={handleDurationChange}
                      disabled={isActive}
                    >
                      <SelectTrigger
                        className={cn(
                          "bg-background/50 border-primary/20",
                          isOverdrive && "border-fuchsia-500/30",
                        )}
                      >
                        <SelectValue placeholder="Select duration" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="5">5 Min (Quick Reset)</SelectItem>
                        <SelectItem value="15">15 Min (Micro-Cycle)</SelectItem>
                        <SelectItem value="25">
                          25 Min (Standard Flow)
                        </SelectItem>
                        <SelectItem value="60">60 Min (Deep Work)</SelectItem>
                        <SelectItem value="90">
                          90 Min (Ultradian Rhythm)
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-3">
                    <div className="flex justify-between items-center text-sm font-medium text-muted-foreground">
                      <span>Neural Aura (Soundscape)</span>
                    </div>
                    <Select
                      value={soundscape}
                      onValueChange={handleSoundscapeChange}
                    >
                      <SelectTrigger
                        className={cn(
                          "bg-background/50 border-primary/20",
                          isOverdrive && "border-fuchsia-500/30",
                        )}
                      >
                        <SelectValue placeholder="Select soundscape" />
                      </SelectTrigger>
                      <SelectContent>
                        {SOUNDSCAPES.map((s) => (
                          <SelectItem key={s.id} value={s.id}>
                            <div className="flex items-center gap-2">
                              <s.icon className={`h-4 w-4 ${s.color}`} />
                              <span>{s.name}</span>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div
                    className={cn(
                      "space-y-3 bg-background/30 p-4 rounded-lg border transition-colors",
                      isOverdrive
                        ? "border-fuchsia-500/20"
                        : "border-border/50",
                    )}
                  >
                    <div className="flex items-center gap-3">
                      <Volume2 className="h-4 w-4 text-muted-foreground" />
                      <Slider
                        value={volume}
                        onValueChange={setVolume}
                        max={100}
                        step={1}
                        className={cn(
                          "flex-1",
                          isOverdrive && "[&_[role=slider]]:bg-fuchsia-500",
                        )}
                      />
                      <span className="text-xs text-muted-foreground tabular-nums w-8 text-right">
                        {volume}%
                      </span>
                    </div>
                  </div>

                  <div
                    className={cn(
                      "space-y-4 bg-background/30 p-4 rounded-lg border transition-colors",
                      isOverdrive
                        ? "border-fuchsia-500/20"
                        : "border-border/50",
                    )}
                  >
                    <div className="flex justify-between items-center text-[10px] text-muted-foreground uppercase tracking-widest font-bold">
                      <span>Neural Sync Intensity</span>
                      <span
                        className={cn(
                          isOverdrive ? "text-fuchsia-500" : "text-primary",
                        )}
                      >
                        {syncIntensity[0]}%
                      </span>
                    </div>
                    <div className="flex items-center gap-3">
                      <BrainCircuit className="h-4 w-4 text-muted-foreground" />
                      <Slider
                        value={syncIntensity}
                        onValueChange={(val) => {
                          setSyncIntensity(val);
                          if (val[0] % 20 === 0) hapticFeedback(5);
                        }}
                        max={100}
                        step={1}
                        className={cn(
                          "flex-1",
                          isOverdrive
                            ? "[&_[role=slider]]:bg-fuchsia-500"
                            : "[&_[role=slider]]:bg-primary",
                        )}
                      />
                      <Zap
                        className={cn(
                          "h-4 w-4",
                          isOverdrive ? "text-fuchsia-500" : "text-primary",
                        )}
                      />
                    </div>
                    <p className="text-[10px] text-muted-foreground italic">
                      Controls neural particle density and biometric
                      synchronization speed.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="analytics" className="flex-1 flex flex-col mt-0">
            <Card className="flex-1 bg-card/40 border-border/50 backdrop-blur-sm flex flex-col">
              <CardHeader>
                <div className="flex items-center gap-2 text-primary mb-2">
                  <TrendingUp className="h-5 w-5" />
                  <CardTitle className="text-xl">Focus Trend</CardTitle>
                </div>
                <CardDescription>7-Day Biometric Focus Average</CardDescription>
              </CardHeader>
              <CardContent className="flex-1 min-h-[300px] flex flex-col justify-end">
                <ChartContainer
                  config={chartConfig}
                  className="w-full h-full max-h-[300px]"
                >
                  <AreaChart
                    data={focusData}
                    margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
                  >
                    <defs>
                      <linearGradient
                        id="fillFocus"
                        x1="0"
                        y1="0"
                        x2="0"
                        y2="1"
                      >
                        <stop
                          offset="5%"
                          stopColor="var(--color-focus)"
                          stopOpacity={0.3}
                        />
                        <stop
                          offset="95%"
                          stopColor="var(--color-focus)"
                          stopOpacity={0}
                        />
                      </linearGradient>
                    </defs>
                    <CartesianGrid
                      strokeDasharray="3 3"
                      vertical={false}
                      stroke="hsl(var(--border)/0.5)"
                    />
                    <XAxis
                      dataKey="date"
                      tickLine={false}
                      axisLine={false}
                      tickMargin={8}
                      tick={{
                        fill: "hsl(var(--muted-foreground))",
                        fontSize: 12,
                      }}
                    />
                    <YAxis
                      domain={[1, 5]}
                      tickLine={false}
                      axisLine={false}
                      tickMargin={8}
                      tick={{
                        fill: "hsl(var(--muted-foreground))",
                        fontSize: 12,
                      }}
                      tickCount={5}
                    />
                    <ChartTooltip
                      cursor={{
                        stroke: "hsl(var(--primary)/0.2)",
                        strokeWidth: 2,
                      }}
                      content={
                        <ChartTooltipContent
                          indicator="line"
                          labelFormatter={(value) => `Session Sync: ${value}`}
                          formatter={(value) => (
                            <div className="flex flex-col gap-1">
                              <div className="flex items-center gap-2">
                                <Zap className="h-3 w-3 text-primary animate-pulse" />
                                <span className="font-bold text-primary">
                                  {value} / 5
                                </span>
                              </div>
                              <span className="text-[10px] text-muted-foreground uppercase tracking-widest font-mono">
                                {Number(value) >= 4.5
                                  ? "Sovereign Flow"
                                  : Number(value) >= 4
                                    ? "Deep Flow"
                                    : Number(value) >= 3
                                      ? "Balanced"
                                      : "Unstable"}
                              </span>
                            </div>
                          )}
                        />
                      }
                    />
                    <Area
                      type="monotone"
                      dataKey="focus"
                      stroke="var(--color-focus)"
                      strokeWidth={2}
                      fillOpacity={1}
                      fill="url(#fillFocus)"
                    />
                  </AreaChart>
                </ChartContainer>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <Dialog open={showCheckIn} onOpenChange={setShowCheckIn}>
          <DialogContent className="sm:max-w-[400px] bg-card/95 border-border/50 backdrop-blur-xl">
            <DialogHeader className="items-center text-center">
              <div className="h-16 w-16 rounded-full bg-primary/20 flex items-center justify-center text-primary mb-4 animate-glow-cyan">
                <CheckCircle2 className="h-8 w-8" />
              </div>
              <DialogTitle className="text-2xl font-bold tracking-tight">
                Neural Sync Complete
              </DialogTitle>
              <DialogDescription>
                Calibration achieved. Please rate your biometric focus.
              </DialogDescription>
            </DialogHeader>

            <div className="py-8 space-y-8">
              <div className="space-y-4 text-center">
                <Label className="text-sm font-medium text-muted-foreground uppercase tracking-widest">
                  Focus Intensity
                </Label>
                <div className="flex items-center justify-center gap-2">
                  {[1, 2, 3, 4, 5].map((rating) => (
                    <button
                      key={rating}
                      onClick={() => {
                        setFocusRating(rating);
                        hapticFeedback(10);
                      }}
                      className={cn(
                        "p-2 rounded-lg transition-all duration-300",
                        focusRating >= rating
                          ? "text-primary scale-110 drop-shadow-[0_0_8px_rgba(0,255,255,0.5)]"
                          : "text-muted-foreground/30 hover:text-muted-foreground/60",
                      )}
                    >
                      <Star
                        className={cn(
                          "h-8 w-8",
                          focusRating >= rating && "fill-primary",
                        )}
                      />
                    </button>
                  ))}
                </div>
                <p className="text-xs font-mono text-primary/80">
                  {focusRating === 1 && "Scattered - High Neural Friction"}
                  {focusRating === 2 && "Unstable - Fluctuating Sync"}
                  {focusRating === 3 && "Balanced - Baseline Flow"}
                  {focusRating === 4 && "Deep - Optimal Calibration"}
                  {focusRating === 5 && "Peak - Sovereign Flow State"}
                </p>
              </div>

              <div className="bg-background/40 p-4 rounded-xl border border-primary/20 space-y-3">
                <div className="flex items-center justify-between text-xs font-medium">
                  <span className="text-muted-foreground uppercase">
                    Session Rewards
                  </span>
                  <span className="text-primary font-bold font-mono">
                    +500 PTS
                  </span>
                </div>
                <Progress value={100} className="h-1.5" />
                <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
                  <Zap className="h-3 w-3 text-yellow-400" />
                  <span>
                    Streak maintained:{" "}
                    {localStorage.getItem("daily_streak") || "7"} days
                  </span>
                </div>
              </div>
            </div>

            <DialogFooter>
              <Button
                onClick={handleSaveCheckIn}
                disabled={isSaving}
                className="w-full h-12 text-base font-bold shadow-[0_0_20px_rgba(0,200,200,0.3)]"
              >
                {isSaving ? (
                  <div className="flex items-center gap-2">
                    <div className="h-4 w-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                    <span>Syncing...</span>
                  </div>
                ) : (
                  "Save Calibration"
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
