import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { Logo } from "@/components/Logo";
import { useNavigate } from "react-router-dom";
import { NeuralNotificationCenter } from "@/components/NeuralNotifications";
import {
  ShieldAlert,
  User,
  Bell,
  Lock,
  Palette,
  Upload,
  Download,
  Plug,
  ArrowRight,
  Crown,
  Layers,
  Zap,
  Eye,
  Trash2,
} from "lucide-react";
import { useTheme } from "next-themes";
import { useEffect, useState } from "react";
import { useDisplayTheme, type DisplayTheme } from "@/hooks/use-display-theme";
import { cn } from "@/lib/utils";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { DataCategoryToggles } from "@/components/DataCategoryToggles";
import { SecurityIncidentPanel } from "@/components/SecurityIncidentPanel";

const ACCENT_COLORS = [
  { name: "Cyan", value: "180 100% 40%", class: "bg-[#00cccc]" },
  { name: "Magenta", value: "300 100% 50%", class: "bg-[#ff00ff]" },
  { name: "Gold", value: "45 100% 50%", class: "bg-[#ffd700]" },
  { name: "Emerald", value: "150 100% 40%", class: "bg-[#00cc66]" },
  { name: "Violet", value: "260 100% 60%", class: "bg-[#9933ff]" },
  { name: "Crimson", value: "348 83% 47%", class: "bg-[#db143c]" },
];

export default function Settings() {
  const { toast } = useToast();
  const navigate = useNavigate();
  const { theme, setTheme } = useTheme();
  const [accentColor, setAccentColor] = useState("180 100% 40%");
  const { displayTheme, setDisplayTheme } = useDisplayTheme();

  useEffect(() => {
    const saved = localStorage.getItem("accentColor");
    if (saved) setAccentColor(saved);
  }, []);

  const handleAccentChange = (colorValue: string) => {
    setAccentColor(colorValue);
    localStorage.setItem("accentColor", colorValue);
    document.documentElement.style.setProperty("--primary", colorValue);
    document.documentElement.style.setProperty("--ring", colorValue);
    toast({
      title: "Accent Color Updated",
      description: "Theme resonance recalibrated.",
    });
  };

  const handleNotificationChange = (name: string) => (checked: boolean) => {
    toast({
      title: "Preferences Updated",
      description: `${name} is now ${checked ? "enabled" : "disabled"}.`,
    });
  };

  const handleImport = () => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".csv,.json";
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        toast({
          title: "Uploading Telemetry",
          description: `Parsing ${file.name}...`,
        });
        setTimeout(() => {
          toast({
            title: "Synchronization Complete",
            description:
              "External biometrics successfully merged into your neural history.",
          });
        }, 1500);
      }
    };
    input.click();
  };

  const handleExport = () => {
    toast({
      title: "Compiling Telemetry",
      description: "Preparing your neural data for export...",
    });
    setTimeout(() => {
      const data = {
        user: "Elias Vance",
        exportDate: new Date().toISOString(),
        metrics: {
          averageFlow: 92,
          dailyStreak: 14,
          auditsCompleted: 42,
        },
      };
      const blob = new Blob([JSON.stringify(data, null, 2)], {
        type: "application/json",
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `neural_export_${new Date().toISOString().split("T")[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      toast({
        title: "Export Complete",
        description: "Your data is ready for external health apps.",
      });
    }, 1500);
  };

  return (
    <div className="flex flex-1 flex-col bg-background text-foreground">
      <main className="flex-1 container max-w-3xl px-4 py-8 md:py-12">
        <div className="mb-8 flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">
              System Settings
            </h1>
            <p className="text-muted-foreground mt-2">
              Manage your biometric identity and access controls.
            </p>
          </div>
          <NeuralNotificationCenter />
        </div>

        <div className="space-y-8">
          <Card className="bg-card/40 border-border/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Palette className="h-5 w-5 text-primary" />
                Appearance
              </CardTitle>
              <CardDescription>
                Customize the application interface.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base">Dark Mode</Label>
                  <p className="text-sm text-muted-foreground">
                    Toggle the clinical dark aesthetic.
                  </p>
                </div>
                <Switch
                  checked={theme === "dark"}
                  onCheckedChange={(checked) => {
                    setTheme(checked ? "dark" : "light");
                    toast({
                      title: "Appearance Updated",
                      description: `Dark mode ${checked ? "enabled" : "disabled"}.`,
                    });
                  }}
                />
              </div>
              <div className="space-y-4 pt-4 border-t border-border/50">
                <div className="space-y-0.5">
                  <Label className="text-base">Accent Color</Label>
                  <p className="text-sm text-muted-foreground">
                    Select your primary neural resonance frequency.
                  </p>
                </div>
                <div className="flex flex-wrap gap-4">
                  {ACCENT_COLORS.map((color) => (
                    <button
                      key={color.name}
                      onClick={() => handleAccentChange(color.value)}
                      className={`h-10 w-10 rounded-full border-2 transition-all ${
                        accentColor === color.value
                          ? "border-primary scale-110 shadow-[0_0_15px_rgba(var(--primary),0.5)]"
                          : "border-transparent hover:scale-105"
                      } ${color.class}`}
                      title={color.name}
                      aria-label={`Select ${color.name} accent`}
                    />
                  ))}
                </div>
              </div>

              {/* Display Theme Selector */}
              <div className="space-y-4 pt-4 border-t border-border/50">
                <div className="space-y-0.5">
                  <Label className="text-base flex items-center gap-2">
                    <Layers className="h-4 w-4 text-primary" />
                    Interface Style
                  </Label>
                  <p className="text-sm text-muted-foreground">
                    Switch between visual rendering modes.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {(
                    [
                      {
                        id: "default" as DisplayTheme,
                        label: "High Contrast",
                        icon: Zap,
                        desc: "Sharp neon glows, deep blacks, maximum readability",
                        preview: "bg-[#020810]",
                        borderActive:
                          "border-cyan-400 shadow-[0_0_20px_rgba(0,255,255,0.4)]",
                        badge: "bg-cyan-500/10 text-cyan-400",
                        dot: "bg-cyan-400",
                      },
                      {
                        id: "glass" as DisplayTheme,
                        label: "Glassmorphism",
                        icon: Eye,
                        desc: "Frosted glass surfaces, soft blurs, ambient depth",
                        preview:
                          "bg-gradient-to-br from-[#0a1428] to-[#06101e]",
                        borderActive:
                          "border-purple-400 shadow-[0_0_20px_rgba(168,85,247,0.4)]",
                        badge: "bg-purple-500/10 text-purple-300",
                        dot: "bg-purple-400",
                      },
                      {
                        id: "hc" as DisplayTheme,
                        label: "Ultra Contrast",
                        icon: Zap,
                        desc: "Maximum contrast, solid borders, zero blur effects",
                        preview: "bg-[#010305]",
                        borderActive:
                          "border-primary shadow-[0_0_20px_hsl(var(--primary)/0.4)]",
                        badge: "bg-primary/10 text-primary",
                        dot: "bg-primary",
                      },
                    ] as const
                  ).map((opt) => {
                    const isSelected = displayTheme === opt.id;
                    return (
                      <button
                        key={opt.id}
                        onClick={(e) => {
                          setDisplayTheme(opt.id, e);
                          toast({
                            title: `${opt.label} Mode`,
                            description: `Interface style updated.`,
                          });
                        }}
                        className={cn(
                          "relative flex flex-col gap-3 p-4 rounded-xl border-2 text-left transition-all duration-300 group overflow-hidden",
                          isSelected
                            ? opt.borderActive
                            : "border-border/40 hover:border-border hover:bg-muted/30",
                        )}
                      >
                        {/* Mini preview */}
                        <div
                          className={cn(
                            "w-full h-12 rounded-lg overflow-hidden relative",
                            opt.preview,
                          )}
                        >
                          {opt.id === "glass" && (
                            <>
                              <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent" />
                              <div className="absolute top-2 left-2 right-2 h-3 rounded bg-white/10 backdrop-blur-sm border border-white/15" />
                              <div className="absolute bottom-2 left-2 right-6 h-2 rounded bg-cyan-400/20 backdrop-blur-sm border border-cyan-400/20" />
                            </>
                          )}
                          {opt.id === "default" && (
                            <>
                              <div className="absolute top-2 left-2 right-2 h-3 rounded bg-cyan-500/20 border border-cyan-500/40" />
                              <div
                                className="absolute bottom-2 left-2 w-8 h-2 rounded"
                                style={{
                                  background: "hsl(var(--primary))",
                                  boxShadow: "0 0 6px hsl(var(--primary)/0.8)",
                                }}
                              />
                            </>
                          )}
                          {opt.id === "hc" && (
                            <>
                              <div className="absolute top-2 left-2 right-2 h-3 rounded border-2 border-primary/80" />
                              <div className="absolute bottom-2 left-2 w-8 h-2 rounded bg-primary" />
                            </>
                          )}
                        </div>

                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <div
                              className={cn(
                                "w-2 h-2 rounded-full",
                                opt.dot,
                                isSelected && "animate-pulse",
                              )}
                            />
                            <span className="text-xs font-bold tracking-widest uppercase text-foreground">
                              {opt.label}
                            </span>
                          </div>
                          <p className="text-[10px] text-muted-foreground leading-tight">
                            {opt.desc}
                          </p>
                        </div>

                        {isSelected && (
                          <div
                            className={cn(
                              "absolute top-2 right-2 text-[9px] font-bold px-2 py-0.5 rounded-full",
                              opt.badge,
                            )}
                          >
                            ACTIVE
                          </div>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card/40 border-border/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5 text-primary" />
                Personal Information
              </CardTitle>
              <CardDescription>
                Update your biometric identity profile.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="first-name">First Name</Label>
                  <Input
                    id="first-name"
                    defaultValue="Elias"
                    className="bg-background/50"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="last-name">Last Name</Label>
                  <Input
                    id="last-name"
                    defaultValue="Vance"
                    className="bg-background/50"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Secure Email</Label>
                <Input
                  id="email"
                  type="email"
                  defaultValue="elias.vance@elite.co"
                  className="bg-background/50"
                />
              </div>
              <Button
                className="mt-4"
                onClick={() =>
                  toast({
                    title: "Profile Updated",
                    description: "Identity parameters saved.",
                  })
                }
              >
                Save Changes
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-card/40 border-border/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="h-5 w-5 text-primary" />
                Telemetry Preferences
              </CardTitle>
              <CardDescription>
                Manage how TherapyFIT Elite App communicates with you.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base">Daily Audit Reminders</Label>
                  <p className="text-sm text-muted-foreground">
                    Receive a push notification to calibrate your ANS.
                  </p>
                </div>
                <Switch
                  defaultChecked
                  onCheckedChange={handleNotificationChange(
                    "Daily Audit Reminders",
                  )}
                />
              </div>
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base">Critical Friction Alerts</Label>
                  <p className="text-sm text-muted-foreground">
                    Immediate warnings when burnout is predicted.
                  </p>
                </div>
                <Switch
                  defaultChecked
                  onCheckedChange={handleNotificationChange(
                    "Critical Friction Alerts",
                  )}
                />
              </div>
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base">Weekly Synthesis Report</Label>
                  <p className="text-sm text-muted-foreground">
                    A 7-day biometric weather report sent via email.
                  </p>
                </div>
                <Switch
                  defaultChecked
                  onCheckedChange={handleNotificationChange(
                    "Weekly Synthesis Report",
                  )}
                />
              </div>
              <div className="flex items-center justify-between pt-4 border-t border-border/50">
                <div className="space-y-0.5">
                  <Label className="text-base">Haptic Feedback</Label>
                  <p className="text-sm text-muted-foreground">
                    Tactile response on interactions.
                  </p>
                </div>
                <Switch
                  defaultChecked={
                    localStorage.getItem("tf_haptics_enabled") !== "false"
                  }
                  onCheckedChange={(c) =>
                    localStorage.setItem("tf_haptics_enabled", String(c))
                  }
                />
              </div>
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base">Interface Sounds</Label>
                  <p className="text-sm text-muted-foreground">
                    Audio cues for success and interaction.
                  </p>
                </div>
                <Switch
                  defaultChecked={
                    localStorage.getItem("tf_sound_enabled") !== "false"
                  }
                  onCheckedChange={(c) =>
                    localStorage.setItem("tf_sound_enabled", String(c))
                  }
                />
              </div>
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base">AI Voiceover</Label>
                  <p className="text-sm text-muted-foreground">
                    Spoken guidance during protocols.
                  </p>
                </div>
                <Switch
                  defaultChecked={
                    localStorage.getItem("tf_voice_enabled") !== "false"
                  }
                  onCheckedChange={(c) =>
                    localStorage.setItem("tf_voice_enabled", String(c))
                  }
                />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card/40 border-border/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lock className="h-5 w-5 text-primary" />
                Access Control
              </CardTitle>
              <CardDescription>Secure your biometric data.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="current-password">Current Passphrase</Label>
                <Input
                  id="current-password"
                  type="password"
                  className="bg-background/50"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="new-password">New Passphrase</Label>
                <Input
                  id="new-password"
                  type="password"
                  className="bg-background/50"
                />
              </div>
              <Button
                variant="outline"
                className="mt-2 border-primary/50 text-primary hover:bg-primary/10"
                onClick={() =>
                  toast({
                    title: "Security Updated",
                    description: "Passphrase changed successfully.",
                  })
                }
              >
                Update Passphrase
              </Button>
            </CardContent>
          </Card>
          <Card className="bg-card/40 border-border/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Upload className="h-5 w-5 text-primary" />
                External Data Synchronization
              </CardTitle>
              <CardDescription>
                Import and export biometric telemetry with third-party health
                apps.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base">Import Biometrics</Label>
                  <p className="text-sm text-muted-foreground">
                    Merge external data into your Neural Audit history.
                  </p>
                </div>
                <Button
                  onClick={handleImport}
                  variant="outline"
                  className="border-primary/50 text-primary hover:bg-primary/10"
                >
                  <Upload className="mr-2 h-4 w-4" />
                  Import
                </Button>
              </div>
              <div className="flex items-center justify-between pt-4 border-t border-border/50">
                <div className="space-y-0.5">
                  <Label className="text-base">Export Telemetry</Label>
                  <p className="text-sm text-muted-foreground">
                    Download your data to sync with Apple Health or Google Fit.
                  </p>
                </div>
                <Button
                  onClick={handleExport}
                  variant="outline"
                  className="border-primary/50 text-primary hover:bg-primary/10"
                >
                  <Download className="mr-2 h-4 w-4" />
                  Export
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card/40 border-border/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Plug className="h-5 w-5 text-primary" />
                Integration Hub
              </CardTitle>
              <CardDescription>
                Manage external API connections and hardware telemetry.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button
                onClick={() => navigate("/integrations")}
                className="w-full sm:w-auto"
              >
                Open Integration Hub
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-card/40 border-primary/50 backdrop-blur-sm shadow-[0_0_15px_rgba(var(--primary),0.1)]">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-primary">
                <Crown className="h-5 w-5" />
                Elite Access Pass
              </CardTitle>
              <CardDescription>
                Manage your subscription and upgrade to Sovereign tier.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button
                onClick={() => navigate("/upgrade")}
                className="w-full sm:w-auto shadow-[0_0_10px_rgba(var(--primary),0.3)]"
              >
                Upgrade Plan
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-card/40 border-destructive/30 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-destructive flex items-center gap-2">
                <ShieldAlert className="h-5 w-5" />
                Data &amp; Privacy
              </CardTitle>
              <CardDescription>
                Manage your data, exercise your right to erasure, and reset the
                system.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="rounded-xl border border-border/40 bg-muted/20 p-4">
                <div className="flex items-start gap-3">
                  <Lock className="w-4 h-4 text-primary mt-0.5 shrink-0" />
                  <div className="text-xs text-muted-foreground leading-relaxed">
                    <span className="text-foreground font-semibold">
                      Data minimization:
                    </span>{" "}
                    TherapyFIT Elite only stores the biometric data needed to
                    run your protocols (HRV, CNS load, hydration, sleep,
                    streaks, waypoints) — locally on this device. No third-party
                    ad trackers. No data is sold or shared with brokers.
                  </div>
                </div>
              </div>

              <DataCategoryToggles />

              <div className="flex flex-col sm:flex-row gap-4 pt-2">
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="destructive">
                      <Trash2 className="mr-2 h-4 w-4" />
                      Delete All My Data
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent className="bg-card border-destructive/40">
                    <AlertDialogHeader>
                      <AlertDialogTitle className="text-destructive">
                        Erase all biometric data?
                      </AlertDialogTitle>
                      <AlertDialogDescription>
                        This permanently deletes every metric, streak, target,
                        waypoint, somatic map, and preference stored on this
                        device — including your onboarding state. This action
                        cannot be undone. You will be returned to the welcome
                        screen.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction
                        className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                        onClick={() => {
                          try {
                            // Preserve nothing — full erasure of all app-owned keys
                            const appKeys = [
                              "accentColor",
                              "active_mercenary_contract",
                              "avatar_glow",
                              "baseline_reflex",
                              "blBudget",
                              "completed_sector_challenges",
                              "daily_streak",
                              "last_audit_date",
                              "neural_decoys",
                              "neural_points",
                              "pendingMissions",
                              "sector_fortification_level",
                              "sector_master_achievement",
                              "tf_avatar",
                              "tf_biometrics",
                              "tf_bl_streak",
                              "tf_bl_target",
                              "tf_cns_load",
                              "tf_cns_streak",
                              "tf_cns_target",
                              "tf_collect_cns",
                              "tf_collect_hrv",
                              "tf_collect_hydration",
                              "tf_collect_sleep",
                              "tf_collect_waypoints",
                              "tf_cookie_consent",
                              "tf_error_log",
                              "tf_daily_summary",
                              "tf_display_theme",
                              "tf_fasting_start",
                              "tf_haptics_enabled",
                              "tf_hrv_score",
                              "tf_hrv_streak",
                              "tf_hrv_target",
                              "tf_hub_pins",
                              "tf_hyd_streak",
                              "tf_hyd_target",
                              "tf_hydration",
                              "tf_hydration_alerts",
                              "tf_morning_audit_complete",
                              "tf_morning_streak",
                              "tf_onboarded",
                              "tf_recent_paths",
                              "tf_saved_replays",
                              "tf_sleep_streak",
                              "tf_sleep_target",
                              "tf_sound_enabled",
                              "tf_userName",
                              "tf_voice_enabled",
                              "tf_waypoints",
                            ];
                            appKeys.forEach((k) => localStorage.removeItem(k));
                          } catch (e) {}
                          toast({
                            variant: "destructive",
                            title: "Data Erased",
                            description:
                              "All biometric data has been permanently deleted.",
                          });
                          setTimeout(() => {
                            window.dispatchEvent(
                              new Event("tf_onboarding_complete"),
                            );
                            navigate("/welcome");
                          }, 600);
                        }}
                      >
                        Yes, Erase Everything
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>

                <Button
                  variant="outline"
                  className="border-destructive/50 text-destructive hover:bg-destructive/10"
                  onClick={() => {
                    localStorage.removeItem("tf_onboarded");
                    window.dispatchEvent(new Event("tf_onboarding_complete"));
                    navigate("/welcome");
                  }}
                >
                  Reset Onboarding Sequence
                </Button>
              </div>
            </CardContent>
          </Card>
          <SecurityIncidentPanel />
        </div>
      </main>
    </div>
  );
}
