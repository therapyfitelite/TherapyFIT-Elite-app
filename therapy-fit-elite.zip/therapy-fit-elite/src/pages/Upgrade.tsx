import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  CheckCircle2,
  Zap,
  Shield,
  Crown,
  Activity,
  ArrowRight,
  CreditCard,
  Lock,
  Loader2,
  Download,
  Receipt,
  Users,
  Copy,
  Share2,
  Gift,
  Target,
  Award,
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { hapticFeedback } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { Logo } from "@/components/Logo";
import { NeuralNotificationCenter } from "@/components/NeuralNotifications";
import confetti from "canvas-confetti";

interface PlanDetails {
  name: string;
  price: string;
  interval: string;
}

export default function Upgrade() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [selectedPlan, setSelectedPlan] = useState<PlanDetails | null>(null);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isUpdatePaymentModalOpen, setIsUpdatePaymentModalOpen] =
    useState(false);
  const [isUpdatingCard, setIsUpdatingCard] = useState(false);
  const [isGiftModalOpen, setIsGiftModalOpen] = useState(false);
  const [isProcessingGift, setIsProcessingGift] = useState(false);
  const [selectedGift, setSelectedGift] = useState<{
    tier: string;
    duration: string;
    price: string;
  } | null>(null);

  const mockInvoices = [
    {
      id: "INV-2026-04",
      date: "Apr 01, 2026",
      amount: "$29.00",
      plan: "Sovereign Tier",
      status: "Paid",
    },
    {
      id: "INV-2026-03",
      date: "Mar 01, 2026",
      amount: "$29.00",
      plan: "Sovereign Tier",
      status: "Paid",
    },
    {
      id: "INV-2026-02",
      date: "Feb 01, 2026",
      amount: "$29.00",
      plan: "Sovereign Tier",
      status: "Paid",
    },
  ];

  const handleDownloadInvoice = (invoiceId: string) => {
    hapticFeedback([20, 30, 20]);
    toast({
      title: "Downloading Invoice",
      description: `Compiling secure PDF for ${invoiceId}...`,
    });
  };

  const handleUpgrade = (name: string, price: string, interval: string) => {
    hapticFeedback([50, 100, 50]);
    setSelectedPlan({ name, price, interval });
    setIsPaymentModalOpen(true);
  };

  const processPayment = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    hapticFeedback([20, 20, 20]);

    // Simulate Stripe API processing delay
    setTimeout(() => {
      setIsProcessing(false);
      setIsPaymentModalOpen(false);

      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
        colors: ["#00ffff", "#ff00ff", "#ffffff"],
      });

      hapticFeedback([100, 50, 100, 50, 200]);
      toast({
        title: "Payment Successful",
        description: `Your ${selectedPlan?.name} subscription is now active. Welcome to the Elite.`,
      });
    }, 2000);
  };

  const processCardUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    setIsUpdatingCard(true);
    hapticFeedback([20, 20, 20]);

    // Simulate Stripe API processing delay
    setTimeout(() => {
      setIsUpdatingCard(false);
      setIsUpdatePaymentModalOpen(false);
      hapticFeedback([50, 100, 50]);
      toast({
        title: "Payment Method Updated",
        description: "Your new card has been securely saved.",
      });
    }, 1500);
  };

  const handleGift = (tier: string, duration: string, price: string) => {
    hapticFeedback([50, 50]);
    setSelectedGift({ tier, duration, price });
    setIsGiftModalOpen(true);
  };

  const processGift = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessingGift(true);
    hapticFeedback([20, 20, 20]);

    // Simulate Stripe API processing delay
    setTimeout(() => {
      setIsProcessingGift(false);
      setIsGiftModalOpen(false);

      confetti({
        particleCount: 150,
        spread: 80,
        origin: { y: 0.6 },
        colors: ["#00ffff", "#ff00ff", "#ffffff", "#ffd700"],
      });

      hapticFeedback([100, 50, 100, 50, 200]);
      toast({
        title: "Gift Sent Successfully!",
        description: `Your ${selectedGift?.tier} gift has been dispatched to the recipient.`,
      });
    }, 2000);
  };

  return (
    <div className="flex flex-1 flex-col bg-background text-foreground">
      <main className="flex-1 container max-w-6xl px-4 py-12 md:py-16 mx-auto">
        <div className="flex justify-end mb-4">
          <NeuralNotificationCenter />
        </div>
        <div className="flex flex-col items-center text-center mb-12 space-y-4">
          <div className="inline-flex items-center rounded-full border border-primary/30 bg-primary/10 px-3 py-1 text-sm font-medium text-primary backdrop-blur-sm">
            <Crown className="w-4 h-4 mr-2" />
            Elite Access Pass
          </div>
          <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight">
            Unlock Total <span className="text-primary">Sovereignty</span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-[600px]">
            Upgrade your neural network to gain exclusive access to global
            dominance protocols, 1-on-1 clinical reviews, and unlimited
            biometric telemetry.
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4 items-end">
          {/* Basic Tier */}
          <Card className="bg-card/40 border-border/50 backdrop-blur-sm flex flex-col h-full">
            <CardHeader>
              <CardTitle className="text-xl">Standard Calibration</CardTitle>
              <CardDescription>Essential biometric monitoring.</CardDescription>
              <div className="mt-4">
                <span className="text-4xl font-bold">Free</span>
              </div>
            </CardHeader>
            <CardContent className="flex-1">
              <ul className="space-y-3 text-sm text-muted-foreground">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                  Daily Neural Audits
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                  Basic ANS Balance Beam
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                  Standard Voice Calibration
                </li>
                <li className="flex items-center gap-2 opacity-50">
                  <div className="h-4 w-4 rounded-full border border-muted-foreground" />
                  Global Map Dominance
                </li>
                <li className="flex items-center gap-2 opacity-50">
                  <div className="h-4 w-4 rounded-full border border-muted-foreground" />
                  Custom Webhooks
                </li>
              </ul>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full" disabled>
                Current Plan
              </Button>
            </CardFooter>
          </Card>

          {/* Sovereign Tier (Highlighted) */}
          <Card className="relative bg-card/60 border-primary/50 backdrop-blur-md flex flex-col h-full transform md:-translate-y-4 shadow-[0_0_30px_rgba(var(--primary),0.15)]">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2">
              <Badge className="bg-primary text-primary-foreground font-bold px-3 py-1 text-sm shadow-[0_0_10px_rgba(var(--primary),0.5)]">
                RECOMMENDED
              </Badge>
            </div>
            <CardHeader className="pt-8">
              <div className="p-2 bg-primary/10 w-fit rounded-lg text-primary mb-2">
                <Shield className="h-6 w-6" />
              </div>
              <CardTitle className="text-2xl text-foreground">
                Sovereign
              </CardTitle>
              <CardDescription>
                Advanced tactical planning and integrations.
              </CardDescription>
              <div className="mt-4 flex items-baseline gap-1">
                <span className="text-4xl font-bold text-primary">$29</span>
                <span className="text-muted-foreground">/mo</span>
              </div>
            </CardHeader>
            <CardContent className="flex-1">
              <ul className="space-y-3 text-sm text-foreground font-medium">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-primary" />
                  Everything in Standard
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-primary" />
                  Global Map Dominance (Sector Wars)
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-primary" />
                  Unlimited Custom Webhooks
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-primary" />
                  7-Day Predictive Forecast
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-primary" />
                  Advanced Neural Engine Syntheses
                </li>
              </ul>
            </CardContent>
            <CardFooter>
              <Button
                className="w-full h-12 text-base shadow-[0_0_15px_rgba(var(--primary),0.4)]"
                onClick={() => handleUpgrade("Sovereign", "$29", "/mo")}
              >
                Upgrade to Sovereign
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </CardFooter>
          </Card>

          {/* Apex Tier */}
          <Card className="bg-card/40 border-border/50 backdrop-blur-sm flex flex-col h-full">
            <CardHeader>
              <div className="p-2 bg-purple-500/10 w-fit rounded-lg text-purple-500 mb-2">
                <Zap className="h-6 w-6" />
              </div>
              <CardTitle className="text-xl">Apex</CardTitle>
              <CardDescription>
                Ultimate cognitive optimization.
              </CardDescription>
              <div className="mt-4 flex items-baseline gap-1">
                <span className="text-4xl font-bold">$99</span>
                <span className="text-muted-foreground">/mo</span>
              </div>
            </CardHeader>
            <CardContent className="flex-1">
              <ul className="space-y-3 text-sm text-muted-foreground">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-purple-500" />
                  Everything in Sovereign
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-purple-500" />
                  1-on-1 Clinical Review Monthly
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-purple-500" />
                  Priority Hardware Sync (Oura/Whoop)
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-purple-500" />
                  Dedicated Faction Leadership
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-purple-500" />
                  Early Access to Protocols
                </li>
              </ul>
            </CardContent>
            <CardFooter>
              <Button
                variant="outline"
                className="w-full border-purple-500/30 text-purple-500 hover:bg-purple-500/10"
                onClick={() => handleUpgrade("Apex", "$99", "/mo")}
              >
                Get Apex Access
              </Button>
            </CardFooter>
          </Card>

          {/* Nexus Tier (AI Coaching) */}
          <Card className="bg-card/40 border-amber-500/30 backdrop-blur-sm flex flex-col h-full shadow-[0_0_20px_rgba(245,158,11,0.1)]">
            <CardHeader>
              <div className="p-2 bg-amber-500/10 w-fit rounded-lg text-amber-500 mb-2">
                <Users className="h-6 w-6" />
              </div>
              <CardTitle className="text-xl text-amber-500">Nexus</CardTitle>
              <CardDescription>
                Personalized AI Coaching Avatars.
              </CardDescription>
              <div className="mt-4 flex items-baseline gap-1">
                <span className="text-4xl font-bold text-amber-500">$199</span>
                <span className="text-muted-foreground">/mo</span>
              </div>
            </CardHeader>
            <CardContent className="flex-1">
              <ul className="space-y-3 text-sm text-muted-foreground">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-amber-500" />
                  Everything in Apex
                </li>
                <li className="flex items-center gap-2 text-foreground font-medium">
                  <CheckCircle2 className="h-4 w-4 text-amber-500" />
                  Exclusive AI Coaching Avatars
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-amber-500" />
                  Real-time Neural Bio-Feedback
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-amber-500" />
                  Hyper-Personalized Daily Protocols
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-amber-500" />
                  24/7 Voice-Activated AI Support
                </li>
              </ul>
            </CardContent>
            <CardFooter>
              <Button
                variant="outline"
                className="w-full border-amber-500/50 text-amber-500 hover:bg-amber-500/10"
                onClick={() => handleUpgrade("Nexus", "$199", "/mo")}
              >
                Unlock Nexus
              </Button>
            </CardFooter>
          </Card>
        </div>

        <div className="mt-16 text-center">
          <p className="text-sm text-muted-foreground flex items-center justify-center gap-2">
            <Lock className="h-4 w-4" />
            Payments are securely processed by Stripe. Cancel anytime.
          </p>
        </div>

        {/* Gift Subscriptions Section */}
        <div className="mt-24">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <Gift className="h-6 w-6 text-primary" />
              <h2 className="text-2xl font-bold tracking-tight">
                Gift Elite Access
              </h2>
            </div>
            <Badge
              variant="outline"
              className="bg-primary/10 text-primary border-primary/20"
            >
              Share the Protocol
            </Badge>
          </div>
          <div className="grid gap-8 md:grid-cols-2">
            <Card className="bg-card/40 border-border/50 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-xl">Gift Sovereign</CardTitle>
                <CardDescription>
                  Give the gift of advanced tactical planning and integrations.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-4 rounded-lg bg-muted/30 border border-border/50">
                  <div>
                    <p className="font-bold">1 Month Access</p>
                    <p className="text-sm text-muted-foreground">$29.00</p>
                  </div>
                  <Button
                    variant="outline"
                    className="border-primary/50 text-primary hover:bg-primary/10"
                    onClick={() => handleGift("Sovereign", "1 Month", "$29.00")}
                  >
                    Gift Now
                  </Button>
                </div>
                <div className="flex items-center justify-between p-4 rounded-lg bg-muted/30 border border-border/50">
                  <div>
                    <p className="font-bold flex items-center gap-2">
                      1 Year Access{" "}
                      <Badge className="bg-emerald-500/20 text-emerald-500 border-emerald-500/30 hover:bg-emerald-500/30">
                        Save 20%
                      </Badge>
                    </p>
                    <p className="text-sm text-muted-foreground">$279.00</p>
                  </div>
                  <Button
                    variant="outline"
                    className="border-primary/50 text-primary hover:bg-primary/10"
                    onClick={() => handleGift("Sovereign", "1 Year", "$279.00")}
                  >
                    Gift Now
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card/40 border-border/50 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-xl text-purple-500">
                  Gift Apex
                </CardTitle>
                <CardDescription>
                  Give the ultimate cognitive optimization experience.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-4 rounded-lg bg-muted/30 border border-border/50">
                  <div>
                    <p className="font-bold">1 Month Access</p>
                    <p className="text-sm text-muted-foreground">$99.00</p>
                  </div>
                  <Button
                    variant="outline"
                    className="border-purple-500/50 text-purple-500 hover:bg-purple-500/10"
                    onClick={() => handleGift("Apex", "1 Month", "$99.00")}
                  >
                    Gift Now
                  </Button>
                </div>
                <div className="flex items-center justify-between p-4 rounded-lg bg-muted/30 border border-border/50">
                  <div>
                    <p className="font-bold flex items-center gap-2">
                      1 Year Access{" "}
                      <Badge className="bg-emerald-500/20 text-emerald-500 border-emerald-500/30 hover:bg-emerald-500/30">
                        Save 20%
                      </Badge>
                    </p>
                    <p className="text-sm text-muted-foreground">$950.00</p>
                  </div>
                  <Button
                    variant="outline"
                    className="border-purple-500/50 text-purple-500 hover:bg-purple-500/10"
                    onClick={() => handleGift("Apex", "1 Year", "$950.00")}
                  >
                    Gift Now
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Billing History Section */}
        <div className="mt-24">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <Receipt className="h-6 w-6 text-primary" />
              <h2 className="text-2xl font-bold tracking-tight">
                Billing History
              </h2>
            </div>
            <Button
              variant="outline"
              className="border-primary/50 text-primary hover:bg-primary/10"
              onClick={() => setIsUpdatePaymentModalOpen(true)}
            >
              <CreditCard className="w-4 h-4 mr-2" />
              Manage Payment Method
            </Button>
          </div>
          <Card className="bg-card/40 border-border/50 backdrop-blur-sm overflow-hidden">
            <Table>
              <TableHeader className="bg-muted/50">
                <TableRow>
                  <TableHead>Invoice</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Plan</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {mockInvoices.map((invoice) => (
                  <TableRow key={invoice.id}>
                    <TableCell className="font-mono text-sm">
                      {invoice.id}
                    </TableCell>
                    <TableCell>{invoice.date}</TableCell>
                    <TableCell>{invoice.plan}</TableCell>
                    <TableCell>{invoice.amount}</TableCell>
                    <TableCell>
                      <Badge
                        variant="outline"
                        className="bg-emerald-500/10 text-emerald-500 border-emerald-500/20"
                      >
                        {invoice.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-8 text-primary hover:text-primary hover:bg-primary/10"
                        onClick={() => handleDownloadInvoice(invoice.id)}
                      >
                        <Download className="h-4 w-4 mr-2" />
                        PDF
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>
        </div>

        {/* Referral Program Section */}
        <div className="mt-24 mb-12">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <Users className="h-6 w-6 text-primary" />
              <h2 className="text-2xl font-bold tracking-tight">
                Referral Program
              </h2>
            </div>
            <Badge
              variant="outline"
              className="bg-primary/10 text-primary border-primary/20"
            >
              Earn 5,000 PTS per Invite
            </Badge>
          </div>

          <div className="grid gap-8 md:grid-cols-2 mb-8">
            <Card className="bg-card/40 border-border/50 backdrop-blur-sm">
              <CardHeader>
                <CardTitle>Your Invite Link</CardTitle>
                <CardDescription>
                  Share this link with other optimizers to earn Neural Points.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex space-x-2">
                  <Input
                    readOnly
                    value="https://therapyfit-elite.app/invite/elias-vance-7x9"
                    className="bg-background/50 font-mono text-sm"
                  />
                  <Button
                    variant="outline"
                    size="icon"
                    className="shrink-0 border-primary/50 text-primary hover:bg-primary/10"
                    onClick={() => {
                      hapticFeedback([20, 20]);
                      toast({
                        title: "Link Copied",
                        description: "Invite link copied to clipboard.",
                      });
                    }}
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
                <Button
                  className="w-full gap-2 shadow-[0_0_15px_rgba(var(--primary),0.3)]"
                  onClick={() => {
                    hapticFeedback([30, 50, 30]);
                    toast({
                      title: "Share Dialog Opened",
                      description: "Select a platform to share your link.",
                    });
                  }}
                >
                  <Share2 className="h-4 w-4" />
                  Share Invite Link
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-card/40 border-border/50 backdrop-blur-sm">
              <CardHeader>
                <CardTitle>Referral Stats</CardTitle>
                <CardDescription>
                  Track your network expansion and earned rewards.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div className="space-y-1">
                      <div className="text-2xl font-bold text-foreground">
                        48
                      </div>
                      <div className="text-[10px] text-muted-foreground uppercase tracking-wider">
                        Invites Sent
                      </div>
                    </div>
                    <div className="space-y-1">
                      <div className="text-2xl font-bold text-primary">12</div>
                      <div className="text-[10px] text-muted-foreground uppercase tracking-wider">
                        Friends Joined
                      </div>
                    </div>
                    <div className="space-y-1">
                      <div className="text-2xl font-bold text-yellow-500">
                        60k
                      </div>
                      <div className="text-[10px] text-muted-foreground uppercase tracking-wider">
                        Points Earned
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2 pt-4 border-t border-border/30">
                    <div className="flex justify-between text-sm font-medium">
                      <span className="flex items-center gap-2">
                        <Target className="h-4 w-4 text-primary" /> Next
                        Milestone: 25 Invites
                      </span>
                      <span className="text-primary">12 / 25</span>
                    </div>
                    <div className="h-2 w-full bg-secondary rounded-full overflow-hidden">
                      <div className="h-full bg-primary w-[48%] rounded-full shadow-[0_0_10px_rgba(var(--primary),0.5)]"></div>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Invite 13 more friends to unlock 1-Year Apex Access.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="bg-card/40 border-border/50 backdrop-blur-sm overflow-hidden">
            <CardHeader className="bg-muted/30 border-b border-border/50">
              <CardTitle className="flex items-center gap-2">
                <Award className="h-5 w-5 text-primary" />
                Milestone Rewards
              </CardTitle>
              <CardDescription>
                Unlock exclusive elite perks as your network grows.
              </CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <div className="grid md:grid-cols-3 divide-y md:divide-y-0 md:divide-x divide-border/50">
                {/* Milestone 10 */}
                <div className="p-6 space-y-4 relative overflow-hidden">
                  <div className="absolute top-0 right-0 p-4 opacity-5">
                    <CheckCircle2 className="w-24 h-24" />
                  </div>
                  <div className="flex justify-between items-start">
                    <Badge className="bg-emerald-500/20 text-emerald-500 border-emerald-500/30 hover:bg-emerald-500/20">
                      Unlocked
                    </Badge>
                    <span className="text-2xl font-bold text-muted-foreground/30">
                      10
                    </span>
                  </div>
                  <div>
                    <h3 className="font-bold text-lg text-emerald-500 flex items-center gap-2">
                      <CheckCircle2 className="h-5 w-5" /> Sovereign Care
                      Package
                    </h3>
                    <p className="text-sm text-muted-foreground mt-1">
                      Exclusive Elite apparel and 10,000 bonus Neural Points.
                    </p>
                  </div>
                </div>

                {/* Milestone 25 */}
                <div className="p-6 space-y-4 relative overflow-hidden bg-muted/10">
                  <div className="absolute top-0 right-0 p-4 opacity-5">
                    <Lock className="w-24 h-24" />
                  </div>
                  <div className="flex justify-between items-start">
                    <Badge
                      variant="outline"
                      className="border-primary/30 text-primary"
                    >
                      In Progress (12/25)
                    </Badge>
                    <span className="text-2xl font-bold text-muted-foreground/30">
                      25
                    </span>
                  </div>
                  <div>
                    <h3 className="font-bold text-lg text-foreground flex items-center gap-2">
                      <Lock className="h-4 w-4 text-muted-foreground" /> 1-Year
                      Apex Access
                    </h3>
                    <p className="text-sm text-muted-foreground mt-1">
                      A full year of the highest tier optimization protocols on
                      us.
                    </p>
                  </div>
                </div>

                {/* Milestone 50 */}
                <div className="p-6 space-y-4 relative overflow-hidden bg-muted/10">
                  <div className="absolute top-0 right-0 p-4 opacity-5">
                    <Crown className="w-24 h-24" />
                  </div>
                  <div className="flex justify-between items-start">
                    <Badge
                      variant="outline"
                      className="border-muted-foreground/30 text-muted-foreground"
                    >
                      Locked (12/50)
                    </Badge>
                    <span className="text-2xl font-bold text-muted-foreground/30">
                      50
                    </span>
                  </div>
                  <div>
                    <h3 className="font-bold text-lg text-foreground flex items-center gap-2">
                      <Lock className="h-4 w-4 text-muted-foreground" /> Founder
                      Status
                    </h3>
                    <p className="text-sm text-muted-foreground mt-1">
                      Lifetime Apex Access and a dedicated Neural Relay named
                      after you.
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Dialog open={isPaymentModalOpen} onOpenChange={setIsPaymentModalOpen}>
          <DialogContent className="sm:max-w-[425px] border-primary/20 bg-background/95 backdrop-blur-xl">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2 text-xl">
                <Lock className="h-5 w-5 text-primary" />
                Secure Checkout
              </DialogTitle>
              <DialogDescription>
                Complete your subscription to the{" "}
                <strong className="text-foreground">
                  {selectedPlan?.name}
                </strong>{" "}
                tier.
              </DialogDescription>
            </DialogHeader>

            <div className="mb-4 p-4 rounded-lg bg-muted/50 border border-border/50 flex justify-between items-center">
              <div>
                <p className="font-medium text-foreground">
                  {selectedPlan?.name} Plan
                </p>
                <p className="text-sm text-muted-foreground">Billed monthly</p>
              </div>
              <div className="text-right">
                <p className="text-2xl font-bold text-foreground">
                  {selectedPlan?.price}
                </p>
              </div>
            </div>

            <form onSubmit={processPayment} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="optimizer@therapyfit.com"
                  required
                  className="bg-background"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="card">Card Information</Label>
                <div className="relative">
                  <CreditCard className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground" />
                  <Input
                    id="card"
                    placeholder="0000 0000 0000 0000"
                    required
                    className="pl-10 bg-background font-mono"
                    maxLength={19}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4 mt-2">
                  <Input
                    placeholder="MM/YY"
                    required
                    className="bg-background font-mono"
                    maxLength={5}
                  />
                  <Input
                    placeholder="CVC"
                    required
                    className="bg-background font-mono"
                    maxLength={4}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="name">Name on Card</Label>
                <Input
                  id="name"
                  placeholder="Sovereign Optimizer"
                  required
                  className="bg-background"
                />
              </div>

              <DialogFooter className="pt-4">
                <Button
                  type="button"
                  variant="ghost"
                  onClick={() => setIsPaymentModalOpen(false)}
                  disabled={isProcessing}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  className="w-full sm:w-auto min-w-[140px]"
                  disabled={isProcessing}
                >
                  {isProcessing ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Processing
                    </>
                  ) : (
                    `Pay ${selectedPlan?.price}`
                  )}
                </Button>
              </DialogFooter>
            </form>

            <div className="mt-2 text-center">
              <span className="text-[10px] text-muted-foreground font-medium uppercase tracking-wider opacity-70 flex items-center justify-center gap-1">
                Powered by{" "}
                <span className="font-bold tracking-normal text-[#635BFF]">
                  stripe
                </span>
              </span>
            </div>
          </DialogContent>
        </Dialog>
        <Dialog
          open={isUpdatePaymentModalOpen}
          onOpenChange={setIsUpdatePaymentModalOpen}
        >
          <DialogContent className="sm:max-w-[425px] border-primary/20 bg-background/95 backdrop-blur-xl">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2 text-xl">
                <CreditCard className="h-5 w-5 text-primary" />
                Update Payment Method
              </DialogTitle>
              <DialogDescription>
                Enter your new card details. This will be used for future
                billing.
              </DialogDescription>
            </DialogHeader>

            <div className="mb-4 p-4 rounded-lg bg-muted/50 border border-border/50 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="h-8 w-12 bg-background rounded flex items-center justify-center border border-border">
                  <span className="text-xs font-bold">VISA</span>
                </div>
                <div>
                  <p className="text-sm font-medium text-foreground">
                    Ending in 4242
                  </p>
                  <p className="text-xs text-muted-foreground">Expires 12/28</p>
                </div>
              </div>
              <Badge
                variant="outline"
                className="bg-primary/10 text-primary border-primary/20"
              >
                Default
              </Badge>
            </div>

            <form onSubmit={processCardUpdate} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="new-card">New Card Information</Label>
                <div className="relative">
                  <CreditCard className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground" />
                  <Input
                    id="new-card"
                    placeholder="0000 0000 0000 0000"
                    required
                    className="pl-10 bg-background font-mono"
                    maxLength={19}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4 mt-2">
                  <Input
                    placeholder="MM/YY"
                    required
                    className="bg-background font-mono"
                    maxLength={5}
                  />
                  <Input
                    placeholder="CVC"
                    required
                    className="bg-background font-mono"
                    maxLength={4}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="new-name">Name on Card</Label>
                <Input
                  id="new-name"
                  placeholder="Sovereign Optimizer"
                  required
                  className="bg-background"
                />
              </div>

              <DialogFooter className="pt-4">
                <Button
                  type="button"
                  variant="ghost"
                  onClick={() => setIsUpdatePaymentModalOpen(false)}
                  disabled={isUpdatingCard}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  className="w-full sm:w-auto min-w-[140px]"
                  disabled={isUpdatingCard}
                >
                  {isUpdatingCard ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Updating
                    </>
                  ) : (
                    "Save Payment Method"
                  )}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        <Dialog open={isGiftModalOpen} onOpenChange={setIsGiftModalOpen}>
          <DialogContent className="sm:max-w-[425px] border-primary/20 bg-background/95 backdrop-blur-xl">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2 text-xl">
                <Gift className="h-5 w-5 text-primary" />
                Gift Elite Access
              </DialogTitle>
              <DialogDescription>
                Send{" "}
                <strong className="text-foreground">
                  {selectedGift?.duration} of {selectedGift?.tier}
                </strong>{" "}
                to a fellow optimizer.
              </DialogDescription>
            </DialogHeader>

            <div className="mb-4 p-4 rounded-lg bg-muted/50 border border-border/50 flex justify-between items-center">
              <div>
                <p className="font-medium text-foreground">
                  {selectedGift?.tier} Gift
                </p>
                <p className="text-sm text-muted-foreground">
                  {selectedGift?.duration}
                </p>
              </div>
              <div className="text-right">
                <p className="text-2xl font-bold text-foreground">
                  {selectedGift?.price}
                </p>
              </div>
            </div>

            <form onSubmit={processGift} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="recipient-email">Recipient Email</Label>
                <Input
                  id="recipient-email"
                  type="email"
                  placeholder="friend@example.com"
                  required
                  className="bg-background"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="personal-message">
                  Personal Message (Optional)
                </Label>
                <Input
                  id="personal-message"
                  placeholder="Welcome to the Elite."
                  className="bg-background"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="gift-card">Payment Method</Label>
                <div className="relative">
                  <CreditCard className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground" />
                  <Input
                    id="gift-card"
                    placeholder="0000 0000 0000 0000"
                    required
                    className="pl-10 bg-background font-mono"
                    maxLength={19}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4 mt-2">
                  <Input
                    placeholder="MM/YY"
                    required
                    className="bg-background font-mono"
                    maxLength={5}
                  />
                  <Input
                    placeholder="CVC"
                    required
                    className="bg-background font-mono"
                    maxLength={4}
                  />
                </div>
              </div>

              <DialogFooter className="pt-4">
                <Button
                  type="button"
                  variant="ghost"
                  onClick={() => setIsGiftModalOpen(false)}
                  disabled={isProcessingGift}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  className="w-full sm:w-auto min-w-[140px]"
                  disabled={isProcessingGift}
                >
                  {isProcessingGift ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Processing
                    </>
                  ) : (
                    `Pay ${selectedGift?.price}`
                  )}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </main>
    </div>
  );
}
