import { useState, useRef, useEffect } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Activity,
  Play,
  Square,
  FileText,
  ChevronLeft,
  WifiOff,
  RefreshCw,
  CheckCircle2,
  Crosshair,
  Zap,
  Shield,
  BrainCircuit,
  Timer,
  ChevronRight,
  X,
  RotateCcw,
  CheckCircle,
  AlertTriangle,
  MapPin,
  Radio,
  ChevronUp,
} from "lucide-react";
import { cn, hapticFeedback, playNodeTapSound } from "@/lib/utils";
import { useNavigate } from "react-router-dom";
import NeuralBackground from "@/components/NeuralBackground";
import { motion, AnimatePresence } from "framer-motion";

const ThermalCard = ({ title, type, predictedImpact, onClick }: any) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const [rotation, setRotation] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);

  const calculateRotation = (clientX: number, clientY: number) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = clientX - rect.left;
    const y = clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    const rotateX = ((y - centerY) / centerY) * -15;
    const rotateY = ((x - centerX) / centerX) * 15;
    setRotation({ x: rotateX, y: rotateY });
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    calculateRotation(e.clientX, e.clientY);
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (e.touches.length > 0) {
      calculateRotation(e.touches[0].clientX, e.touches[0].clientY);
    }
  };

  const handleMouseLeave = () => {
    setRotation({ x: 0, y: 0 });
    setIsHovered(false);
  };

  return (
    <div
      ref={cardRef}
      className="relative perspective-1000 w-full group cursor-pointer"
      onMouseMove={handleMouseMove}
      onMouseEnter={() => {
        setIsHovered(true);
        hapticFeedback(5);
      }}
      onMouseLeave={handleMouseLeave}
      onTouchStart={(e) => {
        setIsHovered(true);
        hapticFeedback(5);
      }}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleMouseLeave}
      onClick={() => {
        hapticFeedback(10);
        playNodeTapSound(500);
        onClick();
      }}
      style={{ perspective: "1000px" }}
    >
      {/* Ambient hydrographic glow behind the card */}
      <div
        className={cn(
          "absolute inset-0 rounded-xl blur-xl transition-all duration-500",
          isHovered ? "opacity-60 scale-110" : "opacity-0 scale-100",
        )}
        style={{ background: "rgba(239,68,68,0.4)" }}
      />

      <div
        className={cn(
          "relative w-full h-32 rounded-xl border bg-black p-4 transition-all duration-200 ease-out overflow-hidden flex flex-col justify-between",
          isHovered
            ? "border-red-500/50 shadow-[0_0_30px_rgba(239,68,68,0.3)]"
            : "border-red-500/20",
        )}
        style={{
          transform: `rotateX(${rotation.x}deg) rotateY(${rotation.y}deg) scale(${isHovered ? 1.02 : 1})`,
          transformStyle: "preserve-3d",
        }}
      >
        {/* Tactical Scanline Background */}
        <div className="absolute inset-0 bg-[linear-gradient(transparent_50%,rgba(239,68,68,0.05)_50%)] bg-[length:100%_4px] pointer-events-none" />

        {/* Thermal Heatmap Background with Hydrographic effect */}
        <div
          className="absolute inset-0 opacity-60 mix-blend-screen transition-transform duration-300"
          style={{
            background: `radial-gradient(ellipse at ${50 + rotation.y * 2}% ${50 - rotation.x * 2}%, rgba(239,68,68,0.8), rgba(249,115,22,0.5), rgba(30,58,138,0.2), transparent 80%)`,
            transform: "translateZ(5px)",
          }}
        />
        <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px]" />

        <div
          className="relative z-10 flex justify-between items-start"
          style={{ transform: "translateZ(20px)" }}
        >
          <Badge
            variant="outline"
            className="bg-black/50 text-white border-white/20 backdrop-blur-md group-hover:border-red-500/50 group-hover:shadow-[0_0_15px_rgba(239,68,68,0.6)] transition-all duration-300"
          >
            {type}
          </Badge>
          <div className="text-right">
            <div className="text-[10px] uppercase tracking-widest text-white/70">
              Impact
            </div>
            <div className="font-mono text-sm text-white font-bold group-hover:text-red-400 transition-colors">
              {predictedImpact}
            </div>
          </div>
        </div>
        <h3
          className="relative z-10 text-lg font-bold text-white tracking-tight group-hover:drop-shadow-[0_0_8px_rgba(255,255,255,0.8)] transition-all"
          style={{ transform: "translateZ(30px)" }}
        >
          {title}
        </h3>
      </div>
    </div>
  );
};

const LIVE_LEADERBOARD = [
  { id: 1, name: "GHOST_09", score: 8420, active: true },
  { id: 2, name: "VIPER_ACTUAL", score: 7950, active: true },
  { id: 3, name: "ECHO_BASE", score: 7810, active: false },
  { id: 4, name: "NOVA_7", score: 7640, active: true },
];

const MissionInterface = ({ mission, onComplete, onCancel }: any) => {
  const [isActive, setIsActive] = useState(false);
  const [time, setTime] = useState(0);
  const [isPressing, setIsPressing] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    let interval: any;
    if (isActive) {
      interval = setInterval(() => setTime((t) => t + 1), 1000);
    }
    return () => clearInterval(interval);
  }, [isActive]);

  // Waveform Visualizer
  useEffect(() => {
    if (!canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationId: number;
    let offset = 0;

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.beginPath();
      ctx.lineWidth = 2;
      ctx.strokeStyle = isActive ? "#ef4444" : "#00cccc";

      const amplitude = isActive ? 40 : 10;
      const frequency = isActive ? 0.05 : 0.02;

      for (let x = 0; x < canvas.width; x++) {
        const y =
          canvas.height / 2 +
          Math.sin(x * frequency + offset) * amplitude * Math.sin(offset * 0.1);
        if (x === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
      offset += 0.1;
      animationId = requestAnimationFrame(render);
    };
    render();
    return () => cancelAnimationFrame(animationId);
  }, [isActive]);

  const handlePressStart = () => {
    setIsPressing(true);
    hapticFeedback(50);
  };

  const handlePressEnd = () => {
    setIsPressing(false);
    setIsActive(!isActive);
    hapticFeedback([20, 50]);
  };

  const formatTime = (s: number) => {
    const mins = Math.floor(s / 60)
      .toString()
      .padStart(2, "0");
    const secs = (s % 60).toString().padStart(2, "0");
    return `${mins}:${secs}`;
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#050505] text-white flex flex-col pb-[env(safe-area-inset-bottom,_0px)]">
      <header className="flex justify-between items-center p-4 pt-[calc(1rem_+_env(safe-area-inset-top,_0px))] border-b border-white/10">
        <Button
          variant="ghost"
          size="icon"
          onClick={onCancel}
          className="text-white/50 hover:text-white"
        >
          <ChevronLeft className="w-6 h-6" />
        </Button>
        <div className="text-center">
          <div className="text-[10px] uppercase tracking-widest text-red-500 font-bold animate-pulse">
            Live Mission
          </div>
          <div className="font-mono text-sm">{mission.title}</div>
        </div>
        <div className="w-10" />
      </header>

      <div className="flex-1 flex flex-col items-center justify-center p-6 space-y-12">
        {/* LED Timer */}
        <div className="bg-black border-2 border-[#222] rounded-xl p-6 shadow-[inset_0_0_20px_rgba(0,0,0,1)] relative overflow-hidden">
          <div
            className={cn(
              "absolute inset-0 bg-red-500/10 transition-opacity duration-300",
              isActive ? "animate-pulse opacity-100" : "opacity-0",
            )}
          />
          <div
            className={cn(
              "relative font-mono text-6xl font-black tracking-widest transition-all duration-300",
              isActive
                ? "text-red-500 drop-shadow-[0_0_20px_rgba(239,68,68,0.9)]"
                : "text-red-500/70 drop-shadow-[0_0_5px_rgba(239,68,68,0.4)]",
            )}
          >
            {formatTime(time)}
          </div>
        </div>

        {/* Waveform */}
        <div
          className={cn(
            "w-full h-32 bg-black/50 border rounded-lg overflow-hidden relative transition-all duration-500",
            isActive
              ? "border-red-500/30 shadow-[0_0_30px_rgba(239,68,68,0.15)]"
              : "border-white/5",
          )}
        >
          <canvas
            ref={canvasRef}
            width={400}
            height={128}
            className="w-full h-full opacity-80"
          />
          <div
            className={cn(
              "absolute top-2 left-2 text-[10px] font-mono",
              isActive ? "text-red-500 animate-pulse" : "text-white/30",
            )}
          >
            FREQ_MOD
          </div>
        </div>

        {/* Physical Spring Button */}
        <div
          className="relative w-32 h-32 flex items-center justify-center cursor-pointer group"
          onMouseDown={handlePressStart}
          onMouseUp={handlePressEnd}
          onTouchStart={handlePressStart}
          onTouchEnd={handlePressEnd}
        >
          {/* Outer Glow Ring */}
          <div
            className={cn(
              "absolute inset-[-15px] rounded-full blur-2xl transition-all duration-500 pointer-events-none",
              isActive
                ? "bg-red-500/40 animate-[pulse_1.5s_ease-in-out_infinite]"
                : "bg-red-500/0 group-hover:bg-red-500/20",
            )}
          />

          <div
            className={cn(
              "absolute inset-0 rounded-full bg-gradient-to-b from-red-500 to-red-800 shadow-[0_10px_20px_rgba(239,68,68,0.4),inset_0_2px_5px_rgba(255,255,255,0.5)] transition-all duration-150",
              isPressing
                ? "scale-95 translate-y-2 shadow-[0_2px_5px_rgba(239,68,68,0.4),inset_0_5px_10px_rgba(0,0,0,0.5)]"
                : "scale-100",
              isActive &&
                !isPressing &&
                "animate-[pulse_2s_ease-in-out_infinite]",
            )}
          />
          <div className="relative z-10 font-bold uppercase tracking-widest text-white drop-shadow-md">
            {isActive ? "PAUSE" : "ENGAGE"}
          </div>
        </div>

        {time > 0 && !isActive && (
          <Button
            className="w-full max-w-xs h-14 bg-white text-black hover:bg-white/90 font-bold uppercase tracking-widest"
            onClick={() => onComplete(time)}
          >
            <Square className="w-4 h-4 mr-2" />
            Terminate & Print Receipt
          </Button>
        )}

        {/* Live Leaderboard */}
        <div className="w-full max-w-sm mt-8 border border-white/10 bg-black/40 rounded-xl p-4 backdrop-blur-md">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
              <span className="text-[10px] uppercase tracking-widest font-bold text-white/70">
                Live Network
              </span>
            </div>
            <span className="text-[10px] text-white/40 font-mono">
              4 OPERATORS ACTIVE
            </span>
          </div>
          <div className="space-y-3">
            {LIVE_LEADERBOARD.map((user, i) => (
              <div key={user.id} className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <span className="text-xs font-mono text-white/30 w-4">
                    {i + 1}
                  </span>
                  <span
                    className={cn(
                      "text-xs font-bold tracking-wider",
                      user.active ? "text-white" : "text-white/50",
                    )}
                  >
                    {user.name}
                  </span>
                </div>
                <div className="flex items-center gap-3">
                  {user.active && (
                    <Activity className="w-3 h-3 text-red-500 animate-pulse" />
                  )}
                  <span className="text-xs font-mono text-white/70">
                    {user.score} XP
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

const ThermalReceipt = ({ mission, time, onSign }: any) => {
  const [signed, setSigned] = useState(false);

  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col items-center justify-center p-4 pt-[env(safe-area-inset-top,_0px)] pb-[env(safe-area-inset-bottom,_0px)]">
      <div className="bg-[#f4f4f0] text-black w-full max-w-sm p-6 shadow-[0_0_30px_rgba(255,255,255,0.1)] font-mono relative overflow-hidden">
        {/* Thermal paper zig-zag top/bottom could be added with CSS, keeping it simple */}
        <div className="text-center border-b-2 border-black/20 pb-4 mb-4">
          <h2 className="text-xl font-black uppercase tracking-tighter">
            TherapyFIT Elite
          </h2>
          <p className="text-xs uppercase mt-1">Mission Debrief Receipt</p>
        </div>

        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span>OP:</span> <span className="font-bold">{mission.title}</span>
          </div>
          <div className="flex justify-between">
            <span>DATE:</span> <span>{new Date().toLocaleDateString()}</span>
          </div>
          <div className="flex justify-between">
            <span>TIME:</span> <span>{new Date().toLocaleTimeString()}</span>
          </div>
          <div className="flex justify-between">
            <span>DUR:</span>{" "}
            <span>
              {Math.floor(time / 60)}m {time % 60}s
            </span>
          </div>
        </div>

        <div className="border-y-2 border-black/20 py-4 my-4 space-y-2 text-sm">
          <div className="flex justify-between">
            <span>HRV IMPACT:</span> <span className="font-bold">+12ms</span>
          </div>
          <div className="flex justify-between">
            <span>CNS LOAD:</span> <span className="font-bold">-15%</span>
          </div>
          <div className="flex justify-between">
            <span>STRESS:</span> <span className="font-bold">-22%</span>
          </div>
        </div>

        <div className="pt-8 pb-4">
          {signed ? (
            <div className="text-center font-['Brush_Script_MT',cursive] text-2xl text-blue-800 -rotate-3 border-b border-black/20 pb-2">
              Operator Signed
            </div>
          ) : (
            <Button
              variant="outline"
              className="w-full border-black border-dashed text-black hover:bg-black/5"
              onClick={() => {
                setSigned(true);
                hapticFeedback(20);
              }}
            >
              Sign to Authenticate
            </Button>
          )}
        </div>

        <div className="text-center text-[10px] opacity-50 mt-4">
          // END OF TRANSMISSION //
        </div>
      </div>

      {signed && (
        <Button
          className="mt-8 bg-primary text-primary-foreground"
          onClick={onSign}
        >
          Return to Ops
        </Button>
      )}
    </div>
  );
};

// Threat level derived from mission type and CNS/HRV state
const getThreatLevel = (mission: any, cnsLoad: number, hrvScore: number) => {
  const isHighIntensity = mission.type === "Gym Protocol";
  if (isHighIntensity)
    return { level: "CRITICAL", color: "#ef4444", code: "DEFCON 2", pct: 85 };
  if (mission.type === "Neural")
    return { level: "MODERATE", color: "#f59e0b", code: "DEFCON 4", pct: 50 };
  return { level: "LOW", color: "#00ff66", code: "DEFCON 5", pct: 20 };
};

// Predicted biometric deltas parsed from the mission string
const parseImpact = (impactStr: string) => {
  const deltas: { label: string; value: string; positive: boolean }[] = [];
  const parts = impactStr.split("|").map((s) => s.trim());
  for (const part of parts) {
    const match = part.match(/^(HRV|CNS|Stress)\s*([+-]?\d+)/i);
    if (match) {
      const label = match[1].toUpperCase();
      const num = parseInt(match[2]);
      const positive =
        label === "CNS" || label === "STRESS" ? num < 0 : num > 0;
      deltas.push({
        label,
        value: `${num > 0 ? "+" : ""}${num}${label === "HRV" ? "ms" : "%"}`,
        positive,
      });
    }
  }
  return deltas;
};

const MissionBriefing = ({
  mission,
  cnsLoad,
  hrvScore,
  onLaunch,
  onAbort,
}: any) => {
  const [countdown, setCountdown] = useState(3);
  const [scanning, setScanning] = useState(true);
  const threat = getThreatLevel(mission, cnsLoad, hrvScore);
  const impacts = parseImpact(mission.predictedImpact);

  // Scan animation -> countdown -> ready
  useEffect(() => {
    const scanTimer = setTimeout(() => setScanning(false), 1800);
    return () => clearTimeout(scanTimer);
  }, []);

  useEffect(() => {
    if (scanning) return;
    if (countdown <= 0) return;
    const t = setInterval(() => {
      setCountdown((c) => {
        if (c <= 1) {
          clearInterval(t);
          return 0;
        }
        hapticFeedback(10);
        return c - 1;
      });
    }, 1000);
    return () => clearInterval(t);
  }, [scanning]);

  // Generate tactical map waypoints
  const waypoints = [
    { x: 15, y: 75, label: "START" },
    { x: 35, y: 40, label: "WP-1" },
    { x: 60, y: 60, label: "WP-2" },
    { x: 82, y: 25, label: "EXTRACT" },
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.3 }}
      className="fixed inset-0 z-50 bg-[#050505] text-white flex flex-col"
    >
      {/* Scanline overlay */}
      <div className="absolute inset-0 pointer-events-none z-50 bg-[repeating-linear-gradient(0deg,transparent,transparent_2px,rgba(0,255,255,0.02)_2px,rgba(0,255,255,0.02)_3px)]" />

      {/* Header */}
      <div className="flex items-center justify-between p-4 pt-[calc(1rem_+_env(safe-area-inset-top,_0px))] border-b border-white/10 bg-black/60 backdrop-blur-xl">
        <button
          onClick={onAbort}
          className="flex items-center gap-1 text-white/50 hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
          <span className="text-[10px] uppercase tracking-widest font-bold">
            Abort
          </span>
        </button>
        <div className="text-center">
          <div className="text-[10px] uppercase tracking-[0.4em] text-white/40 font-bold">
            Mission Briefing
          </div>
          <div className="font-mono text-sm text-white font-bold">
            {mission.title}
          </div>
        </div>
        <div className="w-16" />
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-6 max-w-md mx-auto w-full space-y-5 relative z-10">
        {/* Threat Level Panel */}
        <motion.div
          initial={{ x: -40, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ delay: 0.1, type: "spring", stiffness: 120 }}
          className="relative rounded-2xl border p-5 overflow-hidden"
          style={{
            borderColor: `${threat.color}55`,
            background: `linear-gradient(135deg, ${threat.color}15, transparent)`,
          }}
        >
          <div
            className="absolute top-0 left-0 right-0 h-px"
            style={{
              background: `linear-gradient(90deg, transparent, ${threat.color}, transparent)`,
            }}
          />
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <AlertTriangle
                className="w-5 h-5"
                style={{ color: threat.color }}
              />
              <span className="text-[10px] uppercase tracking-[0.3em] font-black text-white/60">
                Threat Assessment
              </span>
            </div>
            <span
              className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border"
              style={{
                color: threat.color,
                borderColor: `${threat.color}66`,
                background: `${threat.color}15`,
              }}
            >
              {threat.code}
            </span>
          </div>
          <div className="flex items-end justify-between">
            <div>
              <div
                className="text-3xl font-black tracking-tighter"
                style={{
                  color: threat.color,
                  textShadow: `0 0 20px ${threat.color}80`,
                }}
              >
                {threat.level}
              </div>
              <div className="text-[10px] text-white/40 uppercase tracking-widest mt-1">
                {mission.type} Protocol
              </div>
            </div>
            <div className="text-right">
              <div className="text-[10px] text-white/40 uppercase tracking-widest">
                Risk Index
              </div>
              <div
                className="font-mono text-2xl font-bold"
                style={{ color: threat.color }}
              >
                {threat.pct}%
              </div>
            </div>
          </div>
          {/* Threat bar */}
          <div className="mt-3 h-1.5 rounded-full bg-white/5 overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${threat.pct}%` }}
              transition={{ delay: 0.3, duration: 0.8, ease: "easeOut" }}
              className="h-full rounded-full"
              style={{
                background: threat.color,
                boxShadow: `0 0 10px ${threat.color}`,
              }}
            />
          </div>
        </motion.div>

        {/* Predicted Biometric Impact */}
        <motion.div
          initial={{ x: 40, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ delay: 0.2, type: "spring", stiffness: 120 }}
          className="rounded-2xl border border-white/10 bg-black/50 p-5 backdrop-blur-md"
        >
          <div className="flex items-center gap-2 mb-4">
            <Activity className="w-4 h-4 text-cyan-400" />
            <span className="text-[10px] uppercase tracking-[0.3em] font-black text-white/60">
              Predicted Biometric Impact
            </span>
          </div>
          <div className="space-y-3">
            {impacts.map((imp, i) => (
              <motion.div
                key={imp.label}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 + i * 0.1 }}
                className="flex items-center justify-between"
              >
                <span className="text-xs font-bold tracking-widest text-white/70 uppercase">
                  {imp.label}
                </span>
                <div className="flex items-center gap-2">
                  <span
                    className={`font-mono text-lg font-bold ${imp.positive ? "text-emerald-400" : "text-red-400"}`}
                    style={{
                      textShadow: imp.positive
                        ? "0 0 10px rgba(0,255,102,0.4)"
                        : "0 0 10px rgba(239,68,68,0.4)",
                    }}
                  >
                    {imp.value}
                  </span>
                  <span
                    className="text-[9px] uppercase tracking-widest"
                    style={{ color: imp.positive ? "#00ff66" : "#ef4444" }}
                  >
                    {imp.positive ? "OPTIMAL" : "RISK"}
                  </span>
                </div>
              </motion.div>
            ))}
          </div>
          {/* Pre-mission vitals */}
          <div className="mt-4 pt-4 border-t border-white/5 flex gap-4">
            <div className="flex-1 text-center">
              <div className="text-[9px] uppercase tracking-widest text-white/40">
                Current HRV
              </div>
              <div className="font-mono text-lg font-bold text-cyan-400">
                {hrvScore}
              </div>
            </div>
            <div className="w-px bg-white/10" />
            <div className="flex-1 text-center">
              <div className="text-[9px] uppercase tracking-widest text-white/40">
                CNS Load
              </div>
              <div
                className="font-mono text-lg font-bold"
                style={{ color: cnsLoad > 85 ? "#ef4444" : "#f59e0b" }}
              >
                {cnsLoad}%
              </div>
            </div>
          </div>
        </motion.div>

        {/* Tactical Map Route */}
        <motion.div
          initial={{ y: 40, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3, type: "spring", stiffness: 120 }}
          className="rounded-2xl border border-white/10 bg-black/50 p-5 backdrop-blur-md"
        >
          <div className="flex items-center gap-2 mb-4">
            <MapPin className="w-4 h-4 text-cyan-400" />
            <span className="text-[10px] uppercase tracking-[0.3em] font-black text-white/60">
              Tactical Route
            </span>
          </div>
          {/* SVG tactical map */}
          <div className="relative aspect-[16/10] rounded-xl border border-white/5 bg-[#0a0a0a] overflow-hidden">
            {/* Grid */}
            <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff08_1px,transparent_1px),linear-gradient(to_bottom,#ffffff08_1px,transparent_1px)] bg-[size:1.5rem_1.5rem]" />
            {/* Range rings */}
            <svg
              className="absolute inset-0 w-full h-full"
              viewBox="0 0 100 62.5"
              preserveAspectRatio="none"
            >
              <circle
                cx="50"
                cy="31"
                r="20"
                fill="none"
                stroke="rgba(0,255,255,0.08)"
                strokeWidth="0.3"
              />
              <circle
                cx="50"
                cy="31"
                r="35"
                fill="none"
                stroke="rgba(0,255,255,0.05)"
                strokeWidth="0.3"
              />
              {/* Route path */}
              <motion.path
                d={`M ${waypoints[0].x} ${waypoints[0].y * 0.625} L ${waypoints[1].x} ${waypoints[1].y * 0.625} L ${waypoints[2].x} ${waypoints[2].y * 0.625} L ${waypoints[3].x} ${waypoints[3].y * 0.625}`}
                fill="none"
                stroke="rgba(0,255,255,0.5)"
                strokeWidth="0.8"
                strokeDasharray="2 1"
                initial={{ pathLength: 0 }}
                animate={{ pathLength: scanning ? 0 : 1 }}
                transition={{ duration: 1.2, ease: "easeInOut" }}
              />
            </svg>
            {/* Waypoint dots */}
            {waypoints.map((wp, i) => (
              <motion.div
                key={wp.label}
                initial={{ scale: 0, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: 0.6 + i * 0.2, type: "spring" }}
                className="absolute flex flex-col items-center"
                style={{
                  left: `${wp.x}%`,
                  top: `${wp.y}%`,
                  transform: "translate(-50%, -50%)",
                }}
              >
                <div
                  className={cn(
                    "w-2.5 h-2.5 rounded-full border-2",
                    i === 0
                      ? "bg-emerald-400 border-emerald-300"
                      : i === waypoints.length - 1
                        ? "bg-red-500 border-red-400"
                        : "bg-cyan-400 border-cyan-300",
                  )}
                  style={{ boxShadow: "0 0 8px currentColor" }}
                />
                <span className="text-[7px] font-mono font-bold text-white/50 mt-1 tracking-widest">
                  {wp.label}
                </span>
              </motion.div>
            ))}
            {/* Scanning sweep */}
            {scanning && (
              <motion.div
                initial={{ x: "-100%" }}
                animate={{ x: "100%" }}
                transition={{ duration: 1.5, ease: "easeInOut" }}
                className="absolute inset-y-0 w-1/3 pointer-events-none"
                style={{
                  background:
                    "linear-gradient(90deg, transparent, rgba(0,255,255,0.08), transparent)",
                }}
              />
            )}
            {/* Compass */}
            <div className="absolute top-2 right-2 flex items-center gap-1 text-[8px] font-mono text-white/30">
              <Radio className="w-3 h-3" />
              <span>N</span>
            </div>
          </div>
        </motion.div>

        {/* Launch button / countdown */}
        <div className="pt-2 pb-8">
          {countdown > 0 && !scanning ? (
            <motion.div
              key={countdown}
              initial={{ scale: 0.5, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 1.5, opacity: 0 }}
              className="flex flex-col items-center gap-2"
            >
              <div className="text-[10px] uppercase tracking-[0.4em] text-white/40 font-bold">
                Launch In
              </div>
              <div className="text-6xl font-black text-cyan-400 drop-shadow-[0_0_20px_rgba(0,255,255,0.6)] font-mono">
                {countdown}
              </div>
            </motion.div>
          ) : scanning ? (
            <div className="flex flex-col items-center gap-2 py-4">
              <div className="text-[10px] uppercase tracking-[0.4em] text-cyan-400 font-bold animate-pulse">
                Scanning Tactical Environment...
              </div>
              <div className="flex gap-1.5">
                {[0, 1, 2].map((i) => (
                  <motion.div
                    key={i}
                    animate={{ opacity: [0.2, 1, 0.2] }}
                    transition={{
                      duration: 0.8,
                      repeat: Infinity,
                      delay: i * 0.2,
                    }}
                    className="w-2 h-2 rounded-full bg-cyan-400"
                  />
                ))}
              </div>
            </div>
          ) : (
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="flex flex-col gap-3"
            >
              <Button
                className="w-full h-14 bg-cyan-500 hover:bg-cyan-400 text-black font-black uppercase tracking-[0.3em] text-sm shadow-[0_0_30px_rgba(0,255,255,0.3)] active:scale-95 transition-all"
                onClick={() => {
                  hapticFeedback(30);
                  onLaunch();
                }}
              >
                <Crosshair className="w-5 h-5 mr-2" />
                Launch Mission
              </Button>
              <Button
                variant="ghost"
                className="w-full text-white/40 hover:text-white/70 text-[10px] uppercase tracking-widest"
                onClick={onAbort}
              >
                Abort Sequence
              </Button>
            </motion.div>
          )}
        </div>
      </div>
    </motion.div>
  );
};

export default function Ops() {
  const navigate = useNavigate();
  const [activeMission, setActiveMission] = useState<any>(null);
  const [receiptData, setReceiptData] = useState<any>(null);
  const [briefingMission, setBriefingMission] = useState<any>(null);
  const [isOffline, setIsOffline] = useState(!navigator.onLine);
  const [syncing, setSyncing] = useState(false);
  const [pendingCount, setPendingCount] = useState(0);

  const [cnsLoad, setCnsLoad] = useState(() => {
    try {
      return parseInt(localStorage.getItem("tf_cns_load") || "0");
    } catch {
      return 0;
    }
  });
  const [hrvScore, setHrvScore] = useState(() => {
    try {
      return parseInt(localStorage.getItem("tf_hrv_score") || "65");
    } catch {
      return 65;
    }
  });

  const isCnsActive = cnsLoad > 0;
  const isLocked = isCnsActive ? cnsLoad > 85 : hrvScore < 50;
  const lockReason = isCnsActive
    ? `CNS Load critical (${cnsLoad}%). Tactical Advisor mandates active recovery. High-intensity missions locked.`
    : `HRV critical (${hrvScore}). Tactical Advisor mandates active recovery. High-intensity missions locked.`;

  useEffect(() => {
    const checkPending = () => {
      const pending = JSON.parse(
        localStorage.getItem("pendingMissions") || "[]",
      );
      setPendingCount(pending.length);
    };
    checkPending();

    const handleOnline = async () => {
      setIsOffline(false);
      const pending = JSON.parse(
        localStorage.getItem("pendingMissions") || "[]",
      );
      if (pending.length > 0) {
        setSyncing(true);
        // Simulate API sync delay
        await new Promise((resolve) => setTimeout(resolve, 2000));
        localStorage.removeItem("pendingMissions");
        setPendingCount(0);
        setSyncing(false);
      }
    };
    const handleOffline = () => setIsOffline(true);

    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);

    // Initial sync check if we load the app online with pending items
    if (navigator.onLine) {
      handleOnline();
    }

    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, []);

  const handleSignReceipt = () => {
    if (isOffline) {
      const pending = JSON.parse(
        localStorage.getItem("pendingMissions") || "[]",
      );
      pending.push({ ...receiptData, timestamp: Date.now() });
      localStorage.setItem("pendingMissions", JSON.stringify(pending));
      setPendingCount(pending.length);
    }
    setReceiptData(null);
  };

  const missions = [
    {
      id: 1,
      title: "Deep CNS Reset",
      type: "Breathwork",
      predictedImpact: "HRV +15ms | CNS -20%",
    },
    {
      id: 2,
      title: "Tactical Hypertrophy",
      type: "Gym Protocol",
      predictedImpact: "CNS +40% | Stress +10%",
    },
    {
      id: 3,
      title: "Vagal Tone Stimulator",
      type: "Neural",
      predictedImpact: "HRV +8ms | Stress -15%",
    },
  ];

  if (receiptData) {
    return (
      <ThermalReceipt
        mission={receiptData.mission}
        time={receiptData.time}
        onSign={handleSignReceipt}
      />
    );
  }

  if (briefingMission) {
    return (
      <AnimatePresence mode="wait">
        <MissionBriefing
          key="briefing"
          mission={briefingMission}
          cnsLoad={cnsLoad}
          hrvScore={hrvScore}
          onLaunch={() => {
            setActiveMission(briefingMission);
            setBriefingMission(null);
          }}
          onAbort={() => setBriefingMission(null)}
        />
      </AnimatePresence>
    );
  }

  if (activeMission) {
    return (
      <MissionInterface
        mission={activeMission}
        onCancel={() => setActiveMission(null)}
        onComplete={(time: number) => {
          setActiveMission(null);
          setReceiptData({ mission: activeMission, time });
        }}
      />
    );
  }

  return (
    <div className="flex flex-1 flex-col bg-[#050505] text-foreground relative min-h-full">
      {/* Tactical Military Grid Background */}
      <div className="absolute inset-0 pointer-events-none z-0">
        <NeuralBackground />
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#ef444410_1px,transparent_1px),linear-gradient(to_bottom,#ef444410_1px,transparent_1px)] bg-[size:2.5rem_2.5rem] [mask-image:radial-gradient(ellipse_80%_80%_at_50%_50%,#000_40%,transparent_100%)] opacity-30" />
        <div className="absolute top-1/4 right-1/4 w-[500px] h-[500px] bg-red-500/10 rounded-full blur-[120px] animate-pulse mix-blend-screen" />
        <div
          className="absolute bottom-1/4 left-1/4 w-[600px] h-[600px] bg-orange-500/10 rounded-full blur-[150px] animate-pulse mix-blend-screen"
          style={{ animationDelay: "2s" }}
        />
      </div>

      <header className="px-6 py-8 relative z-10 border-b border-red-500/30 bg-black/60 backdrop-blur-xl shadow-[0_0_50px_rgba(239,68,68,0.3)]">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <h1 className="text-4xl font-black tracking-tighter text-white high-res-glow uppercase glow-text-red">
              Tactical Ops
            </h1>
            <p className="text-[10px] text-red-500/80 uppercase tracking-[0.5em] font-black flex items-center gap-2">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-500 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
              </span>
              Sovereign Mission Control v4.2
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                hapticFeedback(10);
                navigate("/loadout");
              }}
              className="px-4 py-2 bg-red-500/10 border border-red-500/40 text-red-500 rounded-lg text-[10px] uppercase tracking-[0.2em] font-black hover:bg-red-500/20 transition-all shadow-[0_0_15px_rgba(239,68,68,0.1)] active:scale-95"
            >
              LOADOUT
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1 px-4 space-y-6 max-w-md mx-auto w-full relative z-10 mt-6">
        {/* Sync Status Banner */}
        {(pendingCount > 0 || syncing) && (
          <div className="bg-black border border-white/10 rounded-xl p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              {syncing ? (
                <RefreshCw className="w-5 h-5 text-blue-400 animate-spin" />
              ) : isOffline ? (
                <FileText className="w-5 h-5 text-orange-400" />
              ) : (
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              )}
              <div>
                <div className="text-sm font-bold text-white">
                  {syncing ? "Syncing to Server..." : "Local Cache Active"}
                </div>
                <div className="text-xs text-muted-foreground">
                  {pendingCount} mission{pendingCount !== 1 ? "s" : ""} pending
                  sync
                </div>
              </div>
            </div>
            {isOffline && (
              <div className="text-[10px] uppercase tracking-widest text-orange-500/70">
                Awaiting Signal
              </div>
            )}
          </div>
        )}

        {/* CNS/HRV Status Banner */}
        {isCnsActive ? (
          <div className="bg-black/60 border border-primary/20 rounded-xl p-4 flex items-center justify-between mb-4 backdrop-blur-md">
            <div className="flex items-center gap-3">
              <BrainCircuit className="w-5 h-5 text-primary" />
              <div>
                <div className="text-sm font-bold text-white">
                  CNS Override Active
                </div>
                <div className="text-xs text-muted-foreground">
                  Local biometric data loaded ({cnsLoad}%)
                </div>
              </div>
            </div>
            <Badge
              variant="outline"
              className="bg-primary/10 text-primary border-primary/30 text-[10px] uppercase tracking-widest"
            >
              Client Override
            </Badge>
          </div>
        ) : (
          <div className="bg-black/60 border border-emerald-500/20 rounded-xl p-4 flex items-center justify-between mb-4 backdrop-blur-md">
            <div className="flex items-center gap-3">
              <Activity className="w-5 h-5 text-emerald-400" />
              <div>
                <div className="text-sm font-bold text-white">
                  HRV Gating Active
                </div>
                <div className="text-xs text-muted-foreground">
                  CNS unavailable. Using HRV-only guidance ({hrvScore}).
                </div>
              </div>
            </div>
            <Badge
              variant="outline"
              className="bg-emerald-500/10 text-emerald-400 border-emerald-500/30 text-[10px] uppercase tracking-widest"
            >
              Server Fallback
            </Badge>
          </div>
        )}

        {/* Missions Locked Warning */}
        {isLocked && (
          <div className="bg-destructive/10 border border-destructive/30 rounded-xl p-4 flex gap-3 animate-pulse mb-6">
            <Shield className="w-5 h-5 text-destructive shrink-0" />
            <div>
              <h4 className="text-sm font-bold text-destructive uppercase tracking-widest">
                Training Gated
              </h4>
              <p className="text-xs text-destructive/80 mt-1">{lockReason}</p>
            </div>
          </div>
        )}

        <div className="space-y-4">
          {missions.map((m) => (
            <div key={m.id} className="relative">
              <ThermalCard
                title={m.title}
                type={m.type}
                predictedImpact={m.predictedImpact}
                onClick={() => {
                  if (isLocked && m.type !== "Breathwork") {
                    hapticFeedback(20);
                    return;
                  }
                  hapticFeedback(10);
                  if (m.type === "Breathwork") {
                    navigate("/breathing");
                  } else {
                    setBriefingMission(m);
                  }
                }}
              />
              {isLocked && m.type !== "Breathwork" && (
                <div className="absolute inset-0 bg-black/60 backdrop-blur-[1px] rounded-xl flex items-center justify-center z-20 cursor-not-allowed">
                  <div className="bg-destructive/20 text-destructive border border-destructive/40 px-3 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest flex items-center gap-2">
                    <Shield className="w-3 h-3" />
                    Locked by {isCnsActive ? "CNS" : "HRV"}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
