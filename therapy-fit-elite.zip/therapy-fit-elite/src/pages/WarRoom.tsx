import { useState, useEffect, useRef } from "react";
import { Logo } from "@/components/Logo";
import { useNavigate } from "react-router-dom";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Slider } from "@/components/ui/slider";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import {
  Crosshair,
  Shield,
  Swords,
  Zap,
  Activity,
  Globe,
  AlertTriangle,
  TrendingUp,
  Target,
  Radar,
  Handshake,
  MessageSquare,
  Send,
  CheckCircle2,
  Waves,
  Radio,
  Activity as Pulse,
  Cpu,
  Briefcase,
  Coins,
  Flag,
  Skull,
  ShieldAlert,
  ZapOff,
  RefreshCcw,
  PhoneCall,
  ShieldCheck as ShieldCheckIcon,
  MessageCircle,
  User,
  X,
  Fingerprint,
  Bell,
} from "lucide-react";
import { hapticFeedback, cn } from "@/lib/utils";
import { toast } from "sonner";
import LiveWarRoomMap from "@/components/LiveWarRoomMap";
import { NeuralNotificationCenter } from "@/components/NeuralNotifications";

const NeuralFeedback = ({
  active,
  variant = "primary",
}: {
  active: boolean;
  variant?: "primary" | "destructive" | "gold" | "fuchsia" | "cyan";
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (!active || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationFrameId: number;
    let offset = 0;

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const color =
        variant === "destructive"
          ? "255, 0, 0"
          : variant === "gold"
            ? "255, 215, 0"
            : variant === "fuchsia"
              ? "217, 70, 239"
              : "0, 255, 255";

      ctx.beginPath();
      ctx.lineWidth = 2;
      ctx.strokeStyle = `rgba(${color}, 0.5)`;

      for (let x = 0; x < canvas.width; x++) {
        const y =
          canvas.height / 2 +
          Math.sin(x * 0.02 + offset) * 20 * Math.sin(offset * 0.5);
        if (x === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();

      ctx.beginPath();
      ctx.lineWidth = 1;
      ctx.strokeStyle = `rgba(${color}, 0.2)`;
      for (let x = 0; x < canvas.width; x++) {
        const y = canvas.height / 2 + Math.cos(x * 0.015 + offset * 0.8) * 30;
        if (x === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();

      offset += 0.1;
      animationFrameId = requestAnimationFrame(render);
    };

    render();
    return () => cancelAnimationFrame(animationFrameId);
  }, [active, variant]);

  return (
    <div
      className={cn(
        "relative h-24 w-full overflow-hidden rounded-lg bg-background/20 border border-border/50 transition-all duration-500",
        active
          ? "opacity-100 scale-100"
          : "opacity-0 scale-95 pointer-events-none h-0 border-none",
      )}
    >
      <canvas
        ref={canvasRef}
        width={800}
        height={100}
        className="w-full h-full opacity-80"
      />
      <div className="absolute inset-0 bg-gradient-to-r from-background via-transparent to-background" />
      <div className="absolute top-2 left-3 flex items-center gap-2">
        <Radio
          className={cn(
            "h-3 w-3 animate-pulse",
            variant === "destructive"
              ? "text-destructive"
              : variant === "gold"
                ? "text-yellow-400"
                : variant === "fuchsia"
                  ? "text-fuchsia-400"
                  : "text-primary",
          )}
        />
        <span className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">
          Neural Resonance Feedback
        </span>
      </div>
    </div>
  );
};

const SECTORS = [
  {
    name: "North America",
    faction: "Aegis Vanguard",
    dominance: 42,
    friction: 12,
    status: "Contested",
    color: "text-primary",
    bg: "bg-primary",
  },
  {
    name: "Europe",
    faction: "Synapse Syndicate",
    dominance: 28,
    friction: 18,
    status: "Stable",
    color: "text-blue-400",
    bg: "bg-blue-400",
  },
  {
    name: "Asia Pacific",
    faction: "Nexus Collective",
    dominance: 30,
    friction: 8,
    status: "Optimal",
    color: "text-fuchsia-400",
    bg: "bg-fuchsia-400",
  },
];

const ACTIVE_DEPLOYMENTS = [
  {
    id: 1,
    type: "Neural Satellite",
    target: "San Francisco",
    eta: "Active",
    impact: "+15% Sync",
  },
  {
    id: 2,
    type: "Friction Dampener",
    target: "Berlin",
    eta: "02:14",
    impact: "-10% Friction",
  },
  {
    id: 3,
    type: "Cognitive Relay",
    target: "Tokyo",
    eta: "Active",
    impact: "Bandwidth x2",
  },
];

export default function WarRoom() {
  const navigate = useNavigate();
  const [globalFriction, setGlobalFriction] = useState(15);
  const [isOverrideActive, setIsOverrideActive] = useState(false);
  const [isTreatyActive, setIsTreatyActive] = useState(false);
  const [isEnvoyActive, setIsEnvoyActive] = useState(false);
  const [isCounterSabotageActive, setIsCounterSabotageActive] = useState(false);
  const [isUnderAttack, setIsUnderAttack] = useState(false);
  const [isBiometricVerifying, setIsBiometricVerifying] = useState(false);
  const [biometricProgress, setBiometricProgress] = useState(0);
  const [pendingAction, setPendingAction] = useState<(() => void) | null>(null);
  const [counterProgress, setCounterProgress] = useState(0);
  const [counterTarget, setCounterTarget] = useState(50);
  const [envoyProgress, setEnvoyProgress] = useState(0);
  const [envoyTarget, setEnvoyTarget] = useState(0);
  const [envoySuccess, setEnvoySuccess] = useState(false);
  const [isSabotageActive, setIsSabotageActive] = useState(false);
  const [isHotlineActive, setIsHotlineActive] = useState(false);
  const [activeNegotiation, setActiveNegotiation] = useState<string | null>(
    null,
  );
  const [sabotageTarget, setSabotageTarget] = useState<string | null>(null);
  const [activeContract, setActiveContract] = useState<{
    sector: string;
    reward: number;
    objective: string;
  } | null>(() => {
    const saved = localStorage.getItem("active_mercenary_contract");
    return saved ? JSON.parse(saved) : null;
  });
  const [summitProgress, setSummitProgress] = useState(65);
  const [isSummitActive, setIsSummitActive] = useState(false);
  const [hasPledged, setHasPledged] = useState(false);
  const [isOverclockActive, setIsOverclockActive] = useState(false);
  const [neuralPoints, setNeuralPoints] = useState(() => {
    const saved = localStorage.getItem("neural_points");
    return saved ? parseInt(saved) : 2500;
  });
  const [decoys, setDecoys] = useState(() => {
    const saved = localStorage.getItem("neural_decoys");
    return saved ? parseInt(saved) : 0;
  });
  const [fortificationLevel, setFortificationLevel] = useState(() => {
    const saved = localStorage.getItem("sector_fortification_level");
    return saved ? parseInt(saved) : 1;
  });

  useEffect(() => {
    localStorage.setItem("neural_points", neuralPoints.toString());
  }, [neuralPoints]);

  useEffect(() => {
    localStorage.setItem("neural_decoys", decoys.toString());
  }, [decoys]);

  useEffect(() => {
    localStorage.setItem(
      "sector_fortification_level",
      fortificationLevel.toString(),
    );
  }, [fortificationLevel]);

  useEffect(() => {
    let timer: number;
    if (isBiometricVerifying && biometricProgress < 100) {
      timer = window.setInterval(() => {
        setBiometricProgress((prev) => {
          if (prev >= 100) {
            clearInterval(timer);
            return 100;
          }
          if (prev % 10 === 0) hapticFeedback(5);
          return prev + 2;
        });
      }, 30);
    }
    return () => clearInterval(timer);
  }, [isBiometricVerifying, biometricProgress]);

  useEffect(() => {
    if (biometricProgress === 100) {
      hapticFeedback([50, 30, 50]);
      setTimeout(() => {
        setIsBiometricVerifying(false);
        setBiometricProgress(0);
        if (pendingAction) {
          pendingAction();
          setPendingAction(null);
        }
      }, 500);
    }
  }, [biometricProgress, pendingAction]);

  const verifyBiometrics = (action: () => void) => {
    setPendingAction(() => action);
    setIsBiometricVerifying(true);
    setBiometricProgress(0);
    hapticFeedback(10);
  };

  useEffect(() => {
    if (activeContract) {
      localStorage.setItem(
        "active_mercenary_contract",
        JSON.stringify(activeContract),
      );
    } else {
      localStorage.removeItem("active_mercenary_contract");
    }
  }, [activeContract]);

  useEffect(() => {
    if (isEnvoyActive) {
      setEnvoyTarget(Math.floor(Math.random() * 60) + 20);
    }
    if (isCounterSabotageActive) {
      setCounterTarget(Math.floor(Math.random() * 70) + 15);
    }
  }, [isEnvoyActive, isCounterSabotageActive]);

  useEffect(() => {
    const attackInterval = setInterval(() => {
      if (
        !isUnderAttack &&
        !isTreatyActive &&
        Math.random() > 0.85 + fortificationLevel * 0.02
      ) {
        if (decoys > 0) {
          setDecoys((prev) => prev - 1);
          hapticFeedback([50, 100, 50]);
          toast.success("Sabotage Misdirected", {
            description: "Neural Decoy deployed. Attack successfully diverted.",
          });
        } else {
          setIsUnderAttack(true);
          hapticFeedback([100, 100, 100]);
          toast.error("INCOMING SABOTAGE DETECTED", {
            description:
              "Rival sector injecting cognitive noise. Defense protocols required.",
          });
        }
      }
    }, 10000);
    return () => clearInterval(attackInterval);
  }, [isUnderAttack, isTreatyActive, decoys, fortificationLevel]);

  useEffect(() => {
    const interval = setInterval(() => {
      if (isTreatyActive) return;
      setGlobalFriction((prev) => {
        const change = isUnderAttack
          ? Math.floor(Math.random() * 5) + 2
          : Math.random() > 0.5
            ? 1
            : -1;
        return Math.max(5, Math.min(95, prev + change));
      });
    }, 3000);
    return () => clearInterval(interval);
  }, [isTreatyActive, isUnderAttack]);

  const handlePledgeSummit = () => {
    verifyBiometrics(() => {
      hapticFeedback([50, 30, 50, 30, 100]);
      setHasPledged(true);
      setSummitProgress((prev) => Math.min(100, prev + 15));
      toast.success("Support Pledged", {
        description:
          "Your biometric signature has been added to the Global Summit.",
      });

      if (summitProgress + 15 >= 100) {
        setTimeout(() => {
          setIsSummitActive(true);
          setGlobalFriction(1);
          hapticFeedback([100, 50, 100, 50, 200, 100, 300]);
          toast.success("GLOBAL SUMMIT REACHED", {
            description:
              "Unprecedented multi-faction sync achieved. Global friction suppressed.",
          });
          setTimeout(() => {
            setIsSummitActive(false);
            setSummitProgress(0);
            setHasPledged(false);
          }, 30000); // 30 seconds of pure bliss
        }, 1000);
      }
    });
  };

  const handleOverclock = () => {
    verifyBiometrics(() => {
      hapticFeedback([100, 50, 100, 50, 200]);
      setIsOverclockActive(true);
      setGlobalFriction((prev) => Math.min(95, prev + 20));
      toast.success("Neural Overclock Engaged", {
        description:
          "All active buffs tripled. Neural friction increased by 20%.",
      });
      setTimeout(() => {
        setIsOverclockActive(false);
        toast.info("Neural Overclock Ended", {
          description: "Buffs returned to normal levels.",
        });
      }, 15000);
    });
  };

  const handleOverride = () => {
    verifyBiometrics(() => {
      hapticFeedback([100, 50, 100, 50, 200]);
      setIsOverrideActive(true);
      toast.success("Global Override Initiated", {
        description:
          "All sector dampeners are now operating at maximum capacity.",
      });
      setTimeout(() => {
        setIsOverrideActive(false);
        setGlobalFriction(5);
      }, 5000);
    });
  };

  const handlePeaceTreaty = () => {
    verifyBiometrics(() => {
      setIsEnvoyActive(true);
      setEnvoyProgress(0);
      setEnvoySuccess(false);
      hapticFeedback(10);
    });
  };

  const handleCounterSabotage = () => {
    setIsCounterSabotageActive(true);
    setCounterProgress(0);
    hapticFeedback(10);
  };

  const completeCounterSabotage = () => {
    if (Math.abs(counterProgress - counterTarget) < 4) {
      hapticFeedback([50, 30, 50, 30, 100]);
      setIsCounterSabotageActive(false);
      setIsUnderAttack(false);
      setGlobalFriction((prev) => Math.max(5, prev - 20));
      toast.success("Counter-Sabotage Successful", {
        description: "Neural interference purged. Sector stability restored.",
      });
    } else {
      hapticFeedback(100);
      toast.error("Calibration Failed", {
        description: "Static noise overwhelming filters. Try again.",
      });
    }
  };

  const completeEnvoyCalibration = () => {
    if (Math.abs(envoyProgress - envoyTarget) < 5) {
      setEnvoySuccess(true);
      hapticFeedback([50, 30, 50]);
      setTimeout(() => {
        setIsEnvoyActive(false);
        setIsTreatyActive(true);
        setGlobalFriction(1);
        toast.success("Diplomatic Envoy Successful", {
          description:
            "Treaty secured with maximum resonance. Friction suppressed.",
        });
        setTimeout(() => setIsTreatyActive(false), 15000); // 50% longer duration for perfect sync
      }, 1500);
    } else {
      hapticFeedback(100);
      toast.error("Calibration Failed", {
        description: "Neural resonance mismatch. Diplomacy aborted.",
      });
      setIsEnvoyActive(false);
    }
  };

  const handleSignContract = (
    sector: string,
    reward: number,
    objective: string,
  ) => {
    hapticFeedback([50, 30, 50, 30, 100]);
    setActiveContract({ sector, reward, objective });
    toast.success("Mercenary Contract Signed", {
      description: `Allegiance shifted to ${sector}. Objective: ${objective}`,
    });
  };

  const handleCompleteContract = () => {
    if (!activeContract) return;
    hapticFeedback([100, 50, 100, 50, 200]);
    toast.success("Contract Fulfilled", {
      description: `Objective met in ${activeContract.sector}. Reward: ${activeContract.reward} PTS claimed.`,
    });
    setActiveContract(null);
  };

  const handleSabotage = (sector: string) => {
    verifyBiometrics(() => {
      hapticFeedback([100, 50, 200, 50, 100]);
      setSabotageTarget(sector);
      setIsSabotageActive(true);
      toast("Sabotage Protocol Initiated", {
        description: `Injecting neural friction into ${sector}.`,
      });

      setTimeout(() => {
        setIsSabotageActive(false);
        setSabotageTarget(null);
        toast.success("Sabotage Complete", {
          description: `Rival sector ${sector} sync disrupted.`,
        });
      }, 5000);
    });
  };

  const handleHotlineConnect = (faction: string) => {
    hapticFeedback([20, 50, 20]);
    setIsHotlineActive(true);
    setActiveNegotiation(faction);
    toast.info("Diplomatic Hotline Established", {
      description: `Secure channel open with ${faction} command.`,
    });
  };

  const handleNegotiation = (type: string) => {
    hapticFeedback([50, 30, 50]);
    toast.success("Negotiation Protocol Sent", {
      description: `${type} request transmitted to ${activeNegotiation}. Awaiting response...`,
    });

    setTimeout(() => {
      hapticFeedback([100, 50, 100]);
      toast.info("Diplomatic Response Received", {
        description: `${activeNegotiation} has acknowledged the ${type.toLowerCase()} protocol.`,
      });
    }, 3000);
  };

  return (
    <div className="flex flex-1 flex-col bg-[#050505] text-foreground relative min-h-full">
      {/* Tactical Military Grid Background */}
      <div className="absolute inset-0 pointer-events-none z-0">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#00ffff08_1px,transparent_1px),linear-gradient(to_bottom,#00ffff08_1px,transparent_1px)] bg-[size:2rem_2rem] [mask-image:radial-gradient(ellipse_80%_80%_at_50%_50%,#000_20%,transparent_100%)]" />
        <div className="absolute top-0 left-0 w-full h-full opacity-20 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]" />

        {/* Animated Glow Orbs */}
        <div className="absolute top-1/4 left-1/4 w-[500px] h-[500px] bg-cyan-500/10 rounded-full blur-[120px] animate-[pulse_8s_ease-in-out_infinite] mix-blend-screen" />
        <div className="absolute bottom-1/4 right-1/4 w-[600px] h-[600px] bg-red-500/10 rounded-full blur-[150px] animate-[pulse_12s_ease-in-out_infinite_reverse] mix-blend-screen" />
        <div className="absolute top-1/2 right-1/3 w-[400px] h-[400px] bg-orange-500/5 rounded-full blur-[100px] animate-[pulse_10s_ease-in-out_infinite_delay-2s] mix-blend-screen" />
        <div className="absolute bottom-1/3 left-1/2 w-[300px] h-[300px] bg-blue-500/10 rounded-full blur-[80px] animate-[pulse_15s_ease-in-out_infinite_delay-5s] mix-blend-screen" />
      </div>

      <header className="px-6 py-8 relative z-10 border-b border-red-500/30 bg-black/80 backdrop-blur-2xl shadow-[0_0_60px_rgba(239,68,68,0.3)] mx-2 mt-2 rounded-b-[40px]">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <h1 className="text-4xl font-black tracking-tighter text-white high-res-glow uppercase glow-text-red">
              War Room
            </h1>
            <p className="text-[10px] text-red-500/80 uppercase tracking-[0.4em] font-black flex items-center gap-2">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-500 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
              </span>
              Strategic Command v6.0
            </p>
          </div>
          <div className="flex items-center gap-4">
            <Badge
              variant="outline"
              className="bg-red-500/10 text-red-400 border-red-500/30 gap-1.5 animate-pulse uppercase font-black text-[9px] tracking-widest px-4 py-1.5 rounded-full shadow-[0_0_15px_rgba(239,68,68,0.4)]"
            >
              LIVE STRATEGY
            </Badge>
            <NeuralNotificationCenter />
          </div>
        </div>
      </header>

      <main className="flex-1 container px-4 md:px-6 py-8">
        <div className="grid gap-6 md:grid-cols-12">
          {/* Tactical Map Overlay */}
          <div className="md:col-span-12 lg:col-span-8">
            <LiveWarRoomMap
              deployments={ACTIVE_DEPLOYMENTS}
              globalFriction={globalFriction}
            />
          </div>

          {/* Command Feed (New) */}
          <Card className="md:col-span-12 lg:col-span-4 bg-card/40 border-border/50 backdrop-blur-sm flex flex-col h-[400px]">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-bold flex items-center gap-2">
                <MessageSquare className="h-4 w-4 text-primary" />
                LIVE COMMAND FEED
              </CardTitle>
            </CardHeader>
            <CardContent className="flex-1 overflow-y-auto custom-scrollbar space-y-4 text-[10px] font-mono">
              {[
                {
                  time: "14:22:01",
                  msg: "Sector_Alpha synchronization established.",
                  type: "success",
                },
                {
                  time: "14:21:45",
                  msg: "Neural friction spike detected in NA_West.",
                  type: "alert",
                },
                {
                  time: "14:20:30",
                  msg: "Satellite deployment successful (ID: SAT-889).",
                  type: "info",
                },
                {
                  time: "14:18:12",
                  msg: "Sovereign Optimizer 'Sarah_Opt' initiated sync.",
                  type: "info",
                },
                {
                  time: "14:15:00",
                  msg: "Global resonance baseline recalibrated.",
                  type: "success",
                },
                {
                  time: "14:12:30",
                  msg: "Nexus Collective buff active: +10% Focus.",
                  type: "info",
                },
                {
                  time: "14:10:05",
                  msg: "Sabotage attempt deflected by Neural Decoy.",
                  type: "success",
                },
              ].map((log, i) => (
                <div
                  key={i}
                  className="flex gap-3 border-l border-border/50 pl-3 py-1 hover:bg-primary/5 transition-colors"
                >
                  <span className="text-muted-foreground shrink-0">
                    {log.time}
                  </span>
                  <span
                    className={cn(
                      log.type === "alert"
                        ? "text-destructive font-bold"
                        : log.type === "success"
                          ? "text-primary font-bold"
                          : "text-foreground",
                    )}
                  >
                    {log.msg}
                  </span>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Global Status */}
          <Card className="md:col-span-12 lg:col-span-8 bg-card/40 border-border/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5 text-primary" />
                Global Neural Network Status
              </CardTitle>
              <CardDescription>
                Real-time telemetry across all operational sectors.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="bg-background/50 border border-border/50 rounded-lg p-4 space-y-2">
                  <div className="text-xs text-muted-foreground uppercase tracking-wider">
                    Global Friction
                  </div>
                  <div className="flex items-end gap-2">
                    <span
                      className={cn(
                        "text-3xl font-bold",
                        globalFriction > 40
                          ? "text-destructive"
                          : "text-primary",
                      )}
                    >
                      {globalFriction}%
                    </span>
                    {globalFriction > 40 && (
                      <AlertTriangle className="h-5 w-5 text-destructive mb-1 animate-pulse" />
                    )}
                  </div>
                  <Progress
                    value={globalFriction}
                    className={cn(
                      "h-1.5",
                      globalFriction > 40
                        ? "bg-destructive/20 [&>div]:bg-destructive"
                        : "bg-primary/20 [&>div]:bg-primary",
                    )}
                  />
                </div>
                <div className="bg-background/50 border border-border/50 rounded-lg p-4 space-y-2">
                  <div className="text-xs text-muted-foreground uppercase tracking-wider">
                    Active Nodes
                  </div>
                  <div className="text-3xl font-bold text-foreground">
                    14,284
                  </div>
                  <div className="text-xs text-primary flex items-center gap-1">
                    <TrendingUp className="h-3 w-3" /> +124 this hour
                  </div>
                </div>
                <div className="bg-background/50 border border-border/50 rounded-lg p-4 space-y-2">
                  <div className="text-xs text-muted-foreground uppercase tracking-wider">
                    Sync Integrity
                  </div>
                  <div className="text-3xl font-bold text-primary">94.2%</div>
                  <Progress
                    value={94.2}
                    className="h-1.5 bg-primary/20 [&>div]:bg-primary"
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div
                  className="bg-background/50 border border-border/50 rounded-lg p-4 space-y-3 cursor-pointer hover:bg-primary/5 transition-colors group"
                  onClick={() => navigate("/integrations")}
                >
                  <div className="flex justify-between items-center">
                    <div className="text-xs text-muted-foreground uppercase tracking-wider">
                      Webhook Infrastructure
                    </div>
                    <Badge
                      variant="outline"
                      className="border-emerald-500 text-emerald-500 bg-emerald-500/10 text-[10px]"
                    >
                      Operational
                    </Badge>
                  </div>
                  <div className="flex justify-between items-end">
                    <div className="space-y-1">
                      <div className="text-2xl font-bold text-foreground">
                        99.98%{" "}
                        <span className="text-[10px] font-normal text-muted-foreground ml-1">
                          Uptime
                        </span>
                      </div>
                      <div className="text-xs text-primary flex items-center gap-1">
                        <Pulse className="h-3 w-3" /> 132ms avg latency
                      </div>
                    </div>
                    <div className="h-8 flex items-end gap-0.5 opacity-50 group-hover:opacity-100 transition-opacity">
                      {[40, 45, 38, 52, 48, 60, 55, 42, 38, 45].map((h, i) => (
                        <div
                          key={i}
                          className="w-1 bg-emerald-500/50 rounded-t-[1px]"
                          style={{ height: `${h}%` }}
                        ></div>
                      ))}
                    </div>
                  </div>
                </div>
                <div
                  className="bg-background/50 border border-border/50 rounded-lg p-4 space-y-3 cursor-pointer hover:bg-primary/5 transition-colors group"
                  onClick={() => navigate("/integrations")}
                >
                  <div className="flex justify-between items-center">
                    <div className="text-xs text-muted-foreground uppercase tracking-wider">
                      API Throughput
                    </div>
                    <Badge
                      variant="outline"
                      className="border-primary text-primary bg-primary/10 text-[10px]"
                    >
                      High Load
                    </Badge>
                  </div>
                  <div className="flex justify-between items-end">
                    <div className="space-y-1">
                      <div className="text-2xl font-bold text-foreground">
                        14.2k{" "}
                        <span className="text-[10px] font-normal text-muted-foreground ml-1">
                          Req/hr
                        </span>
                      </div>
                      <div className="text-xs text-blue-400 flex items-center gap-1">
                        <TrendingUp className="h-3 w-3" /> +8.2% vs baseline
                      </div>
                    </div>
                    <div className="h-8 flex items-end gap-0.5 opacity-50 group-hover:opacity-100 transition-opacity">
                      {[60, 70, 65, 80, 75, 90, 85, 70, 75, 80].map((h, i) => (
                        <div
                          key={i}
                          className="w-1 bg-blue-400/50 rounded-t-[1px]"
                          style={{ height: `${h}%` }}
                        ></div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-sm font-bold uppercase tracking-widest text-muted-foreground">
                  Sector Dominance
                </h3>
                {SECTORS.map((sector) => (
                  <div key={sector.name} className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-foreground">
                          {sector.name}
                        </span>
                        <span className="text-xs text-muted-foreground">
                          ({sector.faction})
                        </span>
                      </div>
                      <span className={cn("font-bold", sector.color)}>
                        {sector.dominance}%
                      </span>
                    </div>
                    <Progress
                      value={sector.dominance}
                      className={cn("h-2", `bg-secondary [&>div]:${sector.bg}`)}
                    />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Active Deployments & Actions */}
          <div className="md:col-span-12 lg:col-span-4 space-y-6">
            <Card className="bg-card/40 border-border/50 backdrop-blur-sm">
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Pulse className="h-5 w-5 text-primary" />
                  Neural Feedback
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <NeuralFeedback active={isSummitActive} variant="gold" />
                <NeuralFeedback
                  active={isOverrideActive}
                  variant="destructive"
                />
                <NeuralFeedback active={isTreatyActive} variant="primary" />
                <NeuralFeedback active={isEnvoyActive} variant="gold" />
                <NeuralFeedback active={isSabotageActive} variant="fuchsia" />
                <NeuralFeedback active={isHotlineActive} variant="cyan" />
                <NeuralFeedback
                  active={isCounterSabotageActive}
                  variant="cyan"
                />
                <NeuralFeedback
                  active={isOverclockActive}
                  variant="destructive"
                />
                {!isSummitActive &&
                  !isOverrideActive &&
                  !isTreatyActive &&
                  !isEnvoyActive &&
                  !isSabotageActive &&
                  !isHotlineActive &&
                  !isCounterSabotageActive &&
                  !isOverclockActive && (
                    <div className="flex flex-col items-center justify-center py-8 text-center space-y-2">
                      <Waves className="h-8 w-8 text-muted-foreground/20" />
                      <p className="text-xs text-muted-foreground italic">
                        Awaiting command resonance...
                      </p>
                    </div>
                  )}
              </CardContent>
            </Card>

            <Card
              className={cn(
                "bg-card/40 border-yellow-400/30 backdrop-blur-sm relative overflow-hidden transition-all duration-500",
                isSummitActive &&
                  "border-yellow-400 shadow-[0_0_30px_rgba(250,204,21,0.3)] scale-[1.02]",
              )}
            >
              {isSummitActive && (
                <div className="absolute inset-0 bg-yellow-400/10 animate-pulse pointer-events-none" />
              )}
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg text-yellow-400">
                  <Globe
                    className={cn("h-5 w-5", isSummitActive && "animate-spin")}
                  />
                  Global Summit
                </CardTitle>
                <CardDescription>
                  Multi-faction sync event for massive friction reduction.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-[10px] uppercase font-bold text-muted-foreground">
                    <span>Global Support</span>
                    <span className="text-yellow-400">{summitProgress}%</span>
                  </div>
                  <Progress
                    value={summitProgress}
                    className={cn(
                      "h-2",
                      "bg-yellow-400/20 [&>div]:bg-yellow-400",
                    )}
                  />
                </div>
                {isSummitActive ? (
                  <div className="p-3 rounded-lg bg-yellow-400/10 border border-yellow-400/30 text-center animate-in fade-in zoom-in">
                    <div className="text-[10px] font-bold text-yellow-400 uppercase tracking-widest animate-pulse">
                      SUMMIT ACTIVE
                    </div>
                    <div className="text-sm font-bold text-foreground mt-1">
                      Total Neural Resonance
                    </div>
                  </div>
                ) : (
                  <Button
                    className="w-full gap-2 bg-yellow-400 text-yellow-950 hover:bg-yellow-500 font-bold tracking-widest"
                    onClick={handlePledgeSummit}
                    disabled={hasPledged}
                  >
                    <Handshake className="h-4 w-4" />
                    {hasPledged ? "SUPPORT PLEDGED" : "PLEDGE SUPPORT"}
                  </Button>
                )}
              </CardContent>
            </Card>

            <Card className="bg-card/40 border-border/50 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Target className="h-5 w-5 text-fuchsia-400" />
                  Active Deployments
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {ACTIVE_DEPLOYMENTS.map((dep) => (
                  <div
                    key={dep.id}
                    className="flex items-center justify-between p-3 rounded-lg bg-background/50 border border-border/50"
                  >
                    <div>
                      <div className="font-medium text-sm">{dep.type}</div>
                      <div className="text-xs text-muted-foreground">
                        {dep.target}
                      </div>
                    </div>
                    <div className="text-right">
                      <div
                        className={cn(
                          "text-xs font-bold",
                          dep.eta === "Active"
                            ? "text-primary animate-pulse"
                            : "text-muted-foreground",
                        )}
                      >
                        {dep.eta}
                      </div>
                      <div className="text-xs text-fuchsia-400">
                        {dep.impact}
                      </div>
                    </div>
                  </div>
                ))}
                <Button
                  className="w-full gap-2 bg-fuchsia-500/20 text-fuchsia-400 border border-fuchsia-500/30 hover:bg-fuchsia-500/30"
                  onClick={() => navigate("/map")}
                >
                  <Crosshair className="h-4 w-4" />
                  DEPLOY NEW ASSET
                </Button>
                <Button
                  className="w-full gap-2 bg-primary/10 text-primary border border-primary/30 hover:bg-primary/20"
                  onClick={() => navigate("/tech-tree")}
                >
                  <Cpu className="h-4 w-4" />
                  FACTION TECH TREE
                </Button>
              </CardContent>
            </Card>

            <Card
              className={cn(
                "bg-card/40 border-border/50 backdrop-blur-sm relative overflow-hidden transition-all duration-500",
                activeContract &&
                  "border-yellow-500/50 shadow-[0_0_20px_rgba(250,204,21,0.2)]",
              )}
            >
              {activeContract && (
                <div className="absolute inset-0 bg-yellow-500/5 animate-pulse pointer-events-none" />
              )}
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg text-yellow-500">
                  <Briefcase className="h-5 w-5" />
                  Mercenary Operations
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {activeContract ? (
                  <div className="space-y-4 animate-in fade-in slide-in-from-top-2">
                    <div className="p-3 rounded-lg bg-yellow-500/10 border border-yellow-500/30 space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-[10px] font-bold text-yellow-500 uppercase tracking-widest">
                          Active Contract
                        </span>
                        <Badge
                          variant="outline"
                          className="text-[8px] border-yellow-500/50 text-yellow-500"
                        >
                          UNDER CONTRACT
                        </Badge>
                      </div>
                      <div className="font-bold text-sm text-foreground">
                        {activeContract.sector}
                      </div>
                      <div className="text-[10px] text-muted-foreground">
                        {activeContract.objective}
                      </div>
                      <div className="flex items-center gap-1 text-xs font-mono text-yellow-500 font-bold">
                        <Coins className="h-3 w-3" />
                        {activeContract.reward} PTS BOUNTY
                      </div>
                    </div>
                    <Button
                      className="w-full h-9 bg-yellow-500 text-yellow-950 hover:bg-yellow-600 font-bold text-xs"
                      onClick={handleCompleteContract}
                    >
                      FULFILL CONTRACT
                    </Button>
                    <Button
                      variant="ghost"
                      className="w-full h-8 text-[10px] text-muted-foreground hover:text-destructive"
                      onClick={() => setActiveContract(null)}
                    >
                      TERMINATE CONTRACT
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <p className="text-xs text-muted-foreground">
                      Shift your allegiance to other sectors to earn massive
                      Neural Point bounties by stabilizing their resonance.
                    </p>
                    <div className="grid gap-2">
                      {SECTORS.map((s) => (
                        <Button
                          key={s.name}
                          variant="outline"
                          size="sm"
                          className="w-full justify-between h-10 border-border/50 hover:border-yellow-500/50 group"
                          onClick={() =>
                            handleSignContract(
                              s.name,
                              2500,
                              `Reduce ${s.name} friction to < 5%`,
                            )
                          }
                        >
                          <div className="flex items-center gap-2">
                            <Flag className="h-3 w-3 text-muted-foreground group-hover:text-yellow-500" />
                            <span className="text-xs">{s.name}</span>
                          </div>
                          <div className="text-[10px] font-mono text-yellow-500 font-bold">
                            2500 PTS
                          </div>
                        </Button>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card
              className={cn(
                "bg-card/40 border-fuchsia-500/30 backdrop-blur-sm relative overflow-hidden transition-all duration-500",
                isSabotageActive &&
                  "border-fuchsia-500 shadow-[0_0_20px_rgba(217,70,239,0.2)]",
              )}
            >
              {isSabotageActive && (
                <div className="absolute inset-0 bg-fuchsia-500/10 animate-pulse pointer-events-none" />
              )}
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg text-fuchsia-400">
                  <Skull className="h-5 w-5" />
                  Sabotage Protocols
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-xs text-muted-foreground">
                  Deploy targeted neural interference to disrupt a rival
                  sector's sync and increase their friction.
                </p>
                {!isSabotageActive ? (
                  <div className="grid gap-2">
                    {SECTORS.map((s) => (
                      <Button
                        key={s.name}
                        variant="outline"
                        size="sm"
                        className="w-full justify-between h-10 border-border/50 hover:border-fuchsia-500/50 group"
                        onClick={() => handleSabotage(s.name)}
                      >
                        <div className="flex items-center gap-2">
                          <Crosshair className="h-3 w-3 text-muted-foreground group-hover:text-fuchsia-400" />
                          <span className="text-xs">Disrupt {s.name}</span>
                        </div>
                        <div className="text-[10px] font-mono text-fuchsia-400 font-bold">
                          COST: 1000 PTS
                        </div>
                      </Button>
                    ))}
                  </div>
                ) : (
                  <div className="p-3 rounded-lg bg-fuchsia-500/10 border border-fuchsia-500/30 space-y-2 animate-in fade-in zoom-in">
                    <div className="flex justify-between items-center">
                      <span className="text-[10px] font-bold text-fuchsia-400 uppercase tracking-widest">
                        Active Sabotage
                      </span>
                      <Badge
                        variant="outline"
                        className="text-[8px] border-fuchsia-500/50 text-fuchsia-400 animate-pulse"
                      >
                        DISRUPTING
                      </Badge>
                    </div>
                    <div className="font-bold text-sm text-foreground">
                      Target: {sabotageTarget}
                    </div>
                    <div className="text-[10px] text-muted-foreground">
                      Injecting cognitive friction...
                    </div>
                    <Progress
                      value={65}
                      className="h-1 bg-fuchsia-500/20 [&>div]:bg-fuchsia-500 animate-pulse"
                    />
                  </div>
                )}
              </CardContent>
            </Card>

            <Card
              className={cn(
                "bg-card/40 border-primary/30 backdrop-blur-sm relative overflow-hidden transition-all duration-500",
                isHotlineActive &&
                  "border-primary shadow-[0_0_20px_rgba(0,255,255,0.2)]",
              )}
            >
              {isHotlineActive && (
                <div className="absolute inset-0 bg-primary/5 animate-pulse pointer-events-none" />
              )}
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg text-primary">
                  <PhoneCall className="h-5 w-5" />
                  Diplomatic Hotline
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {!isHotlineActive ? (
                  <div className="space-y-4">
                    <p className="text-xs text-muted-foreground">
                      Establish direct communication with rival faction leaders
                      to coordinate global stability.
                    </p>
                    <div className="grid gap-2">
                      {SECTORS.filter(
                        (s) => s.faction !== "Aegis Vanguard",
                      ).map((s) => (
                        <Button
                          key={s.faction}
                          variant="outline"
                          size="sm"
                          className="w-full justify-between h-10 border-border/50 hover:border-primary/50 group"
                          onClick={() => handleHotlineConnect(s.faction)}
                        >
                          <div className="flex items-center gap-2">
                            <User className="h-3 w-3 text-muted-foreground group-hover:text-primary" />
                            <span className="text-xs">{s.faction} Command</span>
                          </div>
                          <Badge
                            variant="outline"
                            className="text-[8px] border-primary/30 text-primary"
                          >
                            CONNECT
                          </Badge>
                        </Button>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4 animate-in fade-in slide-in-from-top-2">
                    <div className="p-3 rounded-lg bg-primary/10 border border-primary/30 space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-[10px] font-bold text-primary uppercase tracking-widest">
                          Active Hotline
                        </span>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-4 w-4 text-muted-foreground hover:text-destructive"
                          onClick={() => setIsHotlineActive(false)}
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </div>
                      <div className="flex items-center gap-2">
                        <Avatar className="h-8 w-8 border border-primary/30">
                          <AvatarImage
                            src={`https://i.pravatar.cc/150?u=${activeNegotiation}`}
                          />
                          <AvatarFallback>
                            <User className="h-4 w-4" />
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-bold text-xs text-foreground">
                            {activeNegotiation} Leader
                          </div>
                          <div className="text-[10px] text-primary animate-pulse font-mono tracking-tighter">
                            SECURE_CHANNEL_ESTABLISHED
                          </div>
                        </div>
                      </div>
                      <div className="grid grid-cols-1 gap-2 pt-2">
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-8 text-[10px] font-bold uppercase tracking-wider border-primary/30 hover:bg-primary/10"
                          onClick={() => handleNegotiation("Ceasefire")}
                        >
                          Request Ceasefire
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-8 text-[10px] font-bold uppercase tracking-wider border-primary/30 hover:bg-primary/10"
                          onClick={() => handleNegotiation("Resource Exchange")}
                        >
                          Exchange Neural Points
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-8 text-[10px] font-bold uppercase tracking-wider border-primary/30 hover:bg-primary/10"
                          onClick={() => handleNegotiation("Joint Operation")}
                        >
                          Joint Satellite Deployment
                        </Button>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="bg-card/40 border-primary/30 backdrop-blur-sm relative overflow-hidden">
              {isTreatyActive && (
                <div className="absolute inset-0 bg-primary/5 animate-pulse pointer-events-none" />
              )}
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg text-primary">
                  <Shield className="h-5 w-5" />
                  Diplomatic Protocols
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-xs text-muted-foreground mb-4">
                  Establish a Peace Treaty to synchronize neural resonance and
                  suppress global friction for a sustained duration.
                </p>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full gap-2 font-bold tracking-widest border-primary/50 text-primary hover:bg-primary/10",
                    isTreatyActive && "animate-pulse",
                  )}
                  onClick={handlePeaceTreaty}
                  disabled={isTreatyActive || isOverrideActive}
                >
                  <Handshake className="h-4 w-4" />
                  {isTreatyActive
                    ? "TREATY IN EFFECT"
                    : "INITIATE PEACE TREATY"}
                </Button>
              </CardContent>
            </Card>

            <Card
              className={cn(
                "bg-card/40 border-destructive/30 backdrop-blur-sm relative overflow-hidden transition-all duration-500",
                isUnderAttack &&
                  "border-destructive shadow-[0_0_20px_rgba(255,0,0,0.3)] scale-[1.02]",
              )}
            >
              {isUnderAttack && (
                <div className="absolute inset-0 bg-destructive/5 animate-pulse pointer-events-none" />
              )}
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2 text-lg text-destructive">
                    <ShieldAlert
                      className={cn(
                        "h-5 w-5",
                        isUnderAttack && "animate-bounce",
                      )}
                    />
                    Defense Protocols
                  </CardTitle>
                  <div className="flex items-center gap-2">
                    <Badge
                      variant="outline"
                      className="bg-orange-500/10 text-orange-400 border-orange-500/30 gap-1"
                    >
                      <TrendingUp className="h-3 w-3" />
                      LVL {fortificationLevel}
                    </Badge>
                    {decoys > 0 && (
                      <Badge
                        variant="outline"
                        className="bg-cyan-500/10 text-cyan-400 border-cyan-500/30 gap-1 shadow-[0_0_10px_rgba(6,182,212,0.2)]"
                      >
                        <Shield className="h-3 w-3" />
                        {decoys} Decoys
                      </Badge>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-xs text-muted-foreground">
                  Monitor and neutralize incoming sabotage attempts. Each
                  fortification level increases passive defense by 2%.
                </p>
                {isUnderAttack ? (
                  <Button
                    variant="destructive"
                    className="w-full gap-2 font-bold animate-pulse"
                    onClick={handleCounterSabotage}
                  >
                    <ZapOff className="h-4 w-4" />
                    COUNTER-SABOTAGE
                  </Button>
                ) : (
                  <div className="space-y-3">
                    <div className="grid grid-cols-2 gap-2">
                      <Button
                        variant="outline"
                        className="gap-2 border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/10 text-[10px] h-9"
                        onClick={() => {
                          if (neuralPoints >= 500) {
                            setNeuralPoints((p) => p - 500);
                            setDecoys((p) => p + 1);
                            hapticFeedback([50, 30, 50]);
                            toast.success("Neural Decoy Deployed", {
                              description:
                                "Next incoming sabotage attempt will be automatically misdirected.",
                            });
                          } else {
                            hapticFeedback(100);
                            toast.error("Insufficient Points", {
                              description: "Requires 500 Neural Points.",
                            });
                          }
                        }}
                      >
                        <Shield className="h-3 w-3" />
                        DECOY (500)
                      </Button>
                      <Button
                        variant="outline"
                        className="gap-2 border-orange-500/30 text-orange-400 hover:bg-orange-500/10 text-[10px] h-9"
                        onClick={() => {
                          const cost = fortificationLevel * 1000;
                          if (neuralPoints >= cost) {
                            setNeuralPoints((p) => p - cost);
                            setFortificationLevel((p) => p + 1);
                            hapticFeedback([50, 30, 50, 30, 100]);
                            toast.success("Sector Fortified", {
                              description: `Defense integrity increased to Level ${fortificationLevel + 1}.`,
                            });
                          } else {
                            hapticFeedback(100);
                            toast.error("Insufficient Points", {
                              description: `Requires ${cost} Neural Points.`,
                            });
                          }
                        }}
                      >
                        <TrendingUp className="h-3 w-3" />
                        FORTIFY ({fortificationLevel * 1000})
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card
              className={cn(
                "bg-card/40 border-orange-500/30 backdrop-blur-sm relative overflow-hidden transition-all duration-500",
                isOverclockActive &&
                  "border-orange-500 shadow-[0_0_20px_rgba(249,115,22,0.3)] scale-[1.02]",
              )}
            >
              {isOverclockActive && (
                <div className="absolute inset-0 bg-orange-500/10 animate-pulse pointer-events-none" />
              )}
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg text-orange-500">
                  <Cpu className="h-5 w-5" />
                  Tactical Overclock
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-xs text-muted-foreground mb-4">
                  Temporarily triple all faction biometric buffs at the cost of
                  a massive 20% spike in global friction.
                </p>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full gap-2 font-bold tracking-widest border-orange-500/50 text-orange-500 hover:bg-orange-500/10",
                    isOverclockActive && "animate-pulse",
                  )}
                  onClick={handleOverclock}
                  disabled={isOverclockActive || isTreatyActive}
                >
                  <Zap className="h-4 w-4" />
                  {isOverclockActive ? "OVERCLOCK ACTIVE" : "ENGAGE OVERCLOCK"}
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-card/40 border-destructive/30 backdrop-blur-sm relative overflow-hidden">
              {isOverrideActive && (
                <div className="absolute inset-0 bg-destructive/10 animate-pulse pointer-events-none" />
              )}
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg text-destructive">
                  <AlertTriangle className="h-5 w-5" />
                  Emergency Protocols
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-xs text-muted-foreground mb-4">
                  Initiate global override to temporarily suppress neural
                  friction across all sectors. Use only in critical network
                  failure scenarios.
                </p>
                <Button
                  variant="destructive"
                  className={cn(
                    "w-full gap-2 font-bold tracking-widest",
                    isOverrideActive && "animate-pulse",
                  )}
                  onClick={handleOverride}
                  disabled={isOverrideActive || isTreatyActive}
                >
                  <Zap className="h-4 w-4" />
                  {isOverrideActive
                    ? "OVERRIDE IN PROGRESS"
                    : "INITIATE GLOBAL OVERRIDE"}
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      {/* Biometric Signature Verification Overlay */}
      {isBiometricVerifying && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center bg-background/95 backdrop-blur-xl animate-in fade-in duration-300">
          <div className="max-w-md w-full p-8 space-y-10 text-center">
            <div className="space-y-2">
              <Badge
                variant="outline"
                className="bg-primary/10 text-primary border-primary/20 uppercase tracking-widest text-[10px] animate-pulse"
              >
                Security Clearance Required
              </Badge>
              <h2 className="text-3xl font-bold tracking-tighter">
                Biometric Signature
              </h2>
              <p className="text-sm text-muted-foreground italic">
                Maintain contact to verify neural identity.
              </p>
            </div>

            <div className="relative flex items-center justify-center py-10">
              <div className="relative h-48 w-48 flex items-center justify-center">
                {/* Scanning Animation */}
                <div
                  className={cn(
                    "absolute inset-0 rounded-full border-4 border-primary/20 transition-all duration-500",
                    biometricProgress > 0 &&
                      "border-primary/50 shadow-[0_0_30px_rgba(0,255,255,0.2)]",
                  )}
                />
                <div
                  className="absolute inset-0 rounded-full border-4 border-primary border-t-transparent animate-[spin_2s_linear_infinite]"
                  style={{ opacity: biometricProgress > 0 ? 1 : 0 }}
                />

                {/* Fingerprint / Retina Icon */}
                <div
                  className={cn(
                    "h-32 w-32 rounded-full bg-primary/10 flex items-center justify-center transition-all duration-500",
                    biometricProgress > 0
                      ? "scale-110 bg-primary/20"
                      : "scale-100",
                  )}
                >
                  <Fingerprint
                    className={cn(
                      "h-16 w-16 transition-all duration-500",
                      biometricProgress > 0
                        ? "text-primary animate-pulse"
                        : "text-primary/40",
                    )}
                  />
                </div>

                {/* Progress Ring */}
                <svg className="absolute inset-0 h-full w-full -rotate-90 pointer-events-none">
                  <circle
                    cx="96"
                    cy="96"
                    r="92"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="4"
                    className="text-primary/10"
                  />
                  <circle
                    cx="96"
                    cy="96"
                    r="92"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="4"
                    strokeDasharray={578}
                    strokeDashoffset={578 - (578 * biometricProgress) / 100}
                    className="text-primary transition-all duration-75"
                  />
                </svg>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex justify-between text-[10px] text-muted-foreground uppercase tracking-widest px-1">
                <span>Identity Verification</span>
                <span className="text-primary">{biometricProgress}%</span>
              </div>
              <Progress value={biometricProgress} className="h-1.5" />
            </div>

            <Button
              variant="outline"
              className="w-full border-border/50 text-muted-foreground hover:text-destructive"
              onClick={() => {
                setIsBiometricVerifying(false);
                setBiometricProgress(0);
                setPendingAction(null);
                hapticFeedback(10);
              }}
            >
              CANCEL ACCESS
            </Button>
          </div>
        </div>
      )}

      {/* Diplomatic Envoy Mini-game Overlay */}
      {isEnvoyActive && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-background/95 backdrop-blur-xl animate-in fade-in zoom-in duration-300">
          <div className="max-w-md w-full p-8 space-y-8 text-center">
            <div className="space-y-2">
              <Badge
                variant="outline"
                className="bg-primary/10 text-primary border-primary/20 uppercase tracking-widest text-[10px]"
              >
                DIPLOMATIC ENVOY
              </Badge>
              <h2 className="text-3xl font-bold tracking-tighter">
                Secure Resonance
              </h2>
              <p className="text-sm text-muted-foreground italic">
                Align the diplomatic frequency to secure the Peace Treaty.
              </p>
            </div>

            <div className="relative h-48 bg-secondary/30 rounded-xl border border-border/50 overflow-hidden flex items-center justify-center">
              {/* Target Zone */}
              <div
                className="absolute h-full w-8 bg-primary/20 border-x border-primary/40 animate-pulse"
                style={{
                  left: `${envoyTarget}%`,
                  transform: "translateX(-50%)",
                }}
              />

              {/* Moving Frequency */}
              <div className="w-full px-8 space-y-4">
                <div className="relative h-12 flex items-center">
                  <div
                    className={cn(
                      "absolute h-12 w-1 rounded-full shadow-[0_0_15px_rgba(0,255,255,0.8)] transition-all duration-75",
                      envoySuccess ? "bg-green-400" : "bg-primary",
                    )}
                    style={{
                      left: `${envoyProgress}%`,
                      transform: "translateX(-50%)",
                    }}
                  />
                </div>
                <Slider
                  value={[envoyProgress]}
                  onValueChange={(v) => setEnvoyProgress(v[0])}
                  max={100}
                  step={1}
                  className="[&_[role=slider]]:h-6 [&_[role=slider]]:w-6"
                />
              </div>

              {envoySuccess && (
                <div className="absolute inset-0 bg-green-500/10 flex items-center justify-center animate-in fade-in">
                  <CheckCircle2 className="h-24 w-24 text-green-400 animate-bounce" />
                </div>
              )}
            </div>

            <div className="flex gap-4">
              <Button
                variant="outline"
                className="flex-1 border-border/50"
                onClick={() => setIsEnvoyActive(false)}
                disabled={envoySuccess}
              >
                ABORT
              </Button>
              <Button
                className="flex-1 font-bold"
                onClick={completeEnvoyCalibration}
                disabled={envoySuccess}
              >
                CALIBRATE
              </Button>
            </div>

            <div className="flex justify-center gap-8 text-[10px] text-muted-foreground uppercase tracking-widest">
              <div className="flex items-center gap-1">
                <Activity className="h-3 w-3" />
                Sync: {Math.max(0, 100 - Math.abs(envoyProgress - envoyTarget))}
                %
              </div>
              <div className="flex items-center gap-1">
                <Zap className="h-3 w-3" />
                Resonance: {envoySuccess ? "Locked" : "Scanning"}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Counter-Sabotage Mini-game Overlay */}
      {isCounterSabotageActive && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-background/95 backdrop-blur-xl animate-in fade-in zoom-in duration-300">
          <div className="max-w-md w-full p-8 space-y-8 text-center">
            <div className="space-y-2">
              <Badge
                variant="outline"
                className="bg-destructive/10 text-destructive border-destructive/20 uppercase tracking-widest text-[10px]"
              >
                NEURAL DE-SCRAMBLER
              </Badge>
              <h2 className="text-3xl font-bold tracking-tighter">
                Purge Interference
              </h2>
              <p className="text-sm text-muted-foreground italic">
                Filter out cognitive noise by matching the counter-frequency.
              </p>
            </div>

            <div className="relative h-48 bg-destructive/10 rounded-xl border border-destructive/30 overflow-hidden flex items-center justify-center">
              {/* Static Interference Background */}
              <div className="absolute inset-0 opacity-20 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] animate-pulse" />

              {/* Target Zone */}
              <div
                className="absolute h-full w-10 bg-destructive/30 border-x border-destructive/50"
                style={{
                  left: `${counterTarget}%`,
                  transform: "translateX(-50%)",
                }}
              />

              {/* Moving Frequency */}
              <div className="w-full px-8 space-y-4 relative z-10">
                <div className="relative h-12 flex items-center">
                  <div
                    className="absolute h-16 w-2 bg-destructive shadow-[0_0_20px_rgba(255,0,0,0.8)] transition-all duration-75"
                    style={{
                      left: `${counterProgress}%`,
                      transform: "translateX(-50%)",
                    }}
                  />
                </div>
                <Slider
                  value={[counterProgress]}
                  onValueChange={(v) => {
                    setCounterProgress(v[0]);
                    hapticFeedback(5);
                  }}
                  max={100}
                  step={1}
                  className="[&_[role=slider]]:h-8 [&_[role=slider]]:w-8 [&_[role=slider]]:bg-destructive"
                />
              </div>
            </div>

            <div className="flex gap-4">
              <Button
                variant="outline"
                className="flex-1 border-border/50"
                onClick={() => setIsCounterSabotageActive(false)}
              >
                ABORT DEFENSE
              </Button>
              <Button
                variant="destructive"
                className="flex-1 font-bold shadow-[0_0_20px_rgba(255,0,0,0.3)]"
                onClick={completeCounterSabotage}
              >
                PURGE NOISE
              </Button>
            </div>

            <div className="flex justify-center gap-8 text-[10px] text-muted-foreground uppercase tracking-widest">
              <div className="flex items-center gap-1">
                <ZapOff className="h-3 w-3" />
                Interference:{" "}
                {Math.max(0, 100 - Math.abs(counterProgress - counterTarget))}%
              </div>
              <div className="flex items-center gap-1">
                <RefreshCcw className="h-3 w-3 animate-spin" />
                Filtering...
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
