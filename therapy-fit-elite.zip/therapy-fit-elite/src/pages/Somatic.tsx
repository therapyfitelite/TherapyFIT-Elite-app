import CNSWaveformVisualizer from "@/components/CNSWaveformVisualizer";
import { useState, useEffect, useRef, useCallback } from "react";
import { Play, Pause, RotateCcw, Wind } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Slider } from "@/components/ui/slider";
import {
  Moon,
  Droplets,
  Activity,
  ChevronLeft,
  AlertTriangle,
  Link2,
  Wifi,
  WifiOff,
  CheckCircle2,
  Bluetooth,
  Zap,
  Bell,
  BellOff,
  Clock,
  Timer,
  ArrowUpRight,
  ArrowDownRight,
  ArrowRight,
  Brain,
  Heart,
  Dumbbell,
  Headphones,
  Camera,
  Scan,
} from "lucide-react";
import {
  cn,
  hapticFeedback,
  playNodeTapSound,
  playSuccessChime,
} from "@/lib/utils";
import { useNavigate } from "react-router-dom";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import NeuralBackground from "@/components/NeuralBackground";
import {
  AreaChart,
  Area,
  XAxis,
  Tooltip as RechartsTooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  YAxis,
  CartesianGrid,
  Legend,
  ScatterChart,
  Scatter,
  ZAxis,
} from "recharts";

const BoxBreathingModal = ({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) => {
  const [isActive, setIsActive] = useState(false);
  const [phase, setPhase] = useState<"inhale" | "hold1" | "exhale" | "hold2">(
    "inhale",
  );
  const [timeLeft, setTimeLeft] = useState(4);
  const [cycles, setCycles] = useState(0);

  useEffect(() => {
    if (!isActive) {
      setPhase("inhale");
      setTimeLeft(4);
      return;
    }

    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          if (phase === "inhale") {
            setPhase("hold1");
            return 4;
          } else if (phase === "hold1") {
            setPhase("exhale");
            return 4;
          } else if (phase === "exhale") {
            setPhase("hold2");
            return 4;
          } else {
            setCycles((c) => c + 1);
            setPhase("inhale");
            return 4;
          }
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isActive, phase]);

  useEffect(() => {
    if (isActive) {
      if (timeLeft === 4) hapticFeedback([30, 50, 30]);
    }
  }, [phase, timeLeft, isActive]);

  const getScale = () => {
    if (!isActive) return 1;
    if (phase === "inhale") return 1 + ((4 - timeLeft) / 4) * 0.5;
    if (phase === "hold1") return 1.5;
    if (phase === "exhale") return 1.5 - ((4 - timeLeft) / 4) * 0.5;
    return 1;
  };

  const getPhaseText = () => {
    switch (phase) {
      case "inhale":
        return "Inhale";
      case "hold1":
        return "Hold";
      case "exhale":
        return "Exhale";
      case "hold2":
        return "Hold";
    }
  };

  return (
    <Dialog
      open={open}
      onOpenChange={(val) => {
        onOpenChange(val);
        if (!val) setIsActive(false);
      }}
    >
      <DialogContent className="sm:max-w-md bg-[#111] border-purple-500/30 text-foreground overflow-hidden">
        {isActive && (
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-purple-500/10 via-transparent to-transparent animate-pulse pointer-events-none" />
        )}
        <DialogHeader>
          <DialogTitle className="text-sm uppercase tracking-widest text-purple-400 flex items-center gap-2">
            <Wind className="w-4 h-4" /> Stress Recovery Protocol
          </DialogTitle>
        </DialogHeader>

        <div className="flex flex-col items-center justify-center py-8 relative z-10">
          <div className="relative w-48 h-48 flex items-center justify-center mb-8">
            <div className="absolute inset-0 rounded-full border border-purple-500/20" />
            <div className="absolute inset-4 rounded-full border border-purple-500/10" />

            <div
              className={cn(
                "w-24 h-24 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 shadow-[0_0_40px_rgba(168,85,247,0.3)] transition-transform duration-1000 ease-linear flex items-center justify-center",
                isActive && "animate-pulse",
              )}
              style={{ transform: `scale(${getScale()})` }}
            >
              <Wind className="h-8 w-8 text-white opacity-50" />
            </div>

            {isActive && (
              <div
                className="absolute inset-0 rounded-full border-2 border-purple-500/40 animate-ping"
                style={{
                  animationDuration: "4s",
                  transform: `scale(${getScale()})`,
                }}
              />
            )}

            <div className="absolute -bottom-6 text-center w-full">
              <div className="text-3xl font-bold tracking-tighter tabular-nums text-white drop-shadow-[0_0_15px_rgba(168,85,247,0.5)]">
                {isActive ? timeLeft : "--"}
              </div>
              <div className="text-[10px] font-bold text-purple-400 uppercase tracking-[0.2em] animate-pulse mt-1">
                {isActive ? getPhaseText() : "Ready"}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 w-full text-center mb-6">
            <div className="bg-white/5 p-2 rounded-lg border border-white/10">
              <div className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest mb-1">
                Cycles
              </div>
              <div className="text-lg font-bold text-purple-400">{cycles}</div>
            </div>
            <div className="bg-white/5 p-2 rounded-lg border border-white/10">
              <div className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest mb-1">
                Pattern
              </div>
              <div className="text-lg font-bold text-purple-400">4-4-4-4</div>
            </div>
          </div>

          <div className="flex items-center gap-4 w-full">
            <Button
              variant="outline"
              size="icon"
              className="h-12 w-12 rounded-xl border-purple-500/30 hover:bg-purple-500/20 hover:text-purple-400"
              onClick={() => {
                hapticFeedback(50);
                setIsActive(false);
                setPhase("inhale");
                setTimeLeft(4);
                setCycles(0);
              }}
            >
              <RotateCcw className="h-5 w-5" />
            </Button>
            <Button
              className={cn(
                "flex-1 h-12 rounded-xl text-sm font-bold shadow-[0_0_20px_rgba(168,85,247,0.3)] transition-all uppercase tracking-widest",
                isActive
                  ? "bg-purple-500/20 text-purple-400 hover:bg-purple-500/30 border border-purple-500/50"
                  : "bg-purple-500 text-white hover:bg-purple-600",
              )}
              onClick={() => {
                hapticFeedback(isActive ? 50 : [50, 30, 50]);
                setIsActive(!isActive);
              }}
            >
              {isActive ? (
                <div className="flex items-center gap-2">
                  <Pause className="h-4 w-4" /> Pause
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <Play className="h-4 w-4 fill-current" /> Start Sync
                </div>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

const readinessData = [
  { day: "Mon", score: 82 },
  { day: "Tue", score: 78 },
  { day: "Wed", score: 85 },
  { day: "Thu", score: 91 },
  { day: "Fri", score: 74 },
  { day: "Sat", score: 88 },
  { day: "Sun", score: 94 },
];

const muscleGroups = [
  "Back",
  "Arm",
  "Shoulder",
  "Abs",
  "Chest",
  "Leg",
  "Glutes",
  "Full body",
];

const anomalyZones: Record<
  string,
  {
    top: string;
    left: string;
    width: string;
    height: string;
    color: string;
    label: string;
    status: string;
    impact: string;
  }
> = {
  HRV: {
    top: "30%",
    left: "52%",
    width: "12%",
    height: "12%",
    color: "rgba(234, 88, 12, 0.8)",
    label: "HRV Strain",
    status: "Critical",
    impact: "-20% Output. Recovery needed.",
  },
  CNS: {
    top: "15%",
    left: "50%",
    width: "14%",
    height: "14%",
    color: "rgba(220, 38, 38, 0.8)",
    label: "CNS Fatigue",
    status: "Warning",
    impact: "High Injury Risk. Reflexes down.",
  },
  Vocal: {
    top: "22%",
    left: "50%",
    width: "10%",
    height: "8%",
    color: "rgba(234, 179, 8, 0.8)",
    label: "Vocal Stress",
    status: "Elevated",
    impact: "Cognitive Lag Detected.",
  },
  Stress_Cognitive: {
    top: "12%",
    left: "50%",
    width: "18%",
    height: "18%",
    color: "rgba(168, 85, 247, 0.8)",
    label: "Cognitive Overload",
    status: "Critical",
    impact: "Pre-frontal cortex fatigue. Brain fog.",
  },
  Stress_Emotional: {
    top: "30%",
    left: "50%",
    width: "22%",
    height: "22%",
    color: "rgba(236, 72, 153, 0.8)",
    label: "Emotional Strain",
    status: "Elevated",
    impact: "Heart-rate variability suppression.",
  },
  Stress_Physical: {
    top: "25%",
    left: "50%",
    width: "40%",
    height: "15%",
    color: "rgba(239, 68, 68, 0.8)",
    label: "Physical Tension",
    status: "Warning",
    impact: "Shoulder/neck muscle constriction.",
  },
  Gut_Microbiome: {
    top: "42%",
    left: "50%",
    width: "16%",
    height: "16%",
    color: "rgba(34, 197, 94, 0.8)",
    label: "Gut Inflammation",
    status: "Warning",
    impact: "Serotonin production reduced.",
  },
  Joint_Knee: {
    top: "75%",
    left: "40%",
    width: "10%",
    height: "10%",
    color: "rgba(59, 130, 246, 0.8)",
    label: "Joint Inflammation",
    status: "Elevated",
    impact: "Mobility restriction.",
  },
  Lower_Back: {
    top: "48%",
    left: "50%",
    width: "18%",
    height: "12%",
    color: "rgba(249, 115, 22, 0.8)",
    label: "Lumbar Strain",
    status: "Critical",
    impact: "Core instability. Postural decay.",
  },
};

const muscleZones: Record<
  string,
  { top: string; left: string; width: string; height: string }[]
> = {
  Shoulder: [
    { top: "22%", left: "35%", width: "15%", height: "10%" },
    { top: "22%", left: "65%", width: "15%", height: "10%" },
  ],
  Chest: [{ top: "28%", left: "50%", width: "25%", height: "12%" }],
  Abs: [{ top: "40%", left: "50%", width: "18%", height: "18%" }],
  Arm: [
    { top: "35%", left: "28%", width: "12%", height: "25%" },
    { top: "35%", left: "72%", width: "12%", height: "25%" },
  ],
  Leg: [
    { top: "65%", left: "38%", width: "15%", height: "35%" },
    { top: "65%", left: "62%", width: "15%", height: "35%" },
  ],
  Back: [{ top: "32%", left: "50%", width: "30%", height: "25%" }],
  Glutes: [{ top: "52%", left: "50%", width: "25%", height: "12%" }],
  "Full body": [{ top: "45%", left: "50%", width: "60%", height: "80%" }],
};

export default function Somatic() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("somatic");
  const [selectedMuscles, setSelectedMuscles] = useState<string[]>([]);
  const [hydration, setHydration] = useState(() => {
    const saved = localStorage.getItem("tf_hydration");
    return saved ? parseInt(saved) : 40;
  });

  useEffect(() => {
    localStorage.setItem("tf_hydration", hydration.toString());
  }, [hydration]);
  const [activeAnomalies, setActiveAnomalies] = useState<string[]>([
    "CNS",
    "HRV",
  ]);
  const [activeProtocol, setActiveProtocol] = useState<string | null>(null);
  const [protocolProgress, setProtocolProgress] = useState(0);
  const [isSyncing, setIsSyncing] = useState(false);
  const [bioLinks, setBioLinks] = useState<Record<string, boolean>>({
    appleHealth: false,
    hydroBottle: false,
    whoop: false,
  });
  const [syncingLink, setSyncingLink] = useState<string | null>(null);
  const [predictiveAlert, setPredictiveAlert] = useState<{
    label: string;
    time: string;
  } | null>({ label: "Vocal Stress", time: "45m" });
  const [protocolHistory, setProtocolHistory] = useState<
    {
      id: string;
      label: string;
      timestamp: Date;
      risk: number;
      predictedReturn: string;
      triggers: string[];
    }[]
  >([
    {
      id: "1",
      label: "Vocal Stress",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2),
      risk: 78,
      predictedReturn: "4h 15m",
      triggers: ["Poor Sleep", "High Caffeine"],
    },
  ]);

  // Stress Logging State
  const [stressModalOpen, setStressModalOpen] = useState(false);
  const [tempStressLevel, setTempStressLevel] = useState([5]);
  const [tempStressType, setTempStressType] = useState("Stress_Cognitive");
  const [stressLogged, setStressLogged] = useState(false);
  const [boxBreathingModalOpen, setBoxBreathingModalOpen] = useState(false);
  const [playingRelease, setPlayingRelease] = useState<string | null>(null);
  const [releaseProgress, setReleaseProgress] = useState(0);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (playingRelease) {
      interval = setInterval(() => {
        setReleaseProgress((prev) => {
          if (prev >= 100) {
            setPlayingRelease(null);
            return 0;
          }
          return prev + 100 / 300; // 5 mins
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [playingRelease]);

  const handleLogStress = () => {
    setStressLogged(true);
    setStressModalOpen(false);
    hapticFeedback([20, 50, 20]);

    // Add stress anomaly to active anomalies if not present
    if (!activeAnomalies.includes(tempStressType)) {
      setActiveAnomalies((prev) => [
        ...prev.filter((a) => !a.startsWith("Stress_")),
        tempStressType,
      ]);
    }
  };

  // Hydration Notification Scheduler
  const [hydrationAlertsEnabled, setHydrationAlertsEnabled] = useState<boolean>(
    () => {
      return localStorage.getItem("tf_hydration_alerts") !== "false";
    },
  );
  const [lastWaterLog, setLastWaterLog] = useState<number>(() => Date.now());
  const [nextReminderIn, setNextReminderIn] = useState<number>(45 * 60);
  const [hydrationAlertFired, setHydrationAlertFired] = useState(false);
  const notifPermission = useRef<NotificationPermission>("default");

  // Request notification permission on mount
  useEffect(() => {
    if ("Notification" in window) {
      notifPermission.current = Notification.permission;
      if (Notification.permission === "default") {
        Notification.requestPermission().then((p) => {
          notifPermission.current = p;
        });
      }
    }
  }, []);

  // Countdown timer — fires alert after 45 min without a water log
  useEffect(() => {
    if (!hydrationAlertsEnabled) {
      setNextReminderIn(45 * 60);
      return;
    }
    const tick = setInterval(() => {
      const elapsed = Math.floor((Date.now() - lastWaterLog) / 1000);
      const remaining = Math.max(0, 45 * 60 - elapsed);
      setNextReminderIn(remaining);
      if (remaining === 0 && !hydrationAlertFired) {
        setHydrationAlertFired(true);
        hapticFeedback([20, 40, 20]);
        if ("Notification" in window && notifPermission.current === "granted") {
          new Notification("TherapyFIT Elite — Hydration Alert", {
            body: "You haven't logged water in 45 minutes. Drink 250ml now to stay on track.",
            icon: "/favicon.svg",
            tag: "hydration-reminder",
          });
        }
      }
    }, 1000);
    return () => clearInterval(tick);
  }, [hydrationAlertsEnabled, lastWaterLog, hydrationAlertFired]);

  const toggleHydrationAlerts = useCallback(() => {
    const next = !hydrationAlertsEnabled;
    setHydrationAlertsEnabled(next);
    localStorage.setItem("tf_hydration_alerts", String(next));
    if (
      next &&
      "Notification" in window &&
      Notification.permission === "default"
    ) {
      Notification.requestPermission().then((p) => {
        notifPermission.current = p;
      });
    }
  }, [hydrationAlertsEnabled]);

  const formatCountdown = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s.toString().padStart(2, "0")}`;
  };

  // Daily Summary Scheduler
  const [dailySummaryEnabled, setDailySummaryEnabled] = useState<boolean>(
    () => {
      return localStorage.getItem("tf_daily_summary") !== "false";
    },
  );
  const [summaryFiredToday, setSummaryFiredToday] = useState(false);

  useEffect(() => {
    if (!dailySummaryEnabled) return;
    const tick = setInterval(() => {
      const now = new Date();
      // Fire at 20:00 (8 PM) local time
      if (
        now.getHours() === 20 &&
        now.getMinutes() === 0 &&
        !summaryFiredToday
      ) {
        setSummaryFiredToday(true);
        if ("Notification" in window && notifPermission.current === "granted") {
          new Notification("TherapyFIT Elite — Daily Hydration Summary", {
            body: `You logged ${Math.floor(hydration * 2.5)}ml out of your 2500ml target today.`,
            icon: "/favicon.svg",
            tag: "hydration-summary",
          });
        }
      }
      // Reset at midnight
      if (now.getHours() === 0 && now.getMinutes() === 0) {
        setSummaryFiredToday(false);
      }
    }, 60000); // Check every minute
    return () => clearInterval(tick);
  }, [dailySummaryEnabled, summaryFiredToday, hydration]);

  // Fasting Protocol State
  const [fastingStartTime, setFastingStartTime] = useState<number | null>(
    () => {
      const saved = localStorage.getItem("tf_fasting_start");
      return saved ? parseInt(saved) : null;
    },
  );
  const [fastingElapsed, setFastingElapsed] = useState(0);

  useEffect(() => {
    if (!fastingStartTime) return;
    const tick = setInterval(() => {
      setFastingElapsed(Date.now() - fastingStartTime);
    }, 1000);
    // initial set
    setFastingElapsed(Date.now() - fastingStartTime);
    return () => clearInterval(tick);
  }, [fastingStartTime]);

  const toggleFasting = () => {
    hapticFeedback(10);
    if (fastingStartTime) {
      setFastingStartTime(null);
      localStorage.removeItem("tf_fasting_start");
      setFastingElapsed(0);
    } else {
      const now = Date.now();
      setFastingStartTime(now);
      localStorage.setItem("tf_fasting_start", now.toString());
    }
  };

  const getFastingPhase = (hours: number) => {
    if (hours < 12)
      return {
        label: "Anabolic / Digestion",
        color: "text-blue-400",
        bg: "bg-blue-500/10",
        border: "border-blue-500/30",
        fill: "bg-blue-400",
      };
    if (hours < 16)
      return {
        label: "Catabolic Transition",
        color: "text-orange-400",
        bg: "bg-orange-500/10",
        border: "border-orange-500/30",
        fill: "bg-orange-400",
      };
    if (hours < 24)
      return {
        label: "Deep Ketosis",
        color: "text-purple-400",
        bg: "bg-purple-500/10",
        border: "border-purple-500/30",
        fill: "bg-purple-400",
      };
    return {
      label: "Autophagy",
      color: "text-primary",
      bg: "bg-primary/10",
      border: "border-primary/30",
      fill: "bg-primary",
    };
  };

  const formatFastingTime = (ms: number) => {
    const totalSeconds = Math.floor(ms / 1000);
    const h = Math.floor(totalSeconds / 3600);
    const m = Math.floor((totalSeconds % 3600) / 60);
    const s = totalSeconds % 60;
    return `${h.toString().padStart(2, "0")}:${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
  };

  const fastingHours = fastingElapsed / (1000 * 60 * 60);
  const fastingPhase = getFastingPhase(fastingHours);

  // CGM State
  const [cgmSynced, setCgmSynced] = useState(false);
  const [glucoseLevel, setGlucoseLevel] = useState(88);
  const [glucoseTrend, setGlucoseTrend] = useState<"up" | "down" | "stable">(
    "stable",
  );

  // Ketone State
  const [ketoneLevel, setKetoneLevel] = useState<number | null>(null);

  useEffect(() => {
    if (!cgmSynced) return;
    const interval = setInterval(() => {
      setGlucoseLevel((prev) => {
        const change = Math.floor(Math.random() * 5) - 2;
        const newVal = Math.max(65, Math.min(120, prev + change));
        if (newVal > prev) setGlucoseTrend("up");
        else if (newVal < prev) setGlucoseTrend("down");
        else setGlucoseTrend("stable");
        return newVal;
      });
    }, 5000);
    return () => clearInterval(interval);
  }, [cgmSynced]);

  const getKetoneColor = (level: number) => {
    if (level < 0.5) return "text-muted-foreground bg-white/5 border-white/10";
    if (level < 1.5) return "text-primary bg-primary/10 border-primary/20";
    if (level < 3.0)
      return "text-purple-400 bg-purple-400/10 border-purple-400/20";
    return "text-orange-400 bg-orange-400/10 border-orange-400/20";
  };

  const getKetoneLabel = (level: number) => {
    if (level < 0.5) return "No Ketosis";
    if (level < 1.5) return "Light Ketosis";
    if (level < 3.0) return "Deep Ketosis";
    return "Starvation Ketosis";
  };

  // Body Comp State
  const [scaleConnected, setScaleConnected] = useState(false);
  const [scaleSyncing, setScaleSyncing] = useState(false);
  const [bodyCompData, setBodyCompData] = useState<{
    weight: number;
    bodyFat: number;
    muscleMass: number;
    waterWeight: number;
    boneDensity: number;
    visceralFat: number;
    symmetry: {
      left: number;
      right: number;
      score: number;
      dominant: string;
      breakdown: {
        arms: { left: number; right: number };
        legs: { left: number; right: number };
        trunk: { left: number; right: number };
      };
    };
  } | null>(null);

  const connectScale = () => {
    hapticFeedback([10, 30]);
    setScaleSyncing(true);
    setTimeout(() => {
      setScaleSyncing(false);
      setScaleConnected(true);
      setBodyCompData({
        weight: 182.4,
        bodyFat: 14.2,
        muscleMass: 88.5,
        waterWeight: 62.1,
        boneDensity: 8.4,
        visceralFat: 6,
        symmetry: {
          left: 48.2,
          right: 51.8,
          score: 96.4,
          dominant: "Right",
          breakdown: {
            arms: { left: 47.5, right: 52.5 },
            legs: { left: 49.1, right: 50.9 },
            trunk: { left: 48.0, right: 52.0 },
          },
        },
      });
      hapticFeedback([20, 50, 20]);
    }, 2500);
  };

  // Posture State
  const [postureScanning, setPostureScanning] = useState(false);
  const [showCorrection, setShowCorrection] = useState(false);
  const [postureData, setPostureData] = useState<{
    head: {
      tilt: number;
      direction: string;
      status: "optimal" | "warning" | "critical";
    };
    shoulders: {
      tilt: number;
      direction: string;
      status: "optimal" | "warning" | "critical";
    };
    hips: {
      tilt: number;
      direction: string;
      status: "optimal" | "warning" | "critical";
    };
    score: number;
  } | null>(null);

  const startPostureScan = () => {
    hapticFeedback([10, 30]);
    setPostureScanning(true);
    setTimeout(() => {
      setPostureScanning(false);
      setPostureData({
        head: { tilt: 3.2, direction: "Right", status: "warning" },
        shoulders: { tilt: 1.5, direction: "Left", status: "optimal" },
        hips: { tilt: 4.1, direction: "Right", status: "critical" },
        score: 82,
      });
      hapticFeedback([20, 50, 20]);
    }, 3000);
  };

  const toggleMuscle = (muscle: string) => {
    hapticFeedback(10);
    if (muscle === "Full body") {
      if (selectedMuscles.includes("Full body")) {
        setSelectedMuscles([]);
      } else {
        setSelectedMuscles([...muscleGroups]);
      }
      return;
    }

    setSelectedMuscles((prev) =>
      prev.includes(muscle)
        ? prev.filter((m) => m !== muscle && m !== "Full body")
        : [...prev, muscle],
    );
  };

  const addWater = () => {
    hapticFeedback(10);
    setHydration((prev) => Math.min(100, prev + 10));
    // Reset the 45-min hydration reminder countdown
    setLastWaterLog(Date.now());
    setNextReminderIn(45 * 60);
    setHydrationAlertFired(false);
  };

  const connectBioLink = (key: string) => {
    if (bioLinks[key]) return;
    hapticFeedback(10);
    setSyncingLink(key);
    setTimeout(() => {
      setBioLinks((prev) => ({ ...prev, [key]: true }));
      setSyncingLink(null);
      if (key === "appleHealth")
        setHydration((prev) => Math.min(100, prev + 15));
      if (key === "hydroBottle")
        setHydration((prev) => Math.min(100, prev + 25));
      // Bio-linked device auto-log also resets the reminder
      setLastWaterLog(Date.now());
      setNextReminderIn(45 * 60);
      setHydrationAlertFired(false);
      hapticFeedback([10, 30, 10]);
    }, 1800);
  };

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (activeProtocol) {
      interval = setInterval(() => {
        setProtocolProgress((prev) => {
          let newProgress = prev;
          if (isSyncing) {
            newProgress = Math.min(100, prev + 2);
            if (newProgress % 10 === 0) hapticFeedback(5);
          } else {
            newProgress = Math.max(0, prev - 1);
          }

          if (newProgress === 100) {
            setActiveAnomalies((current) =>
              current.filter((a) => a !== activeProtocol),
            );
            if (activeProtocol) {
              const possibleTriggers = [
                "Heavy Lifting",
                "Poor Sleep",
                "Dehydration",
                "High Caffeine",
                "Late Night Screen",
                "Missed Recovery",
              ];
              const randomTrigger1 =
                possibleTriggers[
                  Math.floor(Math.random() * possibleTriggers.length)
                ];
              const randomTrigger2 =
                possibleTriggers[
                  Math.floor(Math.random() * possibleTriggers.length)
                ];

              setProtocolHistory((prev) => [
                {
                  id: Math.random().toString(36).substr(2, 9),
                  label: anomalyZones[activeProtocol]?.label || activeProtocol,
                  timestamp: new Date(),
                  risk: Math.floor(Math.random() * 40) + 40,
                  predictedReturn: `${Math.floor(Math.random() * 8) + 2}h ${Math.floor(Math.random() * 60)}m`,
                  triggers: Array.from(
                    new Set([randomTrigger1, randomTrigger2]),
                  ),
                },
                ...prev,
              ]);
            }
            setActiveProtocol(null);
            setProtocolProgress(0);
            setIsSyncing(false);
            hapticFeedback([20, 50, 20]);
          }
          return newProgress;
        });
      }, 50);
    }
    return () => clearInterval(interval);
  }, [activeProtocol, isSyncing]);

  return (
    <div className="flex flex-1 flex-col bg-[#050505] text-foreground relative min-h-full">
      {/* Background */}
      <div className="absolute inset-0 pointer-events-none z-0">
        <NeuralBackground />
        <div className="absolute inset-0 bg-gradient-to-b from-black/90 via-transparent to-black/90" />
      </div>

      <header className="px-6 py-8 relative z-10 border-b border-cyan-500/30 bg-black/60 backdrop-blur-xl shadow-[0_0_40px_rgba(0,255,255,0.25)]">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <h1 className="text-3xl font-black tracking-tighter text-white high-res-glow uppercase glow-text-cyan">
              Body & Somatic
            </h1>
            <p className="text-[10px] text-primary/80 uppercase tracking-[0.4em] font-black flex items-center gap-2">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
              </span>
              Neural-Somatic Interface v2.4
            </p>
          </div>
        </div>
      </header>

      {predictiveAlert && (
        <div className="mx-4 mt-6 mb-6 bg-orange-500/10 border border-orange-500/40 rounded-xl p-4 flex items-start gap-3 animate-in slide-in-from-top-2 max-w-md md:mx-auto shadow-[0_0_20px_rgba(249,115,22,0.15)] backdrop-blur-md relative z-10">
          <AlertTriangle className="w-5 h-5 text-orange-400 shrink-0 mt-0.5 animate-pulse" />
          <div className="flex-1">
            <div className="text-sm font-bold text-orange-400">
              Predictive Warning
            </div>
            <div className="text-xs text-orange-200 mt-1 leading-relaxed">
              <span className="text-white font-bold">
                {predictiveAlert.label}
              </span>{" "}
              anomaly is predicted to return in{" "}
              <span className="font-black text-orange-400">
                {predictiveAlert.time}
              </span>
              . Pre-emptive protocol recommended.
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="h-6 px-2 text-[10px] uppercase tracking-wider text-orange-400 hover:text-orange-300 hover:bg-orange-500/20"
            onClick={() => setPredictiveAlert(null)}
          >
            Dismiss
          </Button>
        </div>
      )}

      <main className="flex-1 px-4 max-w-md mx-auto w-full relative z-10 pb-6">
        <Tabs
          value={activeTab}
          onValueChange={(v) => {
            setActiveTab(v);
            hapticFeedback(5);
          }}
          className="w-full"
        >
          <TabsList className="grid w-full grid-cols-4 bg-[#111] border border-white/10 mb-6">
            <TabsTrigger
              value="somatic"
              className="text-[10px] uppercase tracking-widest data-[state=active]:bg-primary/20 data-[state=active]:text-primary"
            >
              Map
            </TabsTrigger>
            <TabsTrigger
              value="insights"
              className="text-[10px] uppercase tracking-widest data-[state=active]:bg-orange-500/20 data-[state=active]:text-orange-400"
            >
              Insights
            </TabsTrigger>
            <TabsTrigger
              value="revive"
              className="text-[10px] uppercase tracking-widest data-[state=active]:bg-blue-500/20 data-[state=active]:text-blue-400"
            >
              Revive
            </TabsTrigger>
            <TabsTrigger
              value="bodycomp"
              className="text-[10px] uppercase tracking-widest data-[state=active]:bg-emerald-500/20 data-[state=active]:text-emerald-400"
            >
              Body Comp
            </TabsTrigger>
          </TabsList>

          <TabsContent
            value="somatic"
            className="space-y-6 animate-in fade-in flex-1 flex flex-col"
          >
            <div className="flex flex-col items-center flex-1">
              <div className="flex items-center justify-between w-full mb-2">
                <h2 className="text-sm font-bold text-white/80 uppercase tracking-widest flex items-center gap-2">
                  <Activity className="w-4 h-4 text-primary" /> System
                  Diagnostics
                </h2>

                <Dialog
                  open={stressModalOpen}
                  onOpenChange={setStressModalOpen}
                >
                  <DialogTrigger asChild>
                    <Button
                      variant="outline"
                      size="sm"
                      className="h-8 text-[10px] uppercase tracking-widest bg-purple-500/10 text-purple-400 border-purple-500/30 hover:bg-purple-500/20"
                      onClick={() => hapticFeedback(5)}
                    >
                      Log Stress
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-md bg-[#111] border-white/10 text-foreground">
                    <DialogHeader>
                      <DialogTitle className="text-sm uppercase tracking-widest text-purple-400 flex items-center gap-2">
                        <AlertTriangle className="w-4 h-4" /> Log Stress Trigger
                      </DialogTitle>
                    </DialogHeader>
                    <div className="space-y-6 py-4">
                      <div>
                        <div className="flex justify-between text-xs mb-3 font-bold uppercase tracking-widest">
                          <span>Intensity</span>
                          <span className="text-purple-400">
                            {tempStressLevel[0]}/10
                          </span>
                        </div>
                        <Slider
                          value={tempStressLevel}
                          onValueChange={setTempStressLevel}
                          max={10}
                          step={1}
                          className="py-2"
                        />
                      </div>

                      <div>
                        <div className="text-xs mb-3 font-bold uppercase tracking-widest">
                          Stress Vector
                        </div>
                        <div className="grid grid-cols-3 gap-2">
                          <Button
                            variant="outline"
                            className={cn(
                              "h-16 flex flex-col gap-1 items-center justify-center bg-white/5 border-white/10",
                              tempStressType === "Stress_Cognitive" &&
                                "bg-purple-500/20 border-purple-500/50 text-purple-400",
                            )}
                            onClick={() => {
                              setTempStressType("Stress_Cognitive");
                              hapticFeedback(5);
                            }}
                          >
                            <Brain className="w-5 h-5" />
                            <span className="text-[9px] uppercase">
                              Cognitive
                            </span>
                          </Button>
                          <Button
                            variant="outline"
                            className={cn(
                              "h-16 flex flex-col gap-1 items-center justify-center bg-white/5 border-white/10",
                              tempStressType === "Stress_Emotional" &&
                                "bg-pink-500/20 border-pink-500/50 text-pink-400",
                            )}
                            onClick={() => {
                              setTempStressType("Stress_Emotional");
                              hapticFeedback(5);
                            }}
                          >
                            <Heart className="w-5 h-5" />
                            <span className="text-[9px] uppercase">
                              Emotional
                            </span>
                          </Button>
                          <Button
                            variant="outline"
                            className={cn(
                              "h-16 flex flex-col gap-1 items-center justify-center bg-white/5 border-white/10",
                              tempStressType === "Stress_Physical" &&
                                "bg-red-500/20 border-red-500/50 text-red-400",
                            )}
                            onClick={() => {
                              setTempStressType("Stress_Physical");
                              hapticFeedback(5);
                            }}
                          >
                            <Dumbbell className="w-5 h-5" />
                            <span className="text-[9px] uppercase">
                              Physical
                            </span>
                          </Button>
                        </div>
                      </div>

                      <Button
                        onClick={handleLogStress}
                        className="w-full bg-purple-500 hover:bg-purple-600 text-white uppercase tracking-widest text-xs font-bold"
                      >
                        Analyze & Generate Plan
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>

              {/* Floating Center Silhouette */}
              <div className="text-[10px] text-muted-foreground text-center mb-2 uppercase tracking-widest animate-pulse">
                Tap neural nodes to map stress points
              </div>
              <div className="relative w-full aspect-[3/4] max-h-[480px] max-w-[360px] mx-auto my-2 flex-1 drop-shadow-[0_0_30px_rgba(34,211,238,0.1)]">
                {/* High-Tech Skeleton Anatomy Silhouette */}
                <div
                  className="absolute inset-0 bg-[url('https://vibe.filesafe.space/1776727899133821812/assets/365860df-cdb2-4522-8ec9-a75d3a4fdcce.png')] bg-contain bg-center bg-no-repeat mix-blend-screen animate-neural-pulse"
                  style={{
                    filter:
                      "contrast(1.5) brightness(1.2) drop-shadow(0 0 15px rgba(34,211,238,0.3))",
                    WebkitMaskImage:
                      "radial-gradient(ellipse at center, black 50%, transparent 90%)",
                    maskImage:
                      "radial-gradient(ellipse at center, black 50%, transparent 90%)",
                  }}
                />

                {/* Highlighted Glowing Zones */}
                {selectedMuscles.map((muscle) =>
                  muscleZones[muscle]?.map((zone, i) => (
                    <div
                      key={`${muscle}-${i}`}
                      className="absolute -translate-x-1/2 -translate-y-1/2 rounded-[100%] bg-cyan-400/50 blur-[10px] transition-all duration-700 mix-blend-screen"
                      style={{
                        top: zone.top,
                        left: zone.left,
                        width: zone.width,
                        height: zone.height,
                        boxShadow: "0 0 30px 15px rgba(34, 211, 238, 0.4)",
                        animation:
                          "pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite",
                      }}
                    />
                  )),
                )}

                {/* Neural Pathway Traces */}
                <style>{`
                  @keyframes neural-trace {
                    from { stroke-dashoffset: 100; }
                    to { stroke-dashoffset: 0; }
                  }
                  @keyframes neural-flow {
                    from { stroke-dashoffset: 24; }
                    to { stroke-dashoffset: 0; }
                  }
                `}</style>
                <svg className="absolute inset-0 w-full h-full pointer-events-none z-20 overflow-visible">
                  {activeAnomalies.map((key, index) => {
                    if (index === 0) return null;
                    const prevKey = activeAnomalies[index - 1];
                    const prevAnomaly = anomalyZones[prevKey];
                    const currAnomaly = anomalyZones[key];

                    if (!prevAnomaly || !currAnomaly) return null;

                    const traceColor = currAnomaly.color.replace("0.8", "1");

                    return (
                      <g key={`trace-group-${prevKey}-${key}`}>
                        {/* Base Trace */}
                        <line
                          x1={prevAnomaly.left}
                          y1={prevAnomaly.top}
                          x2={currAnomaly.left}
                          y2={currAnomaly.top}
                          stroke={traceColor}
                          strokeWidth="2"
                          strokeLinecap="round"
                          className="opacity-30"
                          pathLength="100"
                          strokeDasharray="100"
                          style={{
                            animation: "neural-trace 0.8s ease-out forwards",
                          }}
                        />
                        {/* Flowing Energy Pulses */}
                        <line
                          x1={prevAnomaly.left}
                          y1={prevAnomaly.top}
                          x2={currAnomaly.left}
                          y2={currAnomaly.top}
                          stroke={traceColor}
                          strokeWidth="3"
                          strokeLinecap="round"
                          className="opacity-100 mix-blend-screen"
                          pathLength="100"
                          strokeDasharray="1 11"
                          style={{
                            animation:
                              "neural-trace 0.8s ease-out forwards, neural-flow 0.5s linear infinite 0.8s",
                            filter: `drop-shadow(0 0 8px ${traceColor})`,
                          }}
                        />
                      </g>
                    );
                  })}
                </svg>

                {/* Anomaly Zones */}
                {Object.entries(anomalyZones).map(([anomalyKey, anomaly]) => {
                  const isActive = activeAnomalies.includes(anomalyKey);

                  return (
                    <div
                      key={`anomaly-container-${anomalyKey}`}
                      className="absolute z-30"
                      style={{ top: anomaly.top, left: anomaly.left }}
                    >
                      <button
                        onClick={() => {
                          hapticFeedback(10);
                          playNodeTapSound(500);
                          if (!isActive) {
                            setActiveAnomalies((prev) => [...prev, anomalyKey]);
                          } else {
                            setActiveProtocol(anomalyKey);
                          }
                        }}
                        className="group absolute -translate-x-1/2 -translate-y-1/2 flex items-center justify-center cursor-pointer"
                        style={{ width: anomaly.width, height: anomaly.height }}
                      >
                        {/* Core Pulse */}
                        <div
                          className={cn(
                            "absolute inset-0 rounded-[100%] transition-all duration-700 mix-blend-screen group-hover:scale-125 group-hover:blur-[12px]",
                            isActive
                              ? "blur-[8px] animate-pulse"
                              : "blur-[4px] opacity-30",
                          )}
                          style={{
                            backgroundColor: anomaly.color,
                            boxShadow: isActive
                              ? `0 0 40px 20px ${anomaly.color}`
                              : `0 0 10px 5px ${anomaly.color}`,
                          }}
                        />
                        {/* Interactive Center */}
                        <div
                          className={cn(
                            "w-3 h-3 rounded-full border-2 bg-black/50 z-10 transition-transform group-hover:scale-150",
                            !isActive && "opacity-50",
                          )}
                          style={{
                            borderColor: anomaly.color.replace("0.8", "1"),
                          }}
                        />

                        {/* Tooltip / Label on Hover */}
                        <div className="absolute top-full mt-2 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none flex flex-col items-center">
                          <div
                            className="w-[1px] h-4 bg-white/50 mb-1"
                            style={{
                              backgroundColor: anomaly.color.replace(
                                "0.8",
                                "0.5",
                              ),
                            }}
                          />
                          <div
                            className="bg-black/80 backdrop-blur-md border px-2 py-1 rounded text-[9px] font-bold uppercase tracking-widest whitespace-nowrap"
                            style={{
                              borderColor: anomaly.color.replace("0.8", "0.5"),
                              color: anomaly.color.replace("0.8", "1"),
                            }}
                          >
                            {anomaly.label}{" "}
                            {isActive ? "" : "(Click to Activate)"}
                          </div>
                        </div>
                      </button>
                    </div>
                  );
                })}
              </div>

              {/* Anomaly Alerts */}
              {activeAnomalies.length > 0 && (
                <div className="w-full max-w-sm mb-6 space-y-3 animate-in slide-in-from-bottom-4">
                  <div className="text-[10px] font-bold text-white uppercase tracking-widest mb-4 flex items-center gap-2 bg-red-500/40 p-2.5 rounded-lg border border-red-500/50 shadow-[0_0_15px_rgba(220,38,38,0.3)] backdrop-blur-md">
                    <Activity className="w-4 h-4 text-white animate-pulse" />
                    Critical Biomarkers Detected
                  </div>
                  {activeAnomalies.map((key) => {
                    const anomaly = anomalyZones[key];
                    return (
                      <div
                        key={key}
                        className="flex items-center justify-between bg-red-500/10 border border-red-500/40 p-4 rounded-xl shadow-[0_0_20px_rgba(220,38,38,0.2)] backdrop-blur-md"
                      >
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <div
                              className="w-2 h-2 rounded-full animate-pulse shadow-[0_0_10px_rgba(255,255,255,0.8)]"
                              style={{
                                backgroundColor: anomaly.color.replace(
                                  "0.8",
                                  "1",
                                ),
                              }}
                            />
                            <div className="text-sm font-bold text-white drop-shadow-md">
                              {anomaly.label}
                            </div>
                          </div>
                          <div className="text-xs text-red-200/90 leading-tight font-medium">
                            {anomaly.impact}
                          </div>
                        </div>
                        <Button
                          size="sm"
                          onClick={() => {
                            hapticFeedback(20);
                            playNodeTapSound(700);
                            setActiveProtocol(key);
                          }}
                          className="h-8 text-[10px] uppercase tracking-wider bg-red-500 text-white hover:bg-red-600 border-none shadow-[0_0_15px_rgba(220,38,38,0.5)]"
                        >
                          Protocol
                        </Button>
                      </div>
                    );
                  })}
                </div>
              )}

              {/* Plan of the Day */}
              {stressLogged && (
                <div className="w-full max-w-sm mb-6 bg-[#111] border border-purple-500/30 rounded-xl p-4 animate-in slide-in-from-bottom-4 shadow-[0_0_20px_rgba(168,85,247,0.1)]">
                  <div className="flex items-center gap-2 mb-4 pb-3 border-b border-white/5">
                    <Activity className="w-4 h-4 text-purple-400 animate-pulse" />
                    <h3 className="text-sm font-bold text-purple-400 uppercase tracking-widest">
                      Active Recovery Plan
                    </h3>
                  </div>

                  <div className="space-y-4 relative before:absolute before:inset-y-0 before:left-[11px] before:w-[2px] before:bg-white/10">
                    <div
                      className="relative pl-8 animate-in fade-in slide-in-from-left-4 delay-100 fill-mode-both cursor-pointer group"
                      onClick={() => {
                        hapticFeedback(10);
                        setBoxBreathingModalOpen(true);
                      }}
                    >
                      <div className="absolute left-0 top-1 w-6 h-6 rounded-full bg-purple-500/20 border border-purple-500/50 flex items-center justify-center text-[10px] font-bold text-purple-400 z-10 group-hover:bg-purple-500/40 transition-colors">
                        1
                      </div>
                      <div className="text-xs font-bold text-white group-hover:text-purple-300 transition-colors">
                        Box Breathing Protocol
                      </div>
                      <div className="text-[10px] text-muted-foreground mt-0.5">
                        5 mins • Down-regulates sympathetic nervous system
                      </div>
                    </div>
                    <div className="relative pl-8 animate-in fade-in slide-in-from-left-4 delay-200 fill-mode-both">
                      <div className="absolute left-0 top-1 w-6 h-6 rounded-full bg-black border border-white/20 flex items-center justify-center text-[10px] font-bold text-muted-foreground z-10">
                        2
                      </div>
                      <div className="text-xs font-bold text-white">
                        Hydration Flush
                      </div>
                      <div className="text-[10px] text-muted-foreground mt-0.5">
                        500ml • Clears cortisol metabolites
                      </div>
                    </div>
                    <div className="relative pl-8 animate-in fade-in slide-in-from-left-4 delay-300 fill-mode-both">
                      <div className="absolute left-0 top-1 w-6 h-6 rounded-full bg-black border border-white/20 flex items-center justify-center text-[10px] font-bold text-muted-foreground z-10">
                        3
                      </div>
                      <div className="text-xs font-bold text-white">
                        Somatic Release
                      </div>
                      <div className="text-[10px] text-muted-foreground mt-0.5">
                        10 mins • Target{" "}
                        {tempStressType === "Stress_Cognitive"
                          ? "neck & head"
                          : tempStressType === "Stress_Emotional"
                            ? "chest & gut"
                            : "shoulders & back"}
                      </div>
                    </div>
                  </div>

                  <Button
                    onClick={() => {
                      hapticFeedback(10);
                      navigate("/breathing");
                    }}
                    className="w-full mt-5 bg-purple-500/20 hover:bg-purple-500/30 text-purple-400 border border-purple-500/50 text-xs uppercase tracking-widest font-bold"
                  >
                    Start Protocol
                  </Button>
                </div>
              )}

              <div className="flex flex-wrap justify-center gap-2 mb-6 w-full max-w-sm">
                {muscleGroups.map((muscle) => (
                  <Button
                    key={muscle}
                    variant={
                      selectedMuscles.includes(muscle) ? "default" : "outline"
                    }
                    onClick={() => toggleMuscle(muscle)}
                    className={cn(
                      "rounded-full transition-all duration-300 text-xs h-8 px-4",
                      selectedMuscles.includes(muscle)
                        ? "bg-[#1a73e8] hover:bg-[#1557b0] text-white border-transparent shadow-[0_0_15px_rgba(26,115,232,0.5)]"
                        : "bg-black/40 border-white/10 text-muted-foreground hover:text-white backdrop-blur-md",
                    )}
                  >
                    {muscle}
                  </Button>
                ))}
              </div>

              {selectedMuscles.length > 0 &&
                selectedMuscles[0] !== "Full body" && (
                  <div className="w-full max-w-sm mb-6 space-y-3 animate-in slide-in-from-bottom-4">
                    <div className="flex items-center gap-2 mb-3">
                      <Headphones className="w-4 h-4 text-[#1a73e8]" />
                      <h3 className="text-sm font-bold text-[#1a73e8] uppercase tracking-widest">
                        Somatic Release Audio
                      </h3>
                    </div>
                    {selectedMuscles.map((muscle) => {
                      const isPlaying = playingRelease === muscle;
                      return (
                        <div
                          key={`audio-${muscle}`}
                          className="bg-[#111] border border-[#1a73e8]/30 rounded-xl p-4 shadow-[0_0_15px_rgba(26,115,232,0.1)]"
                        >
                          <div className="flex items-center justify-between">
                            <div>
                              <div className="text-sm font-bold text-white">
                                {muscle} Release Protocol
                              </div>
                              <div className="text-[10px] text-muted-foreground">
                                Binaural • 432Hz • 5 Min
                              </div>
                            </div>
                            <Button
                              size="icon"
                              className={cn(
                                "h-10 w-10 rounded-full transition-all duration-300",
                                isPlaying
                                  ? "bg-[#1a73e8]/20 text-[#1a73e8] border border-[#1a73e8]/50"
                                  : "bg-[#1a73e8] text-white hover:bg-[#1557b0] shadow-[0_0_15px_rgba(26,115,232,0.4)]",
                              )}
                              onClick={() => {
                                hapticFeedback(10);
                                if (isPlaying) {
                                  setPlayingRelease(null);
                                } else {
                                  setPlayingRelease(muscle);
                                  setReleaseProgress(0);
                                }
                              }}
                            >
                              {isPlaying ? (
                                <Pause className="h-4 w-4" />
                              ) : (
                                <Play className="h-4 w-4 ml-0.5" />
                              )}
                            </Button>
                          </div>
                          {isPlaying && (
                            <div className="mt-4 space-y-2 animate-in fade-in">
                              <div className="flex justify-between text-[10px] text-[#1a73e8] font-mono font-bold">
                                <span>
                                  {Math.floor(
                                    ((releaseProgress / 100) * 300) / 60,
                                  )}
                                  :
                                  {(
                                    Math.floor((releaseProgress / 100) * 300) %
                                    60
                                  )
                                    .toString()
                                    .padStart(2, "0")}
                                </span>
                                <span>5:00</span>
                              </div>
                              <div className="h-1.5 w-full bg-white/10 rounded-full overflow-hidden">
                                <div
                                  className="h-full bg-[#1a73e8] transition-all duration-1000"
                                  style={{ width: `${releaseProgress}%` }}
                                />
                              </div>
                              <div className="flex items-end justify-center gap-1 h-8 mt-4">
                                {[...Array(24)].map((_, i) => (
                                  <div
                                    key={i}
                                    className="w-1.5 bg-[#1a73e8]/60 rounded-t-full animate-pulse"
                                    style={{
                                      height: `${Math.max(20, Math.random() * 100)}%`,
                                      animationDelay: `${i * 0.05}s`,
                                      animationDuration: "0.5s",
                                    }}
                                  />
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
            </div>
          </TabsContent>

          <TabsContent
            value="insights"
            className="space-y-6 animate-in fade-in"
          >
            <div className="bg-[#111] border border-white/5 rounded-2xl overflow-hidden relative">
              <div className="p-6">
                <h3 className="font-bold text-lg mb-2">Readiness Trend</h3>
                <p className="text-xs text-muted-foreground mb-6">
                  Flag what matters.
                </p>

                <div className="h-[200px] w-full mt-4">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart
                      data={readinessData}
                      margin={{ top: 5, right: 0, left: 0, bottom: 0 }}
                    >
                      <defs>
                        <linearGradient
                          id="colorScore"
                          x1="0"
                          y1="0"
                          x2="0"
                          y2="1"
                        >
                          <stop
                            offset="5%"
                            stopColor="#ea580c"
                            stopOpacity={0.8}
                          />
                          <stop
                            offset="95%"
                            stopColor="#ea580c"
                            stopOpacity={0}
                          />
                        </linearGradient>
                      </defs>
                      <XAxis
                        dataKey="day"
                        stroke="#555"
                        fontSize={10}
                        tickLine={false}
                        axisLine={false}
                      />
                      <RechartsTooltip
                        contentStyle={{
                          backgroundColor: "#111",
                          border: "1px solid rgba(255,255,255,0.1)",
                          borderRadius: "8px",
                        }}
                        itemStyle={{ color: "#ea580c" }}
                      />
                      <Area
                        type="monotone"
                        dataKey="score"
                        stroke="#ea580c"
                        strokeWidth={3}
                        fillOpacity={1}
                        fill="url(#colorScore)"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>

                <div className="grid grid-cols-2 gap-4 mt-6">
                  <div className="bg-black/40 p-4 rounded-xl border border-white/5">
                    <div className="text-xs text-muted-foreground mb-1">
                      Avg Readiness
                    </div>
                    <div className="text-2xl font-bold text-white">
                      84<span className="text-sm text-muted-foreground">%</span>
                    </div>
                  </div>
                  <div className="bg-black/40 p-4 rounded-xl border border-white/5">
                    <div className="text-xs text-muted-foreground mb-1">
                      Peak Stress Zone
                    </div>
                    <div className="text-lg font-bold text-orange-400">
                      Shoulders
                    </div>
                  </div>
                </div>
              </div>
              <div className="p-6 pt-0">
                <Button
                  onClick={() => {
                    hapticFeedback(10);
                    setActiveTab("revive");
                  }}
                  className="w-full h-14 bg-[#ea580c] hover:bg-[#c2410c] text-white rounded-2xl text-lg font-medium shadow-[0_0_20px_rgba(234,88,12,0.4)]"
                >
                  Next
                </Button>
              </div>
            </div>

            {/* Biometric History Graph */}
            <div className="bg-[#111] border border-white/5 rounded-2xl p-6">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-bold text-lg">Biometric History</h3>
                <Activity className="w-4 h-4 text-cyan-400" />
              </div>
              <p className="text-xs text-muted-foreground mb-6">
                7-day trend across core metrics.
              </p>

              <div className="h-[250px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={[
                      { day: "Mon", hrv: 62, cns: 45, sleep: 82 },
                      { day: "Tue", hrv: 68, cns: 50, sleep: 85 },
                      { day: "Wed", hrv: 55, cns: 75, sleep: 60 },
                      { day: "Thu", hrv: 71, cns: 40, sleep: 88 },
                      { day: "Fri", hrv: 75, cns: 35, sleep: 92 },
                      { day: "Sat", hrv: 60, cns: 65, sleep: 70 },
                      { day: "Sun", hrv: 80, cns: 30, sleep: 95 },
                    ]}
                    margin={{ top: 5, right: 5, left: -20, bottom: 0 }}
                  >
                    <CartesianGrid
                      strokeDasharray="3 3"
                      stroke="#333"
                      vertical={false}
                    />
                    <XAxis
                      dataKey="day"
                      stroke="#555"
                      fontSize={10}
                      tickLine={false}
                      axisLine={false}
                    />
                    <YAxis
                      stroke="#555"
                      fontSize={10}
                      tickLine={false}
                      axisLine={false}
                    />
                    <RechartsTooltip
                      contentStyle={{
                        backgroundColor: "#111",
                        border: "1px solid rgba(255,255,255,0.1)",
                        borderRadius: "8px",
                      }}
                      itemStyle={{ fontSize: "12px" }}
                    />
                    <Legend wrapperStyle={{ fontSize: "10px" }} />
                    <Line
                      type="monotone"
                      dataKey="hrv"
                      name="HRV (ms)"
                      stroke="#00ffff"
                      strokeWidth={2}
                      dot={{ r: 3, fill: "#00ffff" }}
                      activeDot={{ r: 5 }}
                    />
                    <Line
                      type="monotone"
                      dataKey="sleep"
                      name="Sleep Score"
                      stroke="#a855f7"
                      strokeWidth={2}
                      dot={{ r: 3, fill: "#a855f7" }}
                      activeDot={{ r: 5 }}
                    />
                    <Line
                      type="monotone"
                      dataKey="cns"
                      name="CNS Load (%)"
                      stroke="#ef4444"
                      strokeWidth={2}
                      dot={{ r: 3, fill: "#ef4444" }}
                      activeDot={{ r: 5 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* CNS Load History — Bioluminescent Visualizer */}
            <div className="bg-[#111] border border-white/5 rounded-2xl p-6 mt-6 relative overflow-hidden">
              <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(0,242,254,0.04),transparent_70%)] pointer-events-none" />
              <div className="flex items-center justify-between mb-2 relative z-10">
                <h3 className="font-bold text-lg">CNS Load History</h3>
                <Brain className="w-4 h-4 text-red-500" />
              </div>
              <p className="text-xs text-muted-foreground mb-6 relative z-10">
                Nervous system fatigue tracking over time.
              </p>

              <div className="w-full relative z-10">
                <CNSWaveformVisualizer
                  data={[
                    { day: "Mon", cns: 45 },
                    { day: "Tue", cns: 50 },
                    { day: "Wed", cns: 75 },
                    { day: "Thu", cns: 40 },
                    { day: "Fri", cns: 35 },
                    { day: "Sat", cns: 65 },
                    { day: "Sun", cns: 30 },
                  ]}
                  height={220}
                />
              </div>

              <div className="flex items-center justify-between mt-4 pt-4 border-t border-white/5 relative z-10">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-cyan-400 shadow-[0_0_8px_rgba(0,242,254,0.8)]" />
                  <span className="text-[10px] text-muted-foreground uppercase tracking-widest">
                    Optimal Range
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.8)]" />
                  <span className="text-[10px] text-muted-foreground uppercase tracking-widest">
                    Elevated Fatigue
                  </span>
                </div>
              </div>
            </div>

            {/* Biometric Correlation Matrix */}
            <div className="bg-[#111] border border-white/5 rounded-2xl p-6">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-bold text-lg">Correlation Matrix</h3>
                <Activity className="w-4 h-4 text-cyan-400" />
              </div>
              <p className="text-xs text-muted-foreground mb-6">
                Impact of Sleep Architecture on ANS metrics.
              </p>

              <div className="grid grid-cols-3 gap-2 text-center text-xs">
                <div className="bg-[#0d0d0d] p-3 rounded-lg border border-white/5 font-bold text-muted-foreground flex items-center justify-center">
                  Metric
                </div>
                <div className="bg-[#0d0d0d] p-3 rounded-lg border border-white/5 font-bold text-cyan-400 flex items-center justify-center">
                  HRV
                </div>
                <div className="bg-[#0d0d0d] p-3 rounded-lg border border-white/5 font-bold text-red-500 flex items-center justify-center">
                  CNS Load
                </div>

                <div className="bg-[#0d0d0d] p-3 rounded-lg border border-white/5 font-bold text-purple-400 flex items-center justify-center">
                  Sleep Score
                </div>
                <div className="bg-cyan-500/10 p-3 rounded-lg border border-cyan-500/30 text-cyan-400 font-bold flex flex-col justify-center">
                  <span className="text-lg">+0.84</span>
                  <span className="text-[9px] uppercase tracking-widest opacity-70">
                    Strong Positive
                  </span>
                </div>
                <div className="bg-emerald-500/10 p-3 rounded-lg border border-emerald-500/30 text-emerald-400 font-bold flex flex-col justify-center">
                  <span className="text-lg">-0.76</span>
                  <span className="text-[9px] uppercase tracking-widest opacity-70">
                    Strong Negative
                  </span>
                </div>

                <div className="bg-[#0d0d0d] p-3 rounded-lg border border-white/5 font-bold text-cyan-400 flex items-center justify-center">
                  HRV
                </div>
                <div className="bg-white/5 p-3 rounded-lg border border-white/10 text-muted-foreground font-bold flex items-center justify-center">
                  1.00
                </div>
                <div className="bg-emerald-500/10 p-3 rounded-lg border border-emerald-500/30 text-emerald-400 font-bold flex flex-col justify-center">
                  <span className="text-lg">-0.92</span>
                  <span className="text-[9px] uppercase tracking-widest opacity-70">
                    Inverse Link
                  </span>
                </div>
              </div>

              <p className="text-xs text-muted-foreground mt-4 leading-relaxed bg-white/5 p-3 rounded-lg border border-white/5">
                <strong className="text-white">Analysis:</strong> Your Sleep
                Score has a highly significant positive correlation with your
                HRV (+0.84), indicating that better sleep directly increases
                your parasympathetic tone. Conversely, better sleep strongly
                reduces your CNS Load (-0.76).
              </p>
            </div>

            {/* Stress Accumulation Heatmap */}
            <div className="bg-[#111] border border-white/5 rounded-2xl p-6">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-bold text-lg">Stress Accumulation</h3>
                <Brain className="w-4 h-4 text-purple-400" />
              </div>
              <p className="text-xs text-muted-foreground mb-6">
                Time-of-day correlation and load patterns.
              </p>

              <div className="flex flex-col gap-2">
                <div className="flex items-center gap-2 mb-1">
                  <div className="w-12"></div>
                  {["M", "T", "W", "T", "F", "S", "S"].map((d, i) => (
                    <div
                      key={i}
                      className="flex-1 text-center text-[10px] font-bold text-muted-foreground"
                    >
                      {d}
                    </div>
                  ))}
                </div>
                {[
                  { time: "Night", values: [10, 15, 12, 20, 45, 15, 10] },
                  { time: "Morning", values: [40, 60, 55, 80, 65, 30, 25] },
                  { time: "Midday", values: [70, 85, 90, 95, 80, 50, 40] },
                  { time: "Evening", values: [30, 40, 35, 50, 60, 80, 20] },
                ].map((row, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <div className="w-12 text-[9px] uppercase tracking-wider text-muted-foreground">
                      {row.time}
                    </div>
                    {row.values.map((val, j) => (
                      <div
                        key={j}
                        className="flex-1 aspect-square rounded-md transition-all duration-300 hover:scale-110 cursor-pointer relative group"
                        style={{
                          backgroundColor: `rgba(168, 85, 247, ${Math.max(0.1, val / 100)})`,
                          boxShadow:
                            val > 80
                              ? "0 0 10px rgba(168, 85, 247, 0.4)"
                              : "none",
                        }}
                      >
                        <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 opacity-0 group-hover:opacity-100 transition-opacity bg-black/90 text-white text-[10px] px-2 py-1 rounded pointer-events-none z-10 whitespace-nowrap border border-white/10">
                          Load: {val}%
                        </div>
                      </div>
                    ))}
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-[#111] border border-white/5 rounded-2xl p-6 mt-6">
              <h3 className="font-bold text-lg mb-2">
                Protocol History & Forecast
              </h3>
              <p className="text-xs text-muted-foreground mb-4">
                Recently cleared anomalies and re-occurrence predictions.
              </p>
              {protocolHistory.length === 0 ? (
                <div className="text-sm text-muted-foreground text-center py-4 border border-dashed border-white/10 rounded-xl">
                  No cleared anomalies yet.
                </div>
              ) : (
                <div className="space-y-3">
                  {protocolHistory.map((item) => (
                    <div
                      key={item.id}
                      className="bg-black/40 p-3 rounded-xl border border-white/5"
                    >
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
                            <Activity className="w-4 h-4 text-primary" />
                          </div>
                          <div>
                            <div className="text-sm font-bold text-white">
                              {item.label}
                            </div>
                            <div className="text-xs text-muted-foreground">
                              {item.timestamp.toLocaleTimeString([], {
                                hour: "2-digit",
                                minute: "2-digit",
                              })}
                            </div>
                          </div>
                        </div>
                        <Badge
                          variant="outline"
                          className="text-[10px] text-primary border-primary/30 uppercase tracking-widest"
                        >
                          Cleared
                        </Badge>
                      </div>
                      <div className="pt-3 border-t border-white/5 flex flex-col gap-2">
                        <div className="flex items-center justify-between">
                          <div className="text-xs text-muted-foreground flex items-center gap-1">
                            <AlertTriangle className="w-3 h-3 text-orange-400" />
                            Re-occurrence Risk
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="text-xs font-bold text-orange-400">
                              {item.risk}%
                            </div>
                            <div className="text-[10px] text-muted-foreground bg-white/5 px-2 py-0.5 rounded">
                              Est. {item.predictedReturn}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-start gap-2 mt-1">
                          <Link2 className="w-3 h-3 text-blue-400 mt-0.5 shrink-0" />
                          <div className="flex flex-wrap gap-1">
                            {item.triggers.map((t) => (
                              <span
                                key={t}
                                className="text-[9px] uppercase tracking-wider bg-blue-500/10 text-blue-400 px-1.5 py-0.5 rounded border border-blue-500/20"
                              >
                                {t}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent
            value="revive"
            className="space-y-4 animate-in fade-in pb-6"
          >
            {/* Hydration Ring */}
            <div className="bg-[#111] border border-white/5 rounded-xl p-6 text-center">
              <div className="flex justify-center mb-4">
                <div
                  className="relative w-32 h-32 rounded-full border-4 border-white/5 flex items-center justify-center overflow-hidden"
                  style={{
                    boxShadow: `0 0 ${hydration / 2}px ${hydration / 4}px rgba(59,130,246,0.3)`,
                  }}
                >
                  <div
                    className="absolute bottom-0 w-full bg-blue-500/30 transition-all duration-1000"
                    style={{ height: `${hydration}%` }}
                  >
                    <div className="absolute top-0 w-full h-2 bg-blue-400/50" />
                  </div>
                  <Droplets className="w-8 h-8 text-blue-400 relative z-10" />
                </div>
              </div>
              <h3 className="font-bold text-xl mb-1">{hydration}% Hydrated</h3>
              <p className="text-xs text-muted-foreground mb-4">
                Revive Tracker
              </p>
              <div className="grid grid-cols-3 gap-2 mb-4 text-center">
                <div className="bg-black/40 rounded-lg p-2 border border-white/5">
                  <div className="text-sm font-bold text-blue-400">
                    {(hydration * 0.02).toFixed(1)}L
                  </div>
                  <div className="text-[9px] text-muted-foreground uppercase tracking-wider mt-0.5">
                    Logged
                  </div>
                </div>
                <div className="bg-black/40 rounded-lg p-2 border border-white/5">
                  <div className="text-sm font-bold text-cyan-400">
                    {Math.max(0, 2 - hydration * 0.02).toFixed(1)}L
                  </div>
                  <div className="text-[9px] text-muted-foreground uppercase tracking-wider mt-0.5">
                    Remaining
                  </div>
                </div>
                <div className="bg-black/40 rounded-lg p-2 border border-white/5">
                  <div className="text-sm font-bold text-primary">2.0L</div>
                  <div className="text-[9px] text-muted-foreground uppercase tracking-wider mt-0.5">
                    Target
                  </div>
                </div>
              </div>
              <Button
                onClick={addWater}
                className="w-full bg-blue-500/20 text-blue-400 hover:bg-blue-500/30 border border-blue-500/30"
              >
                + Log 250ml
              </Button>
            </div>

            {/* Hydration Notification Scheduler */}
            <div
              className={cn(
                "rounded-xl p-4 border transition-all duration-300",
                hydrationAlertFired
                  ? "bg-orange-500/10 border-orange-500/40 shadow-[0_0_20px_rgba(249,115,22,0.2)]"
                  : nextReminderIn < 300
                    ? "bg-yellow-500/10 border-yellow-500/30"
                    : "bg-[#111] border-white/5",
              )}
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Bell
                    className={cn(
                      "w-4 h-4",
                      hydrationAlertsEnabled
                        ? "text-primary animate-pulse"
                        : "text-muted-foreground",
                    )}
                  />
                  <span className="text-sm font-bold uppercase tracking-widest">
                    Hydration Reminders
                  </span>
                </div>
                <button
                  onClick={toggleHydrationAlerts}
                  className={cn(
                    "flex items-center gap-1.5 text-[10px] uppercase tracking-wider px-3 py-1.5 rounded-lg border transition-all",
                    hydrationAlertsEnabled
                      ? "bg-primary/20 text-primary border-primary/30 hover:bg-primary/30"
                      : "bg-white/5 text-muted-foreground border-white/10 hover:border-white/20",
                  )}
                >
                  {hydrationAlertsEnabled ? (
                    <Bell className="w-3 h-3" />
                  ) : (
                    <BellOff className="w-3 h-3" />
                  )}
                  {hydrationAlertsEnabled ? "On" : "Off"}
                </button>
              </div>

              {hydrationAlertsEnabled ? (
                <>
                  {hydrationAlertFired ? (
                    <div className="flex items-start gap-3 p-3 rounded-lg bg-orange-500/15 border border-orange-500/30 mb-3">
                      <AlertTriangle className="w-4 h-4 text-orange-400 shrink-0 mt-0.5 animate-pulse" />
                      <div>
                        <div className="text-xs font-bold text-orange-400">
                          Hydration Alert
                        </div>
                        <div className="text-[10px] text-orange-400/80 mt-0.5">
                          45 minutes have passed without a water log. Drink
                          250ml now.
                        </div>
                      </div>
                      <Button
                        size="sm"
                        onClick={addWater}
                        className="h-7 px-2 text-[9px] uppercase tracking-wider bg-orange-500/20 text-orange-400 border border-orange-500/30 hover:bg-orange-500/30 shrink-0"
                      >
                        Log Now
                      </Button>
                    </div>
                  ) : (
                    <div className="flex items-center gap-3 mb-3">
                      <div className="flex-1 h-1.5 rounded-full bg-white/10 overflow-hidden">
                        <div
                          className="h-full rounded-full bg-gradient-to-r from-blue-500 to-primary transition-all duration-1000"
                          style={{
                            width: `${((45 * 60 - nextReminderIn) / (45 * 60)) * 100}%`,
                          }}
                        />
                      </div>
                      <div className="flex items-center gap-1 shrink-0">
                        <Clock className="w-3 h-3 text-muted-foreground" />
                        <span
                          className={cn(
                            "text-xs font-mono font-bold tabular-nums",
                            nextReminderIn < 300
                              ? "text-yellow-400"
                              : "text-primary",
                          )}
                        >
                          {formatCountdown(nextReminderIn)}
                        </span>
                      </div>
                    </div>
                  )}
                  <div className="text-[10px] text-muted-foreground">
                    Alert fires every{" "}
                    <span className="text-foreground font-medium">45 min</span>{" "}
                    if no water is logged manually or via a linked device. Timer
                    resets on every log.
                  </div>
                </>
              ) : (
                <p className="text-[10px] text-muted-foreground">
                  Enable to receive alerts every 45 minutes when hydration goes
                  untracked.
                </p>
              )}

              <div className="flex items-center justify-between mt-4 border-t border-white/5 pt-4">
                <div className="flex items-center gap-2">
                  <Moon
                    className={cn(
                      "w-4 h-4",
                      dailySummaryEnabled
                        ? "text-primary"
                        : "text-muted-foreground",
                    )}
                  />
                  <span className="text-xs font-bold uppercase tracking-widest">
                    End-of-Day Summary
                  </span>
                </div>
                <button
                  onClick={() => {
                    const next = !dailySummaryEnabled;
                    setDailySummaryEnabled(next);
                    localStorage.setItem("tf_daily_summary", String(next));
                    if (
                      next &&
                      "Notification" in window &&
                      Notification.permission === "default"
                    ) {
                      Notification.requestPermission().then((p) => {
                        notifPermission.current = p;
                      });
                    }
                  }}
                  className={cn(
                    "flex items-center gap-1.5 text-[10px] uppercase tracking-wider px-3 py-1.5 rounded-lg border transition-all",
                    dailySummaryEnabled
                      ? "bg-primary/20 text-primary border-primary/30 hover:bg-primary/30"
                      : "bg-white/5 text-muted-foreground border-white/10 hover:border-white/20",
                  )}
                >
                  {dailySummaryEnabled ? "On" : "Off"}
                </button>
              </div>
              <div className="text-[10px] text-muted-foreground mt-2">
                Sends a push notification at 8:00 PM with your total water
                logged vs your daily target.
              </div>
            </div>

            {/* Optimal Hydration Windows */}
            <div className="bg-[#111] border border-white/5 rounded-xl p-5">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-blue-400" />
                  <h3 className="font-bold text-sm uppercase tracking-widest text-blue-400">
                    Circadian Windows
                  </h3>
                </div>
                <Badge
                  variant="outline"
                  className="text-[9px] border-blue-500/30 text-blue-400 bg-blue-500/5"
                >
                  Optimal Flow
                </Badge>
              </div>

              <div className="space-y-3">
                {[
                  {
                    time: "07:00 - 09:00",
                    label: "Morning Surge",
                    amount: "500ml",
                    icon: "🌅",
                    active:
                      new Date().getHours() >= 7 && new Date().getHours() < 9,
                  },
                  {
                    time: "11:00 - 13:00",
                    label: "Cognitive Peak",
                    amount: "300ml",
                    icon: "🧠",
                    active:
                      new Date().getHours() >= 11 && new Date().getHours() < 13,
                  },
                  {
                    time: "16:00 - 18:00",
                    label: "Metabolic Recovery",
                    amount: "400ml",
                    icon: "⚡",
                    active:
                      new Date().getHours() >= 16 && new Date().getHours() < 18,
                  },
                  {
                    time: "20:00 - 21:30",
                    label: "Neural Taper",
                    amount: "200ml",
                    icon: "🌙",
                    active:
                      new Date().getHours() >= 20 && new Date().getHours() < 22,
                  },
                ].map((window, idx) => (
                  <div
                    key={idx}
                    className={cn(
                      "flex items-center justify-between p-3 rounded-lg border transition-all duration-300",
                      window.active
                        ? "bg-blue-500/10 border-blue-500/40 shadow-[0_0_15px_rgba(59,130,246,0.1)]"
                        : "bg-black/20 border-white/5 opacity-60",
                    )}
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-lg">{window.icon}</span>
                      <div>
                        <div className="text-xs font-bold text-white">
                          {window.label}
                        </div>
                        <div className="text-[10px] text-muted-foreground font-mono">
                          {window.time}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div
                        className={cn(
                          "text-xs font-bold",
                          window.active
                            ? "text-blue-400"
                            : "text-muted-foreground",
                        )}
                      >
                        {window.amount}
                      </div>
                      {window.active && (
                        <div className="text-[8px] uppercase tracking-tighter text-blue-400 animate-pulse">
                          Active Window
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
              <p className="text-[9px] text-muted-foreground mt-4 italic">
                * Windows are dynamically adjusted based on your circadian
                anchor and recent CNS load.
              </p>
            </div>

            {/* Neural Fuel Guide */}
            <div className="bg-[#111] border border-white/5 rounded-xl p-5">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Zap className="w-4 h-4 text-orange-400" />
                  <h3 className="font-bold text-sm uppercase tracking-widest text-orange-400">
                    Neural Fuel
                  </h3>
                </div>
                <Badge
                  variant="outline"
                  className="text-[9px] border-orange-500/30 text-orange-400 bg-orange-500/5"
                >
                  Macro Sync
                </Badge>
              </div>

              <div className="space-y-3">
                {[
                  {
                    time: "07:00 - 09:00",
                    label: "Morning Ignition",
                    macros: "High Fat, Mod Protein",
                    icon: "🥑",
                    active:
                      new Date().getHours() >= 7 && new Date().getHours() < 9,
                  },
                  {
                    time: "11:00 - 13:00",
                    label: "Cognitive Sustain",
                    macros: "High Protein, Low Glycemic",
                    icon: "🥩",
                    active:
                      new Date().getHours() >= 11 && new Date().getHours() < 13,
                  },
                  {
                    time: "16:00 - 18:00",
                    label: "Metabolic Replenish",
                    macros: "Mod Carb, High Protein",
                    icon: "🍚",
                    active:
                      new Date().getHours() >= 16 && new Date().getHours() < 18,
                  },
                  {
                    time: "20:00 - 21:30",
                    label: "Neural Repair",
                    macros: "Collagen, Magnesium Rich",
                    icon: "🫐",
                    active:
                      new Date().getHours() >= 20 && new Date().getHours() < 22,
                  },
                ].map((window, idx) => (
                  <div
                    key={idx}
                    className={cn(
                      "flex items-center justify-between p-3 rounded-lg border transition-all duration-300",
                      window.active
                        ? "bg-orange-500/10 border-orange-500/40 shadow-[0_0_15px_rgba(249,115,22,0.1)]"
                        : "bg-black/20 border-white/5 opacity-60",
                    )}
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-lg">{window.icon}</span>
                      <div>
                        <div className="text-xs font-bold text-white">
                          {window.label}
                        </div>
                        <div className="text-[10px] text-muted-foreground font-mono">
                          {window.time}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div
                        className={cn(
                          "text-xs font-bold",
                          window.active
                            ? "text-orange-400"
                            : "text-muted-foreground",
                        )}
                      >
                        {window.macros}
                      </div>
                      {window.active && (
                        <div className="text-[8px] uppercase tracking-tighter text-orange-400 animate-pulse">
                          Active Window
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Fasting Protocol */}
            <div className="bg-[#111] border border-white/5 rounded-xl p-5">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Timer
                    className={cn(
                      "w-4 h-4",
                      fastingStartTime
                        ? fastingPhase.color
                        : "text-muted-foreground",
                    )}
                  />
                  <h3
                    className={cn(
                      "font-bold text-sm uppercase tracking-widest",
                      fastingStartTime ? fastingPhase.color : "text-white",
                    )}
                  >
                    Fasting Protocol
                  </h3>
                </div>
                <Badge
                  variant="outline"
                  className={cn(
                    "text-[9px]",
                    fastingStartTime
                      ? `${fastingPhase.border} ${fastingPhase.color} ${fastingPhase.bg}`
                      : "border-white/10 text-muted-foreground",
                  )}
                >
                  {fastingStartTime ? fastingPhase.label : "Inactive"}
                </Badge>
              </div>

              <div className="flex flex-col items-center justify-center py-6">
                <div
                  className={cn(
                    "text-5xl font-black font-mono tracking-tight mb-2",
                    fastingStartTime ? "text-white" : "text-white/20",
                  )}
                >
                  {fastingStartTime
                    ? formatFastingTime(fastingElapsed)
                    : "00:00:00"}
                </div>
                {fastingStartTime && (
                  <div className="w-full max-w-[200px] mt-4">
                    <div className="flex justify-between text-[10px] text-muted-foreground mb-1 uppercase tracking-widest">
                      <span>Metabolic Shift</span>
                      <span>{Math.floor(fastingHours)}h</span>
                    </div>
                    <div className="h-1 w-full bg-white/10 rounded-full overflow-hidden">
                      <div
                        className={cn(
                          "h-full rounded-full transition-all duration-1000",
                          fastingPhase.fill,
                        )}
                        style={{
                          width: `${Math.min(100, (fastingHours / 16) * 100)}%`,
                        }}
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* CGM Integration */}
              <div className="mb-6 border-t border-white/5 pt-4">
                {!cgmSynced ? (
                  <Button
                    variant="outline"
                    className="w-full h-10 bg-white/5 border-white/10 hover:bg-white/10 text-xs text-muted-foreground uppercase tracking-widest"
                    onClick={() => {
                      hapticFeedback(10);
                      setCgmSynced(true);
                    }}
                  >
                    <Activity className="w-3 h-3 mr-2" />
                    Sync CGM Device
                  </Button>
                ) : (
                  <div className="flex items-center justify-between bg-white/5 rounded-lg p-3 border border-white/10">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
                        <Activity className="w-4 h-4 text-primary animate-pulse" />
                      </div>
                      <div>
                        <div className="text-[10px] text-muted-foreground uppercase tracking-widest mb-0.5">
                          Blood Glucose
                        </div>
                        <div className="flex items-center gap-1">
                          <span className="text-lg font-bold text-white">
                            {glucoseLevel}
                          </span>
                          <span className="text-xs text-muted-foreground">
                            mg/dL
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="flex flex-col items-end">
                      <Badge
                        variant="outline"
                        className="bg-primary/10 text-primary border-primary/20 text-[9px] mb-1"
                      >
                        LIVE
                      </Badge>
                      <div className="flex items-center text-xs text-muted-foreground">
                        {glucoseTrend === "up" && (
                          <ArrowUpRight className="w-3 h-3 text-orange-400" />
                        )}
                        {glucoseTrend === "down" && (
                          <ArrowDownRight className="w-3 h-3 text-primary" />
                        )}
                        {glucoseTrend === "stable" && (
                          <ArrowRight className="w-3 h-3 text-muted-foreground" />
                        )}
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Ketone Logging */}
              <div className="mb-6 border-t border-white/5 pt-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="text-[10px] text-muted-foreground uppercase tracking-widest">
                    Ketone Level (mmol/L)
                  </div>
                  {ketoneLevel !== null && (
                    <Badge
                      variant="outline"
                      className={cn(
                        "text-[9px] font-bold border",
                        getKetoneColor(ketoneLevel),
                      )}
                    >
                      {getKetoneLabel(ketoneLevel)}
                    </Badge>
                  )}
                </div>
                <div className="flex gap-2 justify-between">
                  {[0.2, 0.8, 1.5, 2.5, 4.0].map((val) => (
                    <Button
                      key={val}
                      variant="outline"
                      className={cn(
                        "h-8 flex-1 text-xs bg-white/5 border-white/10 hover:bg-white/10",
                        ketoneLevel === val && getKetoneColor(val),
                      )}
                      onClick={() => {
                        hapticFeedback(10);
                        setKetoneLevel(val);
                      }}
                    >
                      {val}
                    </Button>
                  ))}
                </div>
              </div>

              <Button
                onClick={toggleFasting}
                className={cn(
                  "w-full h-12 uppercase tracking-widest font-bold text-xs transition-all duration-300",
                  fastingStartTime
                    ? "bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/30"
                    : "bg-primary text-primary-foreground hover:bg-primary/90 shadow-[0_0_20px_rgba(0,255,255,0.3)]",
                )}
                variant={fastingStartTime ? "outline" : "default"}
              >
                {fastingStartTime ? "End Fast" : "Initiate Protocol"}
              </Button>
            </div>

            {/* Metabolic Flexibility */}
            <div className="bg-[#111] border border-white/5 rounded-xl p-5">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Activity className="w-4 h-4 text-purple-400" />
                  <h3 className="font-bold text-sm uppercase tracking-widest text-purple-400">
                    Metabolic Flexibility
                  </h3>
                </div>
                <Badge
                  variant="outline"
                  className="text-[9px] border-purple-500/30 text-purple-400 bg-purple-500/5"
                >
                  Adaptation
                </Badge>
              </div>
              <div className="flex items-center gap-4 mb-4">
                <div className="relative w-16 h-16 flex items-center justify-center shrink-0">
                  <svg className="absolute inset-0 w-full h-full -rotate-90">
                    <circle
                      cx="32"
                      cy="32"
                      r="28"
                      stroke="currentColor"
                      strokeWidth="4"
                      fill="transparent"
                      className="text-white/10"
                    />
                    <circle
                      cx="32"
                      cy="32"
                      r="28"
                      stroke="currentColor"
                      strokeWidth="4"
                      fill="transparent"
                      strokeDasharray={2 * Math.PI * 28}
                      strokeDashoffset={
                        2 *
                        Math.PI *
                        28 *
                        (1 -
                          Math.min(
                            100,
                            65 + fastingHours * 1.5 + (ketoneLevel || 0) * 5,
                          ) /
                            100)
                      }
                      className="text-purple-400 transition-all duration-1000"
                    />
                  </svg>
                  <span className="text-lg font-bold text-white">
                    {Math.floor(
                      Math.min(
                        100,
                        65 + fastingHours * 1.5 + (ketoneLevel || 0) * 5,
                      ),
                    )}
                  </span>
                </div>
                <div>
                  <div className="text-xs font-bold text-white mb-1">
                    Fat-Adaptation Score
                  </div>
                  <div className="text-[10px] text-muted-foreground leading-snug">
                    Calculated from current fasting duration (
                    {Math.floor(fastingHours)}h), ketone levels, and recent CNS
                    load.
                  </div>
                </div>
              </div>
            </div>

            {/* Electrolyte Kinetics */}
            <div className="bg-[#111] border border-white/5 rounded-xl p-5">
              <div className="flex items-center gap-2 mb-1">
                <Activity className="w-4 h-4 text-cyan-400" />
                <h3 className="font-bold text-sm uppercase tracking-widest text-cyan-400">
                  Electrolyte Kinetics
                </h3>
              </div>
              <p className="text-[10px] text-muted-foreground mb-4">
                Estimated serum balance based on live hydration tracking and
                active anomaly strain.
              </p>

              <div className="space-y-4">
                {/* Sodium */}
                <div>
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="font-bold text-white">Sodium (Na+)</span>
                    <span className="text-muted-foreground font-mono">
                      {Math.floor(40 + (hydration / 100) * 55)}%
                    </span>
                  </div>
                  <div className="h-1.5 w-full bg-white/10 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-cyan-400 rounded-full transition-all duration-1000"
                      style={{ width: `${40 + (hydration / 100) * 55}%` }}
                    />
                  </div>
                </div>

                {/* Potassium */}
                <div>
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="font-bold text-white">Potassium (K+)</span>
                    <span className="text-muted-foreground font-mono">
                      {Math.floor(35 + (hydration / 100) * 60)}%
                    </span>
                  </div>
                  <div className="h-1.5 w-full bg-white/10 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-blue-400 rounded-full transition-all duration-1000"
                      style={{ width: `${35 + (hydration / 100) * 60}%` }}
                    />
                  </div>
                </div>

                {/* Magnesium */}
                <div>
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="font-bold text-white">
                      Magnesium (Mg2+)
                    </span>
                    <span className="text-muted-foreground font-mono">
                      {Math.floor(50 + (hydration / 100) * 45)}%
                    </span>
                  </div>
                  <div className="h-1.5 w-full bg-white/10 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-primary rounded-full transition-all duration-1000"
                      style={{ width: `${50 + (hydration / 100) * 45}%` }}
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Bio-Link Section */}

            <div className="bg-[#111] border border-white/5 rounded-xl p-5">
              <div className="flex items-center gap-2 mb-1">
                <Zap className="w-4 h-4 text-primary animate-pulse" />
                <h3 className="font-bold text-sm uppercase tracking-widest text-primary">
                  Bio-Link
                </h3>
              </div>
              <p className="text-xs text-muted-foreground mb-4">
                Sync hydration data from smart devices. Connected sources update
                your Revive tracker automatically.
              </p>

              <div className="space-y-3">
                {/* Apple Health */}
                <div
                  className={cn(
                    "flex items-center gap-4 p-3 rounded-xl border transition-all duration-300",
                    bioLinks.appleHealth
                      ? "bg-green-500/10 border-green-500/30 shadow-[0_0_15px_rgba(34,197,94,0.15)]"
                      : "bg-black/40 border-white/10 hover:border-white/20",
                  )}
                >
                  <div
                    className={cn(
                      "w-10 h-10 rounded-xl flex items-center justify-center text-lg shrink-0",
                      bioLinks.appleHealth ? "bg-green-500/20" : "bg-white/5",
                    )}
                  >
                    🍎
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-bold text-foreground">
                      Apple Health
                    </div>
                    <div className="text-[10px] text-muted-foreground">
                      {bioLinks.appleHealth
                        ? "Hydration data synced · Live"
                        : "Import daily water intake & HRV"}
                    </div>
                  </div>
                  <Button
                    size="sm"
                    disabled={syncingLink === "appleHealth"}
                    onClick={() => connectBioLink("appleHealth")}
                    className={cn(
                      "h-8 px-3 text-[10px] uppercase tracking-wider shrink-0 transition-all",
                      bioLinks.appleHealth
                        ? "bg-green-500/20 text-green-400 border border-green-500/30 cursor-default"
                        : "bg-primary/20 text-primary border border-primary/30 hover:bg-primary/30",
                    )}
                  >
                    {syncingLink === "appleHealth" ? (
                      <span className="flex items-center gap-1">
                        <Wifi className="w-3 h-3 animate-pulse" /> Linking…
                      </span>
                    ) : bioLinks.appleHealth ? (
                      <span className="flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> Linked
                      </span>
                    ) : (
                      "Connect"
                    )}
                  </Button>
                </div>

                {/* HydroBottle */}
                <div
                  className={cn(
                    "flex items-center gap-4 p-3 rounded-xl border transition-all duration-300",
                    bioLinks.hydroBottle
                      ? "bg-blue-500/10 border-blue-500/30 shadow-[0_0_15px_rgba(59,130,246,0.15)]"
                      : "bg-black/40 border-white/10 hover:border-white/20",
                  )}
                >
                  <div
                    className={cn(
                      "w-10 h-10 rounded-xl flex items-center justify-center text-lg shrink-0",
                      bioLinks.hydroBottle ? "bg-blue-500/20" : "bg-white/5",
                    )}
                  >
                    💧
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-bold text-foreground">
                      Smart Hydro Bottle
                    </div>
                    <div className="text-[10px] text-muted-foreground">
                      {bioLinks.hydroBottle
                        ? "Bluetooth active · Auto-logging intake"
                        : "Hidrate Spark, Equa, HidrateSpark BLE"}
                    </div>
                  </div>
                  <Button
                    size="sm"
                    disabled={syncingLink === "hydroBottle"}
                    onClick={() => connectBioLink("hydroBottle")}
                    className={cn(
                      "h-8 px-3 text-[10px] uppercase tracking-wider shrink-0 transition-all",
                      bioLinks.hydroBottle
                        ? "bg-blue-500/20 text-blue-400 border border-blue-500/30 cursor-default"
                        : "bg-blue-500/20 text-blue-400 border border-blue-500/30 hover:bg-blue-500/30",
                    )}
                  >
                    {syncingLink === "hydroBottle" ? (
                      <span className="flex items-center gap-1">
                        <Bluetooth className="w-3 h-3 animate-pulse" /> Pairing…
                      </span>
                    ) : bioLinks.hydroBottle ? (
                      <span className="flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> Paired
                      </span>
                    ) : (
                      "Pair"
                    )}
                  </Button>
                </div>

                {/* WHOOP */}
                <div
                  className={cn(
                    "flex items-center gap-4 p-3 rounded-xl border transition-all duration-300",
                    bioLinks.whoop
                      ? "bg-red-500/10 border-red-500/30 shadow-[0_0_15px_rgba(239,68,68,0.15)]"
                      : "bg-black/40 border-white/10 hover:border-white/20",
                  )}
                >
                  <div
                    className={cn(
                      "w-10 h-10 rounded-xl flex items-center justify-center text-lg shrink-0",
                      bioLinks.whoop ? "bg-red-500/20" : "bg-white/5",
                    )}
                  >
                    ⌚
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-bold text-foreground">
                      WHOOP
                    </div>
                    <div className="text-[10px] text-muted-foreground">
                      {bioLinks.whoop
                        ? "Recovery & strain data streaming"
                        : "Pull recovery, strain & sweat loss data"}
                    </div>
                  </div>
                  <Button
                    size="sm"
                    disabled={syncingLink === "whoop"}
                    onClick={() => connectBioLink("whoop")}
                    className={cn(
                      "h-8 px-3 text-[10px] uppercase tracking-wider shrink-0 transition-all",
                      bioLinks.whoop
                        ? "bg-red-500/20 text-red-400 border border-red-500/30 cursor-default"
                        : "bg-red-500/20 text-red-400 border border-red-500/30 hover:bg-red-500/30",
                    )}
                  >
                    {syncingLink === "whoop" ? (
                      <span className="flex items-center gap-1">
                        <Wifi className="w-3 h-3 animate-pulse" /> Linking…
                      </span>
                    ) : bioLinks.whoop ? (
                      <span className="flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> Linked
                      </span>
                    ) : (
                      "Connect"
                    )}
                  </Button>
                </div>
              </div>

              {Object.values(bioLinks).some(Boolean) && (
                <div className="mt-4 p-3 rounded-xl bg-primary/5 border border-primary/20 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-primary shrink-0" />
                  <div className="text-[10px] text-primary/80 leading-snug">
                    {Object.values(bioLinks).filter(Boolean).length} source
                    {Object.values(bioLinks).filter(Boolean).length > 1
                      ? "s"
                      : ""}{" "}
                    active — hydration data is being aggregated and your Revive
                    score updates in real-time.
                  </div>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent
            value="bodycomp"
            className="space-y-6 animate-in fade-in"
          >
            <div className="bg-[#111] border border-white/5 rounded-2xl p-6 relative overflow-hidden">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="font-bold text-lg text-emerald-400 flex items-center gap-2">
                    <Activity className="w-5 h-5" />
                    Neural Composition
                  </h3>
                  <p className="text-xs text-muted-foreground mt-1">
                    Smart Scale Integration
                  </p>
                </div>
                {!scaleConnected && !scaleSyncing && (
                  <Button
                    onClick={connectScale}
                    className="bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 border border-emerald-500/50 shadow-[0_0_15px_rgba(16,185,129,0.2)]"
                  >
                    <Bluetooth className="w-4 h-4 mr-2" /> Connect
                  </Button>
                )}
                {scaleSyncing && (
                  <Badge
                    variant="outline"
                    className="bg-emerald-500/10 text-emerald-400 border-emerald-500/30 animate-pulse"
                  >
                    <Wifi className="w-3 h-3 mr-1" /> Syncing...
                  </Badge>
                )}
                {scaleConnected && (
                  <Badge
                    variant="outline"
                    className="bg-emerald-500/20 text-emerald-400 border-emerald-500/50"
                  >
                    <CheckCircle2 className="w-3 h-3 mr-1" /> Connected
                  </Badge>
                )}
              </div>

              {!scaleConnected && !scaleSyncing && (
                <div className="flex flex-col items-center justify-center py-12 text-center border border-dashed border-white/10 rounded-xl bg-black/20">
                  <div className="w-16 h-16 rounded-full bg-emerald-500/10 flex items-center justify-center mb-4 border border-emerald-500/20">
                    <Activity className="w-8 h-8 text-emerald-400/50" />
                  </div>
                  <h4 className="text-sm font-bold text-white mb-2">
                    No Scale Detected
                  </h4>
                  <p className="text-xs text-muted-foreground max-w-[200px]">
                    Connect a compatible smart scale to scan your body
                    composition metrics.
                  </p>
                </div>
              )}

              {scaleSyncing && (
                <div className="flex flex-col items-center justify-center py-12">
                  <div className="relative w-32 h-32 flex items-center justify-center">
                    <div
                      className="absolute inset-0 rounded-full border-2 border-emerald-500/20 animate-ping"
                      style={{ animationDuration: "2s" }}
                    />
                    <div
                      className="absolute inset-4 rounded-full border-2 border-emerald-500/40 animate-ping"
                      style={{
                        animationDuration: "2s",
                        animationDelay: "0.5s",
                      }}
                    />
                    <Bluetooth className="w-8 h-8 text-emerald-400 animate-pulse" />
                  </div>
                  <p className="text-xs text-emerald-400 font-mono mt-6 animate-pulse uppercase tracking-widest">
                    Scanning Bio-Impedance...
                  </p>
                </div>
              )}

              {scaleConnected && bodyCompData && (
                <div className="space-y-6 animate-in zoom-in-95 duration-500">
                  <div className="flex flex-col items-center justify-center py-6 bg-emerald-500/5 rounded-xl border border-emerald-500/20 relative overflow-hidden">
                    <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-emerald-500/10 via-transparent to-transparent opacity-50" />

                    <div className="text-[10px] text-emerald-400/80 uppercase tracking-widest font-bold mb-2 relative z-10">
                      Total Mass
                    </div>
                    <div className="flex items-baseline gap-1 relative z-10">
                      <span className="text-5xl font-black text-transparent bg-clip-text bg-gradient-to-b from-white to-white/60 drop-shadow-[0_0_15px_rgba(16,185,129,0.5)]">
                        {bodyCompData.weight}
                      </span>
                      <span className="text-sm text-emerald-400/60 font-bold">
                        lbs
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-black/40 border border-white/5 p-4 rounded-xl relative overflow-hidden group hover:border-emerald-500/30 transition-colors">
                      <div className="absolute inset-0 bg-emerald-500/5 opacity-0 group-hover:opacity-100 transition-opacity" />
                      <div className="text-[10px] text-muted-foreground uppercase tracking-widest mb-1 flex items-center justify-between">
                        Body Fat
                        <Activity className="w-3 h-3 text-emerald-500" />
                      </div>
                      <div className="text-2xl font-bold text-white">
                        {bodyCompData.bodyFat}
                        <span className="text-xs text-muted-foreground ml-1">
                          %
                        </span>
                      </div>
                      <div className="mt-2 h-1 w-full bg-white/10 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-emerald-500"
                          style={{ width: `${bodyCompData.bodyFat}%` }}
                        />
                      </div>
                    </div>

                    <div className="bg-black/40 border border-white/5 p-4 rounded-xl relative overflow-hidden group hover:border-blue-500/30 transition-colors">
                      <div className="absolute inset-0 bg-blue-500/5 opacity-0 group-hover:opacity-100 transition-opacity" />
                      <div className="text-[10px] text-muted-foreground uppercase tracking-widest mb-1 flex items-center justify-between">
                        Muscle Mass
                        <Dumbbell className="w-3 h-3 text-blue-500" />
                      </div>
                      <div className="text-2xl font-bold text-white">
                        {bodyCompData.muscleMass}
                        <span className="text-xs text-muted-foreground ml-1">
                          %
                        </span>
                      </div>
                      <div className="mt-2 h-1 w-full bg-white/10 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-blue-500"
                          style={{ width: `${bodyCompData.muscleMass}%` }}
                        />
                      </div>
                    </div>

                    <div className="bg-black/40 border border-white/5 p-4 rounded-xl relative overflow-hidden group hover:border-cyan-500/30 transition-colors">
                      <div className="absolute inset-0 bg-cyan-500/5 opacity-0 group-hover:opacity-100 transition-opacity" />
                      <div className="text-[10px] text-muted-foreground uppercase tracking-widest mb-1 flex items-center justify-between">
                        Water Weight
                        <Droplets className="w-3 h-3 text-cyan-500" />
                      </div>
                      <div className="text-2xl font-bold text-white">
                        {bodyCompData.waterWeight}
                        <span className="text-xs text-muted-foreground ml-1">
                          %
                        </span>
                      </div>
                      <div className="mt-2 h-1 w-full bg-white/10 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-cyan-500"
                          style={{ width: `${bodyCompData.waterWeight}%` }}
                        />
                      </div>
                    </div>

                    <div className="bg-black/40 border border-white/5 p-4 rounded-xl relative overflow-hidden group hover:border-purple-500/30 transition-colors">
                      <div className="absolute inset-0 bg-purple-500/5 opacity-0 group-hover:opacity-100 transition-opacity" />
                      <div className="text-[10px] text-muted-foreground uppercase tracking-widest mb-1 flex items-center justify-between">
                        Bone Density
                        <Zap className="w-3 h-3 text-purple-500" />
                      </div>
                      <div className="text-2xl font-bold text-white">
                        {bodyCompData.boneDensity}
                        <span className="text-xs text-muted-foreground ml-1">
                          lbs
                        </span>
                      </div>
                      <div className="mt-2 h-1 w-full bg-white/10 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-purple-500"
                          style={{ width: "80%" }}
                        />
                      </div>
                    </div>

                    <div className="col-span-2 bg-black/40 border border-white/5 p-4 rounded-xl relative group hover:border-orange-500/30 transition-colors">
                      <div className="absolute inset-0 bg-orange-500/5 opacity-0 group-hover:opacity-100 transition-opacity rounded-xl" />
                      <div className="text-[10px] text-muted-foreground uppercase tracking-widest mb-1 flex items-center justify-between">
                        Visceral Fat & Metabolic Risk
                        <Activity className="w-3 h-3 text-orange-500" />
                      </div>
                      <div className="flex items-end justify-between">
                        <div className="text-2xl font-bold text-white">
                          {bodyCompData.visceralFat}
                          <span className="text-xs text-muted-foreground ml-1">
                            lvl
                          </span>
                        </div>
                        <Badge
                          variant="outline"
                          className="bg-emerald-500/10 text-emerald-400 border-emerald-500/30 text-[10px] uppercase tracking-widest"
                        >
                          Low Risk
                        </Badge>
                      </div>
                      <div className="mt-3 relative h-1.5 w-full bg-white/10 rounded-full flex">
                        <div
                          className="h-full bg-emerald-500 rounded-l-full"
                          style={{ width: "30%" }}
                        />
                        <div
                          className="h-full bg-yellow-500"
                          style={{ width: "40%" }}
                        />
                        <div
                          className="h-full bg-red-500 rounded-r-full"
                          style={{ width: "30%" }}
                        />
                        <div
                          className="absolute h-3 w-1 bg-white top-1/2 -translate-y-1/2 rounded-full shadow-[0_0_5px_white] transition-all duration-1000"
                          style={{
                            left: `calc(${(bodyCompData.visceralFat / 20) * 100}% - 2px)`,
                          }}
                        />
                      </div>
                    </div>

                    <div className="col-span-2 bg-black/40 border border-white/5 p-4 rounded-xl relative group hover:border-blue-500/30 transition-colors">
                      <div className="absolute inset-0 bg-blue-500/5 opacity-0 group-hover:opacity-100 transition-opacity rounded-xl" />
                      <div className="text-[10px] text-muted-foreground uppercase tracking-widest mb-1 flex items-center justify-between">
                        Muscle Symmetry Analysis
                        <Dumbbell className="w-3 h-3 text-blue-500" />
                      </div>
                      <div className="flex items-end justify-between mb-3">
                        <div className="text-2xl font-bold text-white">
                          {bodyCompData.symmetry.score}
                          <span className="text-xs text-muted-foreground ml-1">
                            score
                          </span>
                        </div>
                        <Badge
                          variant="outline"
                          className="bg-blue-500/10 text-blue-400 border-blue-500/30 text-[10px] uppercase tracking-widest"
                        >
                          {bodyCompData.symmetry.dominant} Dominant
                        </Badge>
                      </div>

                      <div className="flex justify-between text-[10px] text-muted-foreground mb-1.5 font-mono">
                        <span>L: {bodyCompData.symmetry.left}%</span>
                        <span>R: {bodyCompData.symmetry.right}%</span>
                      </div>
                      <div className="relative h-2 w-full bg-white/10 rounded-full flex overflow-hidden">
                        <div
                          className="h-full bg-cyan-400 transition-all duration-1000"
                          style={{ width: `${bodyCompData.symmetry.left}%` }}
                        />
                        <div
                          className="h-full bg-blue-600 transition-all duration-1000"
                          style={{ width: `${bodyCompData.symmetry.right}%` }}
                        />
                        <div className="absolute h-4 w-0.5 bg-white top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-10 opacity-50" />
                      </div>

                      <div className="mt-4 space-y-3 pt-3 border-t border-white/5">
                        <div className="text-[9px] text-muted-foreground uppercase tracking-widest font-bold mb-2">
                          Regional Breakdown
                        </div>

                        {[
                          {
                            label: "Arms",
                            data: bodyCompData.symmetry.breakdown.arms,
                          },
                          {
                            label: "Legs",
                            data: bodyCompData.symmetry.breakdown.legs,
                          },
                          {
                            label: "Trunk",
                            data: bodyCompData.symmetry.breakdown.trunk,
                          },
                        ].map((region) => (
                          <div key={region.label}>
                            <div className="flex justify-between text-[9px] text-muted-foreground mb-1 font-mono">
                              <span>
                                {region.label} L: {region.data.left}%
                              </span>
                              <span>R: {region.data.right}%</span>
                            </div>
                            <div className="relative h-1.5 w-full bg-white/10 rounded-full flex overflow-hidden">
                              <div
                                className="h-full bg-cyan-400/70 transition-all duration-1000"
                                style={{ width: `${region.data.left}%` }}
                              />
                              <div
                                className="h-full bg-blue-600/70 transition-all duration-1000"
                                style={{ width: `${region.data.right}%` }}
                              />
                              <div className="absolute h-4 w-0.5 bg-white top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-10 opacity-30" />
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Optical Posture Analysis */}
                    <div className="col-span-2 bg-black/40 border border-white/5 p-4 rounded-xl relative group hover:border-cyan-500/30 transition-colors">
                      <div className="absolute inset-0 bg-cyan-500/5 opacity-0 group-hover:opacity-100 transition-opacity rounded-xl" />
                      <div className="text-[10px] text-muted-foreground uppercase tracking-widest mb-3 flex items-center justify-between">
                        Optical Posture Analysis
                        <Camera className="w-3 h-3 text-cyan-500" />
                      </div>

                      {!postureScanning && !postureData && (
                        <div className="flex flex-col items-center justify-center py-6 border border-dashed border-white/10 rounded-lg bg-black/20">
                          <Camera className="w-8 h-8 text-cyan-400/50 mb-3" />
                          <Button
                            onClick={startPostureScan}
                            className="bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-400 border border-cyan-500/50 shadow-[0_0_15px_rgba(6,182,212,0.2)] text-xs h-8"
                          >
                            <Scan className="w-3 h-3 mr-2" /> Initialize Scan
                          </Button>
                        </div>
                      )}

                      {postureScanning && (
                        <div className="flex flex-col items-center justify-center py-6 border border-cyan-500/30 rounded-lg bg-cyan-500/5 relative overflow-hidden">
                          <div className="absolute top-0 left-0 w-full h-[2px] bg-cyan-400 shadow-[0_0_10px_rgba(6,182,212,0.8)] animate-[scan_2s_ease-in-out_infinite]" />
                          <Scan className="w-10 h-10 text-cyan-400 animate-pulse mb-3" />
                          <div className="text-[10px] font-mono text-cyan-400 uppercase tracking-widest animate-pulse">
                            Analyzing Biomechanics...
                          </div>
                          <style>{`
                            @keyframes scan {
                              0% { top: 0; opacity: 0; }
                              10% { opacity: 1; }
                              90% { opacity: 1; }
                              100% { top: 100%; opacity: 0; }
                            }
                          `}</style>
                        </div>
                      )}

                      {postureData && !postureScanning && (
                        <div className="animate-in fade-in zoom-in-95 duration-500">
                          <div className="flex items-end justify-between mb-4">
                            <div className="text-2xl font-bold text-white">
                              {postureData.score}
                              <span className="text-xs text-muted-foreground ml-1">
                                alignment
                              </span>
                            </div>
                            <Badge
                              variant="outline"
                              className="bg-cyan-500/10 text-cyan-400 border-cyan-500/30 text-[10px] uppercase tracking-widest"
                            >
                              Scan Complete
                            </Badge>
                          </div>

                          <div className="grid grid-cols-3 gap-2">
                            {[
                              { label: "Cervical", data: postureData.head },
                              {
                                label: "Shoulders",
                                data: postureData.shoulders,
                              },
                              { label: "Pelvic", data: postureData.hips },
                            ].map((item, i) => (
                              <div
                                key={i}
                                className="bg-white/5 rounded-lg p-2 border border-white/10 relative overflow-hidden"
                              >
                                <div
                                  className={cn(
                                    "absolute top-0 left-0 w-1 h-full",
                                    item.data.status === "optimal"
                                      ? "bg-emerald-500"
                                      : item.data.status === "warning"
                                        ? "bg-yellow-500"
                                        : "bg-red-500",
                                  )}
                                />
                                <div className="pl-2">
                                  <div className="text-[9px] text-muted-foreground uppercase tracking-widest mb-1">
                                    {item.label}
                                  </div>
                                  <div className="text-sm font-bold text-white flex items-center gap-1">
                                    {item.data.tilt}°
                                    <span className="text-[10px] text-muted-foreground font-normal">
                                      {item.data.direction}
                                    </span>
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>

                          <div className="mt-3 p-2 rounded bg-cyan-500/10 border border-cyan-500/20 text-[10px] text-cyan-400 leading-relaxed">
                            <strong className="font-bold">Insight:</strong>{" "}
                            Pelvic tilt detected. Recommended somatic release
                            protocol for right hip flexor and lower back
                            stabilization.
                          </div>

                          {showCorrection ? (
                            <div className="mt-3 p-4 border border-cyan-500/30 rounded-lg bg-black/40 relative overflow-hidden flex flex-col items-center justify-center animate-in zoom-in duration-300">
                              <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(6,182,212,0.15),transparent_70%)]" />
                              <div className="text-[10px] text-cyan-400 uppercase tracking-widest mb-2 z-10 text-center">
                                AI Alignment Overlay
                              </div>
                              <div className="relative w-24 h-40 z-10">
                                {/* Ideal Alignment (Green) */}
                                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[2px] h-full bg-emerald-500/50 shadow-[0_0_8px_rgba(16,185,129,0.5)]" />
                                <div className="absolute top-[20%] left-1/2 -translate-x-1/2 w-12 h-[2px] bg-emerald-500/50" />
                                <div className="absolute top-[50%] left-1/2 -translate-x-1/2 w-10 h-[2px] bg-emerald-500/50" />

                                {/* Current Alignment (Red/Yellow) */}
                                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[2px] h-full bg-red-500/80 rotate-[4deg] origin-bottom shadow-[0_0_8px_rgba(239,68,68,0.5)]" />
                                <div className="absolute top-[20%] left-1/2 -translate-x-1/2 w-12 h-[2px] bg-yellow-500/80 rotate-[-2deg]" />
                                <div className="absolute top-[50%] left-1/2 -translate-x-1/2 w-10 h-[2px] bg-red-500/80 rotate-[-5deg]" />
                              </div>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => setShowCorrection(false)}
                                className="w-full mt-4 h-6 text-[9px] text-cyan-400 hover:text-white uppercase tracking-widest border border-cyan-500/30"
                              >
                                Hide Correction
                              </Button>
                            </div>
                          ) : (
                            <div className="grid grid-cols-2 gap-2 mt-2">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => setShowCorrection(true)}
                                className="w-full h-6 text-[9px] text-cyan-400 hover:text-white uppercase tracking-widest border border-cyan-500/30 bg-cyan-500/10 hover:bg-cyan-500/20"
                              >
                                View AI Correction
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={startPostureScan}
                                className="w-full h-6 text-[9px] text-muted-foreground hover:text-white uppercase tracking-widest"
                              >
                                Rescan
                              </Button>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-xs text-emerald-400 leading-relaxed">
                    <strong className="font-bold">Neural Insight:</strong> Your
                    muscle mass-to-fat ratio is optimal for high-intensity
                    cognitive and physical load. Hydration levels indicate
                    strong cellular volumization.
                  </div>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
        <BoxBreathingModal
          open={boxBreathingModalOpen}
          onOpenChange={setBoxBreathingModalOpen}
        />
      </main>

      {activeProtocol && (
        <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-black/90 backdrop-blur-md animate-in fade-in duration-300">
          <div className="absolute top-6 right-6">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setActiveProtocol(null)}
              className="text-muted-foreground hover:text-white"
            >
              Abort
            </Button>
          </div>

          <div className="text-center mb-12 px-6">
            <h2 className="text-2xl font-bold text-white mb-2 tracking-widest uppercase">
              Neural Recovery
            </h2>
            <p className="text-sm text-red-400">
              Clearing {anomalyZones[activeProtocol]?.label} Anomaly
            </p>
          </div>

          <div className="relative w-64 h-64 flex items-center justify-center mb-12">
            <svg className="absolute inset-0 w-full h-full -rotate-90">
              <circle
                cx="128"
                cy="128"
                r="120"
                stroke="currentColor"
                strokeWidth="4"
                fill="transparent"
                className="text-white/10"
              />
              <circle
                cx="128"
                cy="128"
                r="120"
                stroke="currentColor"
                strokeWidth="8"
                fill="transparent"
                strokeDasharray={2 * Math.PI * 120}
                strokeDashoffset={
                  2 * Math.PI * 120 * (1 - protocolProgress / 100)
                }
                className="text-primary transition-all duration-75"
                style={{ filter: "drop-shadow(0 0 10px hsl(var(--primary)))" }}
              />
            </svg>
            <div className="text-center">
              <div className="text-4xl font-bold text-white">
                {Math.round(protocolProgress)}%
              </div>
              <div className="text-xs text-primary uppercase tracking-widest mt-1">
                Sync
              </div>
            </div>
          </div>

          <Button
            className={cn(
              "w-48 h-16 rounded-2xl text-lg font-bold uppercase tracking-widest transition-all duration-200",
              isSyncing
                ? "bg-primary text-primary-foreground scale-95 shadow-[0_0_30px_hsl(var(--primary))]"
                : "bg-white/10 text-white hover:bg-white/20 border border-white/20",
            )}
            onPointerDown={() => {
              hapticFeedback(10);
              setIsSyncing(true);
            }}
            onPointerUp={() => {
              setIsSyncing(false);
            }}
            onPointerLeave={() => {
              setIsSyncing(false);
            }}
            onContextMenu={(e) => e.preventDefault()}
            style={{ touchAction: "none" }}
          >
            {isSyncing ? "Syncing..." : "Hold to Sync"}
          </Button>
        </div>
      )}
    </div>
  );
}
