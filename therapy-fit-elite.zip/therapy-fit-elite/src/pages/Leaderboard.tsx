import { useState, useRef, useEffect } from "react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { useToast } from "@/components/ui/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  Crown,
  Medal,
  TrendingUp,
  Activity,
  UserPlus,
  Link2,
  Mail,
  Search,
  Swords,
  Shield,
  Eye,
  Zap,
  Flame,
  Clock,
  Trophy,
  Globe,
  Bell,
  Users,
  MessageSquare,
  Send,
  Mic,
  Square,
  Play,
  AudioLines,
  Check,
  CheckCheck,
  Award,
  Bookmark,
  Crosshair,
  Hexagon,
  BrainCircuit,
} from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Logo } from "@/components/Logo";
import { useNavigate } from "react-router-dom";
import { cn, hapticFeedback } from "@/lib/utils";
import { Progress } from "@/components/ui/progress";
import { NeuralNotificationCenter } from "@/components/NeuralNotifications";

const mockSectorsLeaderboard = [
  {
    id: 1,
    name: "Sector-7 (North America)",
    intensity: 94.2,
    status: "Optimal",
    activeNodes: 1240,
    trend: "up",
  },
  {
    id: 2,
    name: "Sector-3 (Europe)",
    intensity: 89.8,
    status: "Stable",
    activeNodes: 980,
    trend: "up",
  },
  {
    id: 3,
    name: "Sector-5 (Asia-Pacific)",
    intensity: 82.5,
    status: "Syncing",
    activeNodes: 750,
    trend: "down",
  },
  {
    id: 4,
    name: "Sector-1 (South America)",
    intensity: 78.1,
    status: "Calibrating",
    activeNodes: 420,
    trend: "up",
  },
  {
    id: 5,
    name: "Sector-8 (Africa)",
    intensity: 72.4,
    status: "Low Latency",
    activeNodes: 310,
    trend: "up",
  },
];

const mockFriendsLeaderboard = [
  {
    id: 10,
    name: "You (Current)",
    score: 89.5,
    trend: "up",
    avatar: "https://i.pravatar.cc/150?u=10",
    isCurrentUser: true,
    history: [80, 82, 85, 84, 86, 88, 89.5],
    duelStatus: "none",
    neuralBadge: "pro",
  },
  {
    id: 11,
    name: "Sarah_Opt",
    score: 88.2,
    trend: "up",
    avatar: "https://i.pravatar.cc/150?u=11",
    history: [85, 84, 85, 86, 87, 88, 88.2],
    duelStatus: "active",
    neuralBadge: "elite",
  },
  {
    id: 12,
    name: "Mike_Flow",
    score: 85.4,
    trend: "down",
    avatar: "https://i.pravatar.cc/150?u=12",
    history: [88, 89, 87, 86, 88, 86, 85.4],
    duelStatus: "none",
    neuralBadge: "pro",
  },
  {
    id: 13,
    name: "Elena_Bio",
    score: 82.1,
    trend: "up",
    avatar: "https://i.pravatar.cc/150?u=13",
    history: [75, 76, 78, 79, 80, 81, 82.1],
    duelStatus: "won",
    neuralBadge: "elite",
  },
  {
    id: 14,
    name: "David_Neural",
    score: 79.8,
    trend: "down",
    avatar: "https://i.pravatar.cc/150?u=14",
    history: [85, 84, 83, 82, 81, 80, 79.8],
    duelStatus: "pending",
    neuralBadge: "basic",
  },
];

const mockTeamLeaderboard = [
  {
    id: 30,
    name: "Alpha Squad",
    score: 94.2,
    trend: "up",
    members: 12,
    avatar: "https://i.pravatar.cc/150?u=30",
    status: "Optimal",
  },
  {
    id: 31,
    name: "Neural Knights",
    score: 91.5,
    trend: "up",
    members: 8,
    avatar: "https://i.pravatar.cc/150?u=31",
    status: "Stable",
  },
  {
    id: 32,
    name: "Bio Hackers (Yours)",
    score: 89.8,
    trend: "up",
    members: 5,
    avatar: "https://i.pravatar.cc/150?u=32",
    status: "Syncing",
    isCurrentUser: true,
  },
  {
    id: 33,
    name: "Flow State Elites",
    score: 86.4,
    trend: "down",
    members: 15,
    avatar: "https://i.pravatar.cc/150?u=33",
    status: "Calibrating",
  },
  {
    id: 34,
    name: "Zenith Vanguard",
    score: 82.1,
    trend: "up",
    members: 6,
    avatar: "https://i.pravatar.cc/150?u=34",
    status: "Low Latency",
  },
];

const mockTeamMembers = [
  {
    id: 10,
    name: "You (Current)",
    score: 89.5,
    trend: "up",
    avatar: "https://i.pravatar.cc/150?u=10",
    isCurrentUser: true,
    history: [80, 82, 85, 84, 86, 88, 89.5],
    role: "Captain",
  },
  {
    id: 11,
    name: "Sarah_Opt",
    score: 88.2,
    trend: "up",
    avatar: "https://i.pravatar.cc/150?u=11",
    history: [85, 84, 85, 86, 87, 88, 88.2],
    role: "Member",
  },
  {
    id: 12,
    name: "Mike_Flow",
    score: 85.4,
    trend: "down",
    avatar: "https://i.pravatar.cc/150?u=12",
    history: [88, 89, 87, 86, 88, 86, 85.4],
    role: "Member",
  },
  {
    id: 13,
    name: "Elena_Bio",
    score: 82.1,
    trend: "up",
    avatar: "https://i.pravatar.cc/150?u=13",
    history: [75, 76, 78, 79, 80, 81, 82.1],
    role: "Member",
  },
];

const mockLeaderboard = [
  {
    id: 1,
    name: "Sovereign_X",
    score: 99.8,
    trend: "up",
    avatar: "https://i.pravatar.cc/150?u=1",
    history: [95, 96, 97, 98, 99, 99.5, 99.8],
    duelStatus: "none",
    neuralBadge: "master",
  },
  {
    id: 2,
    name: "NeuralMaster",
    score: 98.5,
    trend: "up",
    avatar: "https://i.pravatar.cc/150?u=2",
    history: [94, 95, 96, 97, 98, 98.2, 98.5],
    duelStatus: "none",
    neuralBadge: "master",
  },
  {
    id: 3,
    name: "FlowState_99",
    score: 97.2,
    trend: "down",
    avatar: "https://i.pravatar.cc/150?u=3",
    history: [98, 98.5, 99, 98.5, 98, 97.5, 97.2],
    duelStatus: "none",
    neuralBadge: "master",
  },
  {
    id: 4,
    name: "OptimumProtocol",
    score: 95.1,
    trend: "up",
    avatar: "https://i.pravatar.cc/150?u=4",
    history: [90, 91, 92, 93, 94, 94.5, 95.1],
    duelStatus: "none",
    neuralBadge: "pro",
  },
  {
    id: 5,
    name: "ApexCognition",
    score: 94.8,
    trend: "up",
    avatar: "https://i.pravatar.cc/150?u=5",
    history: [92, 92.5, 93, 93.5, 94, 94.5, 94.8],
    duelStatus: "none",
    neuralBadge: "pro",
  },
  {
    id: 6,
    name: "BioHacker_Elite",
    score: 93.5,
    trend: "down",
    avatar: "https://i.pravatar.cc/150?u=6",
    history: [95, 96, 95.5, 95, 94.5, 94, 93.5],
    duelStatus: "none",
    neuralBadge: "elite",
  },
  {
    id: 7,
    name: "ZenithMind",
    score: 92.9,
    trend: "up",
    avatar: "https://i.pravatar.cc/150?u=7",
    history: [88, 89, 90, 91, 92, 92.5, 92.9],
    duelStatus: "none",
    neuralBadge: "elite",
  },
  {
    id: 8,
    name: "AlphaWave",
    score: 91.4,
    trend: "down",
    avatar: "https://i.pravatar.cc/150?u=8",
    history: [94, 93.5, 93, 92.5, 92, 91.5, 91.4],
    duelStatus: "none",
    neuralBadge: "pro",
  },
  {
    id: 9,
    name: "SynapseForge",
    score: 90.2,
    trend: "up",
    avatar: "https://i.pravatar.cc/150?u=9",
    history: [85, 86, 87, 88, 89, 89.5, 90.2],
    duelStatus: "none",
    neuralBadge: "elite",
  },
  {
    id: 10,
    name: "You (Current)",
    score: 89.5,
    trend: "up",
    avatar: "https://i.pravatar.cc/150?u=10",
    isCurrentUser: true,
    history: [80, 82, 85, 84, 86, 88, 89.5],
    duelStatus: "none",
    neuralBadge: "pro",
    streak: 7,
  },
];

const mockStreakLeaderboard = [
  {
    id: 20,
    name: "Streak_King",
    score: 45,
    trend: "up",
    avatar: "https://i.pravatar.cc/150?u=20",
    history: [39, 40, 41, 42, 43, 44, 45],
    neuralBadge: "master",
    streak: 45,
    category: "HRV",
  },
  {
    id: 21,
    name: "Focus_Flow",
    score: 38,
    trend: "up",
    avatar: "https://i.pravatar.cc/150?u=21",
    history: [32, 33, 34, 35, 36, 37, 38],
    neuralBadge: "pro",
    streak: 38,
    category: "Sleep",
  },
  {
    id: 22,
    name: "Neural_Link",
    score: 32,
    trend: "up",
    avatar: "https://i.pravatar.cc/150?u=22",
    history: [26, 27, 28, 29, 30, 31, 32],
    neuralBadge: "elite",
    streak: 32,
    category: "CNS Load",
  },
  {
    id: 23,
    name: "Bio_Hacker",
    score: 28,
    trend: "down",
    avatar: "https://i.pravatar.cc/150?u=23",
    history: [30, 31, 30, 29, 28, 28, 28],
    neuralBadge: "pro",
    streak: 28,
    category: "Hydration",
  },
  {
    id: 24,
    name: "Optimum_Prime",
    score: 24,
    trend: "up",
    avatar: "https://i.pravatar.cc/150?u=24",
    history: [18, 19, 20, 21, 22, 23, 24],
    neuralBadge: "elite",
    streak: 24,
    category: "Blue Light",
  },
  {
    id: 10,
    name: "You (Current)",
    score: 30,
    trend: "up",
    avatar: "https://i.pravatar.cc/150?u=10",
    isCurrentUser: true,
    history: [24, 25, 26, 27, 28, 29, 30],
    neuralBadge: "pro",
    streak: 30,
    category: "Sleep",
  },
];

const mockGlobalStreaks = [
  {
    id: 1,
    city: "San Francisco",
    lat: 37.7749,
    lng: -122.4194,
    streak: 112,
    category: "HRV",
    user: "BioHacker_SF",
    sector: "Sector-7",
  },
  {
    id: 2,
    city: "London",
    lat: 51.5074,
    lng: -0.1278,
    streak: 94,
    category: "Sleep",
    user: "Neural_LDN",
    sector: "Sector-3",
  },
  {
    id: 3,
    city: "Tokyo",
    lat: 35.6762,
    lng: 139.6503,
    streak: 145,
    category: "CNS Load",
    user: "Zen_Tokyo",
    sector: "Sector-5",
  },
  {
    id: 4,
    city: "Berlin",
    lat: 52.52,
    lng: 13.405,
    streak: 82,
    category: "Hydration",
    user: "Flow_Berlin",
    sector: "Sector-3",
  },
  {
    id: 5,
    city: "New York",
    lat: 40.7128,
    lng: -74.006,
    streak: 108,
    category: "Blue Light",
    user: "Gotham_Elite",
    sector: "Sector-7",
  },
  {
    id: 6,
    city: "Sydney",
    lat: -33.8688,
    lng: 151.2093,
    streak: 76,
    category: "HRV",
    user: "Oz_Optimizer",
    sector: "Sector-5",
  },
];

const mockSectorChallenges = [
  {
    id: 1,
    title: "Operation: Deep Sleep",
    target: "50,000 Collective Sleep Hrs",
    current: 42300,
    sector1: "Sector-7",
    sector2: "Sector-3",
    leading: "Sector-7",
    timeRemaining: "12h 45m",
    reward: "500 PTS",
  },
  {
    id: 2,
    title: "Hydration Supremacy",
    target: "10,000L Logged",
    current: 8400,
    sector1: "Sector-5",
    sector2: "Sector-8",
    leading: "Sector-5",
    timeRemaining: "4h 12m",
    reward: "250 PTS",
  },
  {
    id: 3,
    title: "HRV Coherence",
    target: "Avg > 80ms",
    current: 78,
    sector1: "Sector-3",
    sector2: "Sector-1",
    leading: "Sector-3",
    timeRemaining: "2d 6h",
    reward: "1000 PTS",
  },
];

const mockNeuralDuels = [
  {
    id: 1,
    sector1: "Sector-7",
    sector2: "Sector-3",
    metric: "Peak HRV",
    s1Score: 92,
    s2Score: 88,
    timeRemaining: "04h 12m",
    pool: "5,000 PTS",
    leading: "Sector-7",
  },
  {
    id: 2,
    sector1: "Sector-5",
    sector2: "Sector-1",
    metric: "Lowest CNS Load",
    s1Score: 42,
    s2Score: 45,
    timeRemaining: "12h 45m",
    pool: "2,500 PTS",
    leading: "Sector-5",
  },
];

const mockHistoricalDuels = [
  {
    id: 101,
    sector1: "Sector-7",
    sector2: "Sector-5",
    metric: "REM Sleep %",
    s1Score: 28,
    s2Score: 24,
    winner: "Sector-7",
    date: "2026-05-28",
    pool: "10,000 PTS",
  },
  {
    id: 102,
    sector1: "Sector-3",
    sector2: "Sector-1",
    metric: "Max Hydration",
    s1Score: 98,
    s2Score: 99,
    winner: "Sector-1",
    date: "2026-05-25",
    pool: "4,000 PTS",
  },
  {
    id: 103,
    sector1: "Sector-8",
    sector2: "Sector-7",
    metric: "Lowest CNS Load",
    s1Score: 55,
    s2Score: 38,
    winner: "Sector-7",
    date: "2026-05-20",
    pool: "8,500 PTS",
  },
];

const Sparkline = ({
  data,
  color,
  name,
  comparisonData,
  comparisonName,
}: {
  data: number[];
  color: string;
  name: string;
  comparisonData?: number[];
  comparisonName?: string;
}) => {
  const allData = comparisonData ? [...data, ...comparisonData] : data;
  const min = Math.min(...allData);
  const max = Math.max(...allData);
  const range = max - min || 1;
  const width = 48;
  const height = 16;

  const getPoints = (pointsData: number[]) =>
    pointsData
      .map((val, i) => {
        const x = (i / (pointsData.length - 1)) * width;
        const y = height - ((val - min) / range) * height;
        return x + "," + y;
      })
      .join(" ");

  const points = getPoints(data);
  const comparePoints = comparisonData ? getPoints(comparisonData) : null;

  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <div className="cursor-help hover:opacity-100 transition-opacity group relative">
          <svg
            width={width}
            height={height}
            viewBox={"0 0 " + width + " " + height}
            className="overflow-visible"
          >
            {comparePoints && (
              <polyline
                fill="none"
                stroke="hsl(var(--muted-foreground) / 0.3)"
                strokeWidth="1"
                strokeDasharray="2,2"
                strokeLinecap="round"
                strokeLinejoin="round"
                points={comparePoints}
                className="transition-all duration-300"
              />
            )}
            <polyline
              fill="none"
              stroke={color}
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
              points={points}
              className="transition-all duration-300 group-hover:stroke-white"
            />
          </svg>
        </div>
      </TooltipTrigger>
      <TooltipContent
        side="top"
        className="p-3 bg-card/95 border-border/50 backdrop-blur-md shadow-xl min-w-[180px]"
      >
        <div className="space-y-3">
          <div className="flex items-center justify-between gap-4">
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">
              {comparisonName ? "Neural Comparison" : `${name}'s Path`}
            </p>
            <Badge
              variant="outline"
              className="text-[10px] h-4 px-1 border-primary/30 text-primary"
            >
              7D
            </Badge>
          </div>

          <div className="space-y-4">
            <div className="space-y-1.5">
              <div className="flex justify-between items-center text-[10px]">
                <span className="font-medium text-foreground">{name}</span>
                <span className="font-mono text-primary font-bold">
                  {data[data.length - 1]}
                </span>
              </div>
              <div className="flex gap-0.5 items-end h-6">
                {data.map((v, i) => (
                  <div
                    key={i}
                    className={cn(
                      "flex-1 rounded-t-[1px] transition-all duration-300",
                      i === data.length - 1 ? "bg-primary" : "bg-primary/20",
                    )}
                    style={{ height: `${(v / 100) * 100}%` }}
                  />
                ))}
              </div>
            </div>

            {comparisonData && (
              <div className="space-y-1.5 border-t border-border/30 pt-3">
                <div className="flex justify-between items-center text-[10px]">
                  <span className="font-medium text-muted-foreground">
                    {comparisonName}
                  </span>
                  <span className="font-mono text-muted-foreground">
                    {comparisonData[comparisonData.length - 1]}
                  </span>
                </div>
                <div className="flex gap-0.5 items-end h-4 opacity-50">
                  {comparisonData.map((v, i) => (
                    <div
                      key={i}
                      className="flex-1 rounded-t-[1px] bg-muted-foreground/40"
                      style={{ height: `${(v / 100) * 100}%` }}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="flex justify-between items-center text-[10px] font-mono pt-1 border-t border-border/30">
            <div className="flex flex-col">
              <span className="text-muted-foreground">START</span>
              <span className="font-bold">{data[0]}</span>
            </div>
            <TrendingUp
              className={cn(
                "w-3 h-3",
                color.includes("142") ? "text-green-500" : "text-destructive",
              )}
            />
            <div className="flex flex-col items-end">
              <span className="text-muted-foreground">CURRENT</span>
              <span className="font-bold text-primary">
                {data[data.length - 1]}
              </span>
            </div>
          </div>
        </div>
      </TooltipContent>
    </Tooltip>
  );
};

const NeuralBadge = ({
  type,
  className,
}: {
  type: string;
  className?: string;
}) => {
  const badgeConfig = {
    master: {
      icon: Crown,
      color: "text-yellow-400",
      bg: "bg-yellow-400/20",
      glow: "shadow-[0_0_10px_rgba(250,204,21,0.5)] group-hover:shadow-[0_0_20px_rgba(250,204,21,0.8)]",
      label: "Master",
      animation: "animate-[pulse_2s_ease-in-out_infinite]",
    },
    pro: {
      icon: Zap,
      color: "text-fuchsia-500",
      bg: "bg-fuchsia-500/20",
      glow: "shadow-[0_0_10px_rgba(217,70,239,0.5)] group-hover:shadow-[0_0_20px_rgba(217,70,239,0.8)]",
      label: "Pro",
      animation: "animate-[pulse_3s_ease-in-out_infinite]",
    },
    elite: {
      icon: Shield,
      color: "text-primary",
      bg: "bg-primary/20",
      glow: "shadow-[0_0_10px_rgba(0,200,200,0.5)] group-hover:shadow-[0_0_20px_rgba(0,200,200,0.8)]",
      label: "Elite",
      animation: "animate-[pulse_4s_ease-in-out_infinite]",
    },
    basic: {
      icon: Activity,
      color: "text-muted-foreground",
      bg: "bg-muted/20",
      glow: "group-hover:shadow-[0_0_10px_rgba(255,255,255,0.2)]",
      label: "Seeker",
      animation: "",
    },
  };

  const config =
    badgeConfig[type as keyof typeof badgeConfig] || badgeConfig.basic;
  const Icon = config.icon;

  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <div
          className={cn(
            "absolute -bottom-1 -left-1 flex items-center justify-center rounded-full p-1 border-2 border-background z-10 cursor-pointer group transition-all duration-300 hover:scale-125 hover:-translate-y-1",
            config.bg,
            config.glow,
            className,
          )}
        >
          <Icon
            className={cn(
              "w-2.5 h-2.5 transition-transform duration-300 group-hover:rotate-12",
              config.color,
              config.animation,
            )}
          />
        </div>
      </TooltipTrigger>
      <TooltipContent
        side="right"
        className="text-[10px] font-bold uppercase tracking-wider bg-card/95 backdrop-blur-md border-primary/50 text-primary shadow-[0_0_15px_rgba(0,255,255,0.3)]"
      >
        {config.label} Status
      </TooltipContent>
    </Tooltip>
  );
};

export default function Leaderboard() {
  const [savedReplays, setSavedReplays] = useState<number[]>(() => {
    try {
      return JSON.parse(localStorage.getItem("tf_saved_replays") || "[]");
    } catch {
      return [];
    }
  });
  const [activeTab, setActiveTab] = useState("global");
  const [isInviteOpen, setIsInviteOpen] = useState(false);
  const [inviteEmail, setInviteEmail] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [chatMessage, setChatMessage] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const recordingIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const [activeSectorChat, setActiveSectorChat] = useState<any>(null);
  const [sectorMessages, setSectorMessages] = useState<{
    [key: string]: any[];
  }>({
    "Operation: Deep Sleep": [
      {
        id: 1,
        sender: "Commander_7",
        avatar: "https://i.pravatar.cc/150?u=1",
        text: "Targeting 8 hours tonight. Sector-7 needs this.",
        time: "10:30 PM",
        isCurrentUser: false,
      },
      {
        id: 2,
        sender: "BioHacker_SF",
        avatar: "https://i.pravatar.cc/150?u=2",
        text: "Copy that. Magnesium protocol active.",
        time: "10:32 PM",
        isCurrentUser: false,
      },
    ],
    "Hydration Supremacy": [
      {
        id: 1,
        sender: "Aqua_Master",
        avatar: "https://i.pravatar.cc/150?u=3",
        text: "Sector-5 is falling behind. Drink up!",
        time: "02:15 PM",
        isCurrentUser: false,
      },
    ],
    "HRV Coherence": [
      {
        id: 1,
        sender: "Zen_Tokyo",
        avatar: "https://i.pravatar.cc/150?u=4",
        text: "Breathwork session starting in 5 mins for Sector-3.",
        time: "09:00 AM",
        isCurrentUser: false,
      },
    ],
  });

  const startRecording = () => {
    setIsRecording(true);
    setRecordingTime(0);
    recordingIntervalRef.current = setInterval(() => {
      setRecordingTime((prev) => prev + 1);
    }, 1000);
  };

  const stopRecording = () => {
    if (recordingIntervalRef.current)
      clearInterval(recordingIntervalRef.current);
    setIsRecording(false);

    const mins = Math.floor(recordingTime / 60);
    const secs = recordingTime % 60;
    const durationStr = `${mins}:${secs.toString().padStart(2, "0")}`;

    const newMessageId = Date.now();
    setMessages([
      ...messages,
      {
        id: newMessageId,
        sender: "You",
        avatar: "https://i.pravatar.cc/150?u=10",
        text: "Voice Note",
        type: "audio",
        duration: durationStr,
        time: new Date().toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
        }),
        isCurrentUser: true,
        status: "sent",
      },
    ]);
    setRecordingTime(0);

    setTimeout(() => {
      setMessages((prev) =>
        prev.map((m) => (m.id === newMessageId ? { ...m, status: "read" } : m)),
      );
    }, 1500);
  };

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s.toString().padStart(2, "0")}`;
  };

  const [messages, setMessages] = useState<any[]>([
    {
      id: 1,
      sender: "Sarah_Opt",
      avatar: "https://i.pravatar.cc/150?u=11",
      text: "Ready for the 0800 CNS calibration?",
      type: "text",
      time: "07:45 AM",
      isCurrentUser: false,
    },
    {
      id: 2,
      sender: "Mike_Flow",
      avatar: "https://i.pravatar.cc/150?u=12",
      text: "Locked in. HRV is sitting at 92 today.",
      type: "text",
      time: "07:47 AM",
      isCurrentUser: false,
    },
    {
      id: 3,
      sender: "Elena_Bio",
      avatar: "https://i.pravatar.cc/150?u=13",
      text: "I'll join after my breathwork protocol.",
      type: "text",
      time: "07:50 AM",
      isCurrentUser: false,
    },
    {
      id: 4,
      sender: "You",
      avatar: "https://i.pravatar.cc/150?u=10",
      text: "See you all in the grid.",
      type: "text",
      time: "07:52 AM",
      isCurrentUser: true,
      status: "read",
    },
  ]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatMessage.trim()) return;

    const newMessageId = Date.now();
    setMessages([
      ...messages,
      {
        id: newMessageId,
        sender: "You",
        avatar: "https://i.pravatar.cc/150?u=10",
        text: chatMessage,
        type: "text",
        time: new Date().toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
        }),
        isCurrentUser: true,
        status: "sent",
      },
    ]);
    setChatMessage("");

    setTimeout(() => {
      setMessages((prev) =>
        prev.map((m) => (m.id === newMessageId ? { ...m, status: "read" } : m)),
      );
    }, 1500);
  };

  const handleSendSectorMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatMessage.trim() || !activeSectorChat) return;

    const newMessageId = Date.now();
    const newMessage = {
      id: newMessageId,
      sender: "You",
      avatar: "https://i.pravatar.cc/150?u=10",
      text: chatMessage,
      time: new Date().toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit",
      }),
      isCurrentUser: true,
      status: "sent",
    };

    setSectorMessages((prev) => ({
      ...prev,
      [activeSectorChat.title]: [
        ...(prev[activeSectorChat.title] || []),
        newMessage,
      ],
    }));

    setChatMessage("");
    hapticFeedback(10);

    setTimeout(() => {
      setSectorMessages((prev) => ({
        ...prev,
        [activeSectorChat.title]: prev[activeSectorChat.title].map((m) =>
          m.id === newMessageId ? { ...m, status: "read" } : m,
        ),
      }));
    }, 1500);
  };

  const [isCompareMode, setIsCompareMode] = useState(false);
  const [newSquadIcon, setNewSquadIcon] = useState("Shield");
  const [newSquadColor, setNewSquadColor] = useState("cyan");
  const [duelOpponent, setDuelOpponent] = useState<any>(null);
  const [spectatingDuel, setSpectatingDuel] = useState<any>(null);
  const [duelMetric, setDuelMetric] = useState("recovery");
  const [wagerAmount, setWagerAmount] = useState("100");
  const [friendsList, setFriendsList] = useState(mockFriendsLeaderboard);
  const { toast } = useToast();
  const navigate = useNavigate();

  const [neuralPoints, setNeuralPoints] = useState(() => {
    const saved = localStorage.getItem("neural_points");
    return saved ? parseInt(saved) : 2500;
  });

  const [liveMetrics, setLiveMetrics] = useState({
    user1: { cognitive: 45, recovery: 82 },
    user2: { cognitive: 48, recovery: 80 },
  });

  useEffect(() => {
    localStorage.setItem("neural_points", neuralPoints.toString());
  }, [neuralPoints]);

  useEffect(() => {
    const interval = setInterval(() => {
      setLiveMetrics((prev) => ({
        user1: {
          cognitive: Math.max(
            30,
            Math.min(70, prev.user1.cognitive + (Math.random() - 0.5) * 5),
          ),
          recovery: Math.max(
            60,
            Math.min(95, prev.user1.recovery + (Math.random() - 0.5) * 3),
          ),
        },
        user2: {
          cognitive: Math.max(
            30,
            Math.min(70, prev.user2.cognitive + (Math.random() - 0.5) * 5),
          ),
          recovery: Math.max(
            60,
            Math.min(95, prev.user2.recovery + (Math.random() - 0.5) * 3),
          ),
        },
      }));
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  const handleSendDuel = () => {
    if (!duelOpponent) return;
    const wager = parseInt(wagerAmount);

    if (wager > neuralPoints) {
      hapticFeedback(100);
      toast({
        title: "Insufficient Points",
        description: "You don't have enough Neural Points to place this wager.",
        variant: "destructive",
      });
      return;
    }

    hapticFeedback([50, 30, 50]);
    setNeuralPoints((prev) => {
      const next = prev - wager;
      localStorage.setItem("neural_points", next.toString());
      return next;
    });

    setFriendsList((prev) =>
      prev.map((f) =>
        f.id === duelOpponent.id ? { ...f, duelStatus: "pending" } : f,
      ),
    );

    toast({
      title: "Neural Duel Initiated",
      description: `Wager: ${wager} PTS. Challenge sent to ${duelOpponent.name}. Metric: ${duelMetric === "recovery" ? "Highest Recovery Index" : "Lowest Cognitive Load"}`,
    });

    setTimeout(() => {
      hapticFeedback([100, 50, 100]);
      setFriendsList((prev) =>
        prev.map((f) =>
          f.id === duelOpponent.id ? { ...f, duelStatus: "active" } : f,
        ),
      );
      toast({
        title: "Duel Accepted",
        description: `${duelOpponent.name} has accepted your Neural Duel!`,
      });
    }, 5000);

    setDuelOpponent(null);
  };

  const currentUser =
    mockLeaderboard.find((u) => u.isCurrentUser) ||
    mockLeaderboard[mockLeaderboard.length - 1];
  const rankedGlobal = mockLeaderboard.map((u, i) => ({ ...u, rank: i + 1 }));
  const rankedFriends = friendsList.map((u, i) => ({ ...u, rank: i + 1 }));

  const filteredGlobal = rankedGlobal.filter((u) =>
    u.name.toLowerCase().includes(searchQuery.toLowerCase()),
  );
  const filteredFriends = rankedFriends.filter((u) =>
    u.name.toLowerCase().includes(searchQuery.toLowerCase()),
  );

  const copyInviteLink = () => {
    hapticFeedback(10);
    navigator.clipboard.writeText("https://therapyfit.elite/invite/user123");
    toast({
      title: "Link Copied",
      description: "Invite link copied to clipboard.",
    });
  };

  const handleInvite = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inviteEmail) return;
    hapticFeedback(50);
    toast({
      title: "Invitation Sent",
      description: `Neural Protocol invite sent to ${inviteEmail}`,
    });
    setIsInviteOpen(false);
    setInviteEmail("");
  };

  return (
    <div className="flex-1 flex flex-col bg-background">
      <div className="container max-w-2xl px-4 mx-auto pt-6 space-y-6">
        <div className="flex justify-end items-center gap-2 sm:gap-4 mb-4">
          <Badge
            variant="outline"
            className="bg-primary/5 border-primary/20 text-primary font-mono px-3 py-1 gap-1.5 shadow-[0_0_10px_rgba(0,200,200,0.1)]"
          >
            <Zap className="w-3 h-3 fill-primary" />
            {neuralPoints.toLocaleString()} PTS
          </Badge>
          <NeuralNotificationCenter />
        </div>
        <div className="space-y-2 text-center">
          <div className="inline-flex items-center justify-center rounded-lg bg-primary/10 px-3 py-1 text-sm text-primary font-medium border border-primary/20 mb-2">
            <Activity className="w-4 h-4 mr-2" />
            Neural Rankings
          </div>
          <h1 className="text-3xl font-bold tracking-tighter">
            Global Calibration
          </h1>
          <div className="flex items-center justify-center gap-4 mt-2">
            <p className="text-muted-foreground text-sm">
              Compare your Recovery Index and Cognitive Load against the elite.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card className="bg-card/40 border-primary/20 backdrop-blur-sm relative overflow-hidden group">
            <div className="absolute inset-0 bg-gradient-to-r from-primary/5 via-transparent to-transparent opacity-50" />
            <CardContent className="p-4 flex items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="h-10 w-10 rounded-full bg-primary/10 border border-primary/30 flex items-center justify-center text-primary shadow-[0_0_15px_rgba(0,255,255,0.2)]">
                  <Flame className="h-5 w-5 animate-pulse" />
                </div>
                <div>
                  <div className="text-xs font-bold text-muted-foreground uppercase tracking-widest">
                    Your Calibration
                  </div>
                  <div className="flex items-baseline gap-1">
                    <span className="text-xl font-bold text-primary">7</span>
                    <span className="text-[10px] text-muted-foreground uppercase">
                      Day Streak
                    </span>
                  </div>
                </div>
              </div>
              <div className="flex-1 max-w-[140px] space-y-1.5">
                <div className="flex justify-between text-[10px] font-bold">
                  <span className="text-muted-foreground">Daily Progress</span>
                  <span className="text-primary">66%</span>
                </div>
                <Progress value={66} className="h-1.5" />
              </div>
              <Button
                size="sm"
                variant="outline"
                className="h-8 border-primary/50 text-primary hover:bg-primary/10 text-[10px] font-bold uppercase tracking-wider"
                onClick={() => navigate("/profile")}
              >
                Complete
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-card/40 border-primary/20 backdrop-blur-sm relative overflow-hidden group">
            <div className="absolute inset-0 bg-gradient-to-r from-primary/5 via-transparent to-transparent opacity-50" />
            <CardContent className="p-4 flex items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="h-10 w-10 rounded-full bg-primary/10 border border-primary/30 flex items-center justify-center text-primary shadow-[0_0_15px_rgba(0,255,255,0.2)]">
                  <Trophy className="h-5 w-5 text-yellow-400" />
                </div>
                <div>
                  <div className="text-xs font-bold text-muted-foreground uppercase tracking-widest">
                    Rank Tier
                  </div>
                  <div className="text-xl font-bold text-primary">Elite</div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">
                  Global Rank
                </div>
                <div className="text-xl font-mono font-bold text-primary">
                  #1,242
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-5 bg-muted/20 border border-border/50 h-11 p-1">
            <TabsTrigger
              value="global"
              className="text-[10px] uppercase tracking-widest font-bold data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
            >
              Global
            </TabsTrigger>
            <TabsTrigger
              value="map"
              className="text-[10px] uppercase tracking-widest font-bold data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
            >
              Map
            </TabsTrigger>
            <TabsTrigger
              value="streaks"
              className="text-[10px] uppercase tracking-widest font-bold data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
            >
              Streaks
            </TabsTrigger>
            <TabsTrigger
              value="friends"
              className="text-[10px] uppercase tracking-widest font-bold data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
            >
              Network
            </TabsTrigger>
            <TabsTrigger
              value="team"
              className="text-[10px] uppercase tracking-widest font-bold data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
            >
              Squads
            </TabsTrigger>
          </TabsList>

          <TabsContent value="global" className="mt-6 space-y-4">
            <div className="flex items-center relative">
              <Search className="absolute left-3 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search operators..."
                className="pl-10 bg-card/40 border-border/50"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>

            <Card className="bg-card/40 border-border/50 backdrop-blur-sm overflow-hidden">
              <CardContent className="p-0">
                <div className="divide-y divide-border/50">
                  {filteredGlobal.map((user, index) => (
                    <div
                      key={user.id}
                      style={{ animationDelay: `${index * 50}ms` }}
                      className={cn(
                        "flex items-center justify-between p-4 transition-colors hover:bg-muted/30 animate-in fade-in slide-in-from-bottom-4 duration-500 fill-mode-both",
                        user.isCurrentUser &&
                          "bg-primary/10 hover:bg-primary/20 border-l-2 border-l-primary",
                      )}
                    >
                      <div className="flex items-center gap-4">
                        <span
                          className={cn(
                            "text-muted-foreground font-mono text-sm w-4 text-center",
                            index < 3 && "text-primary font-bold",
                          )}
                        >
                          {user.rank}
                        </span>
                        <div className="relative">
                          <Avatar className="w-10 h-10 border border-border">
                            <AvatarImage src={user.avatar} />
                            <AvatarFallback>
                              {user.name.substring(0, 2)}
                            </AvatarFallback>
                          </Avatar>
                          <NeuralBadge type={user.neuralBadge} />
                        </div>
                        <div>
                          <p
                            className={cn(
                              "text-sm font-medium",
                              user.isCurrentUser && "text-primary font-bold",
                            )}
                          >
                            {user.name}
                          </p>
                          <div className="flex items-center gap-1.5 mt-0.5">
                            {index < 3 && (
                              <Medal
                                className={cn(
                                  "w-3 h-3",
                                  index === 0
                                    ? "text-yellow-400"
                                    : index === 1
                                      ? "text-slate-300"
                                      : "text-amber-600",
                                )}
                              />
                            )}
                            <span className="text-[10px] text-muted-foreground uppercase tracking-widest font-bold">
                              {user.rank <= 3 ? "Top Tier" : "Active"}
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-4 sm:gap-6">
                        <div className="hidden sm:block opacity-70">
                          <Sparkline
                            data={user.history}
                            color={
                              user.trend === "up"
                                ? "hsl(142, 71%, 45%)"
                                : "hsl(0, 84%, 60%)"
                            }
                            name={user.name}
                            comparisonData={
                              user.isCurrentUser
                                ? undefined
                                : currentUser.history
                            }
                            comparisonName={
                              user.isCurrentUser ? undefined : "You"
                            }
                          />
                        </div>
                        <div className="text-right min-w-[60px]">
                          <div className="text-lg font-mono font-bold text-primary">
                            {user.score}
                          </div>
                          <div className="flex items-center justify-end gap-1 text-[10px] text-muted-foreground">
                            {user.trend === "up" ? (
                              <TrendingUp className="w-3 h-3 text-green-500" />
                            ) : (
                              <TrendingUp className="w-3 h-3 text-destructive rotate-180" />
                            )}
                            Score
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="map" className="mt-6 space-y-6">
            <Card className="bg-card/40 border-border/50 backdrop-blur-sm overflow-hidden">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Globe className="w-5 h-5 text-cyan-400 animate-[spin_5s_linear_infinite]" />
                  Global Streak Map
                </CardTitle>
                <CardDescription>
                  Live visualization of the longest biometric streaks across the
                  neural network.
                </CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                <div className="relative aspect-[16/9] w-full bg-black/60 overflow-hidden group">
                  <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:20px_20px] pointer-events-none" />
                  <svg
                    viewBox="0 0 800 400"
                    className="w-full h-full opacity-20 stroke-cyan-500/30 fill-none"
                  >
                    <path d="M150,100 Q200,80 250,100 T350,120 T450,100 T550,120 T650,100 T750,120" />
                    <path d="M100,200 Q200,180 300,200 T500,220 T700,200" />
                    <path d="M200,300 Q300,280 400,300 T600,320" />
                  </svg>
                  <div className="absolute inset-0">
                    {mockGlobalStreaks.map((node) => {
                      const x = (node.lng + 180) * (800 / 360);
                      const y = (90 - node.lat) * (400 / 180);
                      return (
                        <TooltipProvider key={node.id}>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <div
                                className="absolute w-6 h-6 -ml-3 -mt-3 flex items-center justify-center transition-all duration-500 hover:scale-150 cursor-help"
                                style={{
                                  left: `${(x / 800) * 100}%`,
                                  top: `${(y / 400) * 100}%`,
                                }}
                              >
                                <div className="absolute inset-0 rounded-full bg-orange-500/20 animate-ping" />
                                <div className="relative w-3 h-3 rounded-full bg-orange-500 shadow-[0_0_15px_rgba(249,115,22,0.8)] border border-white/20 flex items-center justify-center">
                                  <Flame className="w-2 h-2 text-white fill-white" />
                                </div>
                              </div>
                            </TooltipTrigger>
                            <TooltipContent
                              side="top"
                              className="bg-card/95 border-orange-500/30 backdrop-blur-md p-3 shadow-2xl"
                            >
                              <div className="space-y-1.5">
                                <div className="flex items-center justify-between gap-4">
                                  <span className="text-xs font-black text-white uppercase tracking-widest">
                                    {node.city}
                                  </span>
                                  <Badge
                                    variant="outline"
                                    className="text-[8px] h-3.5 px-1 uppercase border-orange-500/30 text-orange-400 bg-orange-500/10"
                                  >
                                    {node.category}
                                  </Badge>
                                </div>
                                <div className="flex items-center gap-2">
                                  <div className="flex items-center gap-1 text-orange-500 font-bold">
                                    <Flame className="w-3 h-3" />
                                    <span className="text-sm font-mono">
                                      {node.streak} Days
                                    </span>
                                  </div>
                                  <span className="text-[10px] text-muted-foreground">
                                    by @{node.user}
                                  </span>
                                </div>
                              </div>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      );
                    })}
                  </div>
                  <div className="absolute bottom-4 left-4 flex flex-col gap-1.5 pointer-events-none">
                    <div className="flex items-center gap-2 bg-black/40 backdrop-blur-md border border-white/5 p-2 rounded-lg">
                      <div className="w-2 h-2 rounded-full bg-orange-500 animate-pulse" />
                      <span className="text-[9px] font-black text-white uppercase tracking-widest">
                        Active High-Streak Nodes
                      </span>
                    </div>
                  </div>
                </div>
                <div className="p-4 bg-muted/20 border-t border-border/50">
                  <div className="grid grid-cols-3 gap-4">
                    {[
                      {
                        label: "Longest Streak",
                        value: "145 Days",
                        sub: "Tokyo Sector",
                      },
                      {
                        label: "Avg Node Streak",
                        value: "92 Days",
                        sub: "Global Network",
                      },
                      {
                        label: "Total Mastery",
                        value: "1,240 Medals",
                        sub: "30+ Day Streaks",
                      },
                    ].map((stat, i) => (
                      <div key={i} className="space-y-1">
                        <p className="text-[9px] font-bold text-muted-foreground uppercase tracking-widest">
                          {stat.label}
                        </p>
                        <p className="text-sm font-black text-primary">
                          {stat.value}
                        </p>
                        <p className="text-[8px] text-muted-foreground/60 uppercase">
                          {stat.sub}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card/40 border-border/50 backdrop-blur-sm overflow-hidden mt-6">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Swords className="w-5 h-5 text-cyan-400" />
                  Active Sector Challenges
                </CardTitle>
                <CardDescription>
                  Compete for regional dominance through collective biometric
                  streaks.
                </CardDescription>
              </CardHeader>
              <CardContent className="p-4 grid gap-4 md:grid-cols-2">
                {mockSectorChallenges.map((challenge, index) => (
                  <div
                    key={challenge.id}
                    className="bg-black/40 border border-white/5 rounded-xl p-4 relative overflow-hidden group animate-in fade-in slide-in-from-bottom-4 duration-500 fill-mode-both"
                    style={{ animationDelay: `${index * 100}ms` }}
                  >
                    <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <h4 className="text-sm font-bold text-white uppercase tracking-widest">
                          {challenge.title}
                        </h4>
                        <p className="text-[10px] text-muted-foreground mt-0.5">
                          Target: {challenge.target}
                        </p>
                      </div>
                      <Badge
                        variant="outline"
                        className="bg-cyan-500/10 text-cyan-400 border-cyan-500/30 text-[9px] uppercase shrink-0"
                      >
                        {challenge.timeRemaining}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between gap-4 mb-2 mt-4">
                      <div className="flex flex-col items-start flex-1">
                        <span
                          className={cn(
                            "text-[10px] font-bold uppercase tracking-widest",
                            challenge.leading === challenge.sector1
                              ? "text-cyan-400"
                              : "text-muted-foreground",
                          )}
                        >
                          {challenge.sector1}
                        </span>
                        <div className="w-full h-1.5 bg-white/10 rounded-full mt-1 overflow-hidden flex justify-start">
                          <div
                            className={cn(
                              "h-full transition-all duration-1000",
                              challenge.leading === challenge.sector1
                                ? "bg-cyan-400"
                                : "bg-muted-foreground",
                            )}
                            style={{
                              width:
                                challenge.leading === challenge.sector1
                                  ? "85%"
                                  : "45%",
                            }}
                          />
                        </div>
                      </div>
                      <div className="shrink-0 flex flex-col items-center">
                        <Swords className="w-4 h-4 text-muted-foreground" />
                      </div>
                      <div className="flex flex-col items-end flex-1">
                        <span
                          className={cn(
                            "text-[10px] font-bold uppercase tracking-widest",
                            challenge.leading === challenge.sector2
                              ? "text-cyan-400"
                              : "text-muted-foreground",
                          )}
                        >
                          {challenge.sector2}
                        </span>
                        <div className="w-full h-1.5 bg-white/10 rounded-full mt-1 overflow-hidden flex justify-end">
                          <div
                            className={cn(
                              "h-full transition-all duration-1000",
                              challenge.leading === challenge.sector2
                                ? "bg-cyan-400"
                                : "bg-muted-foreground",
                            )}
                            style={{
                              width:
                                challenge.leading === challenge.sector2
                                  ? "85%"
                                  : "45%",
                            }}
                          />
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center justify-between mt-5 pt-4 border-t border-white/5">
                      <div className="flex items-center gap-1.5">
                        <Trophy className="w-3.5 h-3.5 text-yellow-500" />
                        <span className="text-[10px] font-bold text-yellow-500">
                          {challenge.reward}
                        </span>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-7 w-7 p-0 text-muted-foreground hover:text-cyan-400 hover:bg-cyan-500/10"
                          onClick={() => {
                            hapticFeedback(10);
                            setActiveSectorChat(challenge);
                          }}
                        >
                          <MessageSquare className="w-3.5 h-3.5" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-7 text-[9px] uppercase tracking-widest border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/10"
                          onClick={() => hapticFeedback(10)}
                        >
                          Join {challenge.sector1}
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card className="bg-card/40 border-border/50 backdrop-blur-sm overflow-hidden mt-6">
              <CardHeader className="pb-2 flex flex-row items-center justify-between">
                <div>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Zap className="w-5 h-5 text-fuchsia-500 animate-pulse" />
                    Neural Duels (1v1)
                  </CardTitle>
                  <CardDescription>
                    Direct 1v1 biometric face-offs between sectors.
                  </CardDescription>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  className="border-fuchsia-500/30 text-fuchsia-400 hover:bg-fuchsia-500/10 h-8 text-[10px] uppercase tracking-widest"
                >
                  Issue Challenge
                </Button>
              </CardHeader>
              <CardContent className="p-4 grid gap-4 md:grid-cols-2">
                {mockNeuralDuels.map((duel, index) => (
                  <Dialog key={duel.id}>
                    <DialogTrigger asChild>
                      <div
                        className="bg-black/40 border border-fuchsia-500/20 rounded-xl p-4 relative overflow-hidden group animate-in fade-in slide-in-from-bottom-4 duration-500 fill-mode-both cursor-pointer hover:border-fuchsia-500/50 transition-all"
                        style={{ animationDelay: `${index * 100}ms` }}
                      >
                        <div className="absolute inset-0 bg-gradient-to-r from-fuchsia-500/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />

                        <div className="flex justify-between items-start mb-4">
                          <div>
                            <Badge
                              variant="outline"
                              className="bg-fuchsia-500/10 text-fuchsia-400 border-fuchsia-500/30 text-[9px] uppercase tracking-widest mb-2"
                            >
                              {duel.metric}
                            </Badge>
                            <div className="flex items-center gap-1.5 text-yellow-500 font-bold text-[10px]">
                              <Trophy className="w-3.5 h-3.5" />
                              Prize Pool: {duel.pool}
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="text-[10px] text-muted-foreground uppercase tracking-widest">
                              Time Remaining
                            </div>
                            <div className="text-sm font-mono text-fuchsia-400">
                              {duel.timeRemaining}
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center justify-between gap-4 py-2">
                          <div className="flex flex-col items-center flex-1">
                            <span
                              className={cn(
                                "text-xs font-bold uppercase tracking-widest",
                                duel.leading === duel.sector1
                                  ? "text-fuchsia-400"
                                  : "text-muted-foreground",
                              )}
                            >
                              {duel.sector1}
                            </span>
                            <span
                              className={cn(
                                "text-2xl font-mono font-black mt-1",
                                duel.leading === duel.sector1
                                  ? "text-white"
                                  : "text-white/60",
                              )}
                            >
                              {duel.s1Score}
                            </span>
                          </div>

                          <div className="shrink-0 flex flex-col items-center justify-center px-4">
                            <div className="bg-fuchsia-500/20 p-2 rounded-full border border-fuchsia-500/30">
                              <Zap className="w-4 h-4 text-fuchsia-500" />
                            </div>
                            <span className="text-[10px] font-bold text-muted-foreground mt-2 uppercase tracking-widest">
                              VS
                            </span>
                          </div>

                          <div className="flex flex-col items-center flex-1">
                            <span
                              className={cn(
                                "text-xs font-bold uppercase tracking-widest",
                                duel.leading === duel.sector2
                                  ? "text-fuchsia-400"
                                  : "text-muted-foreground",
                              )}
                            >
                              {duel.sector2}
                            </span>
                            <span
                              className={cn(
                                "text-2xl font-mono font-black mt-1",
                                duel.leading === duel.sector2
                                  ? "text-white"
                                  : "text-white/60",
                              )}
                            >
                              {duel.s2Score}
                            </span>
                          </div>
                        </div>
                      </div>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-[425px] bg-black/90 border-fuchsia-500/30 backdrop-blur-xl">
                      <DialogHeader>
                        <DialogTitle className="text-fuchsia-400 flex items-center gap-2">
                          <Zap className="w-5 h-5" />
                          Place Wager
                        </DialogTitle>
                        <DialogDescription>
                          Bet your XP points on {duel.sector1} vs {duel.sector2}{" "}
                          for the {duel.metric} duel.
                        </DialogDescription>
                      </DialogHeader>
                      <div className="grid gap-4 py-4">
                        <div className="flex gap-2">
                          <Button
                            variant="outline"
                            className="flex-1 border-fuchsia-500/30 hover:bg-fuchsia-500/10 hover:text-fuchsia-400"
                          >
                            {duel.sector1}
                          </Button>
                          <Button
                            variant="outline"
                            className="flex-1 border-fuchsia-500/30 hover:bg-fuchsia-500/10 hover:text-fuchsia-400"
                          >
                            {duel.sector2}
                          </Button>
                        </div>
                        <div className="space-y-2">
                          <label className="text-xs uppercase tracking-widest text-muted-foreground">
                            Wager Amount (PTS)
                          </label>
                          <Input
                            type="number"
                            placeholder="Enter amount..."
                            className="bg-black/50 border-fuchsia-500/30 focus-visible:ring-fuchsia-500"
                          />
                        </div>
                      </div>
                      <DialogFooter>
                        <Button
                          className="w-full bg-fuchsia-500 hover:bg-fuchsia-600 text-white"
                          onClick={() =>
                            toast({
                              title: "Wager Placed",
                              description:
                                "Your points have been locked in for this duel.",
                            })
                          }
                        >
                          Confirm Wager
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                ))}
              </CardContent>
            </Card>

            {/* Historical Duels & Replays */}
            <Card className="bg-[#0B0C10] border-white/10 mt-6 relative overflow-hidden">
              <CardHeader className="border-b border-white/5 bg-white/5 pb-4">
                <div>
                  <CardTitle className="text-lg flex items-center gap-2 text-primary">
                    <Clock className="w-5 h-5" />
                    Historical Duels & Replays
                  </CardTitle>
                  <CardDescription>
                    Review past sector face-offs and analyze biometric replays.
                  </CardDescription>
                </div>
              </CardHeader>
              <CardContent className="p-4 grid gap-4">
                {mockHistoricalDuels.map((duel, index) => {
                  const isSaved = savedReplays.includes(duel.id);
                  return (
                    <div
                      key={duel.id}
                      className="bg-black/40 border border-white/10 rounded-xl p-4 flex items-center justify-between group hover:bg-white/5 transition-colors animate-in fade-in slide-in-from-bottom-4 duration-500 fill-mode-both"
                      style={{ animationDelay: `${index * 100}ms` }}
                    >
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge
                            variant="outline"
                            className="bg-primary/10 text-primary border-primary/30 text-[9px] uppercase tracking-widest"
                          >
                            {duel.metric}
                          </Badge>
                          <span className="text-[10px] text-muted-foreground font-mono">
                            {duel.date}
                          </span>
                        </div>
                        <div className="flex items-center gap-6">
                          <div className="flex items-center gap-3">
                            <span
                              className={cn(
                                "text-xs font-bold uppercase tracking-widest",
                                duel.winner === duel.sector1
                                  ? "text-primary"
                                  : "text-muted-foreground",
                              )}
                            >
                              {duel.sector1}
                            </span>
                            <span
                              className={cn(
                                "text-lg font-mono font-black",
                                duel.winner === duel.sector1
                                  ? "text-white"
                                  : "text-white/40",
                              )}
                            >
                              {duel.s1Score}
                            </span>
                          </div>
                          <span className="text-[10px] text-white/20 uppercase font-bold tracking-widest">
                            VS
                          </span>
                          <div className="flex items-center gap-3">
                            <span
                              className={cn(
                                "text-lg font-mono font-black",
                                duel.winner === duel.sector2
                                  ? "text-white"
                                  : "text-white/40",
                              )}
                            >
                              {duel.s2Score}
                            </span>
                            <span
                              className={cn(
                                "text-xs font-bold uppercase tracking-widest",
                                duel.winner === duel.sector2
                                  ? "text-primary"
                                  : "text-muted-foreground",
                              )}
                            >
                              {duel.sector2}
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="flex flex-col items-end gap-3 shrink-0">
                        <div className="flex items-center gap-1.5 text-yellow-500 font-bold text-[10px]">
                          <Trophy className="w-3.5 h-3.5" />
                          {duel.pool}
                        </div>
                        <div className="flex items-center gap-2">
                          <Button
                            size="icon"
                            variant="outline"
                            className={cn(
                              "h-8 w-8 transition-colors",
                              isSaved
                                ? "bg-primary/20 text-primary border-primary/50"
                                : "bg-black/40 border-white/10 text-muted-foreground hover:text-primary hover:border-primary/30",
                            )}
                            onClick={() => {
                              hapticFeedback(5);
                              setSavedReplays((prev) => {
                                const next = isSaved
                                  ? prev.filter((id) => id !== duel.id)
                                  : [...prev, duel.id];
                                try {
                                  localStorage.setItem(
                                    "tf_saved_replays",
                                    JSON.stringify(next),
                                  );
                                } catch {}
                                if (isSaved) {
                                  toast({
                                    title: "Replay removed from profile.",
                                  });
                                } else {
                                  toast({
                                    title: "Replay saved to profile.",
                                    description: `${duel.sector1} vs ${duel.sector2}`,
                                  });
                                }
                                return next;
                              });
                            }}
                          >
                            <Bookmark
                              className={cn(
                                "w-3.5 h-3.5",
                                isSaved && "fill-current",
                              )}
                            />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-8 gap-1.5 border-primary/30 text-primary hover:bg-primary/10 text-[10px] uppercase tracking-widest"
                            onClick={() =>
                              toast({
                                title: "Replay Initiated",
                                description: `Loading telemetry for ${duel.sector1} vs ${duel.sector2}...`,
                              })
                            }
                          >
                            <Play className="w-3.5 h-3.5" /> Watch Replay
                          </Button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="streaks" className="mt-6 space-y-4">
            <Card className="bg-card/40 border-border/50 backdrop-blur-sm overflow-hidden">
              <CardContent className="p-0">
                <div className="divide-y divide-border/50">
                  {mockStreakLeaderboard.map((user, index) => (
                    <div
                      key={user.id}
                      style={{ animationDelay: `${index * 50}ms` }}
                      className={cn(
                        "flex items-center justify-between p-4 transition-colors hover:bg-muted/30 animate-in fade-in slide-in-from-bottom-4 duration-500 fill-mode-both",
                        user.isCurrentUser &&
                          "bg-primary/10 hover:bg-primary/20 border-l-2 border-l-primary",
                      )}
                    >
                      <div className="flex items-center gap-4">
                        <span className="text-muted-foreground font-mono text-sm w-4 text-center">
                          {index + 1}
                        </span>
                        <div className="relative">
                          <Avatar className="w-10 h-10 border border-border">
                            <AvatarImage src={user.avatar} />
                            <AvatarFallback>
                              {user.name.substring(0, 2)}
                            </AvatarFallback>
                          </Avatar>
                          <NeuralBadge type={user.neuralBadge} />
                        </div>
                        <div>
                          <p
                            className={cn(
                              "text-sm font-medium",
                              user.isCurrentUser && "text-primary font-bold",
                            )}
                          >
                            {user.name}
                          </p>
                          <Badge
                            variant="outline"
                            className="text-[8px] h-3.5 px-1 uppercase border-primary/30 text-primary mt-1"
                          >
                            {user.category} Master
                          </Badge>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <div className="flex items-center gap-1.5 text-orange-500 font-bold">
                            <Flame className="w-3.5 h-3.5" />
                            <span className="text-lg font-mono">
                              {user.streak}
                            </span>
                          </div>
                          <p className="text-[9px] text-muted-foreground uppercase tracking-widest">
                            Day Streak
                          </p>
                        </div>
                        {user.streak >= 30 && (
                          <div className="bg-yellow-500/10 p-1.5 rounded-full border border-yellow-500/30">
                            <Award className="w-4 h-4 text-yellow-500" />
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="friends" className="mt-6 space-y-4">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium">Your Network</h3>
              <Button
                variant="outline"
                className="border-primary/50 text-primary hover:bg-primary/10"
                onClick={() => setIsInviteOpen(true)}
              >
                <UserPlus className="w-4 h-4 mr-2" />
                Invite
              </Button>
            </div>
            <Card className="bg-card/40 border-border/50 backdrop-blur-sm overflow-hidden">
              <CardContent className="p-0">
                <div className="divide-y divide-border/50">
                  {filteredFriends.map((user, index) => (
                    <div
                      key={user.id}
                      style={{ animationDelay: `${index * 50}ms` }}
                      className={cn(
                        "flex items-center justify-between p-4 transition-colors hover:bg-muted/30 animate-in fade-in slide-in-from-bottom-4 duration-500 fill-mode-both",
                        user.isCurrentUser &&
                          "bg-primary/10 hover:bg-primary/20 border-l-2 border-l-primary",
                      )}
                    >
                      <div className="flex items-center gap-4">
                        <span className="text-muted-foreground font-mono text-sm w-4 text-center">
                          {user.rank}
                        </span>
                        <div className="relative">
                          <Avatar className="w-10 h-10 border border-border">
                            <AvatarImage src={user.avatar} />
                            <AvatarFallback>
                              {user.name.substring(0, 2)}
                            </AvatarFallback>
                          </Avatar>
                          <NeuralBadge type={(user as any).neuralBadge} />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <p
                              className={cn(
                                "text-sm font-medium",
                                user.isCurrentUser && "text-primary font-bold",
                              )}
                            >
                              {user.name}
                            </p>
                            {user.duelStatus && user.duelStatus !== "none" && (
                              <Badge
                                variant={
                                  user.duelStatus === "active"
                                    ? "default"
                                    : "outline"
                                }
                                className={cn(
                                  "text-[10px] h-4 px-1 uppercase tracking-tighter",
                                  user.duelStatus === "pending" &&
                                    "text-yellow-500 border-yellow-500/50",
                                  user.duelStatus === "won" &&
                                    "text-green-500 border-green-500/50",
                                  user.duelStatus === "lost" &&
                                    "text-destructive border-destructive/50",
                                  user.duelStatus === "active" &&
                                    "animate-pulse shadow-[0_0_8px_hsl(var(--primary)/0.4)]",
                                )}
                              >
                                {user.duelStatus}
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <Badge
                          variant={user.isCurrentUser ? "default" : "secondary"}
                          className="font-mono"
                        >
                          {user.score}
                        </Badge>
                        {user.duelStatus === "active" && (
                          <Button
                            variant="outline"
                            size="sm"
                            className="h-8 border-primary/50 text-primary hover:bg-primary/10 gap-1 px-2"
                            onClick={() => setSpectatingDuel(user)}
                          >
                            <Eye className="h-3 w-3 animate-pulse" />
                            <span className="text-[10px] font-bold uppercase">
                              Spectate
                            </span>
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="team" className="mt-6 space-y-4">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-2">
              <h4 className="text-sm font-bold text-muted-foreground uppercase tracking-widest">
                Global Squad Rankings
              </h4>
              <div className="flex items-center gap-2">
                <Dialog>
                  <DialogTrigger asChild>
                    <Button
                      variant="outline"
                      className="border-primary/50 text-primary hover:bg-primary/10 h-8 text-xs"
                    >
                      <UserPlus className="w-3 h-3 mr-2" />
                      Join Squad
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-md bg-card border-border/50 backdrop-blur-xl">
                    <DialogHeader>
                      <DialogTitle>Join a Squad</DialogTitle>
                      <DialogDescription>
                        Enter a squad invite code to join an existing tactical
                        team.
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label htmlFor="invite-code">Invite Code</Label>
                        <Input
                          id="invite-code"
                          placeholder="e.g. SQD-8X9Y2Z"
                          className="bg-background/50 uppercase"
                        />
                      </div>
                    </div>
                    <DialogFooter>
                      <Button
                        className="w-full"
                        onClick={() => {
                          hapticFeedback(10);
                          toast({
                            title: "Request Sent",
                            description:
                              "Your request to join the squad has been sent to the captain.",
                          });
                        }}
                      >
                        Submit Request
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>

                <Dialog>
                  <DialogTrigger asChild>
                    <Button className="bg-primary/90 hover:bg-primary text-primary-foreground h-8 text-xs shadow-[0_0_15px_rgba(0,255,255,0.3)]">
                      <Shield className="w-3 h-3 mr-2" />
                      Create Squad
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-md bg-card border-border/50 backdrop-blur-xl max-h-[90vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle>Create New Squad</DialogTitle>
                      <DialogDescription>
                        Form a new tactical unit. You will be assigned as the
                        Squad Captain.
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-6 py-4">
                      {/* Emblem Customizer */}
                      <div className="space-y-3">
                        <Label>Squad Emblem</Label>
                        <div className="flex flex-col items-center p-4 border border-border/50 rounded-xl bg-black/20">
                          {/* Preview */}
                          <div
                            className={`w-20 h-20 rounded-xl border-2 flex items-center justify-center mb-5 transition-all duration-300 shadow-[0_0_20px_rgba(0,0,0,0.5)] ${
                              newSquadColor === "cyan"
                                ? "border-cyan-400/50 bg-cyan-400/10 shadow-[0_0_20px_rgba(34,211,238,0.2)]"
                                : newSquadColor === "purple"
                                  ? "border-purple-400/50 bg-purple-400/10 shadow-[0_0_20px_rgba(168,85,247,0.2)]"
                                  : newSquadColor === "red"
                                    ? "border-red-500/50 bg-red-500/10 shadow-[0_0_20px_rgba(239,68,68,0.2)]"
                                    : newSquadColor === "yellow"
                                      ? "border-yellow-400/50 bg-yellow-400/10 shadow-[0_0_20px_rgba(250,204,21,0.2)]"
                                      : "border-emerald-400/50 bg-emerald-400/10 shadow-[0_0_20px_rgba(16,185,129,0.2)]"
                            }`}
                          >
                            {newSquadIcon === "Shield" && (
                              <Shield
                                className={`w-10 h-10 transition-colors duration-300 ${newSquadColor === "cyan" ? "text-cyan-400 drop-shadow-[0_0_10px_rgba(34,211,238,0.5)]" : newSquadColor === "purple" ? "text-purple-400 drop-shadow-[0_0_10px_rgba(168,85,247,0.5)]" : newSquadColor === "red" ? "text-red-500 drop-shadow-[0_0_10px_rgba(239,68,68,0.5)]" : newSquadColor === "yellow" ? "text-yellow-400 drop-shadow-[0_0_10px_rgba(250,204,21,0.5)]" : "text-emerald-400 drop-shadow-[0_0_10px_rgba(16,185,129,0.5)]"}`}
                              />
                            )}
                            {newSquadIcon === "Crosshair" && (
                              <Crosshair
                                className={`w-10 h-10 transition-colors duration-300 ${newSquadColor === "cyan" ? "text-cyan-400 drop-shadow-[0_0_10px_rgba(34,211,238,0.5)]" : newSquadColor === "purple" ? "text-purple-400 drop-shadow-[0_0_10px_rgba(168,85,247,0.5)]" : newSquadColor === "red" ? "text-red-500 drop-shadow-[0_0_10px_rgba(239,68,68,0.5)]" : newSquadColor === "yellow" ? "text-yellow-400 drop-shadow-[0_0_10px_rgba(250,204,21,0.5)]" : "text-emerald-400 drop-shadow-[0_0_10px_rgba(16,185,129,0.5)]"}`}
                              />
                            )}
                            {newSquadIcon === "Hexagon" && (
                              <Hexagon
                                className={`w-10 h-10 transition-colors duration-300 ${newSquadColor === "cyan" ? "text-cyan-400 drop-shadow-[0_0_10px_rgba(34,211,238,0.5)]" : newSquadColor === "purple" ? "text-purple-400 drop-shadow-[0_0_10px_rgba(168,85,247,0.5)]" : newSquadColor === "red" ? "text-red-500 drop-shadow-[0_0_10px_rgba(239,68,68,0.5)]" : newSquadColor === "yellow" ? "text-yellow-400 drop-shadow-[0_0_10px_rgba(250,204,21,0.5)]" : "text-emerald-400 drop-shadow-[0_0_10px_rgba(16,185,129,0.5)]"}`}
                              />
                            )}
                            {newSquadIcon === "Zap" && (
                              <Zap
                                className={`w-10 h-10 transition-colors duration-300 ${newSquadColor === "cyan" ? "text-cyan-400 drop-shadow-[0_0_10px_rgba(34,211,238,0.5)]" : newSquadColor === "purple" ? "text-purple-400 drop-shadow-[0_0_10px_rgba(168,85,247,0.5)]" : newSquadColor === "red" ? "text-red-500 drop-shadow-[0_0_10px_rgba(239,68,68,0.5)]" : newSquadColor === "yellow" ? "text-yellow-400 drop-shadow-[0_0_10px_rgba(250,204,21,0.5)]" : "text-emerald-400 drop-shadow-[0_0_10px_rgba(16,185,129,0.5)]"}`}
                              />
                            )}
                            {newSquadIcon === "BrainCircuit" && (
                              <BrainCircuit
                                className={`w-10 h-10 transition-colors duration-300 ${newSquadColor === "cyan" ? "text-cyan-400 drop-shadow-[0_0_10px_rgba(34,211,238,0.5)]" : newSquadColor === "purple" ? "text-purple-400 drop-shadow-[0_0_10px_rgba(168,85,247,0.5)]" : newSquadColor === "red" ? "text-red-500 drop-shadow-[0_0_10px_rgba(239,68,68,0.5)]" : newSquadColor === "yellow" ? "text-yellow-400 drop-shadow-[0_0_10px_rgba(250,204,21,0.5)]" : "text-emerald-400 drop-shadow-[0_0_10px_rgba(16,185,129,0.5)]"}`}
                              />
                            )}
                            {newSquadIcon === "Flame" && (
                              <Flame
                                className={`w-10 h-10 transition-colors duration-300 ${newSquadColor === "cyan" ? "text-cyan-400 drop-shadow-[0_0_10px_rgba(34,211,238,0.5)]" : newSquadColor === "purple" ? "text-purple-400 drop-shadow-[0_0_10px_rgba(168,85,247,0.5)]" : newSquadColor === "red" ? "text-red-500 drop-shadow-[0_0_10px_rgba(239,68,68,0.5)]" : newSquadColor === "yellow" ? "text-yellow-400 drop-shadow-[0_0_10px_rgba(250,204,21,0.5)]" : "text-emerald-400 drop-shadow-[0_0_10px_rgba(16,185,129,0.5)]"}`}
                              />
                            )}
                          </div>

                          {/* Icon Selector */}
                          <div className="w-full mb-5">
                            <div className="text-[10px] uppercase tracking-widest text-muted-foreground mb-3 font-bold text-center">
                              Select Icon
                            </div>
                            <div className="flex gap-2 justify-center flex-wrap">
                              {[
                                { id: "Shield", icon: Shield },
                                { id: "Crosshair", icon: Crosshair },
                                { id: "Hexagon", icon: Hexagon },
                                { id: "Zap", icon: Zap },
                                { id: "BrainCircuit", icon: BrainCircuit },
                                { id: "Flame", icon: Flame },
                              ].map((item) => {
                                const Icon = item.icon;
                                const isSelected = newSquadIcon === item.id;
                                return (
                                  <button
                                    key={item.id}
                                    onClick={() => {
                                      hapticFeedback(5);
                                      setNewSquadIcon(item.id);
                                    }}
                                    className={`w-10 h-10 rounded-lg border flex items-center justify-center transition-all duration-300 ${isSelected ? "border-primary bg-primary/20 text-primary scale-110 shadow-[0_0_10px_rgba(0,255,255,0.2)]" : "border-border/50 bg-background/50 text-muted-foreground hover:border-primary/50 hover:text-primary"}`}
                                  >
                                    <Icon className="w-5 h-5" />
                                  </button>
                                );
                              })}
                            </div>
                          </div>

                          {/* Color Selector */}
                          <div className="w-full">
                            <div className="text-[10px] uppercase tracking-widest text-muted-foreground mb-3 font-bold text-center">
                              Select Color
                            </div>
                            <div className="flex gap-4 justify-center">
                              {[
                                "cyan",
                                "purple",
                                "red",
                                "yellow",
                                "emerald",
                              ].map((color) => {
                                const isSelected = newSquadColor === color;
                                const bgClass =
                                  color === "cyan"
                                    ? "bg-cyan-400"
                                    : color === "purple"
                                      ? "bg-purple-500"
                                      : color === "red"
                                        ? "bg-red-500"
                                        : color === "yellow"
                                          ? "bg-yellow-400"
                                          : "bg-emerald-400";
                                const shadowClass =
                                  color === "cyan"
                                    ? "shadow-[0_0_10px_rgba(34,211,238,0.5)]"
                                    : color === "purple"
                                      ? "shadow-[0_0_10px_rgba(168,85,247,0.5)]"
                                      : color === "red"
                                        ? "shadow-[0_0_10px_rgba(239,68,68,0.5)]"
                                        : color === "yellow"
                                          ? "shadow-[0_0_10px_rgba(250,204,21,0.5)]"
                                          : "shadow-[0_0_10px_rgba(16,185,129,0.5)]";
                                return (
                                  <button
                                    key={color}
                                    onClick={() => {
                                      hapticFeedback(5);
                                      setNewSquadColor(color);
                                    }}
                                    className={`w-6 h-6 rounded-full transition-all duration-300 ${bgClass} ${isSelected ? `ring-2 ring-white ring-offset-2 ring-offset-black scale-125 ${shadowClass}` : "opacity-50 hover:opacity-100 hover:scale-110"}`}
                                  />
                                );
                              })}
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="squad-name">Squad Name</Label>
                        <Input
                          id="squad-name"
                          placeholder="e.g. Neural Vanguard"
                          className="bg-background/50"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="squad-desc">Mission Objective</Label>
                        <Input
                          id="squad-desc"
                          placeholder="e.g. Optimizing HRV and Sleep"
                          className="bg-background/50"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Privacy</Label>
                        <div className="flex gap-2">
                          <Button
                            variant="outline"
                            className="flex-1 border-primary bg-primary/10 text-primary"
                          >
                            Public
                          </Button>
                          <Button
                            variant="outline"
                            className="flex-1 opacity-50"
                          >
                            Invite Only
                          </Button>
                        </div>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button
                        className="w-full"
                        onClick={() => {
                          hapticFeedback(10);
                          toast({
                            title: "Squad Created",
                            description:
                              "Your new squad has been initialized with a custom emblem.",
                          });
                        }}
                      >
                        Initialize Squad
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>
            </div>
            <Card className="bg-card/40 border-border/50 backdrop-blur-sm overflow-hidden mb-8">
              <CardContent className="p-0">
                <div className="divide-y divide-border/50">
                  {mockTeamLeaderboard.map((team, index) => (
                    <div
                      key={team.id}
                      style={{ animationDelay: `${index * 50}ms` }}
                      className={cn(
                        "flex items-center justify-between p-4 transition-colors hover:bg-muted/30 animate-in fade-in slide-in-from-bottom-4 duration-500 fill-mode-both",
                        team.isCurrentUser &&
                          "bg-primary/10 hover:bg-primary/20 border-l-2 border-l-primary",
                      )}
                    >
                      <div className="flex items-center gap-4">
                        <span
                          className={cn(
                            "text-muted-foreground font-mono text-sm w-4 text-center",
                            index === 0 &&
                              "text-yellow-400 font-bold text-lg drop-shadow-[0_0_8px_rgba(250,204,21,0.5)]",
                            index === 1 && "text-slate-300 font-bold",
                            index === 2 && "text-amber-600 font-bold",
                          )}
                        >
                          {index + 1}
                        </span>
                        <Avatar className="w-10 h-10 border border-border">
                          <AvatarImage src={team.avatar} />
                          <AvatarFallback>
                            {team.name.substring(0, 2)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold">{team.name}</span>
                            {team.isCurrentUser && (
                              <Badge
                                variant="outline"
                                className="text-[9px] h-4 px-1 bg-primary/20 text-primary border-primary/30"
                              >
                                YOURS
                              </Badge>
                            )}
                          </div>
                          <div className="flex items-center text-xs text-muted-foreground mt-0.5">
                            <Users className="w-3 h-3 mr-1" />
                            {team.members} Members • {team.status}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <div className="font-mono font-bold text-primary">
                            {team.score}
                          </div>
                          <div className="text-[10px] text-muted-foreground uppercase tracking-widest">
                            Avg Sync
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium">Bio Hackers (Your Squad)</h3>
              <div className="flex items-center gap-2">
                <Sheet>
                  <SheetTrigger asChild>
                    <Button
                      variant="outline"
                      className="border-primary/50 text-primary hover:bg-primary/10"
                    >
                      <MessageSquare className="w-4 h-4 sm:mr-2" />
                      <span className="hidden sm:inline">Squad Chat</span>
                    </Button>
                  </SheetTrigger>
                  <SheetContent className="w-full sm:max-w-md bg-card/95 backdrop-blur-xl border-l-border/50 flex flex-col p-0">
                    <SheetHeader className="p-6 border-b border-border/50 bg-background/50">
                      <SheetTitle className="flex items-center gap-2">
                        <MessageSquare className="w-5 h-5 text-primary" />
                        Bio Hackers Comms
                      </SheetTitle>
                    </SheetHeader>
                    <ScrollArea className="flex-1 p-6">
                      <div className="space-y-4">
                        {messages.map((msg) => (
                          <div
                            key={msg.id}
                            className={cn(
                              "flex gap-3",
                              msg.isCurrentUser ? "flex-row-reverse" : "",
                            )}
                          >
                            <Avatar className="w-8 h-8 border border-border">
                              <AvatarImage src={msg.avatar} />
                              <AvatarFallback>{msg.sender[0]}</AvatarFallback>
                            </Avatar>
                            <div
                              className={cn(
                                "flex flex-col max-w-[75%]",
                                msg.isCurrentUser ? "items-end" : "items-start",
                              )}
                            >
                              <div className="flex items-baseline gap-2 mb-1">
                                <span className="text-xs font-medium text-muted-foreground">
                                  {msg.sender}
                                </span>
                                <span className="text-[10px] text-muted-foreground/70">
                                  {msg.time}
                                </span>
                              </div>
                              <div
                                className={cn(
                                  "p-3 rounded-lg text-sm min-w-[80px]",
                                  msg.isCurrentUser
                                    ? "bg-primary text-primary-foreground rounded-tr-none"
                                    : "bg-muted text-foreground rounded-tl-none",
                                )}
                              >
                                {msg.type === "audio" ? (
                                  <div className="flex items-center gap-3 w-48">
                                    <Button
                                      size="icon"
                                      variant={
                                        msg.isCurrentUser
                                          ? "secondary"
                                          : "default"
                                      }
                                      className="rounded-full shrink-0 h-8 w-8"
                                    >
                                      <Play className="w-4 h-4 ml-0.5" />
                                    </Button>
                                    <div className="flex-1 flex items-center gap-1 overflow-hidden">
                                      <AudioLines
                                        className={cn(
                                          "w-full h-5",
                                          msg.isCurrentUser
                                            ? "text-primary-foreground/50"
                                            : "text-primary/50",
                                        )}
                                      />
                                    </div>
                                    <span className="text-xs font-medium tabular-nums">
                                      {msg.duration}
                                    </span>
                                  </div>
                                ) : (
                                  msg.text
                                )}
                                {msg.isCurrentUser && (
                                  <div className="flex justify-end mt-1 -mb-1 -mr-1">
                                    {msg.status === "read" ? (
                                      <CheckCheck className="w-3.5 h-3.5 text-primary-foreground" />
                                    ) : (
                                      <Check className="w-3.5 h-3.5 text-primary-foreground/70" />
                                    )}
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                    <div className="p-4 border-t border-border/50 bg-background/50">
                      <form
                        onSubmit={handleSendMessage}
                        className="flex gap-2 items-center"
                      >
                        {isRecording ? (
                          <div className="flex-1 flex items-center justify-between bg-destructive/10 border border-destructive/20 rounded-md px-4 py-2 h-10">
                            <div className="flex items-center gap-2 text-destructive">
                              <div className="w-2 h-2 rounded-full bg-destructive animate-pulse" />
                              <span className="text-sm font-medium tabular-nums">
                                {formatTime(recordingTime)}
                              </span>
                            </div>
                            <Button
                              type="button"
                              size="icon"
                              variant="ghost"
                              className="h-6 w-6 text-destructive hover:text-destructive hover:bg-destructive/20"
                              onClick={stopRecording}
                            >
                              <Square className="w-4 h-4 fill-current" />
                            </Button>
                          </div>
                        ) : (
                          <Input
                            value={chatMessage}
                            onChange={(e) => setChatMessage(e.target.value)}
                            placeholder="Transmit message..."
                            className="bg-muted/50 border-border/50 focus-visible:ring-primary"
                          />
                        )}
                        {!isRecording && (
                          <Button
                            type="button"
                            size="icon"
                            variant="outline"
                            className="shrink-0 border-border/50"
                            onClick={startRecording}
                          >
                            <Mic className="w-4 h-4" />
                          </Button>
                        )}
                        <Button
                          type="submit"
                          size="icon"
                          disabled={isRecording || !chatMessage.trim()}
                          className="shrink-0 bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50"
                        >
                          <Send className="w-4 h-4" />
                        </Button>
                      </form>
                    </div>
                  </SheetContent>
                </Sheet>
                <Button
                  variant="outline"
                  className="border-primary/50 text-primary hover:bg-primary/10"
                  onClick={() => setIsInviteOpen(true)}
                >
                  <UserPlus className="w-4 h-4 sm:mr-2" />
                  <span className="hidden sm:inline">Invite</span>
                </Button>
              </div>
            </div>

            <Card className="bg-card/40 border-border/50 backdrop-blur-sm overflow-hidden mb-6">
              <CardContent className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <Avatar className="w-12 h-12 border-2 border-primary shadow-[0_0_15px_rgba(0,255,255,0.2)]">
                    <AvatarImage src="https://i.pravatar.cc/150?u=32" />
                    <AvatarFallback>BH</AvatarFallback>
                  </Avatar>
                  <div>
                    <h4 className="text-lg font-bold text-primary">
                      Bio Hackers
                    </h4>
                    <div className="flex items-center text-xs text-muted-foreground mt-0.5">
                      <Users className="w-3 h-3 mr-1" />5 Active Members •
                      Syncing
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-mono font-bold text-primary">
                    89.8%
                  </div>
                  <div className="text-[10px] text-muted-foreground uppercase tracking-widest">
                    Avg Sync Rate
                  </div>
                </div>
              </CardContent>
            </Card>

            <h4 className="text-sm font-bold text-muted-foreground uppercase tracking-widest mb-2">
              Squad Members
            </h4>
            <Card className="bg-card/40 border-border/50 backdrop-blur-sm overflow-hidden">
              <CardContent className="p-0">
                <div className="divide-y divide-border/50">
                  {mockTeamMembers.map((member, index) => (
                    <div
                      key={member.id}
                      style={{ animationDelay: `${index * 50}ms` }}
                      className={cn(
                        "flex items-center justify-between p-4 transition-colors hover:bg-muted/30 animate-in fade-in slide-in-from-bottom-4 duration-500 fill-mode-both",
                        member.isCurrentUser &&
                          "bg-primary/10 hover:bg-primary/20 border-l-2 border-l-primary",
                      )}
                    >
                      <div className="flex items-center gap-4">
                        <span className="text-muted-foreground font-mono text-sm w-4 text-center">
                          {index + 1}
                        </span>
                        <Avatar className="w-10 h-10 border border-border">
                          <AvatarImage src={member.avatar} />
                          <AvatarFallback>
                            {member.name.substring(0, 2)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p
                            className={cn(
                              "text-sm font-medium",
                              member.isCurrentUser && "text-primary font-bold",
                            )}
                          >
                            {member.name}
                          </p>
                          <div className="flex items-center text-[10px] text-muted-foreground mt-0.5">
                            <Shield className="w-3 h-3 mr-1" />
                            {member.role}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-4 sm:gap-6">
                        <div className="hidden sm:block opacity-70">
                          <Sparkline
                            data={member.history}
                            color={
                              member.trend === "up"
                                ? "hsl(142, 71%, 45%)"
                                : "hsl(0, 84%, 60%)"
                            }
                            name={member.name}
                          />
                        </div>
                        <div className="text-right min-w-[60px]">
                          <div className="text-lg font-mono font-bold text-primary">
                            {member.score}
                          </div>
                          <div className="flex items-center justify-end gap-1 text-[10px] text-muted-foreground">
                            {member.trend === "up" ? (
                              <TrendingUp className="w-3 h-3 text-green-500" />
                            ) : (
                              <TrendingUp className="w-3 h-3 text-destructive rotate-180" />
                            )}
                            Score
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <Sheet
          open={!!activeSectorChat}
          onOpenChange={(open) => !open && setActiveSectorChat(null)}
        >
          <SheetContent className="w-full sm:max-w-md bg-card/95 backdrop-blur-xl border-l-border/50 flex flex-col p-0">
            <SheetHeader className="p-6 border-b border-border/50 bg-background/50">
              <SheetTitle className="flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-cyan-400" />
                {activeSectorChat?.title} Comms
              </SheetTitle>
              <div className="flex items-center gap-2 mt-1">
                <Badge
                  variant="outline"
                  className="bg-cyan-500/10 text-cyan-400 border-cyan-500/30 text-[9px] uppercase"
                >
                  {activeSectorChat?.sector1} Coordination
                </Badge>
              </div>
            </SheetHeader>
            <ScrollArea className="flex-1 p-6">
              <div className="space-y-4">
                {(
                  (activeSectorChat &&
                    sectorMessages[activeSectorChat.title]) ||
                  []
                ).map((msg) => (
                  <div
                    key={msg.id}
                    className={cn(
                      "flex gap-3",
                      msg.isCurrentUser ? "flex-row-reverse" : "",
                    )}
                  >
                    <Avatar className="w-8 h-8 border border-border">
                      <AvatarImage src={msg.avatar} />
                      <AvatarFallback>{msg.sender[0]}</AvatarFallback>
                    </Avatar>
                    <div
                      className={cn(
                        "flex flex-col max-w-[75%]",
                        msg.isCurrentUser ? "items-end" : "items-start",
                      )}
                    >
                      <div className="flex items-baseline gap-2 mb-1">
                        <span
                          className={cn(
                            "text-xs font-medium",
                            msg.isCurrentUser
                              ? "text-primary"
                              : "text-muted-foreground",
                          )}
                        >
                          {msg.sender}
                        </span>
                        <span className="text-[10px] text-muted-foreground/70">
                          {msg.time}
                        </span>
                      </div>
                      <div
                        className={cn(
                          "p-3 rounded-lg text-sm min-w-[80px]",
                          msg.isCurrentUser
                            ? "bg-cyan-500 text-black font-medium rounded-tr-none"
                            : "bg-muted text-foreground rounded-tl-none",
                        )}
                      >
                        {msg.text}
                        {msg.isCurrentUser && (
                          <div className="flex justify-end mt-1 -mb-1 -mr-1">
                            {msg.status === "read" ? (
                              <CheckCheck className="w-3.5 h-3.5 text-black/70" />
                            ) : (
                              <Check className="w-3.5 h-3.5 text-black/50" />
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
            <div className="p-4 border-t border-border/50 bg-background/50">
              <form
                onSubmit={handleSendSectorMessage}
                className="flex gap-2 items-center"
              >
                <Input
                  value={chatMessage}
                  onChange={(e) => setChatMessage(e.target.value)}
                  placeholder={`Message ${activeSectorChat?.sector1}...`}
                  className="bg-muted/50 border-border/50 focus-visible:ring-cyan-500"
                />
                <Button
                  type="submit"
                  size="icon"
                  disabled={!chatMessage.trim()}
                  className="shrink-0 bg-cyan-500 text-black hover:bg-cyan-400 disabled:opacity-50"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </form>
            </div>
          </SheetContent>
        </Sheet>

        <SpectateDialog
          spectatingDuel={spectatingDuel}
          setSpectatingDuel={setSpectatingDuel}
          currentUser={currentUser}
          liveMetrics={liveMetrics}
        />

        <Dialog open={isInviteOpen} onOpenChange={setIsInviteOpen}>
          <DialogContent className="sm:max-w-md bg-card/95 border-border/50 backdrop-blur-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-primary" />
                Expand Your Network
              </DialogTitle>
              <DialogDescription>
                Invite others to compare Neural Calibration scores.
              </DialogDescription>
            </DialogHeader>
            <div className="flex items-center space-x-2 mt-4">
              <div className="grid flex-1 gap-2">
                <Input
                  defaultValue="https://therapyfit.elite/invite/user123"
                  readOnly
                  className="bg-background/50"
                />
              </div>
              <Button
                type="button"
                size="sm"
                className="px-3"
                onClick={copyInviteLink}
              >
                <Link2 className="h-4 w-4" />
              </Button>
            </div>
            <form onSubmit={handleInvite} className="space-y-4 mt-4">
              <div className="grid gap-2">
                <Label htmlFor="email">Email address</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="optimizer@example.com"
                  value={inviteEmail}
                  onChange={(e) => setInviteEmail(e.target.value)}
                  required
                />
              </div>
              <DialogFooter>
                <Button type="submit" className="w-full">
                  <Mail className="w-4 h-4 mr-2" />
                  Send Invite
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        <Dialog
          open={!!duelOpponent}
          onOpenChange={(open) => !open && setDuelOpponent(null)}
        >
          <DialogContent className="sm:max-w-md bg-card/95 border-border/50 backdrop-blur-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2 text-primary">
                <Swords className="w-5 h-5" />
                Initiate Neural Duel
              </DialogTitle>
            </DialogHeader>
            {duelOpponent && (
              <div className="py-6 space-y-6">
                <div className="flex items-center justify-between px-8">
                  <div className="flex flex-col items-center gap-2">
                    <Avatar className="w-16 h-16 border-2 border-primary">
                      <AvatarImage src={currentUser.avatar} />
                      <AvatarFallback>YOU</AvatarFallback>
                    </Avatar>
                    <span className="text-sm font-bold">You</span>
                  </div>
                  <div className="flex flex-col items-center">
                    <span className="text-xs font-bold text-muted-foreground mb-1">
                      VS
                    </span>
                  </div>
                  <div className="flex flex-col items-center gap-2">
                    <Avatar className="w-16 h-16 border-2 border-destructive">
                      <AvatarImage src={duelOpponent.avatar} />
                      <AvatarFallback>OP</AvatarFallback>
                    </Avatar>
                    <span className="text-sm font-bold">
                      {duelOpponent.name}
                    </span>
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label className="text-xs uppercase text-muted-foreground tracking-wider">
                      Select Duel Metric
                    </Label>
                    <div className="grid grid-cols-1 gap-2">
                      <button
                        className={cn(
                          "flex items-center justify-between p-3 rounded-md border text-left transition-all",
                          duelMetric === "recovery"
                            ? "border-primary bg-primary/10"
                            : "border-border/50 bg-background/50",
                        )}
                        onClick={() => setDuelMetric("recovery")}
                      >
                        <div className="font-bold text-sm">
                          Highest Recovery Index
                        </div>
                        <Shield
                          className={cn(
                            "w-4 h-4",
                            duelMetric === "recovery"
                              ? "text-primary"
                              : "text-muted-foreground",
                          )}
                        />
                      </button>
                      <button
                        className={cn(
                          "flex items-center justify-between p-3 rounded-md border text-left transition-all",
                          duelMetric === "cognitive"
                            ? "border-primary bg-primary/10"
                            : "border-border/50 bg-background/50",
                        )}
                        onClick={() => setDuelMetric("cognitive")}
                      >
                        <div className="font-bold text-sm">
                          Lowest Cognitive Load
                        </div>
                        <Activity
                          className={cn(
                            "w-4 h-4",
                            duelMetric === "cognitive"
                              ? "text-primary"
                              : "text-muted-foreground",
                          )}
                        />
                      </button>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <Label className="text-xs uppercase text-muted-foreground tracking-wider">
                        Neural Wager
                      </Label>
                      <span className="text-[10px] text-primary font-mono">
                        Balance: {neuralPoints} PTS
                      </span>
                    </div>
                    <div className="relative">
                      <Zap className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-primary fill-primary/20" />
                      <Input
                        type="number"
                        value={wagerAmount}
                        onChange={(e) => setWagerAmount(e.target.value)}
                        className="pl-9 h-12 bg-background/50 border-border/50 font-mono text-primary"
                        placeholder="Enter wager amount..."
                      />
                    </div>
                    <p className="text-[10px] text-muted-foreground text-center italic">
                      Winner takes the full pool minus 5% neural protocol fee.
                    </p>
                  </div>
                </div>
              </div>
            )}
            <DialogFooter>
              <Button variant="outline" onClick={() => setDuelOpponent(null)}>
                Cancel
              </Button>
              <Button onClick={handleSendDuel}>Send Challenge</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}

const SpectateDialog = ({
  spectatingDuel,
  setSpectatingDuel,
  currentUser,
  liveMetrics,
}: {
  spectatingDuel: any;
  setSpectatingDuel: (val: any) => void;
  currentUser: any;
  liveMetrics: any;
}) => {
  return (
    <Dialog
      open={!!spectatingDuel}
      onOpenChange={(open) => !open && setSpectatingDuel(null)}
    >
      <DialogContent className="sm:max-w-2xl bg-card/95 border-border/50 backdrop-blur-xl p-0 overflow-hidden">
        <div className="relative h-32 bg-gradient-to-b from-primary/20 to-transparent flex items-center justify-center">
          <div className="absolute top-4 left-4">
            <Badge
              variant="default"
              className="bg-red-500 animate-pulse gap-1.5 border-none"
            >
              LIVE SPECTATE
            </Badge>
          </div>
          <div className="flex items-center gap-8 z-10">
            <Avatar className="h-16 w-16 border-2 border-primary shadow-[0_0_20px_hsl(var(--primary)/0.4)]">
              <AvatarImage src={currentUser.avatar} />
            </Avatar>
            <Swords className="h-8 w-8 text-primary/40 animate-bounce" />
            <Avatar className="h-16 w-16 border-2 border-destructive shadow-[0_0_20px_hsl(var(--destructive)/0.4)]">
              <AvatarImage src={spectatingDuel?.avatar} />
            </Avatar>
          </div>
        </div>
        <div className="p-6 space-y-8">
          <div className="grid grid-cols-2 gap-8">
            <div className="space-y-6">
              <div className="space-y-2">
                <div className="flex justify-between text-[10px] uppercase font-bold text-muted-foreground">
                  <span>Cognitive Load</span>
                  <span className="text-primary">
                    {Math.round(liveMetrics.user1.cognitive)}%
                  </span>
                </div>
                <Progress
                  value={liveMetrics.user1.cognitive}
                  className="h-1.5"
                />
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-[10px] uppercase font-bold text-muted-foreground">
                  <span>Recovery Index</span>
                  <span className="text-primary">
                    {Math.round(liveMetrics.user1.recovery)}%
                  </span>
                </div>
                <Progress
                  value={liveMetrics.user1.recovery}
                  className="h-1.5"
                />
              </div>
            </div>
            <div className="space-y-6">
              <div className="space-y-2">
                <div className="flex justify-between text-[10px] uppercase font-bold text-muted-foreground">
                  <span>Cognitive Load</span>
                  <span className="text-destructive">
                    {Math.round(liveMetrics.user2.cognitive)}%
                  </span>
                </div>
                <Progress
                  value={liveMetrics.user2.cognitive}
                  className="h-1.5"
                />
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-[10px] uppercase font-bold text-muted-foreground">
                  <span>Recovery Index</span>
                  <span className="text-destructive">
                    {Math.round(liveMetrics.user2.recovery)}%
                  </span>
                </div>
                <Progress
                  value={liveMetrics.user2.recovery}
                  className="h-1.5"
                />
              </div>
            </div>
          </div>
        </div>
        <DialogFooter className="p-4 bg-muted/20 border-t border-border/30">
          <Button
            variant="ghost"
            onClick={() => setSpectatingDuel(null)}
            className="w-full text-xs uppercase tracking-widest font-bold"
          >
            Exit Stream
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
