import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  ChevronLeft,
  Flame,
  Droplet,
  Moon,
  Brain,
  Activity,
  Sun,
  Check,
  Target,
  Plus,
  Zap,
  ArrowRight,
  Crosshair,
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  hapticFeedback,
  playNodeTapSound,
  playSuccessChime,
} from "@/lib/utils";

const INITIAL_HABITS = [
  {
    id: 1,
    title: "Morning Hydration (1L)",
    category: "Recovery",
    icon: Droplet,
    color: "text-blue-400",
    bg: "bg-blue-400/10",
    border: "border-blue-400/30",
    shadow: "shadow-[0_0_15px_rgba(96,165,250,0.2)]",
    completed: true,
    streak: 12,
  },
  {
    id: 2,
    title: "Circadian Sync (Sunlight)",
    category: "Recovery",
    icon: Sun,
    color: "text-yellow-400",
    bg: "bg-yellow-400/10",
    border: "border-yellow-400/30",
    shadow: "shadow-[0_0_15px_rgba(250,204,21,0.2)]",
    completed: false,
    streak: 4,
  },
  {
    id: 3,
    title: "Neural Down-regulation",
    category: "Cognitive",
    icon: Brain,
    color: "text-purple-400",
    bg: "bg-purple-400/10",
    border: "border-purple-400/30",
    shadow: "shadow-[0_0_15px_rgba(168,85,247,0.2)]",
    completed: false,
    streak: 8,
  },
  {
    id: 4,
    title: "Kinetic Load (Zone 2)",
    category: "Physical",
    icon: Activity,
    color: "text-emerald-400",
    bg: "bg-emerald-400/10",
    border: "border-emerald-400/30",
    shadow: "shadow-[0_0_15px_rgba(16,185,129,0.2)]",
    completed: true,
    streak: 21,
  },
  {
    id: 5,
    title: "Sleep Architecture (8h)",
    category: "Recovery",
    icon: Moon,
    color: "text-indigo-400",
    bg: "bg-indigo-400/10",
    border: "border-indigo-400/30",
    shadow: "shadow-[0_0_15px_rgba(99,102,241,0.2)]",
    completed: false,
    streak: 5,
  },
];

const WEEK_DAYS = [
  { day: "Mon", date: "12", active: false },
  { day: "Tue", date: "13", active: false },
  { day: "Wed", date: "14", active: true }, // Current day
  { day: "Thu", date: "15", active: false },
  { day: "Fri", date: "16", active: false },
  { day: "Sat", date: "17", active: false },
  { day: "Sun", date: "18", active: false },
];

export default function Habits() {
  const navigate = useNavigate();
  const [habits, setHabits] = useState(INITIAL_HABITS);

  const toggleHabit = (id: number) => {
    hapticFeedback(15);
    setHabits((prev) =>
      prev.map((h) => {
        if (h.id === id) {
          const isCompleting = !h.completed;
          if (isCompleting) {
            playNodeTapSound(600);
          } else {
            playNodeTapSound(300);
          }
          return {
            ...h,
            completed: isCompleting,
            streak: isCompleting ? h.streak + 1 : h.streak - 1,
          };
        }
        return h;
      }),
    );

    // Check if all completed after this toggle
    const willBeCompleted = habits.map((h) =>
      h.id === id ? { ...h, completed: !h.completed } : h,
    );
    if (willBeCompleted.every((h) => h.completed)) {
      setTimeout(() => playSuccessChime(), 300);
    }
  };

  const completedCount = habits.filter((h) => h.completed).length;
  const progressPercent = Math.round((completedCount / habits.length) * 100);

  return (
    <div className="min-h-[100dvh] bg-[#050505] text-foreground pb-24 relative overflow-x-hidden">
      {/* Background */}
      <div className="fixed inset-0 z-0 pointer-events-none">
        <div className="absolute inset-0 bg-[url('https://vibe.filesafe.space/1776727899133821812/assets/noise.png')] opacity-10 mix-blend-overlay" />
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-primary/10 blur-[120px] rounded-full pointer-events-none" />
      </div>

      {/* Header */}
      <header className="relative z-10 px-4 pt-[calc(1rem_+_env(safe-area-inset-top,_0px))] pb-4 flex items-center justify-between glass-panel border-b border-white/5 sticky top-0">
        <Button
          variant="ghost"
          size="icon"
          className="rounded-full hover:bg-white/10"
          onClick={() => navigate(-1)}
        >
          <ChevronLeft className="w-5 h-5 text-white" />
        </Button>
        <div className="text-center">
          <h1 className="text-sm font-black uppercase tracking-widest text-white flex items-center justify-center gap-2">
            <Target className="w-4 h-4 text-primary" />
            Daily Directives
          </h1>
          <p className="text-[10px] text-muted-foreground uppercase tracking-widest">
            Standard Operating Procedures
          </p>
        </div>
        <Button
          variant="ghost"
          size="icon"
          className="rounded-full hover:bg-white/10 text-primary"
        >
          <Plus className="w-5 h-5" />
        </Button>
      </header>

      <main className="relative z-10 px-4 pt-6 space-y-8 max-w-md mx-auto">
        {/* Progress Overview */}
        <div className="glass-panel rounded-3xl p-6 border-primary/20 shadow-[0_0_30px_rgba(0,255,255,0.05)] relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-primary/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/4 pointer-events-none" />

          <div className="flex justify-between items-end mb-6 relative z-10">
            <div>
              <Badge
                variant="outline"
                className="bg-primary/10 text-primary border-primary/30 mb-2 uppercase tracking-widest text-[9px] px-2 py-0.5"
              >
                System Status
              </Badge>
              <h2 className="text-3xl font-black text-white tracking-tighter uppercase">
                {progressPercent}%
              </h2>
              <p className="text-xs text-muted-foreground uppercase tracking-widest mt-1">
                Completion Rate
              </p>
            </div>
            <div className="text-right">
              <div className="text-xl font-black text-white">
                {completedCount}/{habits.length}
              </div>
              <p className="text-[10px] text-muted-foreground uppercase tracking-widest mt-1">
                Protocols
              </p>
            </div>
          </div>

          <div className="w-full h-3 bg-black/60 rounded-full overflow-hidden border border-white/5 relative z-10">
            <motion.div
              className="h-full bg-primary shadow-[0_0_15px_rgba(0,255,255,0.6)]"
              initial={{ width: 0 }}
              animate={{ width: `${progressPercent}%` }}
              transition={{ duration: 0.8, ease: "easeOut" }}
            />
          </div>
        </div>

        {/* Weekly Strip */}
        <div>
          <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-4 flex items-center gap-2">
            <Crosshair className="w-3.5 h-3.5" />
            Active Window
          </h3>
          <div className="flex justify-between gap-2">
            {WEEK_DAYS.map((day, i) => (
              <div
                key={i}
                className={`flex flex-col items-center justify-center p-2 rounded-xl flex-1 border ${
                  day.active
                    ? "bg-primary/20 border-primary/50 shadow-[0_0_15px_rgba(0,255,255,0.2)]"
                    : "bg-white/5 border-white/5"
                }`}
              >
                <span
                  className={`text-[9px] uppercase tracking-widest mb-1 ${day.active ? "text-primary" : "text-muted-foreground"}`}
                >
                  {day.day}
                </span>
                <span
                  className={`text-sm font-black ${day.active ? "text-white" : "text-muted-foreground"}`}
                >
                  {day.date}
                </span>
                {day.active && (
                  <div className="w-1 h-1 rounded-full bg-primary mt-1 shadow-[0_0_5px_rgba(0,255,255,1)]" />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Habits List */}
        <div>
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-widest flex items-center gap-2">
              <Zap className="w-3.5 h-3.5" />
              Execution Required
            </h3>
          </div>

          <div className="space-y-3">
            <AnimatePresence>
              {habits.map((habit) => {
                const Icon = habit.icon;
                return (
                  <motion.div
                    key={habit.id}
                    layout
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => toggleHabit(habit.id)}
                    className={`relative p-4 rounded-2xl border cursor-pointer overflow-hidden transition-all duration-300 ${
                      habit.completed
                        ? "bg-primary/5 border-primary/30 shadow-[0_0_20px_rgba(0,255,255,0.05)]"
                        : "glass-panel hover:bg-white/5"
                    }`}
                  >
                    {/* Completion Glow Background */}
                    {habit.completed && (
                      <div className="absolute inset-0 bg-gradient-to-r from-primary/10 to-transparent pointer-events-none" />
                    )}

                    <div className="flex items-center gap-4 relative z-10">
                      {/* Checkbox / Icon */}
                      <div
                        className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 border transition-all duration-300 ${
                          habit.completed
                            ? "bg-primary text-primary-foreground border-primary shadow-[0_0_15px_rgba(0,255,255,0.4)]"
                            : `${habit.bg} ${habit.border} ${habit.color} ${habit.shadow}`
                        }`}
                      >
                        {habit.completed ? (
                          <Check className="w-6 h-6" />
                        ) : (
                          <Icon className="w-6 h-6" />
                        )}
                      </div>

                      {/* Content */}
                      <div className="flex-1">
                        <h4
                          className={`text-sm font-bold uppercase tracking-wide transition-colors ${habit.completed ? "text-white" : "text-foreground"}`}
                        >
                          {habit.title}
                        </h4>
                        <div className="flex items-center gap-3 mt-1">
                          <span className="text-[10px] text-muted-foreground uppercase tracking-widest">
                            {habit.category}
                          </span>
                          <div className="flex items-center gap-1 text-[10px] font-bold text-orange-400">
                            <Flame className="w-3 h-3" />
                            {habit.streak} Day{habit.streak !== 1 ? "s" : ""}
                          </div>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        </div>
      </main>
    </div>
  );
}
