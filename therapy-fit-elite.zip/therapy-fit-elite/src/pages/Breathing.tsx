import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import {
  Wind,
  Play,
  Pause,
  RotateCcw,
  BrainCircuit,
  Waves,
  Activity,
  CheckCircle2,
  ChevronLeft,
} from "lucide-react";
import { hapticFeedback, cn } from "@/lib/utils";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { Label } from "@/components/ui/label";
import { useNavigate } from "react-router-dom";
import { AreaChart, Area, ResponsiveContainer, YAxis } from "recharts";

const BREATH_PATTERNS = [
  {
    id: "box",
    name: "Box Breathing",
    inhale: 4,
    hold1: 4,
    exhale: 4,
    hold2: 4,
    desc: "Equal parts for stability & focus.",
  },
  {
    id: "relax",
    name: "4-7-8 Relax",
    inhale: 4,
    hold1: 7,
    exhale: 8,
    hold2: 0,
    desc: "Parasympathetic activation for recovery.",
  },
  {
    id: "power",
    name: "Power Breath",
    inhale: 6,
    hold1: 2,
    exhale: 7,
    hold2: 0,
    desc: "Increase CO2 tolerance & energy.",
  },
];

const RealTimeHRVChart = ({
  phase,
  isActive,
}: {
  phase: string;
  isActive: boolean;
}) => {
  const [data, setData] = useState<{ time: number; hrv: number }[]>(
    Array.from({ length: 30 }, (_, i) => ({ time: i, hrv: 65 })),
  );
  const timeRef = useRef(30);

  useEffect(() => {
    if (!isActive) return;
    const interval = setInterval(() => {
      setData((prev) => {
        const last = prev[prev.length - 1].hrv;
        let next = last;
        // Respiratory Sinus Arrhythmia simulation
        if (phase === "inhale")
          next = last - (Math.random() * 2 + 1); // HR increases, HRV drops
        else if (phase === "exhale")
          next = last + (Math.random() * 3 + 1.5); // HR decreases, HRV rises
        else next = last + (Math.random() * 1.5 - 0.5); // Hold

        next = Math.max(45, Math.min(95, next));

        return [...prev.slice(1), { time: timeRef.current++, hrv: next }];
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [phase, isActive]);

  const currentHrv = Math.round(data[data.length - 1].hrv);

  return (
    <div className="w-full h-28 bg-background/40 rounded-xl border border-border/50 p-2 flex flex-col relative overflow-hidden mb-8">
      <div className="absolute top-2 left-3 z-10 flex items-center gap-2">
        <Activity
          className={cn(
            "w-3 h-3",
            isActive ? "text-primary animate-pulse" : "text-muted-foreground",
          )}
        />
        <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">
          Live HRV Sync
        </span>
      </div>
      <div className="absolute top-2 right-3 z-10 flex items-baseline gap-1">
        <span className="text-lg font-bold text-primary">{currentHrv}</span>
        <span className="text-[9px] text-muted-foreground font-mono">ms</span>
      </div>
      <div className="flex-1 mt-6">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data}>
            <defs>
              <linearGradient id="hrvGradientSync" x1="0" y1="0" x2="0" y2="1">
                <stop
                  offset="5%"
                  stopColor="hsl(var(--primary))"
                  stopOpacity={0.3}
                />
                <stop
                  offset="95%"
                  stopColor="hsl(var(--primary))"
                  stopOpacity={0}
                />
              </linearGradient>
            </defs>
            <YAxis domain={["dataMin - 2", "dataMax + 2"]} hide />
            <Area
              type="monotone"
              dataKey="hrv"
              stroke="hsl(var(--primary))"
              strokeWidth={2}
              fill="url(#hrvGradientSync)"
              isAnimationActive={false}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default function Breathing() {
  const navigate = useNavigate();
  const [isActive, setIsActive] = useState(false);
  const [patternId, setPatternId] = useState("box");
  const [phase, setPhase] = useState<"inhale" | "hold1" | "exhale" | "hold2">(
    "inhale",
  );
  const [timeLeft, setTimeLeft] = useState(0);
  const [totalSeconds, setTotalSeconds] = useState(0);
  const [cycles, setCycles] = useState(0);

  const audioCtxRef = useRef<AudioContext | null>(null);
  const oscRef = useRef<OscillatorNode | null>(null);
  const gainRef = useRef<GainNode | null>(null);

  const pattern =
    BREATH_PATTERNS.find((p) => p.id === patternId) || BREATH_PATTERNS[0];

  useEffect(() => {
    if (!isActive) {
      setPhase("inhale");
      setTimeLeft(pattern.inhale);
      stopAudio();
      return;
    }

    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          // Switch phase
          if (phase === "inhale") {
            if (pattern.hold1 > 0) {
              setPhase("hold1");
              return pattern.hold1;
            } else {
              setPhase("exhale");
              return pattern.exhale;
            }
          } else if (phase === "hold1") {
            setPhase("exhale");
            return pattern.exhale;
          } else if (phase === "exhale") {
            if (pattern.hold2 > 0) {
              setPhase("hold2");
              return pattern.hold2;
            } else {
              setCycles((c) => c + 1);
              setPhase("inhale");
              return pattern.inhale;
            }
          } else {
            // hold2
            setCycles((c) => c + 1);
            setPhase("inhale");
            return pattern.inhale;
          }
        }
        return prev - 1;
      });
      setTotalSeconds((s) => s + 1);
    }, 1000);

    return () => clearInterval(interval);
  }, [isActive, phase, pattern, patternId]);

  useEffect(() => {
    if (isActive) {
      updateAudio();
      // Haptic feedback on phase change
      if (timeLeft === pattern.inhale && phase === "inhale")
        hapticFeedback([50, 30, 50]);
      if (timeLeft === pattern.hold1 && phase === "hold1") hapticFeedback(30);
      if (timeLeft === pattern.exhale && phase === "exhale")
        hapticFeedback([30, 50, 30]);
      if (timeLeft === pattern.hold2 && phase === "hold2") hapticFeedback(30);
    }
  }, [phase, timeLeft, isActive]);

  const initAudio = () => {
    if (!audioCtxRef.current) {
      audioCtxRef.current = new (
        window.AudioContext || (window as any).webkitAudioContext
      )();
      gainRef.current = audioCtxRef.current.createGain();
      gainRef.current.connect(audioCtxRef.current.destination);
      gainRef.current.gain.value = 0;
    }
  };

  const updateAudio = () => {
    if (!audioCtxRef.current || !gainRef.current) return;
    if (audioCtxRef.current.state === "suspended") audioCtxRef.current.resume();

    if (!oscRef.current) {
      oscRef.current = audioCtxRef.current.createOscillator();
      oscRef.current.type = "sine";
      oscRef.current.connect(gainRef.current);
      oscRef.current.start();
    }

    const now = audioCtxRef.current.currentTime;
    if (phase === "inhale") {
      oscRef.current.frequency.exponentialRampToValueAtTime(440, now + 1);
      gainRef.current.gain.linearRampToValueAtTime(0.1, now + 0.5);
    } else if (phase === "exhale") {
      oscRef.current.frequency.exponentialRampToValueAtTime(220, now + 1);
      gainRef.current.gain.linearRampToValueAtTime(0.1, now + 0.5);
    } else {
      gainRef.current.gain.linearRampToValueAtTime(0.02, now + 0.5);
    }
  };

  const stopAudio = () => {
    if (gainRef.current) {
      gainRef.current.gain.linearRampToValueAtTime(
        0,
        audioCtxRef.current?.currentTime || 0 + 0.5,
      );
    }
    if (oscRef.current) {
      oscRef.current.stop();
      oscRef.current = null;
    }
  };

  const togglePacer = () => {
    initAudio();
    hapticFeedback(isActive ? 50 : [50, 30, 50]);
    setIsActive(!isActive);
  };

  const resetPacer = () => {
    hapticFeedback(50);
    setIsActive(false);
    setPhase("inhale");
    setTimeLeft(pattern.inhale);
    setCycles(0);
    setTotalSeconds(0);
  };

  const handlePatternChange = (val: string) => {
    setPatternId(val);
    const p = BREATH_PATTERNS.find((x) => x.id === val)!;
    setPhase("inhale");
    setTimeLeft(p.inhale);
    if (isActive) hapticFeedback([50, 30, 50]);
  };

  const getPhaseText = () => {
    switch (phase) {
      case "inhale":
        return "Inhale";
      case "hold1":
        return "Hold";
      case "exhale":
        return "Exhale";
      case "hold2":
        return "Hold";
    }
  };

  // Calculate scale for the pacer circle
  const getScale = () => {
    if (!isActive) return 1;
    const p = BREATH_PATTERNS.find((x) => x.id === patternId)!;
    if (phase === "inhale") {
      const progress = (p.inhale - timeLeft) / p.inhale;
      return 1 + progress * 0.5;
    }
    if (phase === "hold1") return 1.5;
    if (phase === "exhale") {
      const progress = (p.exhale - timeLeft) / p.exhale;
      return 1.5 - progress * 0.5;
    }
    return 1;
  };

  const handleComplete = () => {
    hapticFeedback([100, 50, 100]);
    toast.success("Recovery Cycle Complete", {
      description: `Synchronized for ${Math.floor(totalSeconds / 60)}m ${totalSeconds % 60}s. Neural friction reduced.`,
    });
    navigate("/audit");
  };

  return (
    <div className="container max-w-md mx-auto p-4 flex-1 flex flex-col selection:bg-primary/30">
      <div className="flex items-center justify-between mb-8">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => navigate(-1)}
          className="text-muted-foreground"
        >
          <ChevronLeft className="h-6 w-6" />
        </Button>
        <div className="text-center flex-1 mr-10">
          <h1 className="text-2xl font-bold tracking-tight">Neural Sync</h1>
          <p className="text-sm text-muted-foreground">
            Post-audit recovery pacer
          </p>
        </div>
      </div>

      <Card className="flex-1 bg-card/40 border-border/50 backdrop-blur-sm relative overflow-hidden flex flex-col">
        {isActive && (
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-primary/5 via-transparent to-transparent animate-neural-pulse" />
        )}

        <CardContent className="flex-1 flex flex-col items-center justify-center p-8 relative z-10">
          {/* Pacer Visualizer */}
          <div className="relative w-64 h-64 flex items-center justify-center mb-12">
            {/* Background Rings */}
            <div className="absolute inset-0 rounded-full border border-primary/10" />
            <div className="absolute inset-4 rounded-full border border-primary/5" />

            {/* Animated Circle */}
            <div
              className={cn(
                "w-32 h-32 rounded-full bg-gradient-to-br from-primary to-blue-500 shadow-[0_0_40px_rgba(0,255,255,0.3)] transition-transform duration-1000 ease-linear flex items-center justify-center",
                isActive && "animate-pulse",
              )}
              style={{ transform: `scale(${getScale()})` }}
            >
              <Wind className="h-10 w-10 text-primary-foreground opacity-50" />
            </div>

            {/* Glowing Aura */}
            {isActive && (
              <div
                className="absolute inset-0 rounded-full border-2 border-primary/30 animate-ping"
                style={{
                  animationDuration: "4s",
                  transform: `scale(${getScale()})`,
                }}
              />
            )}

            <div className="absolute -bottom-4 text-center">
              <div className="text-4xl font-bold tracking-tighter tabular-nums text-foreground drop-shadow-[0_0_15px_rgba(0,255,255,0.3)]">
                {isActive ? timeLeft : "--"}
              </div>
              <div className="text-xs font-bold text-primary mt-1 uppercase tracking-[0.2em] animate-pulse">
                {isActive ? getPhaseText() : "Ready"}
              </div>
            </div>
          </div>

          <div className="w-full space-y-8">
            <RealTimeHRVChart phase={phase} isActive={isActive} />

            <div className="grid grid-cols-2 gap-4 text-center">
              <div className="bg-background/40 p-3 rounded-lg border border-border/50">
                <div className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest mb-1">
                  Cycles
                </div>
                <div className="text-xl font-bold text-primary">{cycles}</div>
              </div>
              <div className="bg-background/40 p-3 rounded-lg border border-border/50">
                <div className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest mb-1">
                  Duration
                </div>
                <div className="text-xl font-bold text-primary">
                  {Math.floor(totalSeconds / 60)}:
                  {(totalSeconds % 60).toString().padStart(2, "0")}
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <Label className="text-xs font-bold text-muted-foreground uppercase tracking-widest ml-1">
                Breathing Protocol
              </Label>
              <Select
                value={patternId}
                onValueChange={handlePatternChange}
                disabled={isActive}
              >
                <SelectTrigger className="h-12 bg-background/50 border-primary/20">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {BREATH_PATTERNS.map((p) => (
                    <SelectItem key={p.id} value={p.id}>
                      <div className="flex flex-col items-start py-1">
                        <span className="font-bold">{p.name}</span>
                        <span className="text-[10px] text-muted-foreground">
                          {p.desc}
                        </span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center gap-4">
              <Button
                variant="outline"
                size="icon"
                className="h-14 w-14 rounded-xl border-primary/20 hover:bg-primary/10 hover:text-primary"
                onClick={resetPacer}
              >
                <RotateCcw className="h-6 w-6" />
              </Button>
              <Button
                size="lg"
                className={cn(
                  "flex-1 h-14 rounded-xl text-lg font-bold shadow-[0_0_20px_rgba(0,200,200,0.3)] transition-all",
                  isActive &&
                    "bg-destructive text-destructive-foreground hover:bg-destructive/90 shadow-[0_0_20px_rgba(255,0,0,0.3)]",
                )}
                onClick={togglePacer}
              >
                {isActive ? (
                  <div className="flex items-center gap-2">
                    <Pause className="h-5 w-5" />
                    <span>Pause Sync</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <Play className="h-5 w-5 fill-current" />
                    <span>Start Neural Sync</span>
                  </div>
                )}
              </Button>
            </div>

            {cycles >= 3 && !isActive && (
              <Button
                onClick={handleComplete}
                className="w-full h-12 bg-primary/20 text-primary border border-primary/30 hover:bg-primary/30 animate-in fade-in zoom-in-95"
              >
                <CheckCircle2 className="h-4 w-4 mr-2" />
                Finalize Recovery
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      <div className="mt-8 grid grid-cols-3 gap-4">
        <div className="flex flex-col items-center gap-2">
          <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center text-primary">
            <BrainCircuit className="h-5 w-5" />
          </div>
          <span className="text-[10px] text-center text-muted-foreground uppercase font-bold">
            Neural Balance
          </span>
        </div>
        <div className="flex flex-col items-center gap-2">
          <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center text-primary">
            <Waves className="h-5 w-5" />
          </div>
          <span className="text-[10px] text-center text-muted-foreground uppercase font-bold">
            ANS Tuning
          </span>
        </div>
        <div className="flex flex-col items-center gap-2">
          <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center text-primary">
            <Activity className="h-5 w-5" />
          </div>
          <span className="text-[10px] text-center text-muted-foreground uppercase font-bold">
            HRV Sync
          </span>
        </div>
      </div>
    </div>
  );
}
