import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  ChevronLeft,
  Footprints,
  Bike,
  PersonStanding,
  Timer,
  MapPin,
  TrendingUp,
  Trophy,
  Swords,
  Plus,
  Flame,
  Check,
  Crown,
  Zap,
  Target,
  Activity as ActivityIcon,
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  hapticFeedback,
  playNodeTapSound,
  playSuccessChime,
} from "@/lib/utils";
import { toast } from "sonner";

type ActivityType = "steps" | "run" | "ride";

interface ActivityRecord {
  id: string;
  type: ActivityType;
  value: number; // steps for steps, meters for run/ride
  duration: number; // seconds
  timestamp: number;
}

interface Challenge {
  id: string;
  title: string;
  type: ActivityType;
  metric: "distance" | "steps" | "duration";
  target: number;
  owner: string;
  ownerScore: number;
  unit: string;
  description: string;
}

const ACTIVITY_META: Record<
  ActivityType,
  {
    label: string;
    icon: any;
    color: string;
    bg: string;
    border: string;
    shadow: string;
    unit: string;
  }
> = {
  steps: {
    label: "Steps",
    icon: Footprints,
    color: "text-emerald-400",
    bg: "bg-emerald-400/10",
    border: "border-emerald-400/30",
    shadow: "shadow-[0_0_15px_rgba(16,185,129,0.25)]",
    unit: "steps",
  },
  run: {
    label: "Run",
    icon: PersonStanding,
    color: "text-orange-400",
    bg: "bg-orange-400/10",
    border: "border-orange-400/30",
    shadow: "shadow-[0_0_15px_rgba(249,115,22,0.25)]",
    unit: "m",
  },
  ride: {
    label: "Ride",
    icon: Bike,
    color: "text-blue-400",
    bg: "bg-blue-400/10",
    border: "border-blue-400/30",
    shadow: "shadow-[0_0_15px_rgba(59,130,246,0.25)]",
    unit: "m",
  },
};

const STORAGE_KEY = "tf_activity_records";

const INITIAL_CHALLENGES: Challenge[] = [
  {
    id: "c1",
    title: "Sector Sprint Duel",
    type: "run",
    metric: "distance",
    target: 5000,
    owner: "Ghost-09",
    ownerScore: 4820,
    unit: "m",
    description:
      "Beat Ghost-09's best 5K split. Log a run that exceeds the target distance to claim the sector crown.",
  },
  {
    id: "c2",
    title: "Stairway to Hell",
    type: "steps",
    metric: "steps",
    target: 12000,
    owner: "Valkyrie",
    ownerScore: 11450,
    unit: "steps",
    description:
      "Out-walk the Valkyrie operator. Accumulate steps in a single day to surpass the standing record.",
  },
  {
    id: "c3",
    title: "Circuit Charge",
    type: "ride",
    metric: "distance",
    target: 18000,
    owner: "Reaper-03",
    ownerScore: 17200,
    unit: "m",
    description:
      "Top Reaper-03's ride distance. Log a ride exceeding the target to take the circuit title.",
  },
];

const formatDuration = (seconds: number) => {
  const m = Math.floor(seconds / 60);
  const s = Math.round(seconds % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
};

const formatValue = (type: ActivityType, value: number) => {
  if (type === "steps") return value.toLocaleString();
  return `${(value / 1000).toFixed(2)} km`;
};

export default function Activity() {
  const navigate = useNavigate();
  const [records, setRecords] = useState<ActivityRecord[]>([]);
  const [challenges] = useState<Challenge[]>(INITIAL_CHALLENGES);
  const [activeTab, setActiveTab] = useState<ActivityType | "log">("log");
  const [showAddForm, setShowAddForm] = useState(false);
  const [newType, setNewType] = useState<ActivityType>("run");
  const [newValue, setNewValue] = useState("");
  const [newDuration, setNewDuration] = useState("");

  // Load records
  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) setRecords(JSON.parse(saved));
    } catch (e) {}
  }, []);

  const persist = (next: ActivityRecord[]) => {
    setRecords(next);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    } catch (e) {}
  };

  const addRecord = () => {
    const value = parseFloat(newValue);
    const duration = parseFloat(newDuration) || 0;
    if (!value || value <= 0) {
      toast.error("Enter a valid distance / step count.");
      return;
    }
    const record: ActivityRecord = {
      id: `act-${Date.now()}`,
      type: newType,
      value: Math.round(value),
      duration: Math.round(duration * 60),
      timestamp: Date.now(),
    };
    persist([record, ...records]);
    hapticFeedback(20);
    playSuccessChime();
    setShowAddForm(false);
    setNewValue("");
    setNewDuration("");
    toast.success(`${ACTIVITY_META[newType].label} logged.`, {
      description: formatValue(newType, record.value),
    });

    // Check challenges
    challenges.forEach((c) => {
      if (c.type === newType) {
        const beats =
          c.metric === "steps"
            ? record.value > c.ownerScore
            : record.value > c.ownerScore;
        if (beats) {
          setTimeout(
            () =>
              toast(`Crown claimed — ${c.title}`, {
                description: `You beat ${c.owner}'s record of ${formatValue(c.type, c.ownerScore)}.`,
                icon: <Crown className="w-4 h-4 text-yellow-400" />,
              }),
            700,
          );
          hapticFeedback([30, 60, 30]);
        }
      }
    });
  };

  const deleteRecord = (id: string) => {
    hapticFeedback(10);
    playNodeTapSound(300);
    persist(records.filter((r) => r.id !== id));
  };

  // Aggregate stats
  const totalSteps = records
    .filter((r) => r.type === "steps")
    .reduce((a, r) => a + r.value, 0);
  const totalDistance =
    records.filter((r) => r.type !== "steps").reduce((a, r) => a + r.value, 0) /
    1000;
  const totalDuration = records.reduce((a, r) => a + r.duration, 0);
  const sessionCount = records.length;

  const filteredRecords =
    activeTab === "log" ? records : records.filter((r) => r.type === activeTab);

  return (
    <div className="min-h-[100dvh] bg-[#050505] text-foreground pb-24 relative overflow-x-hidden">
      {/* Background */}
      <div className="fixed inset-0 z-0 pointer-events-none">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-primary/10 blur-[120px] rounded-full" />
        <div className="absolute bottom-[10%] right-[5%] w-64 h-64 bg-orange-500/10 blur-[80px] rounded-full" />
      </div>

      {/* Header */}
      <header className="relative z-10 px-4 pt-[calc(1rem_+_env(safe-area-inset-top,_0px))] pb-4 flex items-center justify-between glass-panel border-b border-white/5 sticky top-0">
        <Button
          variant="ghost"
          size="icon"
          className="rounded-full hover:bg-white/10"
          onClick={() => navigate(-1)}
        >
          <ChevronLeft className="w-5 h-5 text-white" />
        </Button>
        <div className="text-center">
          <h1 className="text-sm font-black uppercase tracking-widest text-white flex items-center justify-center gap-2">
            <Zap className="w-4 h-4 text-primary" />
            Kinetic Log
          </h1>
          <p className="text-[10px] text-muted-foreground uppercase tracking-widest">
            Steps · Runs · Rides · Duels
          </p>
        </div>
        <Button
          variant="ghost"
          size="icon"
          className="rounded-full hover:bg-white/10 text-primary"
          onClick={() => {
            hapticFeedback(10);
            setShowAddForm((s) => !s);
          }}
        >
          <Plus className="w-5 h-5" />
        </Button>
      </header>

      <main className="relative z-10 px-4 pt-6 space-y-8 max-w-md mx-auto">
        {/* Aggregate Stats */}
        <div className="grid grid-cols-2 gap-3">
          <StatTile
            icon={Footprints}
            label="Total Steps"
            value={totalSteps.toLocaleString()}
            color="text-emerald-400"
            bg="bg-emerald-400/10"
            border="border-emerald-400/30"
          />
          <StatTile
            icon={TrendingUp}
            label="Distance"
            value={`${totalDistance.toFixed(1)} km`}
            color="text-orange-400"
            bg="bg-orange-400/10"
            border="border-orange-400/30"
          />
          <StatTile
            icon={Timer}
            label="Move Time"
            value={formatDuration(totalDuration)}
            color="text-blue-400"
            bg="bg-blue-400/10"
            border="border-blue-400/30"
          />
          <StatTile
            icon={Target}
            label="Sessions"
            value={String(sessionCount)}
            color="text-primary"
            bg="bg-primary/10"
            border="border-primary/30"
          />
        </div>

        {/* Add Form */}
        <AnimatePresence>
          {showAddForm && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="glass-panel rounded-3xl p-5 border border-white/10 overflow-hidden"
            >
              <h3 className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-4 flex items-center gap-2">
                <Plus className="w-3.5 h-3.5" />
                Log New Activity
              </h3>
              <div className="grid grid-cols-3 gap-2 mb-4">
                {(Object.keys(ACTIVITY_META) as ActivityType[]).map((t) => {
                  const M = ACTIVITY_META[t];
                  const Icon = M.icon;
                  return (
                    <button
                      key={t}
                      onClick={() => {
                        hapticFeedback(8);
                        setNewType(t);
                      }}
                      className={`flex flex-col items-center gap-1.5 p-3 rounded-xl border transition-all ${newType === t ? `${M.bg} ${M.border} ${M.color} ${M.shadow}` : "bg-white/5 border-white/10 text-muted-foreground"}`}
                    >
                      <Icon className="w-5 h-5" />
                      <span className="text-[9px] font-bold uppercase tracking-widest">
                        {M.label}
                      </span>
                    </button>
                  );
                })}
              </div>
              <div className="space-y-3">
                <input
                  type="number"
                  inputMode="numeric"
                  value={newValue}
                  onChange={(e) => setNewValue(e.target.value)}
                  placeholder={newType === "steps" ? "Steps" : "Distance (m)"}
                  className="w-full bg-black/50 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder:text-muted-foreground focus:border-primary/50 outline-none"
                />
                <input
                  type="number"
                  inputMode="numeric"
                  value={newDuration}
                  onChange={(e) => setNewDuration(e.target.value)}
                  placeholder="Duration (minutes)"
                  className="w-full bg-black/50 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder:text-muted-foreground focus:border-primary/50 outline-none"
                />
                <Button
                  className="w-full rounded-xl bg-primary text-primary-foreground font-black uppercase tracking-widest text-sm shadow-[0_0_20px_rgba(0,255,255,0.3)]"
                  onClick={addRecord}
                >
                  <Check className="w-4 h-4 mr-2" />
                  Log Activity
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Challenges / Duels */}
        <div>
          <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-4 flex items-center gap-2">
            <Swords className="w-3.5 h-3.5 text-yellow-400" />
            Operator Duels — Beat The Record
          </h3>
          <div className="space-y-3">
            {challenges.map((c, i) => {
              const M = ACTIVITY_META[c.type];
              const Icon = M.icon;
              const best = records
                .filter((r) => r.type === c.type)
                .reduce((max, r) => (r.value > max ? r.value : max), 0);
              const pct = Math.min(
                100,
                Math.round((best / c.ownerScore) * 100),
              );
              const beaten = best > c.ownerScore;
              return (
                <motion.div
                  key={c.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.06 }}
                  className={`glass-panel rounded-2xl p-4 border ${beaten ? "border-yellow-400/40 shadow-[0_0_20px_rgba(250,204,21,0.15)]" : "border-white/10"}`}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-10 h-10 rounded-xl flex items-center justify-center border ${M.bg} ${M.border} ${M.color}`}
                      >
                        <Icon className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-white uppercase tracking-wide">
                          {c.title}
                        </h4>
                        <p className="text-[10px] text-muted-foreground uppercase tracking-widest">
                          Held by {c.owner}
                        </p>
                      </div>
                    </div>
                    {beaten ? (
                      <Badge className="bg-yellow-400/20 text-yellow-400 border-yellow-400/40 uppercase tracking-widest text-[9px]">
                        <Crown className="w-3 h-3 mr-1" /> Crowned
                      </Badge>
                    ) : (
                      <Trophy className="w-4 h-4 text-yellow-400/60" />
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground leading-relaxed mb-3">
                    {c.description}
                  </p>
                  <div className="space-y-2">
                    <div className="flex justify-between text-[10px] uppercase tracking-widest">
                      <span className="text-muted-foreground">Your Best</span>
                      <span className="text-white font-bold">
                        {formatValue(c.type, best)}
                      </span>
                    </div>
                    <div className="flex justify-between text-[10px] uppercase tracking-widest">
                      <span className="text-muted-foreground">Record</span>
                      <span className="text-yellow-400 font-bold">
                        {formatValue(c.type, c.ownerScore)}
                      </span>
                    </div>
                    <div className="w-full h-2 bg-black/60 rounded-full overflow-hidden border border-white/5">
                      <motion.div
                        className={`h-full ${beaten ? "bg-yellow-400" : "bg-primary"} shadow-[0_0_10px_currentColor]`}
                        initial={{ width: 0 }}
                        animate={{ width: `${pct}%` }}
                        transition={{ duration: 0.8, ease: "easeOut" }}
                      />
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      className="w-full rounded-xl border-primary/30 text-primary hover:bg-primary/10 uppercase tracking-widest text-[10px] font-bold"
                      onClick={() => {
                        hapticFeedback(10);
                        setShowAddForm(true);
                        setNewType(c.type);
                        document
                          .getElementById("log-top")
                          ?.scrollIntoView({ behavior: "smooth" });
                      }}
                    >
                      <Swords className="w-3 h-3 mr-1" /> Challenge {c.owner}
                    </Button>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Tabs */}
        <div>
          <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-4 flex items-center gap-2">
            <ActivityIcon className="w-3.5 h-3.5" />
            Activity Archive
          </h3>
          <div className="flex gap-2 mb-4 overflow-x-auto scrollbar-hide">
            {[
              { key: "log" as const, label: "All", icon: Timer },
              { key: "steps" as const, label: "Steps", icon: Footprints },
              { key: "run" as const, label: "Runs", icon: PersonStanding },
              { key: "ride" as const, label: "Rides", icon: Bike },
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.key}
                  onClick={() => {
                    hapticFeedback(5);
                    setActiveTab(tab.key);
                  }}
                  className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all whitespace-nowrap ${activeTab === tab.key ? "bg-primary text-primary-foreground shadow-[0_0_15px_rgba(0,255,255,0.3)]" : "bg-white/5 text-muted-foreground border border-white/10"}`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  {tab.label}
                </button>
              );
            })}
          </div>

          {/* Records list */}
          <div className="space-y-2.5">
            <AnimatePresence>
              {filteredRecords.length === 0 ? (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="text-center py-12 text-muted-foreground"
                >
                  <Target className="w-8 h-8 mx-auto mb-3 opacity-30" />
                  <p className="text-xs uppercase tracking-widest font-bold">
                    No logs yet
                  </p>
                  <p className="text-[10px] mt-1">
                    Log a run, ride, or steps to populate the archive.
                  </p>
                </motion.div>
              ) : (
                filteredRecords.map((r) => {
                  const M = ACTIVITY_META[r.type];
                  const Icon = M.icon;
                  return (
                    <motion.div
                      key={r.id}
                      layout
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 10 }}
                      className={`relative p-4 rounded-2xl border glass-panel overflow-hidden ${M.border}`}
                    >
                      <div className="flex items-center gap-4 relative z-10">
                        <div
                          className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 border ${M.bg} ${M.border} ${M.color} ${M.shadow}`}
                        >
                          <Icon className="w-5 h-5" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="text-sm font-bold uppercase tracking-wide text-white">
                            {M.label}
                          </h4>
                          <div className="flex items-center gap-3 mt-0.5">
                            <span className="text-[10px] text-muted-foreground uppercase tracking-widest">
                              {formatValue(r.type, r.value)}
                            </span>
                            {r.duration > 0 && (
                              <span className="text-[10px] text-muted-foreground uppercase tracking-widest flex items-center gap-1">
                                <Timer className="w-3 h-3" />
                                {formatDuration(r.duration)}
                              </span>
                            )}
                            <span className="text-[10px] text-muted-foreground uppercase tracking-widest flex items-center gap-1">
                              <MapPin className="w-3 h-3" />
                              {new Date(r.timestamp).toLocaleDateString()}
                            </span>
                          </div>
                        </div>
                        <button
                          onClick={() => deleteRecord(r.id)}
                          className="text-muted-foreground/40 hover:text-red-400 transition-colors p-1"
                          aria-label="Delete activity"
                        >
                          <Flame className="w-4 h-4" />
                        </button>
                      </div>
                    </motion.div>
                  );
                })
              )}
            </AnimatePresence>
          </div>
        </div>
      </main>
    </div>
  );
}

function StatTile({
  icon: Icon,
  label,
  value,
  color,
  bg,
  border,
}: {
  icon: any;
  label: string;
  value: string;
  color: string;
  bg: string;
  border: string;
}) {
  return (
    <motion.div
      whileTap={{ scale: 0.97 }}
      className={`glass-panel rounded-2xl p-4 border ${border} relative overflow-hidden`}
    >
      <div
        className={`absolute top-0 right-0 w-16 h-16 ${bg} rounded-full blur-2xl opacity-50`}
      />
      <div
        className={`w-8 h-8 rounded-lg flex items-center justify-center mb-2 border ${bg} ${border} ${color}`}
      >
        <Icon className="w-4 h-4" />
      </div>
      <div className={`text-lg font-black ${color}`}>{value}</div>
      <div className="text-[9px] text-muted-foreground uppercase tracking-widest font-bold">
        {label}
      </div>
    </motion.div>
  );
}
