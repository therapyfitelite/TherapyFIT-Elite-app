import { useState, useRef, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Activity,
  BrainCircuit,
  HeartPulse,
  Zap,
  AlertTriangle,
  ChevronRight,
  ShieldAlert,
  TrendingUp,
  TrendingDown,
  Share2,
  Moon,
  Sun,
  Droplets,
  Crosshair,
  Hexagon,
  Shield,
  Rss,
  ArrowRightLeft,
  Users,
  Settings,
  Award,
  Wind,
  Globe,
  Grid,
  GitBranch,
  Link,
  Lock,
  BarChart,
  Package,
  CheckCircle2,
  Circle,
  Navigation,
  MapPin,
  Plus,
  Trash2,
  Copy,
  Gamepad2,
  Flame,
  Info,
  Target,
} from "lucide-react";

import {
  cn,
  hapticFeedback,
  playNodeTapSound,
  playSuccessChime,
} from "@/lib/utils";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  AreaChart,
  Area,
  ResponsiveContainer,
  Tooltip as RechartsTooltip,
  ReferenceLine,
  XAxis,
  YAxis,
} from "recharts";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { NeuralBrain } from "@/components/NeuralBrain";
import confetti from "canvas-confetti";

const HUB_SECTIONS = [
  {
    title: "Core Protocols",
    items: [
      {
        id: "dash",
        label: "DASH",
        path: "/",
        icon: Activity,
        color: "text-primary",
        tags: ["Core", "Monitoring"],
      },
      {
        id: "ops",
        label: "Tactical Ops",
        path: "/ops",
        icon: Crosshair,
        color: "text-red-500",
        tags: ["Focus", "Performance"],
      },
      {
        id: "somatic",
        label: "Body & Somatic",
        path: "/somatic",
        icon: Hexagon,
        color: "text-blue-500",
        tags: ["Recovery", "Body"],
      },
      {
        id: "sleep",
        label: "Sleep Architecture",
        path: "/sleep",
        icon: Moon,
        color: "text-purple-500",
        tags: ["Recovery", "Sleep"],
      },
    ],
  },
  {
    title: "Network & Intel",
    items: [
      {
        id: "feed",
        label: "Global Feed",
        path: "/feed",
        icon: Rss,
        color: "text-emerald-500",
        tags: ["Community", "Social"],
      },
      {
        id: "intel",
        label: "Intelligence",
        path: "/intel",
        icon: Shield,
        color: "text-yellow-500",
        tags: ["Data", "Analysis"],
      },
      {
        id: "leaderboard",
        label: "Leaderboard",
        path: "/leaderboard",
        icon: Award,
        color: "text-orange-500",
        tags: ["Community", "Performance"],
      },
      {
        id: "map",
        label: "Global Map",
        path: "/map",
        icon: Globe,
        color: "text-cyan-500",
        tags: ["Community", "Global"],
      },
      {
        id: "war-room",
        label: "War Room",
        path: "/war-room",
        icon: Grid,
        color: "text-red-500",
        tags: ["Focus", "Performance"],
      },
    ],
  },
  {
    title: "Training & Upgrades",
    items: [
      {
        id: "breathing",
        label: "Neural Reset",
        path: "/breathing",
        icon: Wind,
        color: "text-teal-500",
        tags: ["Recovery", "Focus"],
      },
      {
        id: "flow",
        label: "Flow State",
        path: "/flow",
        icon: Zap,
        color: "text-yellow-400",
        tags: ["Focus", "Performance"],
      },
      {
        id: "tech-tree",
        label: "Tech Tree",
        path: "/tech-tree",
        icon: GitBranch,
        color: "text-fuchsia-500",
        tags: ["Progression", "Upgrades"],
      },
      {
        id: "loadout",
        label: "Tactical Loadout",
        path: "/loadout",
        icon: Package,
        color: "text-red-400",
        tags: ["Performance", "Preparation"],
      },
      {
        id: "marketplace",
        label: "Marketplace",
        path: "/marketplace",
        icon: ArrowRightLeft,
        color: "text-green-500",
        tags: ["Community", "Upgrades"],
      },
    ],
  },
  {
    title: "System & Settings",
    items: [
      {
        id: "profile",
        label: "Operator Profile",
        path: "/profile",
        icon: Users,
        color: "text-blue-400",
        tags: ["System", "Settings"],
      },
      {
        id: "settings",
        label: "System Settings",
        path: "/settings",
        icon: Settings,
        color: "text-gray-400",
        tags: ["System", "Settings"],
      },
      {
        id: "integrations",
        label: "Integrations",
        path: "/integrations",
        icon: Link,
        color: "text-indigo-400",
        tags: ["System", "Data"],
      },
      {
        id: "upgrade",
        label: "Elite Upgrade",
        path: "/upgrade",
        icon: Lock,
        color: "text-yellow-500",
        tags: ["System", "Upgrades"],
      },
      {
        id: "admin",
        label: "Analytics (Admin)",
        path: "/admin",
        icon: BarChart,
        color: "text-red-500",
        tags: ["System", "Data"],
      },
    ],
  },
];

const ALL_ITEMS = HUB_SECTIONS.flatMap((s) => s.items);

// Live waveform component that reacts to CNS load
const LiveWaveform = ({ cnsLoad }: { cnsLoad: number }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animFrameRef = useRef<number>(0);
  const timeRef = useRef(0);

  const isCritical = cnsLoad > 85;
  const isElevated = cnsLoad > 60;

  const color = isCritical
    ? "rgba(239, 68, 68," // red
    : isElevated
      ? "rgba(249, 115, 22," // orange
      : "rgba(0, 200, 200,"; // cyan

  const amplitude = 4 + (cnsLoad / 100) * 22; // 4–26px based on load
  const frequency = 0.018 + (cnsLoad / 100) * 0.032; // faster when higher
  const chaos = isCritical ? 0.6 : isElevated ? 0.25 : 0.05;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const draw = () => {
      const W = canvas.width;
      const H = canvas.height;
      ctx.clearRect(0, 0, W, H);

      timeRef.current += 0.04;
      const t = timeRef.current;

      // Draw 3 layered waveforms for depth
      for (let layer = 0; layer < 3; layer++) {
        const opacity = layer === 0 ? 0.9 : layer === 1 ? 0.4 : 0.15;
        const layerAmp =
          amplitude * (layer === 0 ? 1 : layer === 1 ? 0.6 : 0.35);
        const phaseOffset = layer * 0.8;

        ctx.beginPath();
        ctx.strokeStyle = `${color}${opacity})`;
        ctx.lineWidth = layer === 0 ? 1.5 : 1;
        ctx.shadowBlur = layer === 0 ? 8 : 0;
        ctx.shadowColor = `${color}0.8)`;

        for (let x = 0; x < W; x++) {
          const progress = x / W;
          const noiseVal =
            chaos * Math.sin(x * 0.3 + t * 3.7) * Math.sin(x * 0.07 + t * 1.3);
          const y =
            H / 2 +
            Math.sin(x * frequency + t + phaseOffset) * layerAmp +
            Math.sin(x * frequency * 2.3 + t * 1.5 + phaseOffset) *
              (layerAmp * 0.3) +
            noiseVal * layerAmp;

          if (x === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.stroke();
        ctx.shadowBlur = 0;
      }

      // Pulse beat spike every ~2s based on CNS load
      const beatInterval = Math.max(40, 120 - cnsLoad);
      const beatPhase = (Math.floor(t * 30) % beatInterval) / beatInterval;
      if (beatPhase < 0.08) {
        const spike = Math.sin((beatPhase / 0.08) * Math.PI) * amplitude * 2.5;
        const beatX = W * 0.72;
        ctx.beginPath();
        ctx.strokeStyle = `${color}0.95)`;
        ctx.lineWidth = 2;
        ctx.shadowBlur = 16;
        ctx.shadowColor = `${color}1)`;
        ctx.moveTo(beatX - 4, H / 2);
        ctx.lineTo(beatX, H / 2 - spike);
        ctx.lineTo(beatX + 2, H / 2 + spike * 0.4);
        ctx.lineTo(beatX + 6, H / 2);
        ctx.stroke();
        ctx.shadowBlur = 0;
      }

      animFrameRef.current = requestAnimationFrame(draw);
    };

    draw();
    return () => cancelAnimationFrame(animFrameRef.current);
  }, [cnsLoad, amplitude, frequency, chaos, color]);

  return (
    <canvas
      ref={canvasRef}
      width={260}
      height={48}
      className="w-full opacity-90"
      style={{ display: "block" }}
    />
  );
};

// 3D Tilt Card Component with Hydrographic Glow
const HolographicCard = ({
  title,
  value,
  unit,
  icon: Icon,
  colorClass,
  shadowClass,
  glowColor,
  activeBgClass,
  trendData,
  targetValue,
  onTargetChange,
  min = 0,
  max = 100,
  reverseTarget = false,
  streakCount,
  onStreakIncrement,
  tooltipText,
}: any) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const [rotation, setRotation] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);
  const [touchStart, setTouchStart] = useState({ x: 0, y: 0 });
  const [isEditing, setIsEditing] = useState(false);
  const [localTarget, setLocalTarget] = useState(targetValue);
  const [justMet, setJustMet] = useState(false);

  const targetMet =
    targetValue !== undefined &&
    (reverseTarget ? value <= targetValue : value >= targetValue);

  const prevTargetMet = useRef(targetMet);
  useEffect(() => {
    if (targetMet && !prevTargetMet.current) {
      setJustMet(true);
      if (onStreakIncrement) onStreakIncrement();
      try {
        confetti({
          particleCount: 40,
          spread: 50,
          origin: { y: 0.7 },
          colors: ["#34d399", "#ffffff"],
          zIndex: 1000,
        });
      } catch (e) {}
      const timer = setTimeout(() => setJustMet(false), 2000);
      prevTargetMet.current = targetMet;
      return () => clearTimeout(timer);
    }
    prevTargetMet.current = targetMet;
  }, [targetMet, onStreakIncrement]);

  useEffect(() => {
    setLocalTarget(targetValue);
  }, [targetValue]);

  const calculateRotation = (clientX: number, clientY: number) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = clientX - rect.left;
    const y = clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    const rotateX = ((y - centerY) / centerY) * -20; // Increased rotation
    const rotateY = ((x - centerX) / centerX) * 20;
    setRotation({ x: rotateX, y: rotateY });
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    calculateRotation(e.clientX, e.clientY);
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (e.touches.length > 0) {
      calculateRotation(e.touches[0].clientX, e.touches[0].clientY);
    }
  };

  const handleMouseLeave = () => {
    setRotation({ x: 0, y: 0 });
    setIsHovered(false);
  };

  return (
    <div
      ref={cardRef}
      className="relative perspective-1000 w-full group cursor-pointer"
      onMouseMove={handleMouseMove}
      onMouseEnter={() => {
        setIsHovered(true);
        hapticFeedback(5);
      }}
      onMouseLeave={handleMouseLeave}
      onTouchStart={(e) => {
        setIsHovered(true);
        hapticFeedback(5);
        setTouchStart({ x: e.touches[0].clientX, y: e.touches[0].clientY });
      }}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleMouseLeave}
      style={{ perspective: "1000px" }}
    >
      {streakCount !== undefined && streakCount >= 30 && (
        <div
          className="absolute -top-3 -right-3 z-50 animate-in zoom-in duration-500 pointer-events-auto"
          style={{ transform: "translateZ(40px)" }}
        >
          <div className="relative group/medal cursor-help">
            <div
              className="absolute inset-0 blur-xl rounded-full animate-pulse opacity-60"
              style={{ background: glowColor }}
            />
            <div
              className="w-12 h-12 rounded-full border-[3px] bg-gradient-to-br from-black to-slate-900 flex items-center justify-center shadow-2xl relative overflow-hidden"
              style={{
                borderColor:
                  glowColor?.replace(/rgba\((.*?),\s*[\d.]+\)/, "rgb($1)") ||
                  "white",
              }}
            >
              <div
                className="absolute inset-0 opacity-40 mix-blend-screen"
                style={{
                  background: `radial-gradient(circle at top left, ${glowColor}, transparent)`,
                }}
              />
              <Award
                className="w-6 h-6 relative z-10"
                style={{
                  color:
                    glowColor?.replace(/rgba\((.*?),\s*[\d.]+\)/, "rgb($1)") ||
                    "white",
                  filter: `drop-shadow(0 0 5px ${glowColor})`,
                }}
              />
              <div className="absolute bottom-1 right-1 w-4 h-4 rounded-full bg-black flex items-center justify-center border border-white/20 z-20 shadow-md">
                <span className="text-[7px] font-black text-white">30</span>
              </div>
            </div>
            <div
              className="absolute -top-8 left-1/2 -translate-x-1/2 opacity-0 group-hover/medal:opacity-100 transition-opacity bg-black/95 text-white text-[9px] font-black uppercase tracking-widest px-3 py-1.5 rounded border shadow-xl whitespace-nowrap z-[60]"
              style={{
                borderColor:
                  glowColor?.replace(/rgba\((.*?),\s*[\d.]+\)/, "rgb($1)") ||
                  "white",
              }}
            >
              30-Day Mastery
            </div>
          </div>
        </div>
      )}

      {/* Ambient hydrographic glow behind the card - tightened and dimmed for crispness */}
      <div
        className={cn(
          "absolute inset-0 rounded-2xl blur-2xl transition-all duration-700",
          isHovered ? "opacity-30 scale-100" : "opacity-10 scale-100",
        )}
        style={{ background: glowColor || "rgba(0,255,255,0.2)" }}
      />

      <div
        className={cn(
          "illuminate-card relative w-full h-full rounded-2xl border bg-[#0B0C10]/90 backdrop-blur-xl p-5 transition-all duration-300 ease-out overflow-hidden shadow-[inset_0_1px_1px_rgba(255,255,255,0.05)]",
          isHovered ? shadowClass : "border-white/10",
        )}
        style={{
          transform: `rotateX(${rotation.x}deg) rotateY(${rotation.y}deg) scale(${isHovered ? 1.02 : 1})`,
          transformStyle: "preserve-3d",
        }}
      >
        {/* Vibrant Base Fill */}
        {activeBgClass && (
          <div
            className={cn(
              "absolute inset-0 pointer-events-none opacity-20 transition-opacity duration-500",
              activeBgClass,
            )}
            style={{ transform: "translateZ(1px)" }}
          />
        )}

        {/* Hydrographic liquid effect inner layer */}
        <div
          className="absolute inset-0 opacity-30 pointer-events-none mix-blend-screen transition-transform duration-500"
          style={{
            background: `radial-gradient(circle at ${50 + rotation.y * 2}% ${50 - rotation.x * 2}%, ${glowColor || "rgba(0,255,255,0.5)"} 0%, transparent 85%)`,
            transform: "translateZ(5px)",
          }}
        />

        <div
          className="absolute inset-0 rounded-2xl bg-gradient-to-br from-white/5 to-transparent opacity-30 pointer-events-none"
          style={{ transform: "translateZ(10px)" }}
        />

        <div
          className="flex justify-between items-start mb-6 relative z-10"
          style={{ transform: "translateZ(20px)" }}
        >
          <div className="flex items-center gap-1.5">
            <span className="text-[11px] text-muted-foreground uppercase tracking-[0.2em] font-bold">
              {title}
            </span>
            {tooltipText && (
              <Tooltip delayDuration={0}>
                <TooltipTrigger asChild>
                  <div
                    className="cursor-help p-0.5 rounded-full bg-white/5 hover:bg-white/10 transition-colors"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <Info className="w-3 h-3 text-muted-foreground" />
                  </div>
                </TooltipTrigger>
                <TooltipContent
                  side="top"
                  className="max-w-[200px] bg-black/95 border-white/10 text-xs text-white/90 leading-relaxed shadow-xl backdrop-blur-md p-3"
                >
                  <p>{tooltipText}</p>
                </TooltipContent>
              </Tooltip>
            )}
          </div>
          <div className="flex items-center gap-2">
            {targetMet && (
              <div
                className={cn(
                  "flex items-center gap-1 bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded-full border border-emerald-500/30 transition-all duration-500",
                  justMet
                    ? "shadow-[0_0_20px_rgba(52,211,153,0.8)] scale-110"
                    : "shadow-[0_0_10px_rgba(52,211,153,0.3)]",
                )}
              >
                <CheckCircle2 className="w-2.5 h-2.5" />
                <span className="text-[8px] uppercase tracking-widest font-black">
                  Met
                </span>
              </div>
            )}
            <div
              className={cn(
                "p-1.5 rounded-full bg-white/5 backdrop-blur-md border border-white/10",
                colorClass,
                justMet && "animate-pulse",
              )}
            >
              <Icon className="w-4 h-4" />
            </div>
          </div>
        </div>

        <div
          className="relative z-10"
          style={{ transform: "translateZ(30px)" }}
        >
          <div className="flex items-baseline gap-1.5">
            <span
              className={cn(
                "text-4xl font-sans font-black transition-all duration-500 high-res-glow tracking-tighter",
                colorClass,
                isHovered ? "scale-105 origin-left" : "",
              )}
              style={{
                textShadow: `0 0 ${isHovered ? "15px" : "8px"} ${glowColor || "rgba(255,255,255,0.8)"}, 0 0 ${isHovered ? "30px" : "15px"} ${glowColor || "rgba(255,255,255,0.4)"}`,
              }}
            >
              {value}
            </span>
            <span
              className={cn(
                "text-xs font-bold transition-colors duration-500 uppercase tracking-widest",
                isHovered ? "text-white/90" : "text-muted-foreground",
              )}
            >
              {unit}
            </span>
          </div>

          {targetValue !== undefined && (
            <div
              className="mt-2 flex flex-wrap items-center gap-2"
              onClick={(e) => e.stopPropagation()}
            >
              {isEditing ? (
                <div className="animate-in fade-in slide-in-from-top-2 duration-300 bg-black/60 p-2.5 rounded-2xl border border-white/10 backdrop-blur-md mt-2 shadow-xl w-full">
                  <div className="flex justify-between items-center mb-3">
                    <span className="text-[9px] uppercase tracking-widest text-muted-foreground">
                      Target:{" "}
                      <span className="text-white font-bold">
                        {localTarget}
                        {unit}
                      </span>
                    </span>
                    <button
                      className="text-[9px] font-black bg-primary/20 text-primary px-2.5 py-1 rounded-xl hover:bg-primary/40 transition-colors uppercase tracking-widest"
                      onClick={() => {
                        setIsEditing(false);
                        if (onTargetChange) onTargetChange(localTarget);
                        hapticFeedback(10);
                      }}
                    >
                      SAVE
                    </button>
                  </div>
                  <input
                    type="range"
                    min={min}
                    max={max}
                    value={localTarget}
                    onChange={(e) => setLocalTarget(Number(e.target.value))}
                    className="w-full h-1.5 rounded-full appearance-none cursor-pointer outline-none"
                    style={{
                      background: "rgba(255,255,255,0.1)",
                      accentColor:
                        glowColor?.replace(
                          /rgba\((.*?),\s*[\d.]+\)/,
                          "rgb($1)",
                        ) || "hsl(var(--primary))",
                    }}
                  />
                </div>
              ) : (
                <>
                  <div
                    className="inline-flex items-center gap-1.5 text-[10px] uppercase tracking-widest text-muted-foreground hover:text-white transition-colors cursor-pointer mt-1"
                    onClick={(e) => {
                      e.stopPropagation();
                      setIsEditing(true);
                      hapticFeedback(5);
                    }}
                  >
                    <Crosshair className="w-3 h-3 opacity-70" /> Target:{" "}
                    <span className="font-bold text-white/80">
                      {targetValue}
                      {unit}
                    </span>
                  </div>
                  {streakCount !== undefined && streakCount > 0 && (
                    <div
                      className={cn(
                        "inline-flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-widest mt-1 transition-all duration-500",
                        targetMet
                          ? "text-orange-400 drop-shadow-[0_0_8px_rgba(249,115,22,0.6)]"
                          : "text-muted-foreground/70",
                      )}
                    >
                      <Flame
                        className={cn("w-3 h-3", targetMet && "animate-pulse")}
                      />
                      {streakCount} Day{streakCount !== 1 ? "s" : ""}
                    </div>
                  )}
                </>
              )}
            </div>
          )}
        </div>

        {/* Animated Trend Line */}
        {trendData &&
          trendData.length > 1 &&
          (() => {
            const min = Math.min(...trendData);
            const max = Math.max(...trendData);
            const range = max - min || 1;
            const points = trendData
              .map((val: number, i: number) => {
                const x = (i / (trendData.length - 1)) * 100;
                const y = 30 - ((val - min) / range) * 20 - 5;
                return `${x},${y}`;
              })
              .join(" ");

            return (
              <div
                className="absolute bottom-0 left-0 right-0 h-16 pointer-events-none opacity-50 group-hover:opacity-100 transition-opacity duration-700"
                style={{ transform: "translateZ(15px)" }}
              >
                <svg
                  viewBox="0 0 100 30"
                  preserveAspectRatio="none"
                  className="w-full h-full"
                >
                  <defs>
                    <linearGradient
                      id={`grad-${title.replace(/\s+/g, "")}`}
                      x1="0"
                      y1="0"
                      x2="0"
                      y2="1"
                    >
                      <stop
                        offset="0%"
                        stopColor={glowColor}
                        stopOpacity={0.5}
                      />
                      <stop
                        offset="100%"
                        stopColor={glowColor}
                        stopOpacity={0}
                      />
                    </linearGradient>
                  </defs>
                  <polygon
                    points={`0,30 ${points} 100,30`}
                    fill={`url(#grad-${title.replace(/\s+/g, "")})`}
                    className="transition-all duration-1000"
                    style={{ opacity: isHovered ? 1 : 0.3 }}
                  />
                  <polyline
                    points={points}
                    fill="none"
                    stroke={glowColor}
                    strokeWidth="0.5"
                    className="opacity-30"
                  />
                  <polyline
                    points={points}
                    fill="none"
                    stroke={glowColor}
                    strokeWidth="1.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    style={{
                      strokeDasharray: "200",
                      strokeDashoffset: isHovered ? "0" : "200",
                      transition:
                        "stroke-dashoffset 1.5s cubic-bezier(0.4, 0, 0.2, 1)",
                      filter: `drop-shadow(0 0 4px ${glowColor})`,
                    }}
                  />
                </svg>
              </div>
            );
          })()}
      </div>
    </div>
  );
};

// HRV 7-day sparkline history
const HRV_HISTORY = [
  { day: "Mon", hrv: 54, label: "Mon" },
  { day: "Tue", hrv: 61, label: "Tue" },
  { day: "Wed", hrv: 58, label: "Wed" },
  { day: "Thu", hrv: 72, label: "Thu" },
  { day: "Fri", hrv: 65, label: "Fri" },
  { day: "Sat", hrv: 70, label: "Sat" },
  { day: "Sun", hrv: 68, label: "Sun" },
];

const HRV_BASELINE = 63;

const HRVSparkline = () => {
  const latest = HRV_HISTORY[HRV_HISTORY.length - 1].hrv;
  const prev = HRV_HISTORY[HRV_HISTORY.length - 2].hrv;
  const delta = latest - prev;
  const isUp = delta >= 0;
  const avg = Math.round(
    HRV_HISTORY.reduce((s, d) => s + d.hrv, 0) / HRV_HISTORY.length,
  );
  const min = Math.min(...HRV_HISTORY.map((d) => d.hrv));
  const max = Math.max(...HRV_HISTORY.map((d) => d.hrv));

  return (
    <Dialog>
      <DialogTrigger asChild>
        <div className="cursor-pointer transition-transform hover:scale-[1.01] active:scale-[0.99]">
          <Card className="bg-[#111] border-white/5 w-full hover:border-primary/20 hover:shadow-[0_0_15px_rgba(0,255,255,0.05)] transition-all rounded-2xl">
            <CardContent className="p-4 space-y-3">
              {/* Header */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Activity className="w-3.5 h-3.5 text-primary" />
                  <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">
                    HRV History
                  </span>
                  <Badge
                    variant="outline"
                    className="text-[9px] bg-primary/10 text-primary border-primary/20 px-1.5 py-0"
                  >
                    7 Days
                  </Badge>
                </div>
                <div className="flex items-center gap-1.5">
                  {isUp ? (
                    <TrendingUp className="w-3 h-3 text-emerald-400" />
                  ) : (
                    <TrendingDown className="w-3 h-3 text-destructive" />
                  )}
                  <span
                    className={cn(
                      "text-xs font-bold",
                      isUp ? "text-emerald-400" : "text-destructive",
                    )}
                  >
                    {isUp ? "+" : ""}
                    {delta}ms
                  </span>
                  <span className="text-[10px] text-muted-foreground">
                    vs yesterday
                  </span>
                </div>
              </div>

              {/* Chart */}
              <div className="h-24 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart
                    data={HRV_HISTORY}
                    margin={{ top: 4, right: 2, left: 2, bottom: 0 }}
                  >
                    <defs>
                      <linearGradient id="hrvGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop
                          offset="5%"
                          stopColor="hsl(var(--primary))"
                          stopOpacity={0.3}
                        />
                        <stop
                          offset="95%"
                          stopColor="hsl(var(--primary))"
                          stopOpacity={0.0}
                        />
                      </linearGradient>
                    </defs>
                    <ReferenceLine
                      y={HRV_BASELINE}
                      stroke="rgba(255,255,255,0.1)"
                      strokeDasharray="3 3"
                      label={{
                        value: `Baseline ${HRV_BASELINE}`,
                        position: "insideTopRight",
                        fontSize: 8,
                        fill: "rgba(255,255,255,0.3)",
                      }}
                    />
                    <RechartsTooltip
                      content={({ active, payload, label }) => {
                        if (!active || !payload?.length) return null;
                        return (
                          <div className="bg-[#1a1a1a] border border-white/10 rounded-lg px-2.5 py-1.5 text-[10px]">
                            <div className="text-muted-foreground font-mono">
                              {label}
                            </div>
                            <div className="text-primary font-bold">
                              {payload[0].value}ms HRV
                            </div>
                          </div>
                        );
                      }}
                    />
                    <Area
                      type="monotone"
                      dataKey="hrv"
                      stroke="hsl(var(--primary))"
                      strokeWidth={1.5}
                      fill="url(#hrvGrad)"
                      dot={(props: any) => {
                        const isLast = props.index === HRV_HISTORY.length - 1;
                        if (!isLast)
                          return (
                            <circle
                              key={props.key}
                              cx={props.cx}
                              cy={props.cy}
                              r={2}
                              fill="hsl(var(--primary))"
                              fillOpacity={0.4}
                              stroke="none"
                            />
                          );
                        return (
                          <g key={props.key}>
                            <circle
                              cx={props.cx}
                              cy={props.cy}
                              r={4}
                              fill="hsl(var(--primary))"
                              fillOpacity={0.2}
                              stroke="hsl(var(--primary))"
                              strokeWidth={1}
                            />
                            <circle
                              cx={props.cx}
                              cy={props.cy}
                              r={2.5}
                              fill="hsl(var(--primary))"
                            />
                          </g>
                        );
                      }}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>

              {/* Day labels */}
              <div className="flex justify-between px-0.5">
                {HRV_HISTORY.map((d) => (
                  <span
                    key={d.day}
                    className="text-[9px] text-muted-foreground font-mono"
                  >
                    {d.day}
                  </span>
                ))}
              </div>

              {/* Stats row */}
              <div className="grid grid-cols-3 gap-2 pt-1 border-t border-white/5">
                {[
                  { label: "7d Avg", value: `${avg}ms` },
                  { label: "Peak", value: `${max}ms` },
                  { label: "Low", value: `${min}ms` },
                ].map((stat) => (
                  <div key={stat.label} className="text-center">
                    <div className="text-[9px] text-muted-foreground uppercase tracking-widest">
                      {stat.label}
                    </div>
                    <div className="text-xs font-bold text-foreground font-mono">
                      {stat.value}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px] bg-[#111] border-white/10 text-foreground">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-primary uppercase tracking-widest text-xs">
            <Activity className="w-4 h-4" /> Deep HRV Analysis
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-6 py-4">
          <div className="h-40 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart
                data={HRV_HISTORY}
                margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
              >
                <defs>
                  <linearGradient id="hrvGradDeep" x1="0" y1="0" x2="0" y2="1">
                    <stop
                      offset="5%"
                      stopColor="hsl(var(--primary))"
                      stopOpacity={0.4}
                    />
                    <stop
                      offset="95%"
                      stopColor="hsl(var(--primary))"
                      stopOpacity={0.0}
                    />
                  </linearGradient>
                </defs>
                <XAxis
                  dataKey="day"
                  stroke="rgba(255,255,255,0.2)"
                  fontSize={10}
                  tickLine={false}
                  axisLine={false}
                />
                <YAxis
                  stroke="rgba(255,255,255,0.2)"
                  fontSize={10}
                  tickLine={false}
                  axisLine={false}
                  domain={["dataMin - 5", "dataMax + 5"]}
                />
                <ReferenceLine
                  y={HRV_BASELINE}
                  stroke="rgba(255,255,255,0.2)"
                  strokeDasharray="3 3"
                  label={{
                    value: `Baseline ${HRV_BASELINE}`,
                    position: "insideTopLeft",
                    fontSize: 10,
                    fill: "rgba(255,255,255,0.5)",
                  }}
                />
                <RechartsTooltip
                  content={({ active, payload, label }) => {
                    if (!active || !payload?.length) return null;
                    return (
                      <div className="bg-[#1a1a1a] border border-white/10 rounded-lg px-3 py-2 text-xs shadow-xl">
                        <div className="text-muted-foreground font-mono mb-1">
                          {label}
                        </div>
                        <div className="text-primary font-bold text-lg">
                          {payload[0].value}ms
                        </div>
                      </div>
                    );
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="hrv"
                  stroke="hsl(var(--primary))"
                  strokeWidth={2}
                  fill="url(#hrvGradDeep)"
                  dot={{
                    r: 4,
                    fill: "hsl(var(--primary))",
                    strokeWidth: 2,
                    stroke: "#111",
                  }}
                  activeDot={{
                    r: 6,
                    fill: "hsl(var(--primary))",
                    strokeWidth: 0,
                  }}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white/5 p-3 rounded-lg border border-white/5">
              <div className="text-[10px] text-muted-foreground uppercase tracking-widest mb-1">
                Parasympathetic Tone
              </div>
              <div className="text-lg font-bold text-emerald-400">Dominant</div>
            </div>
            <div className="bg-white/5 p-3 rounded-lg border border-white/5">
              <div className="text-[10px] text-muted-foreground uppercase tracking-widest mb-1">
                Recovery Capacity
              </div>
              <div className="text-lg font-bold text-primary">Optimal</div>
            </div>
          </div>

          <p className="text-xs text-muted-foreground leading-relaxed bg-primary/5 border border-primary/20 p-3 rounded-lg">
            Your HRV variance over the last 7 days indicates strong adaptation
            to recent stressors. The upward trend suggests optimal central
            nervous system recovery.{" "}
            <strong className="text-primary font-medium">
              Proceed with high-intensity protocols.
            </strong>
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
};

// ─── GARMIN-STYLE ADVANCED METRICS ───────────────────────────────────────────
const generateStressData = () => {
  const data = [];
  for (let i = 0; i < 96; i++) {
    let val = 0;
    if (i < 28) {
      val = 10 + Math.random() * 15;
    } // Sleep
    else if (i < 32) {
      val = 30 + Math.random() * 20;
    } // Morning
    else if (i < 38) {
      val = 70 + Math.random() * 25;
    } // Workout
    else if (i < 60) {
      val = 40 + Math.random() * 30;
    } // Work
    else if (i < 64) {
      val = 15 + Math.random() * 10;
    } // Nap/Rest
    else if (i < 80) {
      val = 50 + Math.random() * 20;
    } // Evening
    else {
      val = 15 + Math.random() * 15;
    } // Wind down
    data.push({ time: i, value: val });
  }
  return data;
};

const ANSStressTimeline = () => {
  const [data] = useState(generateStressData);

  return (
    <Card className="glass-panel border-white/5 shadow-[0_0_20px_rgba(0,0,0,0.5)] rounded-2xl overflow-hidden mt-6">
      <CardContent className="p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-primary" />
            <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">
              24-Hour ANS Stress & Recovery
            </span>
          </div>
          <Badge
            variant="outline"
            className="text-[9px] bg-primary/10 text-primary border-primary/20"
          >
            LIVE
          </Badge>
        </div>

        <div className="h-32 w-full flex items-end gap-[1px]">
          {data.map((d, i) => {
            let color = "bg-primary";
            let shadow = "shadow-[0_0_4px_rgba(0,255,255,0.4)]";
            if (d.value > 75) {
              color = "bg-destructive";
              shadow = "shadow-[0_0_4px_rgba(239,68,68,0.4)]";
            } else if (d.value > 50) {
              color = "bg-orange-500";
              shadow = "shadow-[0_0_4px_rgba(249,115,22,0.4)]";
            } else if (d.value > 25) {
              color = "bg-yellow-400";
              shadow = "shadow-[0_0_4px_rgba(250,204,21,0.4)]";
            }

            return (
              <div
                key={i}
                className="flex-1 flex flex-col justify-end h-full group relative"
              >
                <div
                  className={cn(
                    "w-full rounded-t-sm opacity-80 hover:opacity-100 transition-all",
                    color,
                    shadow,
                  )}
                  style={{ height: `${d.value}%` }}
                />
              </div>
            );
          })}
        </div>

        <div className="flex justify-between mt-2 text-[8px] font-mono text-muted-foreground uppercase tracking-widest">
          <span>12 AM</span>
          <span>6 AM</span>
          <span>12 PM</span>
          <span>6 PM</span>
          <span>12 AM</span>
        </div>

        <div className="flex items-center justify-center gap-4 mt-4 pt-4 border-t border-white/5">
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-primary" />
            <span className="text-[9px] text-white/60 uppercase tracking-widest">
              Rest
            </span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-yellow-400" />
            <span className="text-[9px] text-white/60 uppercase tracking-widest">
              Low
            </span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-orange-500" />
            <span className="text-[9px] text-white/60 uppercase tracking-widest">
              Med
            </span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-destructive" />
            <span className="text-[9px] text-white/60 uppercase tracking-widest">
              High
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

const TacticalStatus = () => {
  return (
    <div className="grid grid-cols-2 gap-4 mt-4">
      <Card className="glass-panel border-white/5 rounded-2xl p-4 flex flex-col justify-between group hover:border-emerald-500/30 transition-colors">
        <div>
          <div className="text-[9px] font-bold text-muted-foreground uppercase tracking-widest mb-1 flex items-center gap-1.5">
            <TrendingUp className="w-3 h-3 text-emerald-400" />
            Tactical Status
          </div>
          <div className="text-xl font-black text-emerald-400 uppercase tracking-tight glow-text-emerald">
            Productive
          </div>
          <p className="text-[10px] text-white/50 mt-1 leading-tight">
            Load is optimal. Fitness is increasing while fatigue remains
            controlled.
          </p>
        </div>
        <div className="mt-4 pt-3 border-t border-white/5 flex justify-between items-end">
          <div>
            <div className="text-[8px] text-muted-foreground uppercase tracking-widest">
              Neural VO2 Max
            </div>
            <div className="text-lg font-mono font-bold text-white">54</div>
          </div>
          <div className="text-[9px] text-emerald-400 font-bold uppercase tracking-widest bg-emerald-500/10 px-1.5 py-0.5 rounded">
            Top 5%
          </div>
        </div>
      </Card>

      <Card className="glass-panel border-white/5 rounded-2xl p-4 flex flex-col justify-between group hover:border-cyan-500/30 transition-colors">
        <div>
          <div className="text-[9px] font-bold text-muted-foreground uppercase tracking-widest mb-1 flex items-center gap-1.5">
            <Target className="w-3 h-3 text-cyan-400" />
            Load Focus
          </div>
          <div className="text-xl font-black text-cyan-400 uppercase tracking-tight glow-text-cyan">
            Balanced
          </div>
        </div>
        <div className="mt-3 flex-1 flex items-center justify-center">
          <div className="w-full space-y-2.5">
            <div>
              <div className="flex justify-between text-[7px] uppercase tracking-widest mb-1">
                <span className="text-white/60">Anaerobic</span>
                <span className="text-white font-mono">840</span>
              </div>
              <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                <div
                  className="h-full bg-purple-500 rounded-full shadow-[0_0_8px_rgba(168,85,247,0.8)]"
                  style={{ width: "60%" }}
                />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-[7px] uppercase tracking-widest mb-1">
                <span className="text-white/60">High Aerobic</span>
                <span className="text-white font-mono">1250</span>
              </div>
              <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                <div
                  className="h-full bg-orange-500 rounded-full shadow-[0_0_8px_rgba(249,115,22,0.8)]"
                  style={{ width: "85%" }}
                />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-[7px] uppercase tracking-widest mb-1">
                <span className="text-white/60">Low Aerobic</span>
                <span className="text-white font-mono">920</span>
              </div>
              <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                <div
                  className="h-full bg-cyan-400 rounded-full shadow-[0_0_8px_rgba(34,211,238,0.8)]"
                  style={{ width: "70%" }}
                />
              </div>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
};

// ─── TACTICAL CLOCK & COMPASS ────────────────────────────────────────────────
interface Waypoint {
  id: string;
  name: string;
  lat: number;
  lng: number;
  savedAt: string;
  elevation?: number; // metres above sea level (simulated)
}

const TacticalClockCompass = () => {
  const [time, setTime] = useState(new Date());
  const [heading] = useState(247);
  const [headingDrift, setHeadingDrift] = useState(0);

  const [gpsCoord, setGpsCoord] = useState({ lat: 51.5074, lng: -0.1278 });
  const [gpsFix, setGpsFix] = useState<"LOCK" | "SEEK" | "WEAK">("LOCK");

  // Waypoints
  const [waypoints, setWaypoints] = useState<Waypoint[]>(() => {
    try {
      return JSON.parse(localStorage.getItem("tf_waypoints") || "[]");
    } catch {
      return [];
    }
  });
  const [showWaypointInput, setShowWaypointInput] = useState(false);
  const [waypointName, setWaypointName] = useState("");
  const [showWaypointList, setShowWaypointList] = useState(false);
  const [showRangeRings, setShowRangeRings] = useState(false);

  // Mission Playback
  const [isPlayingBack, setIsPlayingBack] = useState(false);
  const [playbackProgress, setPlaybackProgress] = useState(0); // 0..1 across total route
  const [playbackSegment, setPlaybackSegment] = useState(0); // which segment dot is on
  const [playbackSpeed, setPlaybackSpeed] = useState<0.5 | 1 | 2>(1);
  const playbackRef = useRef<number | null>(null);

  const startPlayback = () => {
    if (waypoints.length === 0) return;
    hapticFeedback(20);
    setIsPlayingBack(true);
    setPlaybackProgress(0);
    setPlaybackSegment(0);
  };

  const stopPlayback = () => {
    if (playbackRef.current) cancelAnimationFrame(playbackRef.current);
    setIsPlayingBack(false);
    setPlaybackProgress(0);
    setPlaybackSegment(0);
  };

  // Animate playback dot across route segments
  useEffect(() => {
    if (!isPlayingBack || waypoints.length === 0) return;
    const chronological = [...waypoints].reverse();
    const totalSegments = chronological.length; // origin→wp[0], wp[0]→wp[1], etc.
    const segmentDuration = 1200 / playbackSpeed; // ms per segment, scaled by speed
    const totalDuration = totalSegments * segmentDuration;
    const start = Date.now();

    const tick = () => {
      const elapsed = Date.now() - start;
      const t = Math.min(elapsed / totalDuration, 1);
      setPlaybackProgress(t);
      setPlaybackSegment(Math.floor(t * totalSegments));
      if (t < 1) {
        playbackRef.current = requestAnimationFrame(tick);
      } else {
        setIsPlayingBack(false);
        hapticFeedback([10, 20, 30]);
        setPlaybackProgress(0);
        setPlaybackSegment(0);
      }
    };
    playbackRef.current = requestAnimationFrame(tick);
    return () => {
      if (playbackRef.current) cancelAnimationFrame(playbackRef.current);
    };
  }, [isPlayingBack, waypoints, playbackSpeed]);

  const [mode, setMode] = useState<"CLOCK" | "TIMER">("CLOCK");
  const [timerMs, setTimerMs] = useState(0);
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const startTimeRef = useRef<number>(0);
  const accumulatedRef = useRef<number>(0);

  useEffect(() => {
    const tick = setInterval(() => setTime(new Date()), 1000);
    // Simulate slow compass drift for realism
    const drift = setInterval(() => {
      setHeadingDrift((d) => {
        const next = d + (Math.random() - 0.5) * 0.8;
        return Math.max(-4, Math.min(4, next));
      });
    }, 800);

    // GPS drift — tiny lat/lng nudges every 1.2s to simulate live tracking
    const gpsDrift = setInterval(() => {
      setGpsCoord((prev) => ({
        lat: prev.lat + (Math.random() - 0.5) * 0.0003,
        lng: prev.lng + (Math.random() - 0.5) * 0.0004,
      }));
      // Occasionally flicker fix quality
      const roll = Math.random();
      setGpsFix(roll > 0.92 ? "SEEK" : roll > 0.96 ? "WEAK" : "LOCK");
    }, 1200);

    return () => {
      clearInterval(tick);
      clearInterval(drift);
      clearInterval(gpsDrift);
    };
  }, []);

  useEffect(() => {
    let interval: any;
    if (isTimerRunning) {
      startTimeRef.current = Date.now();
      interval = setInterval(() => {
        setTimerMs(
          accumulatedRef.current + (Date.now() - startTimeRef.current),
        );
      }, 50);
    } else {
      accumulatedRef.current = timerMs;
    }
    return () => clearInterval(interval);
  }, [isTimerRunning, timerMs]);

  const toggleTimer = () => {
    hapticFeedback(10);
    setIsTimerRunning(!isTimerRunning);
  };

  const resetTimer = () => {
    hapticFeedback(20);
    setIsTimerRunning(false);
    setTimerMs(0);
    accumulatedRef.current = 0;
  };

  const effectiveHeading = heading + headingDrift;
  const hours = time.getHours();
  const minutes = time.getMinutes();
  const seconds = time.getSeconds();
  const ms = time.getMilliseconds();

  const tSec = Math.floor(timerMs / 1000);
  const tMin = Math.floor(tSec / 60);
  const tHr = Math.floor(tMin / 60);

  const displayHours = mode === "TIMER" ? tHr : hours;
  const displayMinutes = mode === "TIMER" ? tMin % 60 : minutes;
  const displaySeconds = mode === "TIMER" ? tSec % 60 : seconds;
  const displayMs = mode === "TIMER" ? timerMs % 1000 : ms;

  // Clock hand angles
  const secDeg = (displaySeconds + displayMs / 1000) * 6;
  const minDeg = (displayMinutes + displaySeconds / 60) * 6;
  const hrDeg = ((displayHours % 12) + displayMinutes / 60) * 30;

  const pad = (n: number) => String(n).padStart(2, "0");
  const timeStr =
    mode === "TIMER"
      ? `${pad(displayHours)}:${pad(displayMinutes)}:${pad(displaySeconds)}`
      : `${pad(displayHours)}:${pad(displayMinutes)}:${pad(displaySeconds)}`;
  const msStr = mode === "TIMER" ? `.${Math.floor(displayMs / 100)}` : "";
  const dateStr = time
    .toLocaleDateString("en-GB", {
      weekday: "short",
      day: "2-digit",
      month: "short",
    })
    .toUpperCase();

  // Cardinal directions around compass
  const cardinals = [
    { label: "N", deg: 0 },
    { label: "NE", deg: 45 },
    { label: "E", deg: 90 },
    { label: "SE", deg: 135 },
    { label: "S", deg: 180 },
    { label: "SW", deg: 225 },
    { label: "W", deg: 270 },
    { label: "NW", deg: 315 },
  ];

  const getBearingLabel = (deg: number) => {
    const d = ((deg % 360) + 360) % 360;
    if (d < 22.5 || d >= 337.5) return "N";
    if (d < 67.5) return "NE";
    if (d < 112.5) return "E";
    if (d < 157.5) return "SE";
    if (d < 202.5) return "S";
    if (d < 247.5) return "SW";
    if (d < 292.5) return "W";
    return "NW";
  };

  return (
    <Card className="illuminate-card glass-panel border-primary/20 relative overflow-hidden rounded-2xl shadow-[0_0_25px_rgba(0,255,255,0.05)] inner-glow">
      {/* Scanline texture */}
      <div
        className="absolute inset-0 pointer-events-none z-0 opacity-30"
        style={{
          background:
            "repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,255,255,0.015) 2px, rgba(0,255,255,0.015) 4px)",
        }}
      />
      {/* Corner brackets */}
      {[
        ["top-2 left-2", "border-t-2 border-l-2"],
        ["top-2 right-2", "border-t-2 border-r-2"],
        ["bottom-2 left-2", "border-b-2 border-l-2"],
        ["bottom-2 right-2", "border-b-2 border-r-2"],
      ].map(([pos, border], i) => (
        <div
          key={i}
          className={`absolute ${pos} w-5 h-5 ${border} border-primary/40 z-10`}
        />
      ))}

      <CardContent className="p-5 relative z-10">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex gap-2">
            <button
              onClick={() => {
                hapticFeedback(10);
                setMode("CLOCK");
              }}
              className={cn(
                "text-[9px] font-black uppercase tracking-[0.3em] transition-colors",
                mode === "CLOCK"
                  ? "text-primary/90"
                  : "text-primary/30 hover:text-primary/60",
              )}
            >
              Tactical Clock
            </button>
            <span className="text-primary/30">|</span>
            <button
              onClick={() => {
                hapticFeedback(10);
                setMode("TIMER");
              }}
              className={cn(
                "text-[9px] font-black uppercase tracking-[0.3em] transition-colors",
                mode === "TIMER"
                  ? "text-primary/90"
                  : "text-primary/30 hover:text-primary/60",
              )}
            >
              Mission Timer
            </button>
          </div>
          <div className="flex items-center gap-1.5">
            <span
              className={cn(
                "h-1.5 w-1.5 rounded-full shadow-[0_0_6px_rgba(0,255,255,0.8)]",
                mode === "TIMER" && isTimerRunning
                  ? "bg-red-500 shadow-[0_0_6px_rgba(239,68,68,0.8)] animate-pulse"
                  : "bg-primary animate-pulse",
              )}
            />
            <span className="text-[9px] font-mono text-primary/60 uppercase tracking-widest">
              {mode === "TIMER" && isTimerRunning ? "ACTIVE" : "LIVE"}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-5">
          {/* ─── Analog Clock ─── */}
          <div className="relative shrink-0 group/clock">
            <svg
              width="140"
              height="140"
              viewBox="0 0 140 140"
              className="drop-shadow-[0_0_25px_rgba(0,255,255,0.2)] transition-transform duration-500 group-hover/clock:scale-105"
            >
              <defs>
                <radialGradient id="clockBg" cx="50%" cy="50%" r="50%">
                  <stop offset="0%" stopColor="rgba(0,20,30,0.95)" />
                  <stop offset="80%" stopColor="rgba(0,10,15,0.98)" />
                  <stop offset="100%" stopColor="rgba(0,5,10,1)" />
                </radialGradient>
                <filter id="clockGlow">
                  <feGaussianBlur stdDeviation="2" result="blur" />
                  <feComposite in="SourceGraphic" in2="blur" operator="over" />
                </filter>
                <linearGradient
                  id="bezelGrad"
                  x1="0%"
                  y1="0%"
                  x2="100%"
                  y2="100%"
                >
                  <stop offset="0%" stopColor="rgba(0,255,255,0.3)" />
                  <stop offset="50%" stopColor="rgba(0,255,255,0.05)" />
                  <stop offset="100%" stopColor="rgba(0,255,255,0.2)" />
                </linearGradient>
              </defs>

              {/* Outer tactical bezel */}
              <circle
                cx="70"
                cy="70"
                r="68"
                fill="none"
                stroke="url(#bezelGrad)"
                strokeWidth="3"
              />
              <circle cx="70" cy="70" r="65" fill="url(#clockBg)" />
              <circle
                cx="70"
                cy="70"
                r="65"
                fill="none"
                stroke="rgba(0,255,255,0.15)"
                strokeWidth="1"
              />

              {/* Inner data rings */}
              <circle
                cx="70"
                cy="70"
                r="40"
                fill="none"
                stroke="rgba(255,255,255,0.03)"
                strokeWidth="1"
                strokeDasharray="2 4"
              />
              <circle
                cx="70"
                cy="70"
                r="25"
                fill="none"
                stroke="rgba(0,255,255,0.05)"
                strokeWidth="1"
              />

              {/* Tick marks */}
              {Array.from({ length: 60 }).map((_, i) => {
                const angle = (i / 60) * 360;
                const rad = (angle - 90) * (Math.PI / 180);
                const isMajor = i % 5 === 0;
                const isCardinal = i % 15 === 0;
                const r1 = isCardinal ? 52 : isMajor ? 56 : 60;
                const r2 = 63;
                const x1 = 70 + r1 * Math.cos(rad);
                const y1 = 70 + r1 * Math.sin(rad);
                const x2 = 70 + r2 * Math.cos(rad);
                const y2 = 70 + r2 * Math.sin(rad);
                return (
                  <line
                    key={i}
                    x1={x1}
                    y1={y1}
                    x2={x2}
                    y2={y2}
                    stroke={
                      isCardinal
                        ? "rgba(0,255,255,0.9)"
                        : isMajor
                          ? "rgba(0,255,255,0.5)"
                          : "rgba(0,255,255,0.15)"
                    }
                    strokeWidth={isCardinal ? 2.5 : isMajor ? 1.5 : 1}
                    strokeLinecap="round"
                  />
                );
              })}

              {/* Hour numerals (12, 3, 6, 9) */}
              {[
                { n: "12", a: 0 },
                { n: "3", a: 90 },
                { n: "6", a: 180 },
                { n: "9", a: 270 },
              ].map(({ n, a }) => {
                const rad = ((a - 90) * Math.PI) / 180;
                return (
                  <text
                    key={n}
                    x={70 + 44 * Math.cos(rad)}
                    y={70 + 44 * Math.sin(rad)}
                    textAnchor="middle"
                    dominantBaseline="central"
                    fill="rgba(0,255,255,0.8)"
                    fontSize="10"
                    fontFamily="monospace"
                    fontWeight="900"
                    style={{
                      filter: "drop-shadow(0 0 2px rgba(0,255,255,0.5))",
                    }}
                  >
                    {n}
                  </text>
                );
              })}

              {/* Digital sub-dial (bottom) */}
              <rect
                x="50"
                y="85"
                width="40"
                height="14"
                rx="4"
                fill="rgba(0,0,0,0.5)"
                stroke="rgba(0,255,255,0.2)"
                strokeWidth="0.5"
              />
              <text
                x="70"
                y="93"
                textAnchor="middle"
                dominantBaseline="central"
                fill="rgba(0,255,255,0.7)"
                fontSize="7"
                fontFamily="monospace"
                fontWeight="bold"
                letterSpacing="1"
              >
                {dateStr.split(" ")[0]} {dateStr.split(" ")[1]}
              </text>

              {/* Hour hand */}
              <line
                x1="70"
                y1="70"
                x2={70 + 32 * Math.cos(((hrDeg - 90) * Math.PI) / 180)}
                y2={70 + 32 * Math.sin(((hrDeg - 90) * Math.PI) / 180)}
                stroke="rgba(255,255,255,0.9)"
                strokeWidth="4"
                strokeLinecap="round"
                filter="url(#clockGlow)"
              />
              {/* Minute hand */}
              <line
                x1="70"
                y1="70"
                x2={70 + 46 * Math.cos(((minDeg - 90) * Math.PI) / 180)}
                y2={70 + 46 * Math.sin(((minDeg - 90) * Math.PI) / 180)}
                stroke="rgba(0,255,255,0.8)"
                strokeWidth="2.5"
                strokeLinecap="round"
                filter="url(#clockGlow)"
              />
              {/* Second hand */}
              <line
                x1={70 - 12 * Math.cos(((secDeg - 90) * Math.PI) / 180)}
                y1={70 - 12 * Math.sin(((secDeg - 90) * Math.PI) / 180)}
                x2={70 + 52 * Math.cos(((secDeg - 90) * Math.PI) / 180)}
                y2={70 + 52 * Math.sin(((secDeg - 90) * Math.PI) / 180)}
                stroke={
                  mode === "TIMER" ? "rgba(239,68,68,1)" : "rgba(239,68,68,0.9)"
                }
                strokeWidth="1.5"
                strokeLinecap="round"
                style={{ filter: "drop-shadow(0 0 4px rgba(239,68,68,0.8))" }}
              />
              {/* Center pin stack */}
              <circle
                cx="70"
                cy="70"
                r="5"
                fill="rgba(0,20,30,1)"
                stroke="rgba(0,255,255,0.5)"
                strokeWidth="1"
              />
              <circle cx="70" cy="70" r="2" fill="rgba(239,68,68,0.9)" />
            </svg>
          </div>

          {/* ─── Right Panel: Digital + Compass/Timer Controls ─── */}
          <div className="flex-1 space-y-3 min-w-0">
            {/* Digital time */}
            <div className="text-center bg-black/40 rounded-xl p-2 border border-primary/10 shadow-[inset_0_0_15px_rgba(0,255,255,0.05)] relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-primary/50 to-transparent opacity-50" />
              <div
                className="font-mono text-3xl font-black text-white tracking-wider tabular-nums flex items-baseline justify-center"
                style={{
                  textShadow:
                    "0 0 10px rgba(0,255,255,0.8), 0 0 20px rgba(0,255,255,0.4)",
                }}
              >
                {timeStr}
                {mode === "TIMER" && (
                  <span className="text-lg text-primary/80 ml-1">{msStr}</span>
                )}
              </div>
              <div className="text-[8px] font-mono text-primary/60 tracking-[0.4em] mt-1 font-bold">
                {mode === "TIMER" ? "ELAPSED TIME" : dateStr}
              </div>
            </div>

            {mode === "CLOCK" ? (
              /* Compass Rose SVG */
              <div className="flex flex-col items-center gap-1.5 mt-2">
                <svg
                  width="100"
                  height="100"
                  viewBox="0 0 100 100"
                  className="drop-shadow-[0_0_15px_rgba(0,255,255,0.2)]"
                >
                  <defs>
                    <radialGradient id="compassBg" cx="50%" cy="50%" r="50%">
                      <stop offset="0%" stopColor="rgba(0,20,30,0.95)" />
                      <stop offset="100%" stopColor="rgba(0,5,10,1)" />
                    </radialGradient>
                    <linearGradient
                      id="compassBezel"
                      x1="0%"
                      y1="0%"
                      x2="100%"
                      y2="100%"
                    >
                      <stop offset="0%" stopColor="rgba(0,255,255,0.4)" />
                      <stop offset="100%" stopColor="rgba(0,255,255,0.05)" />
                    </linearGradient>
                  </defs>
                  <circle
                    cx="50"
                    cy="50"
                    r="48"
                    fill="url(#compassBg)"
                    stroke="url(#compassBezel)"
                    strokeWidth="2"
                  />
                  <circle
                    cx="50"
                    cy="50"
                    r="40"
                    fill="none"
                    stroke="rgba(0,255,255,0.1)"
                    strokeWidth="1"
                    strokeDasharray="1 3"
                  />

                  {/* Rotating group — entire compass face rotates opposite to heading */}
                  <g
                    transform={`rotate(${-effectiveHeading}, 50, 50)`}
                    style={{
                      transition:
                        "transform 0.8s cubic-bezier(0.2, 0.8, 0.2, 1)",
                    }}
                  >
                    {/* Degree ring ticks */}
                    {Array.from({ length: 72 }).map((_, i) => {
                      const a = (i / 72) * 360;
                      const rad = ((a - 90) * Math.PI) / 180;
                      const isMajor = i % 9 === 0;
                      const r1 = isMajor ? 34 : 37;
                      return (
                        <line
                          key={i}
                          x1={50 + r1 * Math.cos(rad)}
                          y1={50 + r1 * Math.sin(rad)}
                          x2={50 + 44 * Math.cos(rad)}
                          y2={50 + 44 * Math.sin(rad)}
                          stroke={
                            isMajor
                              ? "rgba(0,255,255,0.7)"
                              : "rgba(0,255,255,0.2)"
                          }
                          strokeWidth={isMajor ? 1.5 : 0.8}
                        />
                      );
                    })}

                    {/* Cardinal labels */}
                    {cardinals.map(({ label, deg }) => {
                      const rad = ((deg - 90) * Math.PI) / 180;
                      const isMain = ["N", "S", "E", "W"].includes(label);
                      return (
                        <text
                          key={label}
                          x={50 + 24 * Math.cos(rad)}
                          y={50 + 24 * Math.sin(rad)}
                          textAnchor="middle"
                          dominantBaseline="central"
                          fill={
                            label === "N"
                              ? "rgba(239,68,68,1)"
                              : isMain
                                ? "rgba(0,255,255,0.9)"
                                : "rgba(0,255,255,0.4)"
                          }
                          fontSize={isMain ? 9 : 6}
                          fontFamily="monospace"
                          fontWeight="900"
                          style={{
                            filter:
                              label === "N"
                                ? "drop-shadow(0 0 4px rgba(239,68,68,0.8))"
                                : "none",
                          }}
                        >
                          {label}
                        </text>
                      );
                    })}
                  </g>

                  {/* Fixed north indicator needle (always points up = current heading) */}
                  <g>
                    {/* North half — red */}
                    <polygon
                      points="50,12 45,50 50,45 55,50"
                      fill="rgba(239,68,68,0.9)"
                      style={{
                        filter: "drop-shadow(0 0 6px rgba(239,68,68,0.8))",
                      }}
                    />
                    {/* South half — cyan */}
                    <polygon
                      points="50,88 45,50 50,55 55,50"
                      fill="rgba(0,255,255,0.5)"
                    />
                    <circle
                      cx="50"
                      cy="50"
                      r="4"
                      fill="rgba(0,255,255,1)"
                      style={{
                        filter: "drop-shadow(0 0 4px rgba(0,255,255,0.8))",
                      }}
                    />
                    <circle cx="50" cy="50" r="2" fill="#0B0C10" />
                  </g>
                </svg>

                {/* Bearing readout */}
                <div className="flex items-center gap-2 bg-black/40 px-3 py-1 rounded-lg border border-primary/20 shadow-[inset_0_0_10px_rgba(0,255,255,0.05)]">
                  <Navigation className="w-3.5 h-3.5 text-primary/80" />
                  <span
                    className="font-mono text-sm font-black text-white tabular-nums tracking-wider"
                    style={{ textShadow: "0 0 10px rgba(0,255,255,0.5)" }}
                  >
                    {String(Math.round(effectiveHeading)).padStart(3, "0")}°
                  </span>
                  <span className="text-[10px] text-primary/70 font-mono uppercase tracking-widest font-bold">
                    {getBearingLabel(effectiveHeading)}
                  </span>
                </div>
              </div>
            ) : (
              /* Timer Controls */
              <div className="flex flex-col items-center justify-center gap-3 pt-3">
                <div className="flex gap-2 w-full px-2">
                  <Button
                    className={cn(
                      "flex-1 h-12 text-[11px] font-black uppercase tracking-widest border-2 rounded-xl transition-all duration-300",
                      isTimerRunning
                        ? "bg-red-500/20 text-red-400 border-red-500/50 hover:bg-red-500/30 shadow-[0_0_15px_rgba(239,68,68,0.3)]"
                        : "bg-primary/20 text-primary border-primary/50 hover:bg-primary/30 shadow-[0_0_15px_rgba(0,255,255,0.2)]",
                    )}
                    onClick={toggleTimer}
                  >
                    {isTimerRunning ? "STOP" : "START"}
                  </Button>
                  <Button
                    variant="outline"
                    className="flex-1 h-12 text-[11px] font-black uppercase tracking-widest bg-[#0d0d0d] border-white/10 hover:bg-white/10 hover:border-white/30 rounded-xl transition-all duration-300"
                    onClick={resetTimer}
                  >
                    RESET
                  </Button>
                </div>
                <div className="text-[9px] text-primary/60 uppercase tracking-widest text-center font-bold bg-primary/5 px-4 py-1.5 rounded-full border border-primary/10">
                  Mission Protocol Ready
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Status bar */}
        <div className="mt-5 pt-4 border-t border-primary/20 grid grid-cols-3 gap-2 text-center relative">
          <div className="absolute -top-1.5 left-1/2 -translate-x-1/2 bg-black px-2 text-[8px] font-mono text-primary/40 uppercase tracking-widest">
            SYS.DATA
          </div>
          {[
            {
              label: "ZULU",
              value: `${pad((hours + 1) % 24)}:${pad(minutes)}Z`,
            },
            { label: "GRID", value: "47N TK" },
            { label: "ALT", value: "312m" },
          ].map(({ label, value }) => (
            <div
              key={label}
              className="bg-primary/5 rounded-lg border border-primary/10 py-1.5"
            >
              <div className="text-[8px] text-primary/50 font-mono uppercase tracking-widest mb-0.5 font-bold">
                {label}
              </div>
              <div className="text-[11px] font-mono font-black text-primary/90 tabular-nums">
                {value}
              </div>
            </div>
          ))}
        </div>

        {/* GPS Coordinate Display */}
        <div className="mt-3 pt-3 border-t border-primary/10">
          <div className="flex items-center justify-between mb-1.5">
            <div className="flex items-center gap-1.5">
              <svg
                width="10"
                height="10"
                viewBox="0 0 10 10"
                className="shrink-0"
              >
                <circle
                  cx="5"
                  cy="5"
                  r="4"
                  fill="none"
                  stroke="rgba(0,255,255,0.5)"
                  strokeWidth="1"
                />
                <circle cx="5" cy="5" r="1.5" fill="rgba(0,255,255,0.9)" />
                <line
                  x1="5"
                  y1="1"
                  x2="5"
                  y2="3"
                  stroke="rgba(0,255,255,0.6)"
                  strokeWidth="0.8"
                />
                <line
                  x1="5"
                  y1="7"
                  x2="5"
                  y2="9"
                  stroke="rgba(0,255,255,0.6)"
                  strokeWidth="0.8"
                />
                <line
                  x1="1"
                  y1="5"
                  x2="3"
                  y2="5"
                  stroke="rgba(0,255,255,0.6)"
                  strokeWidth="0.8"
                />
                <line
                  x1="7"
                  y1="5"
                  x2="9"
                  y2="5"
                  stroke="rgba(0,255,255,0.6)"
                  strokeWidth="0.8"
                />
              </svg>
              <span className="text-[8px] font-mono text-primary/50 uppercase tracking-widest flex items-center gap-1">
                GPS{" "}
                <span className="text-[7px] text-primary/30 font-bold">
                  • TAP TO COPY
                </span>
              </span>
            </div>
            <div className="flex items-center gap-1">
              <span
                className={cn(
                  "h-1.5 w-1.5 rounded-full transition-colors duration-500",
                  gpsFix === "LOCK"
                    ? "bg-emerald-400 shadow-[0_0_4px_rgba(52,211,153,0.8)] animate-pulse"
                    : gpsFix === "SEEK"
                      ? "bg-yellow-400 shadow-[0_0_4px_rgba(250,204,21,0.8)] animate-ping"
                      : "bg-destructive shadow-[0_0_4px_rgba(239,68,68,0.8)] animate-pulse",
                )}
              />
              <span
                className={cn(
                  "text-[8px] font-mono uppercase tracking-widest transition-colors duration-500",
                  gpsFix === "LOCK"
                    ? "text-emerald-400"
                    : gpsFix === "SEEK"
                      ? "text-yellow-400"
                      : "text-destructive",
                )}
              >
                {gpsFix}
              </span>
            </div>
          </div>

          <div
            className="grid grid-cols-2 gap-2 cursor-pointer group/gps active:scale-[0.98] transition-transform"
            onClick={() => {
              const text = `${gpsCoord.lat.toFixed(4)}, ${gpsCoord.lng.toFixed(4)}`;
              navigator.clipboard.writeText(text);
              hapticFeedback(10);
              toast.success("Tactical coordinates copied to clipboard.", {
                description: "Grid: " + text,
                icon: <Link className="w-4 h-4 text-primary" />,
              });
            }}
          >
            <div className="bg-primary/5 border border-primary/15 rounded-lg px-2.5 py-1.5 group-hover/gps:border-primary/40 transition-colors">
              <div className="text-[7px] text-primary/40 font-mono uppercase tracking-widest mb-0.5">
                LAT
              </div>
              <div className="text-[11px] font-mono font-black text-primary/80 tabular-nums transition-all duration-[1200ms]">
                {gpsCoord.lat >= 0 ? "N" : "S"}
                {Math.abs(gpsCoord.lat).toFixed(4)}°
              </div>
            </div>
            <div className="bg-primary/5 border border-primary/15 rounded-lg px-2.5 py-1.5 group-hover/gps:border-primary/40 transition-colors">
              <div className="text-[7px] text-primary/40 font-mono uppercase tracking-widest mb-0.5">
                LNG
              </div>
              <div className="text-[11px] font-mono font-black text-primary/80 tabular-nums transition-all duration-[1200ms]">
                {gpsCoord.lng >= 0 ? "E" : "W"}
                {Math.abs(gpsCoord.lng).toFixed(4)}°
              </div>
            </div>
          </div>

          {/* Satellite signal bars */}
          <div className="flex items-end gap-0.5 mt-2 justify-center">
            {[4, 6, 8, 7, 5, 9, 6, 3].map((h, i) => (
              <div
                key={i}
                className={cn(
                  "w-2 rounded-sm transition-all duration-[1200ms]",
                  gpsFix === "LOCK"
                    ? "bg-primary/70"
                    : gpsFix === "SEEK"
                      ? "bg-yellow-400/50"
                      : "bg-destructive/40",
                )}
                style={{
                  height: `${h * 1.5}px`,
                  opacity: gpsFix === "WEAK" && i > 4 ? 0.2 : 0.7 + i * 0.02,
                }}
              />
            ))}
            <span className="text-[7px] text-primary/40 font-mono ml-1.5 self-center uppercase tracking-widest">
              8 SAT
            </span>
          </div>

          {/* ── Waypoint Radar Map ── */}
          {waypoints.length > 0 && (
            <div className="mt-3 pt-3 border-t border-primary/10">
              <div className="flex items-center justify-between mb-2 px-1">
                <div className="flex items-center gap-1.5">
                  <Grid className="w-3 h-3 text-primary/60" />
                  <span className="text-[8px] font-mono text-primary/50 uppercase tracking-widest">
                    Tactical Radar Grid
                  </span>
                </div>
                {/* Controls row */}
                <div className="flex items-center gap-1.5">
                  {/* Range Rings Toggle */}
                  <button
                    onClick={() => {
                      hapticFeedback(5);
                      setShowRangeRings((v) => !v);
                    }}
                    className={cn(
                      "flex items-center gap-1 text-[7px] font-mono uppercase tracking-widest transition-all px-1.5 py-0.5 rounded border",
                      showRangeRings
                        ? "bg-primary/20 text-primary border-primary/40 shadow-[0_0_8px_rgba(0,255,255,0.3)]"
                        : "bg-white/5 text-primary/40 border-white/10 hover:text-primary/60 hover:border-primary/20",
                    )}
                  >
                    <svg
                      width="8"
                      height="8"
                      viewBox="0 0 8 8"
                      className="shrink-0"
                    >
                      <circle
                        cx="4"
                        cy="4"
                        r="3"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="0.8"
                      />
                      <circle
                        cx="4"
                        cy="4"
                        r="1.8"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="0.6"
                        strokeDasharray="1 0.5"
                      />
                      <circle cx="4" cy="4" r="0.7" fill="currentColor" />
                    </svg>
                    Rings
                  </button>
                  {/* Mission Playback Toggle */}
                  <button
                    onClick={() =>
                      isPlayingBack ? stopPlayback() : startPlayback()
                    }
                    disabled={waypoints.length === 0}
                    className={cn(
                      "flex items-center gap-1 text-[7px] font-mono uppercase tracking-widest transition-all px-1.5 py-0.5 rounded border",
                      isPlayingBack
                        ? "bg-orange-500/20 text-orange-400 border-orange-500/50 shadow-[0_0_8px_rgba(249,115,22,0.4)] animate-pulse"
                        : waypoints.length === 0
                          ? "bg-white/5 text-primary/20 border-white/5 cursor-not-allowed opacity-50"
                          : "bg-white/5 text-primary/40 border-white/10 hover:text-orange-400 hover:border-orange-500/30",
                    )}
                  >
                    <svg
                      width="8"
                      height="8"
                      viewBox="0 0 8 8"
                      className="shrink-0"
                    >
                      {isPlayingBack ? (
                        <rect
                          x="1.5"
                          y="1.5"
                          width="2"
                          height="5"
                          fill="currentColor"
                          rx="0.3"
                        />
                      ) : (
                        <polygon points="1.5,1 7,4 1.5,7" fill="currentColor" />
                      )}
                      {isPlayingBack && (
                        <rect
                          x="4.5"
                          y="1.5"
                          width="2"
                          height="5"
                          fill="currentColor"
                          rx="0.3"
                        />
                      )}
                    </svg>
                    {isPlayingBack ? "Stop" : "Playback"}
                  </button>
                  {/* Speed Control */}
                  <div className="flex items-center rounded border border-primary/15 overflow-hidden">
                    {([0.5, 1, 2] as const).map((speed) => (
                      <button
                        key={speed}
                        onClick={() => {
                          hapticFeedback(5);
                          setPlaybackSpeed(speed);
                        }}
                        className={cn(
                          "text-[7px] font-mono font-black uppercase tracking-widest px-1.5 py-0.5 transition-all",
                          playbackSpeed === speed
                            ? "bg-orange-500/30 text-orange-400 shadow-[inset_0_0_6px_rgba(249,115,22,0.3)]"
                            : "bg-white/5 text-primary/40 hover:text-orange-400/70 hover:bg-white/10",
                        )}
                      >
                        {speed}x
                      </button>
                    ))}
                  </div>
                </div>
              </div>
              <div className="relative aspect-square w-full bg-black/40 rounded-xl border border-primary/10 overflow-hidden group/radar">
                {/* Grid Lines */}
                <div className="absolute inset-0 opacity-20 pointer-events-none">
                  <div
                    className="absolute inset-0"
                    style={{
                      background:
                        "linear-gradient(90deg, rgba(0,255,255,0.1) 1px, transparent 1px), linear-gradient(0deg, rgba(0,255,255,0.1) 1px, transparent 1px)",
                      backgroundSize: "20% 20%",
                    }}
                  />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-full h-[1px] bg-primary/40" />
                    <div className="h-full w-[1px] bg-primary/40" />
                  </div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-[66%] h-[66%] rounded-full border border-primary/20" />
                    <div className="w-[33%] h-[33%] rounded-full border border-primary/20" />
                  </div>
                </div>

                <svg
                  viewBox="0 0 100 100"
                  className="absolute inset-0 w-full h-full p-2"
                >
                  {/* ── Range Rings (1km, 5km, 10km) ── */}
                  {showRangeRings &&
                    (() => {
                      // 1° lat ≈ 111km → km to SVG units using same scale logic
                      // We derive scale from waypoints, fallback to 1° = 40 SVG units
                      const diffs = waypoints.map((wp) => ({
                        dx: wp.lng - gpsCoord.lng,
                        dy: wp.lat - gpsCoord.lat,
                      }));
                      const maxDiff = Math.max(
                        ...diffs.flatMap((d) => [
                          Math.abs(d.dx),
                          Math.abs(d.dy),
                        ]),
                        0.001,
                      );
                      const scale = 40 / maxDiff;
                      // degrees per km (lat): 1/111
                      const degPerKm = 1 / 111;
                      const rings = [
                        {
                          km: 1,
                          color: "rgba(0,255,255,0.55)",
                          dash: "1 1",
                          label: "1km",
                        },
                        {
                          km: 5,
                          color: "rgba(0,255,102,0.45)",
                          dash: "2 1.5",
                          label: "5km",
                        },
                        {
                          km: 10,
                          color: "rgba(255,165,0,0.40)",
                          dash: "3 2",
                          label: "10km",
                        },
                      ];
                      return rings.map(({ km, color, dash, label }) => {
                        const r = degPerKm * km * scale;
                        return (
                          <g key={km}>
                            <circle
                              cx="50"
                              cy="50"
                              r={r}
                              fill="none"
                              stroke={color}
                              strokeWidth="0.6"
                              strokeDasharray={dash}
                            />
                            {/* Label at top of ring */}
                            <text
                              x="50"
                              y={50 - r - 1}
                              fontSize="3"
                              fill={color}
                              textAnchor="middle"
                              fontFamily="monospace"
                              fontWeight="bold"
                            >
                              {label}
                            </text>
                          </g>
                        );
                      });
                    })()}

                  {/* Current Position (Center) */}
                  <g className="animate-pulse">
                    <circle
                      cx="50"
                      cy="50"
                      r="2.5"
                      fill="rgba(0,255,255,0.8)"
                    />
                    <circle
                      cx="50"
                      cy="50"
                      r="5"
                      fill="none"
                      stroke="rgba(0,255,255,0.4)"
                      strokeWidth="0.5"
                    />
                  </g>

                  {/* Waypoints + Trail Lines */}
                  {(() => {
                    const diffs = waypoints.map((wp) => ({
                      dx: wp.lng - gpsCoord.lng,
                      dy: wp.lat - gpsCoord.lat,
                      name: wp.name,
                      savedAt: wp.savedAt,
                    }));
                    const maxDiff = Math.max(
                      ...diffs.flatMap((d) => [Math.abs(d.dx), Math.abs(d.dy)]),
                      0.001,
                    );
                    const scale = 40 / maxDiff;

                    const points = diffs.map((d) => ({
                      x: 50 + d.dx * scale,
                      y: 50 - d.dy * scale,
                      name: d.name,
                      savedAt: d.savedAt,
                    }));

                    // Build full route: origin → wp[0] → wp[1] → ... (waypoints are newest-first, reverse for chronological order)
                    const chronological = [...points].reverse();
                    const routePoints = [
                      { x: 50, y: 50, name: "ORIGIN" },
                      ...chronological,
                    ];

                    return (
                      <g>
                        {/* Trail lines */}
                        <defs>
                          <linearGradient
                            id="trailGrad"
                            x1="0%"
                            y1="0%"
                            x2="100%"
                            y2="0%"
                            gradientUnits="userSpaceOnUse"
                          >
                            <stop offset="0%" stopColor="rgba(0,255,255,0.2)" />
                            <stop
                              offset="100%"
                              stopColor="rgba(0,255,255,0.7)"
                            />
                          </linearGradient>
                        </defs>
                        {routePoints.slice(0, -1).map((pt, i) => {
                          const next = routePoints[i + 1];
                          const progress = (i + 1) / (routePoints.length - 1);
                          return (
                            <g key={`trail-${i}`}>
                              {/* Glow shadow line */}
                              <line
                                x1={pt.x}
                                y1={pt.y}
                                x2={next.x}
                                y2={next.y}
                                stroke="rgba(0,255,255,0.15)"
                                strokeWidth="2.5"
                                strokeLinecap="round"
                              />
                              {/* Main trail line */}
                              <line
                                x1={pt.x}
                                y1={pt.y}
                                x2={next.x}
                                y2={next.y}
                                stroke={`rgba(0,255,255,${0.25 + progress * 0.55})`}
                                strokeWidth="0.8"
                                strokeLinecap="round"
                                strokeDasharray="2 1.5"
                              />
                              {/* Midpoint direction arrow */}
                              {(() => {
                                const mx = (pt.x + next.x) / 2;
                                const my = (pt.y + next.y) / 2;
                                const angle =
                                  Math.atan2(next.y - pt.y, next.x - pt.x) *
                                  (180 / Math.PI);
                                return (
                                  <g
                                    transform={`translate(${mx},${my}) rotate(${angle})`}
                                  >
                                    <polygon
                                      points="-2,-1 2,0 -2,1"
                                      fill={`rgba(0,255,255,${0.4 + progress * 0.4})`}
                                    />
                                  </g>
                                );
                              })()}
                              {/* Segment index label */}
                              <text
                                x={(pt.x + next.x) / 2 + 1.5}
                                y={(pt.y + next.y) / 2 - 2}
                                fontSize="2.5"
                                fill="rgba(0,255,255,0.35)"
                                textAnchor="middle"
                                fontFamily="monospace"
                              >
                                {i + 1}
                              </text>
                            </g>
                          );
                        })}

                        {/* Waypoint dots + labels */}
                        {points.map((pt, i) => (
                          <g key={`wp-${i}`}>
                            <circle
                              cx={pt.x}
                              cy={pt.y}
                              r="3"
                              fill="rgba(0,255,255,0.08)"
                            />
                            <circle
                              cx={pt.x}
                              cy={pt.y}
                              r="1.8"
                              fill="rgba(0,255,255,0.9)"
                              stroke="rgba(0,20,40,0.8)"
                              strokeWidth="0.6"
                            />
                            {/* Name Label */}
                            <text
                              x={pt.x}
                              y={pt.y - 3.5}
                              fontSize="3.2"
                              fill="rgba(0,255,255,0.8)"
                              textAnchor="middle"
                              fontFamily="monospace"
                              fontWeight="bold"
                            >
                              {pt.name}
                            </text>
                            {/* Timestamp Label */}
                            <text
                              x={pt.x}
                              y={pt.y + 6}
                              fontSize="2.5"
                              fill="rgba(0,255,255,0.4)"
                              textAnchor="middle"
                              fontFamily="monospace"
                              fontWeight="bold"
                            >
                              {pt.savedAt}
                            </text>
                          </g>
                        ))}
                      </g>
                    );
                  })()}

                  {/* ── Mission Playback Animated Dot ── */}
                  {isPlayingBack &&
                    (() => {
                      const chronological = [...waypoints].reverse();
                      const diffs = chronological.map((wp) => ({
                        dx: wp.lng - gpsCoord.lng,
                        dy: wp.lat - gpsCoord.lat,
                      }));
                      const maxDiff = Math.max(
                        ...diffs.flatMap((d) => [
                          Math.abs(d.dx),
                          Math.abs(d.dy),
                        ]),
                        0.001,
                      );
                      const scale = 40 / maxDiff;

                      const routePoints = [
                        { x: 50, y: 50 },
                        ...diffs.map((d) => ({
                          x: 50 + d.dx * scale,
                          y: 50 - d.dy * scale,
                        })),
                      ];

                      const totalSegments = routePoints.length - 1;
                      if (totalSegments === 0) return null;

                      const globalT = playbackProgress * totalSegments;
                      const segIdx = Math.min(
                        Math.floor(globalT),
                        totalSegments - 1,
                      );
                      const segT = globalT - segIdx;

                      const from = routePoints[segIdx];
                      const to = routePoints[segIdx + 1];
                      const dotX = from.x + (to.x - from.x) * segT;
                      const dotY = from.y + (to.y - from.y) * segT;

                      const coveredPath =
                        routePoints
                          .slice(0, segIdx + 1)
                          .map((p, i) => `${i === 0 ? "M" : "L"} ${p.x} ${p.y}`)
                          .join(" ") + ` L ${dotX} ${dotY}`;

                      return (
                        <g>
                          {/* Active Ghost Trail */}
                          <path
                            d={coveredPath}
                            fill="none"
                            stroke="rgba(249,115,22,0.2)"
                            strokeWidth="3"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            style={{
                              filter:
                                "drop-shadow(0 0 6px rgba(249,115,22,0.5))",
                            }}
                          />
                          <path
                            d={coveredPath}
                            fill="none"
                            stroke="rgba(249,115,22,0.8)"
                            strokeWidth="1.2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />

                          {/* Outer glow ring */}
                          <circle
                            cx={dotX}
                            cy={dotY}
                            r="7"
                            fill="rgba(249,115,22,0.1)"
                          />
                          <circle
                            cx={dotX}
                            cy={dotY}
                            r="4.5"
                            fill="rgba(249,115,22,0.2)"
                          />
                          {/* Bright core dot */}
                          <circle
                            cx={dotX}
                            cy={dotY}
                            r="2.5"
                            fill="rgba(249,115,22,1)"
                            style={{
                              filter:
                                "drop-shadow(0 0 4px rgba(249,115,22,0.9))",
                            }}
                          />
                          {/* Inner white highlight */}
                          <circle
                            cx={dotX - 0.6}
                            cy={dotY - 0.6}
                            r="0.8"
                            fill="rgba(255,255,255,0.8)"
                          />
                          {/* Segment counter label */}
                          <text
                            x={dotX + 4}
                            y={dotY - 4}
                            fontSize="3"
                            fill="rgba(249,115,22,0.9)"
                            fontFamily="monospace"
                            fontWeight="bold"
                          >
                            {segIdx + 1}/{totalSegments}
                          </text>
                        </g>
                      );
                    })()}
                </svg>

                {/* Radar Sweep Effect */}
                <div
                  className="absolute inset-0 pointer-events-none origin-center animate-[spin_4s_linear_infinite]"
                  style={{
                    background:
                      "conic-gradient(from 0deg, rgba(0,255,255,0.15) 0deg, transparent 60deg)",
                  }}
                />

                {/* Range ring legend */}
                {showRangeRings && (
                  <div className="absolute bottom-1.5 right-1.5 flex flex-col items-end gap-0.5 pointer-events-none">
                    {[
                      { label: "1km", color: "rgba(0,255,255,0.8)" },
                      { label: "5km", color: "rgba(0,255,102,0.8)" },
                      { label: "10km", color: "rgba(255,165,0,0.8)" },
                    ].map(({ label, color }) => (
                      <div key={label} className="flex items-center gap-1">
                        <div
                          className="w-3 h-[1px]"
                          style={{
                            background: color,
                            borderTop: `1px dashed ${color}`,
                          }}
                        />
                        <span
                          className="text-[6px] font-mono font-bold"
                          style={{ color }}
                        >
                          {label}
                        </span>
                      </div>
                    ))}
                  </div>
                )}

                {/* Playback progress bar */}
                {isPlayingBack && (
                  <div className="absolute bottom-0 left-0 right-0 h-[3px] bg-black/40">
                    <div
                      className="h-full bg-orange-500 transition-none shadow-[0_0_6px_rgba(249,115,22,0.8)]"
                      style={{ width: `${playbackProgress * 100}%` }}
                    />
                  </div>
                )}
                {/* Playback status label */}
                {isPlayingBack && (
                  <div className="absolute top-1.5 left-1.5 flex items-center gap-1 bg-black/60 rounded px-1.5 py-0.5 pointer-events-none">
                    <span className="h-1.5 w-1.5 rounded-full bg-orange-400 animate-pulse shadow-[0_0_4px_rgba(249,115,22,0.9)]" />
                    <span className="text-[6px] font-mono text-orange-400 uppercase tracking-widest font-bold">
                      PLAYBACK {Math.round(playbackProgress * 100)}%
                    </span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ── Elevation Profile ── */}
          {waypoints.length >= 2 && (
            <div className="mt-3 pt-3 border-t border-primary/10">
              <div className="flex items-center justify-between mb-2 px-1">
                <div className="flex items-center gap-1.5">
                  <svg
                    width="10"
                    height="10"
                    viewBox="0 0 10 10"
                    className="shrink-0"
                  >
                    <polyline
                      points="1,8 3,5 5,6 7,2 9,4"
                      fill="none"
                      stroke="rgba(0,255,255,0.7)"
                      strokeWidth="1.2"
                      strokeLinejoin="round"
                    />
                  </svg>
                  <span className="text-[8px] font-mono text-primary/50 uppercase tracking-widest">
                    Elevation Profile
                  </span>
                </div>
                <span className="text-[7px] font-mono text-primary/30 uppercase tracking-widest">
                  {(() => {
                    const chronological = [...waypoints].reverse();
                    const elevations = [
                      150,
                      ...chronological.map((wp) => wp.elevation ?? 150),
                    ];
                    const gain = elevations.reduce((acc, el, i) => {
                      if (i === 0) return acc;
                      const diff = el - elevations[i - 1];
                      return diff > 0 ? acc + diff : acc;
                    }, 0);
                    const loss = elevations.reduce((acc, el, i) => {
                      if (i === 0) return acc;
                      const diff = el - elevations[i - 1];
                      return diff < 0 ? acc + Math.abs(diff) : acc;
                    }, 0);
                    return `▲${gain}m  ▼${loss}m`;
                  })()}
                </span>
              </div>
              {(() => {
                const chronological = [...waypoints].reverse();
                const originElev = 150;
                const elevPoints = [
                  { name: "ORIGIN", elevation: originElev },
                  ...chronological.map((wp) => ({
                    name: wp.name,
                    elevation: wp.elevation ?? 150,
                  })),
                ];
                const elevations = elevPoints.map((p) => p.elevation);
                const minElev = Math.min(...elevations);
                const maxElev = Math.max(...elevations);
                const range = Math.max(maxElev - minElev, 10);
                const W = 100;
                const H = 32;
                const pad = 4;
                const xStep =
                  (W - pad * 2) / Math.max(elevPoints.length - 1, 1);
                const toSvgX = (i: number) => pad + i * xStep;
                const toSvgY = (el: number) =>
                  H - pad - ((el - minElev) / range) * (H - pad * 2);
                const areaPath =
                  `M${pad},${H - pad} ` +
                  elevPoints
                    .map((p, i) => `L${toSvgX(i)},${toSvgY(p.elevation)}`)
                    .join(" ") +
                  ` L${toSvgX(elevPoints.length - 1)},${H - pad} Z`;
                const segments = elevPoints.slice(0, -1).map((p, i) => {
                  const next = elevPoints[i + 1];
                  const isGain = next.elevation > p.elevation + 2;
                  return {
                    x1: toSvgX(i),
                    y1: toSvgY(p.elevation),
                    x2: toSvgX(i + 1),
                    y2: toSvgY(next.elevation),
                    isGain,
                  };
                });
                const totalSegments = elevPoints.length - 1;
                const coveredIdx = isPlayingBack
                  ? Math.min(
                      Math.floor(playbackProgress * totalSegments),
                      totalSegments,
                    )
                  : -1;
                return (
                  <div className="relative bg-black/40 rounded-lg border border-primary/10 overflow-hidden px-1 py-1">
                    <svg
                      viewBox={`0 0 ${W} ${H}`}
                      className="w-full"
                      style={{ height: 56 }}
                    >
                      <defs>
                        <linearGradient
                          id="elevGrad"
                          x1="0"
                          y1="0"
                          x2="0"
                          y2="1"
                        >
                          <stop offset="0%" stopColor="rgba(0,255,255,0.2)" />
                          <stop offset="100%" stopColor="rgba(0,255,255,0.0)" />
                        </linearGradient>
                      </defs>
                      {[0.25, 0.5, 0.75].map((f, gi) => (
                        <line
                          key={gi}
                          x1={pad}
                          y1={pad + f * (H - pad * 2)}
                          x2={W - pad}
                          y2={pad + f * (H - pad * 2)}
                          stroke="rgba(0,255,255,0.06)"
                          strokeWidth="0.5"
                        />
                      ))}
                      <path d={areaPath} fill="url(#elevGrad)" />
                      {segments.map((seg, i) => (
                        <g key={i}>
                          <line
                            x1={seg.x1}
                            y1={seg.y1}
                            x2={seg.x2}
                            y2={seg.y2}
                            stroke={
                              seg.isGain
                                ? "rgba(249,115,22,0.2)"
                                : "rgba(0,255,255,0.1)"
                            }
                            strokeWidth="2.5"
                            strokeLinecap="round"
                          />
                          <line
                            x1={seg.x1}
                            y1={seg.y1}
                            x2={seg.x2}
                            y2={seg.y2}
                            stroke={
                              seg.isGain
                                ? "rgba(249,115,22,0.9)"
                                : "rgba(0,255,255,0.7)"
                            }
                            strokeWidth="0.9"
                            strokeLinecap="round"
                          />
                          {isPlayingBack && i < coveredIdx && (
                            <line
                              x1={seg.x1}
                              y1={seg.y1}
                              x2={seg.x2}
                              y2={seg.y2}
                              stroke="rgba(255,255,255,0.55)"
                              strokeWidth="1.3"
                              strokeLinecap="round"
                            />
                          )}
                        </g>
                      ))}
                      {elevPoints.map((p, i) => {
                        const cx = toSvgX(i);
                        const cy = toSvgY(p.elevation);
                        return (
                          <g key={i}>
                            <circle
                              cx={cx}
                              cy={cy}
                              r="1.8"
                              fill={
                                i === 0
                                  ? "rgba(0,255,255,0.9)"
                                  : "rgba(249,115,22,0.9)"
                              }
                              stroke="rgba(0,0,0,0.6)"
                              strokeWidth="0.5"
                            />
                            <text
                              x={cx}
                              y={cy - 2.8}
                              fontSize="2.8"
                              fill={
                                i === 0
                                  ? "rgba(0,255,255,0.65)"
                                  : "rgba(249,115,22,0.65)"
                              }
                              textAnchor="middle"
                              fontFamily="monospace"
                              fontWeight="bold"
                            >
                              {p.elevation}m
                            </text>
                            <text
                              x={cx}
                              y={H - 0.5}
                              fontSize="2.4"
                              fill="rgba(0,255,255,0.3)"
                              textAnchor="middle"
                              fontFamily="monospace"
                            >
                              {p.name.length > 5 ? p.name.slice(0, 5) : p.name}
                            </text>
                          </g>
                        );
                      })}
                      {isPlayingBack &&
                        coveredIdx >= 0 &&
                        coveredIdx <= totalSegments && (
                          <line
                            x1={toSvgX(coveredIdx)}
                            y1={pad}
                            x2={toSvgX(coveredIdx)}
                            y2={H - pad}
                            stroke="rgba(255,255,255,0.35)"
                            strokeWidth="0.6"
                            strokeDasharray="1.5 1"
                          />
                        )}
                    </svg>
                    <div className="flex items-center gap-3 px-1 pb-0.5">
                      <div className="flex items-center gap-1">
                        <div
                          className="w-3 h-[1.5px] rounded"
                          style={{ background: "rgba(0,255,255,0.7)" }}
                        />
                        <span className="text-[6px] font-mono text-primary/40 uppercase tracking-widest">
                          Descent
                        </span>
                      </div>
                      <div className="flex items-center gap-1">
                        <div
                          className="w-3 h-[1.5px] rounded"
                          style={{ background: "rgba(249,115,22,0.8)" }}
                        />
                        <span
                          className="text-[6px] font-mono"
                          style={{ color: "rgba(249,115,22,0.5)" }}
                        >
                          Ascent
                        </span>
                      </div>
                      {isPlayingBack && (
                        <div className="flex items-center gap-1">
                          <div className="w-3 h-[1.5px] rounded bg-white/50" />
                          <span className="text-[6px] font-mono text-white/30 uppercase tracking-widest">
                            Covered
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })()}
            </div>
          )}

          {/* ── Tactical Waypoints ── */}
          <div className="mt-3 pt-3 border-t border-primary/10">
            {/* Header row */}
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-1.5">
                <MapPin className="w-3 h-3 text-primary/60" />
                <span className="text-[8px] font-mono text-primary/50 uppercase tracking-widest">
                  Tactical Waypoints
                </span>
                {waypoints.length > 0 && (
                  <Badge
                    variant="outline"
                    className="text-[7px] bg-primary/10 text-primary border-primary/20 px-1 py-0 h-3.5"
                  >
                    {waypoints.length}
                  </Badge>
                )}
              </div>
              <div className="flex items-center gap-1.5">
                {waypoints.length > 0 && (
                  <button
                    onClick={() => {
                      hapticFeedback(5);
                      setShowWaypointList((v) => !v);
                    }}
                    className="text-[7px] font-mono text-primary/40 hover:text-primary/70 uppercase tracking-widest transition-colors"
                  >
                    {showWaypointList ? "HIDE" : "VIEW ALL"}
                  </button>
                )}
                <button
                  onClick={() => {
                    hapticFeedback(10);
                    setShowWaypointInput((v) => !v);
                    setWaypointName("");
                  }}
                  className={cn(
                    "flex items-center gap-0.5 text-[7px] font-mono uppercase tracking-widest transition-colors px-1.5 py-0.5 rounded border",
                    showWaypointInput
                      ? "bg-destructive/20 text-destructive border-destructive/40"
                      : "bg-primary/10 text-primary border-primary/30 hover:bg-primary/20",
                  )}
                >
                  <Plus className="w-2.5 h-2.5" />
                  {showWaypointInput ? "CANCEL" : "SAVE"}
                </button>
              </div>
            </div>

            {/* Save waypoint input */}
            {showWaypointInput && (
              <div className="flex gap-1.5 mb-2">
                <input
                  type="text"
                  placeholder="Waypoint name (e.g. Alpha Base)"
                  value={waypointName}
                  onChange={(e) => setWaypointName(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      const name =
                        waypointName.trim() ||
                        `WP-${String(waypoints.length + 1).padStart(2, "0")}`;
                      const wp: Waypoint = {
                        id: Date.now().toString(),
                        name,
                        lat: parseFloat(gpsCoord.lat.toFixed(4)),
                        lng: parseFloat(gpsCoord.lng.toFixed(4)),
                        savedAt: new Date().toLocaleTimeString("en-GB", {
                          hour: "2-digit",
                          minute: "2-digit",
                        }),
                        elevation: Math.round(100 + Math.random() * 900), // simulated elevation in metres
                      };
                      const updated = [wp, ...waypoints].slice(0, 8);
                      setWaypoints(updated);
                      try {
                        localStorage.setItem(
                          "tf_waypoints",
                          JSON.stringify(updated),
                        );
                      } catch {}
                      hapticFeedback([20, 50, 20]);
                      toast.success(`Waypoint "${name}" saved.`, {
                        description: `${wp.lat >= 0 ? "N" : "S"}${Math.abs(wp.lat)}° ${wp.lng >= 0 ? "E" : "W"}${Math.abs(wp.lng)}°`,
                      });
                      setShowWaypointInput(false);
                      setWaypointName("");
                    }
                  }}
                  className="flex-1 h-7 bg-primary/5 border border-primary/20 rounded px-2 text-[10px] font-mono text-foreground placeholder:text-primary/20 focus:outline-none focus:border-primary/50"
                />
                <button
                  className="h-7 px-2 bg-primary/20 border border-primary/40 rounded text-[9px] font-black text-primary hover:bg-primary/30 uppercase tracking-widest transition-colors"
                  onClick={() => {
                    const name =
                      waypointName.trim() ||
                      `WP-${String(waypoints.length + 1).padStart(2, "0")}`;
                    const wp: Waypoint = {
                      id: Date.now().toString(),
                      name,
                      lat: parseFloat(gpsCoord.lat.toFixed(4)),
                      lng: parseFloat(gpsCoord.lng.toFixed(4)),
                      savedAt: new Date().toLocaleTimeString("en-GB", {
                        hour: "2-digit",
                        minute: "2-digit",
                      }),
                      elevation: Math.round(100 + Math.random() * 900),
                    };
                    const updated = [wp, ...waypoints].slice(0, 8);
                    setWaypoints(updated);
                    try {
                      localStorage.setItem(
                        "tf_waypoints",
                        JSON.stringify(updated),
                      );
                    } catch {}
                    hapticFeedback([20, 50, 20]);
                    toast.success(`Waypoint "${name}" saved.`, {
                      description: `${wp.lat >= 0 ? "N" : "S"}${Math.abs(wp.lat)}° ${wp.lng >= 0 ? "E" : "W"}${Math.abs(wp.lng)}°`,
                    });
                    setShowWaypointInput(false);
                    setWaypointName("");
                  }}
                >
                  MARK
                </button>
              </div>
            )}

            {/* Waypoint list */}
            {waypoints.length === 0 && !showWaypointInput && (
              <div className="text-center py-2">
                <p className="text-[8px] text-primary/25 font-mono uppercase tracking-widest">
                  No waypoints saved — tap SAVE to mark a position
                </p>
              </div>
            )}

            {(showWaypointList || waypoints.length <= 2) &&
              waypoints.length > 0 && (
                <div className="space-y-1">
                  {waypoints.map((wp) => (
                    <div
                      key={wp.id}
                      className="flex items-center gap-2 bg-primary/5 border border-primary/10 rounded-lg px-2 py-1.5 group/wp hover:border-primary/30 transition-colors"
                    >
                      <MapPin className="w-2.5 h-2.5 text-primary/50 shrink-0" />
                      <div className="flex-1 min-w-0">
                        <div className="text-[9px] font-black text-foreground truncate uppercase tracking-wide">
                          {wp.name}
                        </div>
                        <div className="text-[7px] font-mono text-primary/40 tabular-nums">
                          {wp.lat >= 0 ? "N" : "S"}
                          {Math.abs(wp.lat)}° · {wp.lng >= 0 ? "E" : "W"}
                          {Math.abs(wp.lng)}°
                        </div>
                      </div>
                      <span className="text-[7px] text-primary/25 font-mono shrink-0">
                        {wp.savedAt}
                      </span>
                      <button
                        className="opacity-0 group-hover/wp:opacity-100 transition-opacity"
                        onClick={() => {
                          const text = `${wp.lat}, ${wp.lng}`;
                          navigator.clipboard.writeText(text);
                          hapticFeedback(5);
                          toast.success(`Copied: ${wp.name}`);
                        }}
                      >
                        <Copy className="w-3 h-3 text-primary/50 hover:text-primary transition-colors" />
                      </button>
                      <button
                        className="opacity-0 group-hover/wp:opacity-100 transition-opacity"
                        onClick={() => {
                          const updated = waypoints.filter(
                            (w) => w.id !== wp.id,
                          );
                          setWaypoints(updated);
                          try {
                            localStorage.setItem(
                              "tf_waypoints",
                              JSON.stringify(updated),
                            );
                          } catch {}
                          hapticFeedback(10);
                          toast.success(`Waypoint "${wp.name}" removed.`);
                        }}
                      >
                        <Trash2 className="w-3 h-3 text-destructive/50 hover:text-destructive transition-colors" />
                      </button>
                    </div>
                  ))}
                </div>
              )}

            {!showWaypointList && waypoints.length > 2 && (
              <div className="space-y-1">
                {waypoints.slice(0, 2).map((wp) => (
                  <div
                    key={wp.id}
                    className="flex items-center gap-2 bg-primary/5 border border-primary/10 rounded-lg px-2 py-1.5 group/wp hover:border-primary/30 transition-colors"
                  >
                    <MapPin className="w-2.5 h-2.5 text-primary/50 shrink-0" />
                    <div className="flex-1 min-w-0">
                      <div className="text-[9px] font-black text-foreground truncate uppercase tracking-wide">
                        {wp.name}
                      </div>
                      <div className="text-[7px] font-mono text-primary/40 tabular-nums">
                        {wp.lat >= 0 ? "N" : "S"}
                        {Math.abs(wp.lat)}° · {wp.lng >= 0 ? "E" : "W"}
                        {Math.abs(wp.lng)}°
                      </div>
                    </div>
                    <span className="text-[7px] text-primary/25 font-mono shrink-0">
                      {wp.savedAt}
                    </span>
                    <button
                      className="opacity-0 group-hover/wp:opacity-100 transition-opacity"
                      onClick={() => {
                        const text = `${wp.lat}, ${wp.lng}`;
                        navigator.clipboard.writeText(text);
                        hapticFeedback(5);
                        toast.success(`Copied: ${wp.name}`);
                      }}
                    >
                      <Copy className="w-3 h-3 text-primary/50 hover:text-primary transition-colors" />
                    </button>
                    <button
                      className="opacity-0 group-hover/wp:opacity-100 transition-opacity"
                      onClick={() => {
                        const updated = waypoints.filter((w) => w.id !== wp.id);
                        setWaypoints(updated);
                        try {
                          localStorage.setItem(
                            "tf_waypoints",
                            JSON.stringify(updated),
                          );
                        } catch {}
                        hapticFeedback(10);
                        toast.success(`Waypoint "${wp.name}" removed.`);
                      }}
                    >
                      <Trash2 className="w-3 h-3 text-destructive/50 hover:text-destructive transition-colors" />
                    </button>
                  </div>
                ))}
                <button
                  onClick={() => {
                    hapticFeedback(5);
                    setShowWaypointList(true);
                  }}
                  className="w-full text-center text-[7px] font-mono text-primary/30 hover:text-primary/60 uppercase tracking-widest transition-colors pt-1"
                >
                  +{waypoints.length - 2} more waypoints — tap to expand
                </button>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
// ─────────────────────────────────────────────────────────────────────────────
// ─── THREAT ASSESSMENT — MILITARY GAME ELEMENT ───────────────────────────────
const ThreatAssessment = ({
  cnsLoad,
  hrv,
  readiness,
  streak,
  onMitigate,
}: {
  cnsLoad: number;
  hrv: number;
  readiness: number;
  streak: number;
  onMitigate: (amt: number) => void;
}) => {
  const [threats, setThreats] = useState([
    {
      id: "cns",
      label: "CNS Overload",
      level: cnsLoad,
      icon: BrainCircuit,
      color: "text-red-500",
      barColor: "bg-red-500",
      border: "border-red-500/40",
      bg: "bg-red-500/10",
      mitigated: false,
    },
    {
      id: "hrv",
      label: "HRV Volatility",
      level: Math.max(0, 100 - hrv),
      icon: HeartPulse,
      color: "text-orange-500",
      barColor: "bg-orange-500",
      border: "border-orange-500/40",
      bg: "bg-orange-500/10",
      mitigated: false,
    },
    {
      id: "fatigue",
      label: "Recovery Debt",
      level: Math.max(0, 100 - readiness),
      icon: Moon,
      color: "text-purple-400",
      barColor: "bg-purple-500",
      border: "border-purple-500/40",
      bg: "bg-purple-500/10",
      mitigated: false,
    },
  ]);
  const [scanProgress, setScanProgress] = useState(0);
  const [isScanning, setIsScanning] = useState(false);

  useEffect(() => {
    setThreats((prev) =>
      prev.map((t) => {
        if (t.mitigated) return t;
        if (t.id === "cns") return { ...t, level: cnsLoad };
        if (t.id === "hrv") return { ...t, level: Math.max(0, 100 - hrv) };
        if (t.id === "fatigue")
          return { ...t, level: Math.max(0, 100 - readiness) };
        return t;
      }),
    );
  }, [cnsLoad, hrv, readiness]);

  const runScan = () => {
    if (isScanning) return;
    setIsScanning(true);
    hapticFeedback(10);
    let prog = 0;
    const interval = setInterval(() => {
      prog += 5;
      setScanProgress(prog);
      if (prog >= 100) {
        clearInterval(interval);
        setIsScanning(false);
        setScanProgress(0);
        playSuccessChime();
        // Auto-mitigate the highest threat
        const highest = threats
          .filter((t) => !t.mitigated)
          .sort((a, b) => b.level - a.level)[0];
        if (highest && highest.level > 50) {
          const reduction = Math.round(highest.level * 0.15);
          setThreats((prev) =>
            prev.map((t) =>
              t.id === highest.id ? { ...t, mitigated: true } : t,
            ),
          );
          onMitigate(reduction);
          hapticFeedback([30, 60, 30]);
        }
      }
    }, 50);
  };

  const mitigate = (id: string) => {
    hapticFeedback(20);
    const threat = threats.find((t) => t.id === id);
    if (!threat || threat.mitigated) return;
    const reduction = Math.round(threat.level * 0.1);
    setThreats((prev) =>
      prev.map((t) => (t.id === id ? { ...t, mitigated: true, level: 0 } : t)),
    );
    onMitigate(reduction);
    playNodeTapSound(600);
  };

  const threatLevel =
    threats.reduce((sum, t) => sum + (t.mitigated ? 0 : t.level), 0) / 3;
  const defcon =
    threatLevel > 70
      ? 1
      : threatLevel > 50
        ? 2
        : threatLevel > 30
          ? 3
          : threatLevel > 15
            ? 4
            : 5;
  const defconColor =
    defcon <= 2
      ? "text-red-500"
      : defcon === 3
        ? "text-orange-500"
        : defcon === 4
          ? "text-yellow-400"
          : "text-emerald-400";
  const defconGlow =
    defcon <= 2
      ? "shadow-[0_0_20px_rgba(239,68,68,0.3)] border-red-500/50"
      : defcon === 3
        ? "shadow-[0_0_20px_rgba(249,115,22,0.2)] border-orange-500/40"
        : defcon === 4
          ? "shadow-[0_0_20px_rgba(250,204,21,0.2)] border-yellow-500/30"
          : "shadow-[0_0_20px_rgba(16,185,129,0.2)] border-emerald-500/30";

  return (
    <Card
      className={cn(
        "glass-panel relative overflow-hidden rounded-2xl transition-all duration-500 group",
        defconGlow,
      )}
    >
      {/* Scanline overlay */}
      <div className="absolute inset-0 pointer-events-none opacity-20 tactical-scanlines" />
      {/* Corner brackets */}
      <div className="absolute top-2 left-2 w-4 h-4 border-t-2 border-l-2 border-red-500/40 z-10" />
      <div className="absolute top-2 right-2 w-4 h-4 border-t-2 border-r-2 border-red-500/40 z-10" />
      <div className="absolute bottom-2 left-2 w-4 h-4 border-b-2 border-l-2 border-red-500/40 z-10" />
      <div className="absolute bottom-2 right-2 w-4 h-4 border-b-2 border-r-2 border-red-500/40 z-10" />

      <CardContent className="p-5 relative z-10">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <ShieldAlert className={cn("w-4 h-4 animate-pulse", defconColor)} />
            <h3 className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">
              Threat Assessment
            </h3>
          </div>
          <div
            className={cn(
              "flex items-center gap-1.5 px-2 py-1 rounded-full bg-black/40 border",
              defconColor,
              defcon <= 2
                ? "border-red-500/40"
                : defcon === 3
                  ? "border-orange-500/40"
                  : defcon === 4
                    ? "border-yellow-500/40"
                    : "border-emerald-500/40",
            )}
          >
            <span className="text-[9px] font-black tracking-widest">
              DEFCON {defcon}
            </span>
          </div>
        </div>

        {/* DEFCON Meter */}
        <div className="mb-4">
          <div className="flex items-center gap-1 mb-2">
            {[1, 2, 3, 4, 5].map((level) => (
              <div
                key={level}
                className={cn(
                  "flex-1 h-2 rounded-full transition-all duration-500",
                  level >= defcon
                    ? defcon <= 2
                      ? "bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.6)]"
                      : defcon === 3
                        ? "bg-orange-500 shadow-[0_0_8px_rgba(249,115,22,0.5)]"
                        : defcon === 4
                          ? "bg-yellow-400 shadow-[0_0_8px_rgba(250,204,21,0.4)]"
                          : "bg-emerald-400 shadow-[0_0_8px_rgba(16,185,129,0.4)]"
                    : "bg-white/5",
                )}
              />
            ))}
          </div>
          <div className="flex justify-between text-[8px] uppercase tracking-widest font-mono text-muted-foreground">
            <span className="text-red-500">Critical</span>
            <span className="text-emerald-400">Secure</span>
          </div>
        </div>

        {/* Threat List */}
        <div className="space-y-2 mb-4">
          {threats.map((threat) => {
            const Icon = threat.icon;
            return (
              <div
                key={threat.id}
                className={cn(
                  "flex items-center gap-3 p-2.5 rounded-xl border transition-all duration-300",
                  threat.mitigated
                    ? "bg-emerald-500/5 border-emerald-500/20 opacity-50"
                    : cn(threat.bg, threat.border),
                )}
              >
                <div
                  className={cn(
                    "w-8 h-8 rounded-lg flex items-center justify-center border",
                    threat.border,
                    "bg-black/40",
                  )}
                >
                  <Icon
                    className={cn(
                      "w-4 h-4",
                      threat.mitigated ? "text-emerald-400" : threat.color,
                    )}
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <span
                      className={cn(
                        "text-xs font-bold uppercase tracking-widest",
                        threat.mitigated ? "text-emerald-400" : "text-white",
                      )}
                    >
                      {threat.label}
                    </span>
                    <span
                      className={cn(
                        "text-xs font-mono font-black tabular-nums",
                        threat.mitigated ? "text-emerald-400" : threat.color,
                      )}
                    >
                      {threat.mitigated
                        ? "NEUT"
                        : `${Math.round(threat.level)}%`}
                    </span>
                  </div>
                  {/* Mini threat bar */}
                  <div className="mt-1 h-1 bg-black/60 rounded-full overflow-hidden">
                    <div
                      className={cn(
                        "h-full rounded-full transition-all duration-500",
                        threat.mitigated ? "bg-emerald-500" : threat.barColor,
                      )}
                      style={{
                        width: `${threat.mitigated ? 100 : threat.level}%`,
                      }}
                    />
                  </div>
                </div>
                {!threat.mitigated && threat.level > 30 && (
                  <button
                    onClick={() => mitigate(threat.id)}
                    className="shrink-0 px-2 py-1 rounded-lg bg-white/5 border border-white/10 text-[9px] font-black uppercase tracking-widest text-white hover:bg-white/10 transition-all active:scale-95"
                  >
                    Mitigate
                  </button>
                )}
                {threat.mitigated && (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                )}
              </div>
            );
          })}
        </div>

        {/* Scan Button */}
        <button
          onClick={runScan}
          disabled={isScanning}
          className={cn(
            "w-full h-10 rounded-xl font-black uppercase tracking-widest text-[10px] transition-all duration-300 border-2 flex items-center justify-center gap-2",
            isScanning
              ? "bg-primary/10 border-primary/30 text-primary/50"
              : "bg-red-500/10 border-red-500/40 text-red-400 hover:bg-red-500/20 hover:shadow-[0_0_15px_rgba(239,68,68,0.2)] active:scale-95",
          )}
        >
          {isScanning ? (
            <>
              <div className="w-3 h-3 border-2 border-primary/40 border-t-primary rounded-full animate-spin" />
              Scanning... {scanProgress}%
            </>
          ) : (
            <>
              <Crosshair className="w-3.5 h-3.5" />
              Run Threat Scan
            </>
          )}
        </button>
        {scanProgress > 0 && isScanning && (
          <div className="mt-2 h-0.5 bg-black/60 rounded-full overflow-hidden">
            <div
              className="h-full bg-red-500 transition-all duration-75"
              style={{ width: `${scanProgress}%` }}
            />
          </div>
        )}

        {/* Streak bonus indicator */}
        {streak >= 7 && (
          <div className="mt-3 flex items-center justify-center gap-1.5 text-[9px] uppercase tracking-widest text-emerald-400/80 font-bold">
            <Shield className="w-3 h-3" />
            Streak Bonus: Auto-Mitigation Active
          </div>
        )}
      </CardContent>
    </Card>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// ─── ACTIVE RECOVERY MINI-GAME ───────────────────────────────────────────────
const ActiveRecoveryGame = ({
  onComplete,
  onClose,
}: {
  onComplete: (val: number) => void;
  onClose: () => void;
}) => {
  const [score, setScore] = useState(0);
  const [feedback, setFeedback] = useState<"HIT" | "MISS" | null>(null);
  const [gameState, setGameState] = useState<"START" | "PLAYING" | "WON">(
    "START",
  );
  const startTimeRef = useRef(Date.now());
  const animRef = useRef(0);
  const [scale, setScale] = useState(1);

  useEffect(() => {
    if (gameState !== "PLAYING") return;
    const tick = () => {
      const t = Date.now() - startTimeRef.current;
      const currentScale = 1 + 0.4 * Math.sin((t / 2000) * Math.PI * 2);
      setScale(currentScale);
      animRef.current = requestAnimationFrame(tick);
    };
    animRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(animRef.current);
  }, [gameState]);

  const handleSync = () => {
    if (gameState !== "PLAYING") return;
    const error = Math.abs(scale - 1.0);
    if (error < 0.12) {
      hapticFeedback([10, 30]);
      playNodeTapSound(800);
      setFeedback("HIT");
      setScore((s) => {
        const newScore = s + 1;
        if (newScore >= 5) {
          setGameState("WON");
          setTimeout(() => {
            onComplete(20);
            onClose();
            playSuccessChime();
          }, 1500);
        }
        return newScore;
      });
    } else {
      hapticFeedback([50]);
      playNodeTapSound(200);
      setFeedback("MISS");
      setScore((s) => Math.max(0, s - 1));
    }
    setTimeout(() => setFeedback(null), 400);
  };

  return (
    <div className="flex flex-col items-center justify-center p-6 space-y-8 relative z-10">
      <div className="text-center space-y-2">
        <h3 className="text-lg font-black uppercase tracking-widest text-emerald-400">
          Neural Sync
        </h3>
        <p className="text-xs text-emerald-400/60 max-w-[250px]">
          Tap SYNC when the expanding ring perfectly aligns with the target zone
          to lower CNS load.
        </p>
      </div>

      {gameState === "START" ? (
        <Button
          className="bg-emerald-500 hover:bg-emerald-400 text-white w-full max-w-[200px] h-12 text-xs font-black tracking-widest uppercase shadow-[0_0_20px_rgba(52,211,153,0.3)] rounded-2xl"
          onClick={() => {
            setGameState("PLAYING");
            startTimeRef.current = Date.now();
          }}
        >
          Initiate
        </Button>
      ) : gameState === "WON" ? (
        <div className="text-center space-y-4 animate-in zoom-in duration-500 py-8">
          <div className="w-20 h-20 mx-auto rounded-full bg-emerald-500/20 flex items-center justify-center border border-emerald-500/50 shadow-[0_0_30px_rgba(52,211,153,0.5)]">
            <CheckCircle2 className="w-10 h-10 text-emerald-400" />
          </div>
          <p className="text-sm font-bold text-emerald-400 uppercase tracking-widest">
            Sync Optimal
          </p>
        </div>
      ) : (
        <>
          <div className="relative w-48 h-48 flex items-center justify-center">
            <div className="absolute inset-0 rounded-full border-2 border-emerald-500/30 border-dashed" />
            <div className="absolute inset-2 rounded-full border border-emerald-500/10" />
            <div className="absolute -inset-2 rounded-full border border-emerald-500/10" />

            <div
              className={cn(
                "absolute inset-0 rounded-full border-[3px] transition-colors duration-100",
                feedback === "HIT"
                  ? "border-emerald-400 shadow-[0_0_20px_rgba(52,211,153,0.8)]"
                  : feedback === "MISS"
                    ? "border-destructive shadow-[0_0_20px_rgba(239,68,68,0.8)]"
                    : "border-white/80 shadow-[0_0_15px_rgba(255,255,255,0.5)]",
              )}
              style={{ transform: `scale(${scale})` }}
            />

            <div className="w-8 h-8 rounded-full bg-emerald-500/20 animate-pulse border border-emerald-500/50" />
          </div>

          <div className="flex gap-2">
            {[1, 2, 3, 4, 5].map((i) => (
              <div
                key={i}
                className={cn(
                  "w-8 h-2 rounded-full transition-colors duration-300",
                  i <= score
                    ? "bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)]"
                    : "bg-white/10",
                )}
              />
            ))}
          </div>

          <Button
            className="w-full max-w-[200px] h-16 text-xl font-black tracking-widest bg-emerald-500 hover:bg-emerald-400 text-white shadow-[0_0_20px_rgba(52,211,153,0.3)] active:scale-95 transition-all rounded-2xl"
            onClick={handleSync}
          >
            SYNC
          </Button>
        </>
      )}
    </div>
  );
};

export default function Index() {
  const navigate = useNavigate();
  const [isSpinning, setIsSpinning] = useState(false);
  const [isHydrationDialogOpen, setIsHydrationDialogOpen] = useState(false);
  const [isRecoveryGameOpen, setIsRecoveryGameOpen] = useState(false);
  const [showHydrationMedal, setShowHydrationMedal] = useState(false);

  const handleShareStreak = async () => {
    hapticFeedback(10);
    const shareData = {
      title: "TherapyFIT Elite - Neural Streak",
      text: "I'm currently on a 14-Day Neural Streak in the TherapyFIT Elite App. My cognitive readiness is locked in. 🧠⚡️",
      url: window.location.origin,
    };

    try {
      if (navigator.share) {
        await navigator.share(shareData);
        toast.success("Streak shared to network.");
      } else {
        await navigator.clipboard.writeText(
          `${shareData.text} ${shareData.url}`,
        );
        toast.success("Streak protocol copied to clipboard.");
      }
    } catch (err) {
      console.error("Error sharing:", err);
    }
  };
  const [isGlowing, setIsGlowing] = useState(false);

  const handleHydrate = () => {
    hapticFeedback([20, 50, 20]);
    setHydration((prev) => {
      const next = Math.min(100, prev + 15);
      if (next === 100 && prev < 100) {
        setShowHydrationMedal(true);
        playSuccessChime();
        confetti({
          particleCount: 150,
          spread: 90,
          origin: { y: 0.6 },
          colors: ["#00cccc", "#3b82f6", "#ffffff", "#ffd700"],
          zIndex: 1000,
        });
      }
      try {
        localStorage.setItem("tf_hydration", next.toString());
      } catch (e) {}
      return next;
    });
  };
  const [readiness, setReadiness] = useState(82);
  const [cnsLoad, setCnsLoad] = useState(() => {
    try {
      return parseInt(localStorage.getItem("tf_cns_load") || "45");
    } catch {
      return 45;
    }
  });
  const [hrv, setHrv] = useState(68);
  const [blueLightUsed, setBlueLightUsed] = useState(0);
  const [hydration, setHydration] = useState(0);
  const [isResetting, setIsResetting] = useState(false);
  const [resetPhase, setResetPhase] = useState("");
  const [recentPaths, setRecentPaths] = useState<string[]>([]);
  const [streakMultiplier, setStreakMultiplier] = useState(1.5);
  const [showLevelUp, setShowLevelUp] = useState(false);
  const [isAuditComplete, setIsAuditComplete] = useState(() => {
    try {
      return localStorage.getItem("tf_morning_audit_complete") === "true";
    } catch (e) {
      return false;
    }
  });
  const [streak, setStreak] = useState(() => {
    try {
      return parseInt(localStorage.getItem("tf_morning_streak") || "14");
    } catch (e) {
      return 14;
    }
  });

  const [hrvTarget, setHrvTarget] = useState(() => {
    try {
      return parseInt(localStorage.getItem("tf_hrv_target") || "65");
    } catch {
      return 65;
    }
  });
  const [cnsTarget, setCnsTarget] = useState(() => {
    try {
      return parseInt(localStorage.getItem("tf_cns_target") || "60");
    } catch {
      return 60;
    }
  });
  const [hydrationTarget, setHydrationTarget] = useState(() => {
    try {
      return parseInt(localStorage.getItem("tf_hyd_target") || "100");
    } catch {
      return 100;
    }
  });
  const [sleepTarget, setSleepTarget] = useState(() => {
    try {
      return parseInt(localStorage.getItem("tf_sleep_target") || "85");
    } catch {
      return 85;
    }
  });
  const [blueLightTarget, setBlueLightTarget] = useState(() => {
    try {
      return parseInt(localStorage.getItem("tf_bl_target") || "50");
    } catch {
      return 50;
    }
  });

  const [hrvStreak, setHrvStreak] = useState(() => {
    try {
      return parseInt(localStorage.getItem("tf_hrv_streak") || "4");
    } catch {
      return 4;
    }
  });
  const [cnsStreak, setCnsStreak] = useState(() => {
    try {
      return parseInt(localStorage.getItem("tf_cns_streak") || "2");
    } catch {
      return 2;
    }
  });
  const [hydStreak, setHydStreak] = useState(() => {
    try {
      return parseInt(localStorage.getItem("tf_hyd_streak") || "7");
    } catch {
      return 7;
    }
  });
  const [sleepStreak, setSleepStreak] = useState(() => {
    try {
      return parseInt(localStorage.getItem("tf_sleep_streak") || "30");
    } catch {
      return 30;
    }
  });
  const [blStreak, setBlStreak] = useState(() => {
    try {
      return parseInt(localStorage.getItem("tf_bl_streak") || "5");
    } catch {
      return 5;
    }
  });

  const updateTarget = (key: string, setter: any) => (val: number) => {
    setter(val);
    try {
      localStorage.setItem(key, val.toString());
    } catch {}
  };

  const incrementStreak = (key: string, setter: any, name: string) => () => {
    setter((prev: number) => {
      const next = prev + 1;
      try {
        localStorage.setItem(key, next.toString());
      } catch {}

      if (next === 30) {
        toast.success(`${name} 30-Day Mastery Unlocked!`, {
          description: `Elite virtual medal awarded.`,
          icon: <Award className="w-5 h-5 text-yellow-400" />,
        });
      } else {
        toast.success(`${name} Target Met!`, {
          description: `Target Streak increased to ${next} days.`,
          icon: <Flame className="w-4 h-4 text-orange-500" />,
        });
      }
      return next;
    });
  };

  useEffect(() => {
    const checkAudit = () => {
      try {
        setIsAuditComplete(
          localStorage.getItem("tf_morning_audit_complete") === "true",
        );
        setStreak(parseInt(localStorage.getItem("tf_morning_streak") || "14"));
      } catch (e) {}
    };
    window.addEventListener("storage", checkAudit);
    const interval = setInterval(checkAudit, 1000);
    return () => {
      window.removeEventListener("storage", checkAudit);
      clearInterval(interval);
    };
  }, []);
  const [dailyChecklist, setDailyChecklist] = useState([
    {
      id: "reset",
      label: "Neural Reset Protocol",
      completed: false,
      icon: Wind,
      color: "text-teal-500",
    },
    {
      id: "hydration",
      label: "Optimal Hydration",
      completed: true,
      icon: Droplets,
      color: "text-blue-500",
    },
    {
      id: "ops",
      label: "Tactical Mission",
      completed: false,
      icon: Crosshair,
      color: "text-red-500",
    },
    {
      id: "sleep",
      label: "Sleep Architecture",
      completed: false,
      icon: Moon,
      color: "text-purple-500",
    },
  ]);

  const toggleChecklist = (id: string) => {
    hapticFeedback(10);
    setDailyChecklist((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, completed: !item.completed } : item,
      ),
    );
  };

  const handleLevelUp = () => {
    hapticFeedback([50, 100, 150]);
    setShowLevelUp(true);
    setStreakMultiplier((prev) => prev + 0.5);

    const duration = 3000;
    const end = Date.now() + duration;

    const frame = () => {
      confetti({
        particleCount: 5,
        angle: 60,
        spread: 55,
        origin: { x: 0 },
        colors: ["#f97316", "#eab308", "#00cccc"],
        zIndex: 100,
      });
      confetti({
        particleCount: 5,
        angle: 120,
        spread: 55,
        origin: { x: 1 },
        colors: ["#f97316", "#eab308", "#00cccc"],
        zIndex: 100,
      });

      if (Date.now() < end) {
        requestAnimationFrame(frame);
      }
    };
    frame();

    setTimeout(() => setShowLevelUp(false), 3000);
  };

  // Persist HRV so the Biometric Pulsar can read it during theme transitions
  useEffect(() => {
    try {
      // Normalise HRV to a 0-100 score (typical range 20ms-100ms → 0-100)
      const normalised = Math.min(
        100,
        Math.max(0, Math.round((hrv / 100) * 100)),
      );
      localStorage.setItem("tf_hrv_score", String(normalised));
    } catch {}
  }, [hrv]);

  useEffect(() => {
    try {
      localStorage.setItem("tf_cns_load", cnsLoad.toString());
    } catch {}
  }, [cnsLoad]);

  useEffect(() => {
    const loadData = () => {
      try {
        const blRaw = localStorage.getItem("blBudget");
        if (blRaw) {
          const parsed = JSON.parse(blRaw);
          const today = new Date().toISOString().slice(0, 10);
          if (parsed.date === today) {
            const pct = Math.min(100, Math.round((parsed.total / 3000) * 100));
            setBlueLightUsed(pct);
          }
        }

        // Load hydration from somatic storage if available, or use a default
        const somaticHydration = localStorage.getItem("tf_hydration");
        setHydration(somaticHydration ? parseInt(somaticHydration) : 64);

        // Load recent paths
        const recent = JSON.parse(
          localStorage.getItem("tf_recent_paths") || "[]",
        );
        setRecentPaths(recent);
      } catch (err) {
        console.error("Error loading dashboard data:", err);
      }
    };

    loadData();
    const interval = setInterval(loadData, 10000);
    return () => clearInterval(interval);
  }, []);

  const handleRingInteraction = () => {
    setIsSpinning(true);
    hapticFeedback([20, 50, 20]);
    playNodeTapSound(600);
    setTimeout(() => setIsSpinning(false), 2000);
  };

  const handleRingPress = () => {
    setIsGlowing(true);
    hapticFeedback(50);
    playNodeTapSound(400);
  };

  const handleRingRelease = () => {
    setIsGlowing(false);
  };

  const startNeuralReset = () => {
    if (isResetting) return;
    setIsResetting(true);
    hapticFeedback(50);

    let currentPhaseIndex = 0;
    const phases = [
      { text: "Inhale", duration: 4000 },
      { text: "Hold", duration: 4000 },
      { text: "Exhale", duration: 4000 },
      { text: "Hold", duration: 4000 },
    ];

    const runPhase = () => {
      if (currentPhaseIndex >= phases.length * 2) {
        // 2 full box breathing cycles
        setIsResetting(false);
        setResetPhase("");
        toast.success("Neural Reset Complete. CNS Load Optimal.");
        return;
      }

      const current = phases[currentPhaseIndex % phases.length];
      setResetPhase(current.text);

      if (current.text === "Exhale") {
        // Gradually decrease CNS load during exhale
        setCnsLoad((prev) => Math.max(45, prev - 25));
      }

      hapticFeedback(
        current.text === "Inhale" ? 20 : current.text === "Exhale" ? 10 : 5,
      );

      setTimeout(runPhase, current.duration);
      currentPhaseIndex++;
    };

    runPhase();
  };

  return (
    <div className="flex flex-1 flex-col spatial-dash-bg text-foreground relative min-h-full">
      <style>
        {`
          @keyframes neural-pulse {
            0% { transform: scale(0.95); opacity: 0.05; }
            15% { transform: scale(1.02); opacity: 0.15; }
            30% { transform: scale(0.98); opacity: 0.08; }
            45% { transform: scale(1.05); opacity: 0.20; }
            100% { transform: scale(0.95); opacity: 0.05; }
          }
          @keyframes pan-grid {
            0% { background-position: 0px 0px; }
            100% { background-position: 40px 40px; }
          }
        `}
      </style>

      {/* Dimmed Neural Pulse */}
      <div
        className="absolute inset-0 pointer-events-none z-0 mix-blend-screen"
        style={{
          background: `radial-gradient(circle at 50% 30%, hsl(var(--primary) / 0.3) 0%, transparent 65%)`,
          animation: `neural-pulse ${120 / hrv}s ease-in-out infinite`,
        }}
      />

      {/* Scientific Neural Grid Overlay */}
      <div
        className="absolute inset-0 pointer-events-none z-0 opacity-30"
        style={{
          backgroundImage:
            "radial-gradient(circle, rgba(0, 255, 255, 0.15) 1px, transparent 1px), linear-gradient(to right, rgba(0, 255, 255, 0.03) 1px, transparent 1px), linear-gradient(to bottom, rgba(0, 255, 255, 0.03) 1px, transparent 1px)",
          backgroundSize: "40px 40px, 40px 40px, 40px 40px",
          animation: "pan-grid 30s linear infinite",
        }}
      />

      <header className="px-6 py-8 flex justify-between items-center relative z-10 border-b border-white/[0.08] spatial-card rounded-b-[28px] mx-2 mt-2">
        <div className="space-y-1">
          <h1 className="text-3xl md:text-4xl font-tech font-black tracking-tighter text-white">
            DASH
          </h1>
          <p className="text-[0.65rem] text-white/40 uppercase tracking-[0.25em] flex items-center gap-2">
            <span className="h-1.5 w-1.5 rounded-full bg-primary animate-pulse shadow-[0_0_10px_rgba(0,255,255,0.8)]" />
            Sovereign Command
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge
            variant="outline"
            className="bg-white/[0.03] text-white/60 border-white/[0.08] px-4 py-2 rounded-xl text-[0.65rem] tracking-[0.25em] uppercase backdrop-blur-md"
          >
            Elite Operator
          </Badge>
        </div>
      </header>

      <main className="flex-1 px-6 space-y-10 max-w-md mx-auto w-full relative z-10 pb-6">
        {/* Readiness Spiral Ring */}
        <div className="flex flex-col items-center justify-center py-8">
          <div
            className="relative w-64 h-64 flex items-center justify-center cursor-pointer rounded-full spatial-readiness-orb"
            onClick={handleRingInteraction}
            onMouseDown={handleRingPress}
            onMouseUp={handleRingRelease}
            onTouchStart={handleRingPress}
            onTouchEnd={handleRingRelease}
          >
            <NeuralBrain cnsLoad={cnsLoad} isGlowing={isGlowing} />

            {/* Abstract Spiral/Ring representation */}
            <svg
              viewBox="0 0 200 200"
              className={cn(
                "absolute inset-0 w-full h-full transition-all duration-1000 z-10",
                isSpinning && "animate-[spin_2s_cubic-bezier(0.4,0,0.2,1)]",
                isGlowing &&
                  "drop-shadow-[0_0_30px_rgba(0,255,255,0.8)] scale-105",
                isResetting && resetPhase === "Inhale" && "scale-110",
                isResetting && resetPhase === "Exhale" && "scale-90",
              )}
            >
              <defs>
                <linearGradient
                  id="ringGrad"
                  x1="0%"
                  y1="0%"
                  x2="100%"
                  y2="100%"
                >
                  <stop offset="0%" stopColor="hsl(var(--primary))" />
                  <stop offset="100%" stopColor="#004444" />
                </linearGradient>
              </defs>
              {/* Outer Ring */}
              <circle
                cx="100"
                cy="100"
                r="90"
                fill="none"
                stroke="rgba(255,255,255,0.05)"
                strokeWidth="2"
              />
              {/* Data Ring */}
              <circle
                cx="100"
                cy="100"
                r="80"
                fill="none"
                stroke="url(#ringGrad)"
                strokeWidth="8"
                strokeDasharray="502"
                strokeDashoffset={502 - (502 * readiness) / 100}
                strokeLinecap="round"
                className="transform -rotate-90 origin-center transition-all duration-1000"
              />
              {/* Inner details */}
              <circle
                cx="100"
                cy="100"
                r="70"
                fill="none"
                stroke="rgba(0,255,255,0.1)"
                strokeWidth="1"
                strokeDasharray="4 4"
                className="animate-[spin_20s_linear_infinite]"
              />
              <circle
                cx="100"
                cy="100"
                r="60"
                fill="none"
                stroke="rgba(0,255,255,0.2)"
                strokeWidth="1"
                strokeDasharray="2 6"
                className="animate-[spin_15s_linear_infinite_reverse]"
              />
            </svg>

            <div className="text-center z-20 flex flex-col items-center pointer-events-none">
              {isResetting ? (
                <>
                  <span className="text-[10px] uppercase tracking-widest font-bold mb-1 text-primary bg-black/40 px-2 rounded-full backdrop-blur-sm animate-pulse">
                    Neural Reset
                  </span>
                  <span className="text-4xl font-black text-white drop-shadow-xl animate-pulse">
                    {resetPhase}
                  </span>
                </>
              ) : (
                <>
                  <span className="text-[0.65rem] tracking-[0.25em] uppercase text-white/40 mb-1">
                    Readiness
                  </span>
                  <span
                    className={cn(
                      "text-[4.5rem] font-extralight tracking-[-0.02em] transition-all duration-500",
                      isGlowing
                        ? "spatial-score-glow text-white scale-110"
                        : "spatial-score",
                    )}
                  >
                    {readiness}
                  </span>
                </>
              )}
            </div>
          </div>

          <p className="text-xs text-muted-foreground mt-4 text-center max-w-[250px]">
            Tap to resync. Hold to amplify neural resonance.
          </p>

          {/* Live Waveform — reacts to CNS Load */}
          <div className="w-full max-w-[260px] mt-4 space-y-1">
            <div className="flex items-center justify-between px-1">
              <span className="text-[9px] text-muted-foreground uppercase tracking-widest font-bold">
                CNS Waveform
              </span>
              <span
                className={cn(
                  "text-[9px] font-bold uppercase tracking-widest",
                  cnsLoad > 85
                    ? "text-destructive animate-pulse"
                    : cnsLoad > 60
                      ? "text-orange-500"
                      : "text-primary",
                )}
              >
                {cnsLoad > 85
                  ? "CRITICAL"
                  : cnsLoad > 60
                    ? "ELEVATED"
                    : "OPTIMAL"}
              </span>
            </div>

            {/* Canvas waveform */}
            <div
              className={cn(
                "spatial-waveform relative w-full rounded-lg border overflow-hidden p-2 transition-all duration-500",
                cnsLoad > 85
                  ? "bg-destructive/5 border-destructive/20"
                  : cnsLoad > 60
                    ? "bg-orange-500/5 border-orange-500/20"
                    : "bg-primary/5 border-primary/20",
              )}
            >
              {/* Scanline overlay */}
              <div
                className="absolute inset-0 pointer-events-none"
                style={{
                  background:
                    "repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,0,0,0.03) 2px, rgba(0,0,0,0.03) 4px)",
                }}
              />
              <LiveWaveform cnsLoad={cnsLoad} />
            </div>

            {/* CNS Load bar */}
            <div className="flex items-center gap-2 px-1">
              <div className="flex-1 h-1 bg-white/5 rounded-full overflow-hidden">
                <div
                  className={cn(
                    "h-full rounded-full transition-all duration-1000",
                    cnsLoad > 85
                      ? "bg-destructive"
                      : cnsLoad > 60
                        ? "bg-orange-500"
                        : "bg-primary",
                  )}
                  style={{ width: `${cnsLoad}%` }}
                />
              </div>
              <span className="text-[9px] text-muted-foreground font-mono">
                {cnsLoad}%
              </span>
            </div>
          </div>

          {/* CNS Load slider for demo purposes */}
          <div className="w-full max-w-[260px] mt-3 flex items-center gap-3">
            <span className="text-[9px] text-muted-foreground uppercase tracking-widest shrink-0">
              Simulate
            </span>
            <input
              type="range"
              min={0}
              max={100}
              value={cnsLoad}
              onChange={(e) => setCnsLoad(Number(e.target.value))}
              className="flex-1 h-1 accent-current cursor-pointer"
              style={{
                accentColor:
                  cnsLoad > 85
                    ? "#ef4444"
                    : cnsLoad > 60
                      ? "#f97316"
                      : "hsl(var(--primary))",
              }}
            />
          </div>

          {cnsLoad > 60 && !isResetting && (
            <div className="w-full max-w-[260px] mt-3 grid grid-cols-2 gap-2">
              <Button
                variant="outline"
                className="bg-primary/10 border-primary/30 text-primary hover:bg-primary/20 hover:border-primary/50 px-2 text-[10px] uppercase tracking-widest font-bold rounded-xl"
                onClick={startNeuralReset}
              >
                <Zap className="w-3 h-3 mr-1 shrink-0" /> Reset
              </Button>
              <Button
                variant="outline"
                className="bg-emerald-500/10 border-emerald-500/30 text-emerald-500 hover:bg-emerald-500/20 hover:border-emerald-500/50 px-2 text-[10px] uppercase tracking-widest font-bold rounded-xl"
                onClick={() => {
                  hapticFeedback(10);
                  setIsRecoveryGameOpen(true);
                }}
              >
                <Gamepad2 className="w-3 h-3 mr-1 shrink-0" /> Mini-Game
              </Button>
            </div>
          )}
        </div>

        {/* Morning Ritual Progress */}
        {!isAuditComplete ? (
          <Card
            className="glass-panel border-primary/40 bg-gradient-to-br from-[#0d0d0d] to-primary/5 p-5 rounded-2xl cursor-pointer hover:border-primary/60 transition-all group relative overflow-hidden shadow-[0_0_25px_rgba(0,255,255,0.1)]"
            onClick={() => {
              hapticFeedback(10);
              playNodeTapSound(500);
              navigate("/morning-checkin");
            }}
          >
            <div className="absolute inset-0 bg-gradient-to-r from-primary/10 via-transparent to-transparent animate-shimmer pointer-events-none" />
            <div className="flex items-center justify-between relative z-10">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-primary/20 border border-primary/40 flex items-center justify-center shadow-[0_0_20px_rgba(0,255,255,0.3)] group-hover:scale-110 transition-transform duration-500">
                  <Sun className="w-6 h-6 text-primary animate-[spin_10s_linear_infinite]" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-white uppercase tracking-widest glow-text-cyan">
                    Morning Ritual
                  </h3>
                  <p className="text-[10px] text-primary/70 uppercase tracking-widest font-bold mt-0.5">
                    Audit Pending • +50 XP Available
                  </p>
                </div>
              </div>
              <Button
                size="sm"
                className="bg-primary text-primary-foreground rounded-xl font-black uppercase tracking-widest text-[10px] px-5 shadow-[0_0_20px_rgba(0,255,255,0.5)] hover:scale-105 transition-transform"
              >
                Start Audit
              </Button>
            </div>
          </Card>
        ) : (
          <Card className="glass-panel border-emerald-500/30 bg-emerald-500/5 p-5 rounded-2xl shadow-[0_10px_30px_rgba(16,185,129,0.1)]">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center">
                  <CheckCircle2 className="w-6 h-6 text-emerald-400" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-white uppercase tracking-widest">
                    Morning Ritual
                  </h3>
                  <p className="text-[10px] text-emerald-400 uppercase tracking-widest font-bold">
                    Audit Synchronized • Optimal Sync
                  </p>
                </div>
              </div>
              <Badge
                variant="outline"
                className="text-[9px] bg-emerald-500/10 text-emerald-400 border-emerald-500/20 px-3 py-1 rounded-full"
              >
                +50 XP EARNED
              </Badge>
            </div>
          </Card>
        )}

        {/* Daily Directives Card (Habit Tracking) */}
        <motion.div
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className="glass-panel rounded-2xl p-5 mb-6 relative overflow-hidden cursor-pointer group border-primary/30 shadow-[0_0_25px_rgba(0,255,255,0.1)] bg-gradient-to-br from-[#0d0d0d] to-primary/5"
          onClick={() => {
            hapticFeedback(10);
            navigate("/habits");
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
          <div className="flex justify-between items-start mb-5 relative z-10">
            <div>
              <h3 className="text-sm font-black text-white uppercase tracking-widest flex items-center gap-2 glow-text-cyan">
                <Target className="w-4 h-4 text-primary" />
                Daily Directives
              </h3>
              <p className="text-[10px] font-bold text-primary/70 uppercase tracking-widest mt-1">
                Standard Operating Procedures
              </p>
            </div>
            <Badge
              variant="outline"
              className="bg-primary/10 text-primary border-primary/40 shadow-[0_0_10px_rgba(0,255,255,0.2)] px-3 py-1 font-black text-[10px]"
            >
              2 / 5 Complete
            </Badge>
          </div>
          <div className="w-full bg-black/60 h-2 rounded-full overflow-hidden border border-white/10 relative z-10">
            <div
              className="h-full bg-primary shadow-[0_0_15px_rgba(0,255,255,0.8)] relative"
              style={{ width: "40%" }}
            >
              <div className="absolute inset-0 bg-white/30 animate-shimmer" />
            </div>
          </div>
        </motion.div>

        <div className="flex items-center justify-between mb-2">
          <h2 className="text-[10px] font-black uppercase tracking-[0.3em] text-white/40">
            Neural Readiness
          </h2>
        </div>

        {/* Holographic Biometric Cards */}
        <div className="grid grid-cols-2 gap-4">
          <HolographicCard
            title="HRV"
            value={hrv}
            unit="ms"
            icon={Activity}
            colorClass="text-primary"
            shadowClass="shadow-[0_0_20px_rgba(0,255,255,0.3)] border-primary/50"
            glowColor="rgba(0,255,255,0.6)"
            activeBgClass="bg-gradient-to-br from-cyan-500/30 to-transparent"
            trendData={[58, 62, 59, 65, 63, 68, hrv]}
            targetValue={hrvTarget}
            onTargetChange={updateTarget("tf_hrv_target", setHrvTarget)}
            min={30}
            max={120}
            streakCount={hrvStreak}
            onStreakIncrement={incrementStreak(
              "tf_hrv_streak",
              setHrvStreak,
              "HRV",
            )}
            tooltipText="Heart Rate Variability measures the time difference between heartbeats. Higher HRV indicates better recovery and readiness for high-intensity load."
          />
          <HolographicCard
            title="CNS Load"
            value={cnsLoad}
            unit="%"
            icon={BrainCircuit}
            colorClass={cnsLoad > 85 ? "text-destructive" : "text-orange-500"}
            shadowClass={
              cnsLoad > 85
                ? "shadow-[0_0_20px_rgba(255,0,0,0.3)] border-destructive/50"
                : "shadow-[0_0_20px_rgba(249,115,22,0.3)] border-orange-500/50"
            }
            glowColor={
              cnsLoad > 85 ? "rgba(239,68,68,0.6)" : "rgba(249,115,22,0.6)"
            }
            activeBgClass={
              cnsLoad > 85
                ? "bg-gradient-to-br from-red-500/30 to-transparent"
                : "bg-gradient-to-br from-orange-500/30 to-transparent"
            }
            trendData={[40, 45, 55, 50, 60, cnsLoad - 5, cnsLoad]}
            targetValue={cnsTarget}
            onTargetChange={updateTarget("tf_cns_target", setCnsTarget)}
            min={0}
            max={100}
            reverseTarget={true}
            streakCount={cnsStreak}
            onStreakIncrement={incrementStreak(
              "tf_cns_streak",
              setCnsStreak,
              "CNS Load",
            )}
            tooltipText="Central Nervous System fatigue. Above 85% indicates critical neural strain, requiring immediate active recovery and gating high-intensity missions."
          />
          <div
            onClick={() => {
              hapticFeedback(10);
              setIsHydrationDialogOpen(true);
            }}
          >
            <HolographicCard
              title="Hydration"
              value={hydration}
              unit="%"
              icon={Droplets}
              colorClass={hydration < 50 ? "text-orange-400" : "text-blue-400"}
              shadowClass={
                hydration < 50
                  ? "shadow-[0_0_20px_rgba(249,115,22,0.3)] border-orange-500/50"
                  : "shadow-[0_0_20px_rgba(59,130,246,0.3)] border-blue-400/50"
              }
              glowColor={
                hydration < 50 ? "rgba(249,115,22,0.6)" : "rgba(59,130,246,0.6)"
              }
              activeBgClass={
                hydration < 50
                  ? "bg-gradient-to-br from-orange-500/30 to-transparent"
                  : "bg-gradient-to-br from-blue-500/30 to-transparent"
              }
              trendData={[70, 65, 60, 55, 75, 80, hydration]}
              targetValue={hydrationTarget}
              onTargetChange={updateTarget("tf_hyd_target", setHydrationTarget)}
              min={0}
              max={100}
              streakCount={hydStreak}
              onStreakIncrement={incrementStreak(
                "tf_hyd_streak",
                setHydStreak,
                "Hydration",
              )}
              tooltipText="Daily water and electrolyte intake. Optimal hydration maintains cognitive baseline and physical performance."
            />
          </div>
          <div
            onClick={() => {
              hapticFeedback(10);
              navigate("/sleep");
            }}
          >
            <HolographicCard
              title="Sleep Score"
              value="92"
              unit="pts"
              icon={Moon}
              colorClass="text-purple-400"
              shadowClass="shadow-[0_0_20px_rgba(192,132,252,0.3)] border-purple-400/50"
              glowColor="rgba(168,85,247,0.6)"
              activeBgClass="bg-gradient-to-br from-purple-500/30 to-transparent"
              trendData={[85, 88, 86, 90, 94, 91, 92]}
              targetValue={sleepTarget}
              onTargetChange={updateTarget("tf_sleep_target", setSleepTarget)}
              min={0}
              max={100}
              streakCount={sleepStreak}
              onStreakIncrement={incrementStreak(
                "tf_sleep_streak",
                setSleepStreak,
                "Sleep",
              )}
              tooltipText="Composite score based on sleep architecture, REM cycles, and deep sleep phases. Drives next-day readiness predictions."
            />
          </div>
          <div
            className="col-span-2 cursor-pointer transition-transform hover:scale-[1.02] active:scale-[0.98]"
            onClick={() => {
              hapticFeedback(10);
              navigate("/sleep");
            }}
          >
            <HolographicCard
              title="Blue Light Exposure"
              value={blueLightUsed}
              unit="%"
              icon={Sun}
              colorClass={
                blueLightUsed > 90
                  ? "text-destructive"
                  : blueLightUsed > 65
                    ? "text-orange-400"
                    : "text-blue-400"
              }
              shadowClass={
                blueLightUsed > 90
                  ? "shadow-[0_0_20px_rgba(239,68,68,0.3)] border-destructive/50"
                  : "shadow-[0_0_20px_rgba(96,165,250,0.3)] border-blue-400/50"
              }
              glowColor={
                blueLightUsed > 90
                  ? "rgba(239,68,68,0.6)"
                  : "rgba(96,165,250,0.6)"
              }
              activeBgClass={
                blueLightUsed > 90
                  ? "bg-gradient-to-br from-red-500/30 to-transparent"
                  : blueLightUsed > 65
                    ? "bg-gradient-to-br from-orange-500/30 to-transparent"
                    : "bg-gradient-to-br from-blue-500/30 to-transparent"
              }
              trendData={[30, 45, 60, 40, 50, 70, blueLightUsed]}
              targetValue={blueLightTarget}
              onTargetChange={updateTarget("tf_bl_target", setBlueLightTarget)}
              min={0}
              max={100}
              reverseTarget={true}
              streakCount={blStreak}
              onStreakIncrement={incrementStreak(
                "tf_bl_streak",
                setBlStreak,
                "Blue Light",
              )}
              tooltipText="Tracks screen time and circadian disruption. High exposure before sleep degrades recovery quality."
            />
          </div>
        </div>

        {/* HRV Sparkline History */}
        <HRVSparkline />

        {/* Garmin-Style Advanced Metrics */}
        <ANSStressTimeline />
        <TacticalStatus />

        {/* Tactical Clock & Compass */}
        <div className="mt-8">
          <TacticalClockCompass />
        </div>

        {/* Quick Launch Widget */}
        {recentPaths.length > 0 && (
          <div className="space-y-3">
            <h2 className="text-[10px] font-bold uppercase tracking-widest text-emerald-500 flex items-center gap-2 px-1">
              <Activity className="w-3 h-3" />
              Quick Launch
            </h2>
            <div className="grid grid-cols-3 gap-3">
              {recentPaths.slice(0, 3).map((path) => {
                const item = ALL_ITEMS.find((i) => i.path === path);
                if (!item) return null;
                const Icon = item.icon;
                return (
                  <Card
                    key={item.id}
                    className="glass-panel border-white/5 hover:border-primary/40 hover:bg-white/5 transition-all duration-500 cursor-pointer group flex flex-col items-center justify-center p-4 gap-3 rounded-2xl"
                    onClick={() => {
                      hapticFeedback(10);
                      navigate(item.path);
                    }}
                  >
                    <div
                      className={cn(
                        "w-10 h-10 rounded-2xl bg-black/40 border border-white/10 flex items-center justify-center shadow-inner group-hover:scale-105 group-hover:shadow-[0_0_15px_rgba(0,255,255,0.15)] transition-all duration-500",
                        item.color,
                      )}
                    >
                      <Icon className="w-5 h-5" />
                    </div>
                    <span className="text-[9px] font-black tracking-widest uppercase text-muted-foreground group-hover:text-white transition-colors text-center leading-tight">
                      {item.label}
                    </span>
                  </Card>
                );
              })}
            </div>
          </div>
        )}

        {/* Daily Protocol Checklist */}
        <Card className="glass-panel border-white/5 relative overflow-hidden shadow-[0_0_30px_rgba(0,0,0,0.6)] rounded-2xl group/protocol">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-transparent pointer-events-none opacity-50 group-hover/protocol:opacity-100 transition-opacity duration-700" />
          <CardContent className="p-0 space-y-0">
            <div className="p-5 pb-4 border-b border-white/5 relative">
              <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-primary/30 to-transparent opacity-50" />
              <div className="flex items-center justify-between mb-3">
                <span className="text-[11px] font-black text-white uppercase tracking-[0.2em] flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-primary" /> Standard
                  Operating Procedures
                </span>
                <Badge
                  variant="outline"
                  className="text-[9px] font-black bg-primary/10 text-primary border-primary/30 px-2.5 py-0.5 shadow-[0_0_10px_rgba(0,255,255,0.2)]"
                >
                  {dailyChecklist.filter((i) => i.completed).length} /{" "}
                  {dailyChecklist.length}
                </Badge>
              </div>
              {/* Master Progress Bar */}
              <div className="w-full h-1.5 bg-black/60 rounded-full overflow-hidden border border-white/5">
                <div
                  className="h-full bg-primary rounded-full shadow-[0_0_10px_rgba(0,255,255,0.8)] transition-all duration-700 relative"
                  style={{
                    width: `${(dailyChecklist.filter((i) => i.completed).length / dailyChecklist.length) * 100}%`,
                  }}
                >
                  <div className="absolute inset-0 bg-white/30 animate-shimmer" />
                </div>
              </div>
            </div>

            <div className="p-3 space-y-2 relative z-10 bg-black/20">
              {dailyChecklist.map((item) => (
                <div
                  key={item.id}
                  className={cn(
                    "flex items-center justify-between p-3.5 rounded-xl border cursor-pointer transition-all duration-300 relative overflow-hidden group/item",
                    item.completed
                      ? "bg-primary/10 border-primary/30 shadow-[0_0_15px_rgba(0,255,255,0.1)]"
                      : "bg-[#0d0d0d] border-white/5 hover:border-white/20 hover:bg-white/5",
                  )}
                  onClick={() => toggleChecklist(item.id)}
                >
                  {item.completed && (
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-primary/10 to-transparent animate-shimmer pointer-events-none" />
                  )}
                  <div className="flex items-center gap-3 relative z-10">
                    <div
                      className={cn(
                        "p-2 rounded-lg transition-colors duration-300",
                        item.completed
                          ? "bg-primary/20 text-primary"
                          : `bg-white/5 ${item.color}`,
                      )}
                    >
                      <item.icon className="w-4 h-4" />
                    </div>
                    <div className="flex flex-col">
                      <span
                        className={cn(
                          "text-xs font-bold uppercase tracking-wider transition-all duration-300",
                          item.completed
                            ? "text-primary/70 line-through"
                            : "text-white",
                        )}
                      >
                        {item.label}
                      </span>
                      <span
                        className={cn(
                          "text-[9px] font-mono uppercase tracking-widest transition-colors duration-300",
                          item.completed
                            ? "text-primary/50"
                            : "text-muted-foreground",
                        )}
                      >
                        {item.completed ? "Executed" : "Pending"}
                      </span>
                    </div>
                  </div>
                  <div className="relative z-10">
                    {item.completed ? (
                      <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center border border-primary/50 shadow-[0_0_10px_rgba(0,255,255,0.5)]">
                        <CheckCircle2 className="w-3.5 h-3.5 text-primary" />
                      </div>
                    ) : (
                      <div className="w-6 h-6 rounded-full border-2 border-white/10 group-hover/item:border-white/30 transition-colors" />
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* CNS Load Warning if > 85% */}

        {cnsLoad > 85 && (
          <div className="bg-destructive/10 border border-destructive/30 rounded-xl p-4 flex gap-3 animate-pulse">
            <ShieldAlert className="w-5 h-5 text-destructive shrink-0" />
            <div>
              <h4 className="text-sm font-bold text-destructive uppercase tracking-widest">
                Training Gated
              </h4>
              <p className="text-xs text-destructive/80 mt-1">
                CNS Load critical. Tactical Advisor mandates active recovery.
                All high-intensity missions are currently locked.
              </p>
            </div>
          </div>
        )}

        {/* Daily Intel Brief */}
        <Card className="bg-[#0d0d0d] border-yellow-500/20 relative overflow-hidden shadow-[0_0_20px_rgba(234,179,8,0.1)] group transition-all duration-500 hover:border-yellow-500/40 hover:shadow-[0_0_30px_rgba(234,179,8,0.15)] rounded-2xl">
          <div className="absolute inset-0 bg-gradient-to-br from-yellow-500/15 via-transparent to-transparent pointer-events-none opacity-50 group-hover:opacity-100 transition-opacity" />
          <div className="absolute top-0 right-0 p-4 opacity-20 group-hover:opacity-40 transition-opacity">
            <Shield className="w-12 h-12 text-yellow-500 rotate-12" />
          </div>
          <CardContent className="p-6 space-y-4 relative z-10">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-black text-yellow-500/80 uppercase tracking-[0.3em]">
                Intelligence Briefing
              </span>
              <div className="flex items-center gap-2">
                <span className="h-2 w-2 rounded-full bg-yellow-500 animate-ping" />
                <Badge
                  variant="outline"
                  className="text-[9px] font-black bg-yellow-500/10 text-yellow-400 border-yellow-500/40 shadow-[0_0_12px_rgba(234,179,8,0.5)]"
                >
                  PRIORITY 1
                </Badge>
              </div>
            </div>
            <div className="space-y-4">
              <p className="text-sm text-foreground/90 leading-relaxed font-medium">
                HRV is{" "}
                <span className="text-emerald-400 font-black glow-text-emerald">
                  trending 4% above baseline
                </span>
                . Parasympathetic dominance confirmed. Neural fatigue at 12%.
              </p>
              <div className="p-4 rounded-xl bg-yellow-500/5 border border-yellow-500/20 backdrop-blur-md">
                <span className="glow-text-gold font-black block text-base leading-tight uppercase tracking-tight">
                  PRIME EXECUTION WINDOW: HIGH-INTENSITY LOAD MANDATED UNTIL
                  14:00.
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* AI Smart Protocol Suggestions */}
        {(() => {
          const suggestions = [];
          if (cnsLoad > 75) {
            suggestions.push({
              title: "Neural Reset",
              path: "/breathing",
              reason:
                "Elevated CNS load. Immediate down-regulation recommended.",
              icon: Wind,
              color: "text-teal-500",
              glow: "rgba(20,184,166,0.2)",
            });
          }
          if (hydration < 65) {
            suggestions.push({
              title: "Hydration Protocol",
              path: "/somatic",
              reason: "Suboptimal hydration detected. Fluid intake required.",
              icon: Droplets,
              color: "text-blue-500",
              glow: "rgba(59,130,246,0.2)",
            });
          }
          if (hrv >= 65 && cnsLoad <= 60) {
            suggestions.push({
              title: "Tactical Mission",
              path: "/ops",
              reason:
                "Peak cognitive readiness. Prime window for high-intensity load.",
              icon: Crosshair,
              color: "text-red-500",
              glow: "rgba(239,68,68,0.2)",
            });
          }
          if (suggestions.length === 0) {
            suggestions.push({
              title: "Flow State",
              path: "/flow",
              reason: "Baseline optimal. Maintain focus and steady execution.",
              icon: Zap,
              color: "text-yellow-400",
              glow: "rgba(250,204,21,0.2)",
            });
          }

          return (
            <div className="space-y-3">
              <h2 className="text-[10px] font-bold uppercase tracking-widest text-primary flex items-center gap-2 px-1 mt-6">
                <BrainCircuit className="w-3 h-3 animate-pulse" />
                AI Smart Suggestions
              </h2>
              <div className="grid gap-3">
                {suggestions.map((s, i) => (
                  <Card
                    key={i}
                    className="bg-[#111] border-white/5 hover:border-white/20 transition-all duration-300 cursor-pointer overflow-hidden relative group"
                    onClick={() => {
                      hapticFeedback(10);
                      navigate(s.path);
                    }}
                  >
                    <div
                      className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"
                      style={{
                        background: `radial-gradient(circle at right, ${s.glow}, transparent 70%)`,
                      }}
                    />
                    <CardContent className="p-3 flex items-center gap-4 relative z-10">
                      <div
                        className={cn(
                          "p-2 rounded-full bg-black/50 border border-white/5",
                          s.color,
                        )}
                      >
                        <s.icon className="w-5 h-5" />
                      </div>
                      <div className="flex-1">
                        <h4 className="text-sm font-bold text-foreground">
                          {s.title}
                        </h4>
                        <p className="text-xs text-muted-foreground mt-0.5 leading-tight">
                          {s.reason}
                        </p>
                      </div>
                      <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-white transition-colors" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          );
        })()}

        {/* Neural Adherence & Streak Tracker */}
        <Card className="illuminate-card glass-panel border-white/5 relative overflow-hidden shadow-[0_0_20px_rgba(0,0,0,0.5)] rounded-2xl group hover:border-orange-500/30 transition-all duration-500 inner-glow">
          <div className="absolute inset-0 bg-gradient-to-br from-orange-500/10 via-transparent to-transparent pointer-events-none opacity-30 group-hover:opacity-60 transition-opacity" />

          <CardContent className="p-5 relative z-10">
            <div className="flex justify-between items-start mb-4">
              <div className="flex items-center gap-2">
                <Flame className="w-4 h-4 text-orange-500 animate-pulse" />
                <h3 className="text-[10px] font-black text-muted-foreground uppercase tracking-widest">
                  Neural Adherence
                </h3>
              </div>
              <Badge
                variant="outline"
                className="bg-orange-500/10 text-orange-400 border-orange-500/20 px-2 py-0.5 flex items-center gap-1"
              >
                <Shield className="w-3 h-3" />
                <span className="text-[9px] uppercase tracking-widest font-bold">
                  Tier {Math.floor(streak / 7) + 1}
                </span>
              </Badge>
            </div>

            <div className="flex items-end gap-3 mb-5">
              <div
                className="text-5xl font-black text-orange-500 tracking-tighter"
                style={{ textShadow: "0 0 20px rgba(249,115,22,0.4)" }}
              >
                {streak}
              </div>
              <div className="pb-1.5">
                <div className="text-sm font-bold text-white uppercase tracking-widest">
                  Day Streak
                </div>
                <div className="text-[9px] text-muted-foreground uppercase tracking-widest">
                  Next milestone: {Math.ceil((streak + 1) / 30) * 30} Days
                </div>
              </div>
            </div>

            {/* Progress to next milestone */}
            <div className="mb-5">
              <div className="w-full h-1.5 bg-black/60 rounded-full overflow-hidden border border-white/5">
                <div
                  className="h-full bg-orange-500 rounded-full shadow-[0_0_10px_rgba(249,115,22,0.8)] relative"
                  style={{ width: `${((streak % 30) / 30) * 100}%` }}
                >
                  <div className="absolute inset-0 bg-white/20 animate-shimmer" />
                </div>
              </div>
            </div>

            {/* Tactical 7-Day History */}
            <div className="grid grid-cols-7 gap-1.5">
              {Array.from({ length: 7 }).map((_, i) => {
                const d = new Date();
                d.setDate(d.getDate() - (6 - i));
                const isToday = i === 6;

                let isCompleted = false;
                if (isAuditComplete) {
                  isCompleted = 6 - i < streak;
                } else {
                  const daysAgo = 5 - i;
                  if (daysAgo >= 0) {
                    isCompleted = daysAgo < streak;
                  }
                }

                return (
                  <div key={i} className="flex flex-col items-center gap-1.5">
                    <div
                      className={cn(
                        "w-full aspect-square rounded-md flex items-center justify-center border transition-all duration-500",
                        isCompleted
                          ? "bg-orange-500/20 border-orange-500/50 shadow-[inset_0_0_10px_rgba(249,115,22,0.2),0_0_8px_rgba(249,115,22,0.3)]"
                          : "bg-black/40 border-white/5 opacity-50",
                        isToday &&
                          !isCompleted &&
                          "border-orange-500/30 animate-pulse bg-orange-500/5",
                      )}
                    >
                      {isCompleted ? (
                        <CheckCircle2 className="w-3.5 h-3.5 text-orange-400" />
                      ) : (
                        <div className="w-1 h-1 rounded-full bg-white/20" />
                      )}
                    </div>
                    <span
                      className={cn(
                        "text-[8px] uppercase tracking-widest font-mono",
                        isToday
                          ? "text-orange-400 font-bold"
                          : "text-muted-foreground",
                      )}
                    >
                      {d
                        .toLocaleDateString("en-US", { weekday: "short" })
                        .charAt(0)}
                    </span>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Threat Assessment — Military Game Element */}
        <ThreatAssessment
          cnsLoad={cnsLoad}
          hrv={hrv}
          readiness={readiness}
          streak={streak}
          onMitigate={(amt: number) => {
            setCnsLoad((prev) => Math.max(0, prev - amt));
            toast.success(`Threat neutralized. CNS load -${amt}%`, {
              icon: <Shield className="w-4 h-4 text-emerald-400" />,
            });
          }}
        />

        {/* Stress Trigger Logger */}
        <Card
          className="glass-panel border-purple-500/30 bg-gradient-to-r from-[#0d0d0d] to-purple-900/10 hover:border-purple-500/60 transition-all duration-500 cursor-pointer group rounded-2xl overflow-hidden relative mb-6 shadow-[0_0_20px_rgba(168,85,247,0.1)]"
          onClick={() => {
            hapticFeedback(10);
            navigate("/somatic");
          }}
        >
          <div className="absolute inset-0 bg-purple-500/5 group-hover:bg-purple-500/10 transition-colors" />
          <div className="absolute left-0 top-0 bottom-0 w-1 bg-purple-500 shadow-[0_0_10px_rgba(168,85,247,0.8)]" />
          <CardContent className="p-4 flex items-center justify-between relative z-10">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-xl bg-purple-500/20 border border-purple-500/40 flex items-center justify-center shadow-[0_0_15px_rgba(168,85,247,0.3)] group-hover:scale-110 transition-transform duration-500">
                <Zap className="w-5 h-5 text-purple-400 animate-pulse" />
              </div>
              <div>
                <h4
                  className="text-sm font-black text-purple-400 uppercase tracking-widest"
                  style={{ textShadow: "0 0 10px rgba(168,85,247,0.5)" }}
                >
                  Log Stress Trigger
                </h4>
                <p className="text-[9px] text-purple-400/60 uppercase tracking-widest font-bold mt-0.5">
                  Record somatic & environmental load
                </p>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-purple-400/50 group-hover:text-purple-400 transition-colors group-hover:translate-x-1" />
          </CardContent>
        </Card>

        {/* Hydration Dialog */}
        <Dialog
          open={isHydrationDialogOpen}
          onOpenChange={setIsHydrationDialogOpen}
        >
          <DialogContent className="sm:max-w-md bg-[#0a0a0a] border-blue-500/30 text-foreground overflow-hidden">
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-blue-900/20 via-transparent to-transparent pointer-events-none" />
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2 text-blue-400 uppercase tracking-widest text-xs">
                <Droplets className="w-4 h-4" /> Tactical Hydration
              </DialogTitle>
            </DialogHeader>
            <div className="flex flex-col items-center justify-center py-8 relative z-10">
              {showHydrationMedal ? (
                <div className="flex flex-col items-center animate-in zoom-in duration-500">
                  <div className="w-32 h-32 rounded-full border-4 border-cyan-400 bg-blue-950/50 flex items-center justify-center shadow-[0_0_50px_rgba(34,211,238,0.6)] mb-6 relative">
                    <div className="absolute inset-0 rounded-full bg-cyan-400/20 animate-ping" />
                    <Award className="w-16 h-16 text-cyan-400 drop-shadow-[0_0_15px_rgba(34,211,238,1)]" />
                  </div>
                  <h3 className="text-2xl font-black text-cyan-400 uppercase tracking-widest text-center mb-2 glow-text-cyan">
                    Aquatic Supremacy
                  </h3>
                  <p className="text-sm text-blue-200/70 text-center max-w-[250px]">
                    Daily hydration protocol complete. Cellular resonance
                    optimal.
                  </p>
                </div>
              ) : (
                <>
                  {/* Military Jug */}
                  <div className="flex flex-col items-center mb-8 relative group">
                    <div className="absolute inset-0 bg-blue-500/20 blur-3xl rounded-full scale-150 opacity-0 group-hover:opacity-100 transition-opacity duration-700" />

                    {/* Cap & Handle */}
                    <div className="flex justify-between w-32 mb-1 relative z-10">
                      <div className="w-8 h-5 bg-slate-700 rounded-t-sm border-2 border-slate-600 border-b-0" />
                      <div className="w-16 h-8 border-4 border-slate-700 rounded-t-xl border-b-0" />
                    </div>
                    {/* Jug Body */}
                    <div className="relative w-40 h-56 border-4 border-slate-700 rounded-2xl overflow-hidden bg-slate-900/80 shadow-[inset_0_0_30px_rgba(0,0,0,0.8)] z-10">
                      {/* Fill */}
                      <div
                        className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-blue-600/80 to-cyan-400/60 shadow-[0_0_40px_rgba(34,211,238,0.6)] transition-all duration-1000 ease-out flex flex-col justify-start"
                        style={{ height: `${hydration}%` }}
                      >
                        <div className="w-full h-2 bg-cyan-300/80 animate-pulse" />
                        {/* Bubbles */}
                        <div className="absolute bottom-4 left-6 w-2 h-2 rounded-full bg-cyan-200/60 animate-bounce" />
                        <div className="absolute bottom-8 right-8 w-3 h-3 rounded-full bg-cyan-200/60 animate-bounce delay-100" />
                        <div className="absolute bottom-12 left-10 w-1.5 h-1.5 rounded-full bg-cyan-200/60 animate-bounce delay-300" />
                      </div>

                      {/* Volume markers */}
                      <div className="absolute top-0 bottom-0 left-2 flex flex-col justify-between py-6 opacity-40">
                        <div className="w-4 h-[2px] bg-slate-300" />
                        <div className="w-4 h-[2px] bg-slate-300" />
                        <div className="w-4 h-[2px] bg-slate-300" />
                        <div className="w-4 h-[2px] bg-slate-300" />
                      </div>

                      {/* Overlay Texture */}
                      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI0IiBoZWlnaHQ9IjQiPgo8cmVjdCB3aWR0aD0iNCIgaGVpZ2h0PSI0IiBmaWxsPSIjZmZmIiBmaWxsLW9wYWNpdHk9IjAuMDUiLz4KPC9zdmc+')] opacity-20 pointer-events-none mix-blend-overlay" />
                    </div>
                  </div>

                  <div className="text-center space-y-4 w-full">
                    <div className="flex items-end justify-center gap-1">
                      <span className="text-5xl font-black text-blue-400 drop-shadow-[0_0_15px_rgba(59,130,246,0.5)]">
                        {hydration}
                      </span>
                      <span className="text-xl text-blue-400/60 mb-1">%</span>
                    </div>

                    <Button
                      className="w-full max-w-[200px] h-12 gap-2 bg-blue-500/20 text-blue-400 hover:bg-blue-500/30 border border-blue-500/50 shadow-[0_0_20px_rgba(59,130,246,0.2)] rounded-2xl"
                      onClick={handleHydrate}
                    >
                      <Droplets className="w-5 h-5" />
                      Log 250ml
                    </Button>
                  </div>
                </>
              )}
            </div>
          </DialogContent>
        </Dialog>

        {/* Active Recovery Game Dialog */}
        <Dialog open={isRecoveryGameOpen} onOpenChange={setIsRecoveryGameOpen}>
          <DialogContent className="sm:max-w-md bg-[#0a0a0a] border-emerald-500/30 text-foreground overflow-hidden">
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-emerald-900/20 via-transparent to-transparent pointer-events-none" />
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2 text-emerald-400 uppercase tracking-widest text-xs">
                <Gamepad2 className="w-4 h-4" /> Active Recovery Protocol
              </DialogTitle>
            </DialogHeader>
            <ActiveRecoveryGame
              onComplete={(reduction) => {
                setCnsLoad((prev) => Math.max(0, prev - reduction));
              }}
              onClose={() => setIsRecoveryGameOpen(false)}
            />
          </DialogContent>
        </Dialog>
      </main>
    </div>
  );
}
