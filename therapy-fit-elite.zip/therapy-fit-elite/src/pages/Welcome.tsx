import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Activity,
  Zap,
  BrainCircuit,
  HeartPulse,
  Shield,
  ChevronRight,
  ArrowRight,
  Star,
  TrendingUp,
  Users,
  Award,
  Crosshair,
  Hexagon,
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Logo } from "@/components/Logo";
import { motion, AnimatePresence } from "framer-motion";
import NeuralBackground from "@/components/NeuralBackground";
import { PreOnboardingFlow } from "@/components/PreOnboardingFlow";
import { HeroMascot } from "@/components/HeroMascot";
import {
  cn,
  hapticFeedback,
  playNodeTapSound,
  playSuccessChime,
  playVoiceover,
} from "@/lib/utils";

// Floating particle system
const FloatingParticles = () => {
  const particles = Array.from({ length: 30 }, (_, i) => ({
    id: i,
    x: Math.random() * 100,
    y: Math.random() * 100,
    size: Math.random() * 3 + 1,
    duration: Math.random() * 8 + 4,
    delay: Math.random() * 4,
    opacity: Math.random() * 0.5 + 0.1,
  }));

  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
      {particles.map((p) => (
        <motion.div
          key={p.id}
          className="absolute rounded-full"
          style={{
            left: `${p.x}%`,
            top: `${p.y}%`,
            width: p.size,
            height: p.size,
            background:
              p.id % 3 === 0
                ? "rgba(0,255,255,0.8)"
                : p.id % 3 === 1
                  ? "rgba(100,200,255,0.6)"
                  : "rgba(0,180,180,0.5)",
            boxShadow: `0 0 ${p.size * 3}px ${p.size}px ${p.id % 3 === 0 ? "rgba(0,255,255,0.4)" : "rgba(100,200,255,0.3)"}`,
          }}
          animate={{
            y: [0, -40, 0],
            x: [0, Math.sin(p.id) * 20, 0],
            opacity: [p.opacity, p.opacity * 1.5, p.opacity],
            scale: [1, 1.3, 1],
          }}
          transition={{
            duration: p.duration,
            delay: p.delay,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
      ))}
    </div>
  );
};

// Animated stat counter
const AnimatedStat = ({
  value,
  label,
  suffix = "",
  icon: Icon,
  color,
}: any) => {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const [started, setStarted] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting && !started) {
        setStarted(true);
        let start = 0;
        const end = parseInt(value);
        const step = Math.ceil(end / 60);
        const timer = setInterval(() => {
          start += step;
          if (start >= end) {
            setCount(end);
            clearInterval(timer);
          } else setCount(start);
        }, 20);
      }
    });
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [value, started]);

  return (
    <motion.div
      ref={ref}
      className="flex flex-col items-center gap-2 group"
      whileHover={{ scale: 1.05 }}
    >
      <div
        className="w-12 h-12 rounded-full border flex items-center justify-center mb-1 transition-all duration-300 group-hover:scale-110"
        style={{
          borderColor: color,
          background: `${color}15`,
          boxShadow: `0 0 20px ${color}30`,
        }}
      >
        <Icon className="w-5 h-5" style={{ color }} />
      </div>
      <div
        className="text-3xl font-black font-mono"
        style={{ color, textShadow: `0 0 20px ${color}` }}
      >
        {started ? count : 0}
        {suffix}
      </div>
      <div className="text-xs text-muted-foreground uppercase tracking-widest font-bold text-center">
        {label}
      </div>
    </motion.div>
  );
};

// Feature card with hover glow
const FeatureCard = ({ icon: Icon, title, description, color, delay }: any) => (
  <motion.div
    initial={{ opacity: 0, y: 30 }}
    whileInView={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5, delay }}
    viewport={{ once: true }}
    whileHover={{ scale: 1.03, y: -4 }}
    className="relative p-6 rounded-2xl border border-white/5 bg-[#0a0a0a]/80 backdrop-blur-sm overflow-hidden group cursor-pointer"
    style={{ boxShadow: `0 0 0 1px ${color}10` }}
  >
    <div
      className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"
      style={{
        background: `radial-gradient(circle at top left, ${color}20 0%, transparent 60%)`,
      }}
    />
    <div
      className="w-12 h-12 rounded-xl flex items-center justify-center mb-4 border transition-all duration-300 group-hover:scale-110"
      style={{
        borderColor: `${color}40`,
        background: `${color}15`,
        boxShadow: `0 0 20px ${color}20`,
      }}
    >
      <Icon className="w-5 h-5" style={{ color }} />
    </div>
    <h3 className="font-bold text-foreground mb-2 text-sm uppercase tracking-widest">
      {title}
    </h3>
    <p className="text-muted-foreground text-sm leading-relaxed">
      {description}
    </p>
    <div
      className="absolute bottom-0 left-0 right-0 h-px opacity-0 group-hover:opacity-100 transition-opacity duration-500"
      style={{
        background: `linear-gradient(90deg, transparent, ${color}, transparent)`,
      }}
    />
  </motion.div>
);

// Testimonial card
const TestimonialCard = ({ name, role, quote, rating, delay }: any) => (
  <motion.div
    initial={{ opacity: 0, x: -20 }}
    whileInView={{ opacity: 1, x: 0 }}
    transition={{ duration: 0.5, delay }}
    viewport={{ once: true }}
    className="p-6 rounded-2xl border border-white/5 bg-[#0a0a0a]/80 backdrop-blur-sm relative overflow-hidden"
  >
    <div
      className="absolute top-0 right-0 w-24 h-24 rounded-full blur-2xl opacity-20"
      style={{
        background: "rgba(0,255,255,0.3)",
        transform: "translate(40%, -40%)",
      }}
    />
    <div className="flex gap-1 mb-3">
      {Array.from({ length: rating }).map((_, i) => (
        <Star key={i} className="w-3.5 h-3.5 fill-yellow-400 text-yellow-400" />
      ))}
    </div>
    <p className="text-sm text-foreground/90 leading-relaxed mb-4 italic">
      "{quote}"
    </p>
    <div>
      <div className="text-sm font-bold text-foreground">{name}</div>
      <div className="text-xs text-muted-foreground uppercase tracking-widest">
        {role}
      </div>
    </div>
  </motion.div>
);

export default function Welcome() {
  const navigate = useNavigate();
  const [typedTitle1, setTypedTitle1] = useState("");
  const [typedTitle2, setTypedTitle2] = useState("");
  const [showSubtitle, setShowSubtitle] = useState(false);
  const [showCta, setShowCta] = useState(false);
  const [activeSection, setActiveSection] = useState("hero");
  const [onboardingStep, setOnboardingStep] = useState<number | null>(null);
  const [showPreOnboarding, setShowPreOnboarding] = useState(false);
  const [nodesClicked, setNodesClicked] = useState<number[]>([]);
  const [tapProgress, setTapProgress] = useState(0);
  const [sliderValue, setSliderValue] = useState(0);
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (onboardingStep === 1) {
      setNodesClicked([]);
      playVoiceover(
        "Welcome to Therapy Fit Elite. Please calibrate your neural baseline by tapping the floating nodes.",
      );
    }
    if (onboardingStep === 2) {
      setTapProgress(0);
      playVoiceover(
        "Calibration complete. Now, tap rapidly to simulate high-intensity load and amplify your neural drive.",
      );
    }
    if (onboardingStep === 3) {
      setSliderValue(0);
      playVoiceover(
        "System stabilized. Drag the slider to lock in your sovereign command sequence and enter the hub.",
      );
    }
  }, [onboardingStep]);

  const fullTitle1 = "Neural Calibration";
  const fullTitle2 = "For The Elite.";

  // Typing animation
  useEffect(() => {
    let timeout: NodeJS.Timeout;
    if (typedTitle1.length < fullTitle1.length) {
      timeout = setTimeout(
        () => setTypedTitle1(fullTitle1.slice(0, typedTitle1.length + 1)),
        55,
      );
    } else if (typedTitle2.length < fullTitle2.length) {
      timeout = setTimeout(
        () => setTypedTitle2(fullTitle2.slice(0, typedTitle2.length + 1)),
        65,
      );
    } else {
      setTimeout(() => setShowSubtitle(true), 200);
      setTimeout(() => setShowCta(true), 600);
    }
    return () => clearTimeout(timeout);
  }, [typedTitle1, typedTitle2]);

  // Intersection observer for nav highlight
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) setActiveSection(entry.target.id);
        });
      },
      { threshold: 0.3 },
    );
    ["hero", "stats", "features", "testimonials", "cta-section"].forEach(
      (id) => {
        const el = document.getElementById(id);
        if (el) observer.observe(el);
      },
    );
    return () => observer.disconnect();
  }, []);

  const completeOnboarding = (targetPath: string) => {
    hapticFeedback([50, 100, 50]);
    playSuccessChime();
    try {
      localStorage.setItem("tf_onboarded", "true");
    } catch (e) {}
    window.dispatchEvent(new Event("tf_onboarding_complete"));
    navigate(targetPath || "/");
  };

  const navLinks = [
    { id: "stats", label: "Results" },
    { id: "features", label: "Features" },
    { id: "testimonials", label: "Operators" },
  ];

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  const features = [
    {
      icon: BrainCircuit,
      title: "CNS Load Monitoring",
      description:
        "Real-time central nervous system load tracking with predictive burnout detection before it happens.",
      color: "rgba(0,255,255,1)",
    },
    {
      icon: HeartPulse,
      title: "HRV Biofeedback",
      description:
        "Heart rate variability analysis synced to your breathing protocols for instant parasympathetic activation.",
      color: "rgba(168,85,247,1)",
    },
    {
      icon: Shield,
      title: "Neural Missions",
      description:
        "Gamified tactical missions that push your cognitive limits while monitoring recovery capacity in real time.",
      color: "rgba(239,68,68,1)",
    },
    {
      icon: Activity,
      title: "Somatic Mapping",
      description:
        "Interactive 3D body stress maps with targeted audio release protocols for specific muscle groups.",
      color: "rgba(59,130,246,1)",
    },
    {
      icon: Zap,
      title: "Flow State Engine",
      description:
        "AI-driven protocol sequencing that builds you into peak flow state within 90 seconds.",
      color: "rgba(250,204,21,1)",
    },
    {
      icon: TrendingUp,
      title: "Streak Multiplier",
      description:
        "Consecutive daily protocol completion unlocks XP multipliers and elite tier progression rewards.",
      color: "rgba(16,185,129,1)",
    },
  ];

  const testimonials = [
    {
      name: "Marcus R.",
      role: "Special Forces Operator",
      quote:
        "My CNS recovery time dropped by 40% in 3 weeks. I'm performing at a level I thought was behind me.",
      rating: 5,
    },
    {
      name: "Dr. Elaine K.",
      role: "Neurosurgeon",
      quote:
        "The HRV sync during breathing sessions is the most precise biofeedback tool I've used outside a clinical setting.",
      rating: 5,
    },
    {
      name: "Jordan T.",
      role: "Professional Athlete",
      quote:
        "I've tried everything. This is the first app that actually reads my body and tells me when NOT to push. Game changer.",
      rating: 5,
    },
  ];

  return (
    <div className="min-h-[100dvh] bg-[#050505] text-foreground flex flex-col relative overflow-x-hidden">
      {/* Animated Background */}
      <div className="fixed inset-0 z-0 light-rays">
        <div
          className="absolute inset-0"
          style={{
            background:
              "radial-gradient(ellipse 80% 60% at 50% -10%, rgba(0,255,255,0.12) 0%, transparent 70%)",
          }}
        />
        <div
          className="absolute inset-0"
          style={{
            background:
              "radial-gradient(ellipse 60% 40% at 80% 80%, rgba(168,85,247,0.06) 0%, transparent 60%)",
          }}
        />
        <div
          className="absolute inset-0"
          style={{
            background:
              "radial-gradient(ellipse 40% 30% at 20% 50%, rgba(250,204,21,0.04) 0%, transparent 60%)",
          }}
        />
        <NeuralBackground />
        <FloatingParticles />
      </div>

      {/* Sticky Nav */}
      <header className="fixed top-0 left-0 right-0 z-50 px-4 md:px-8 py-3 pt-[calc(0.75rem_+_env(safe-area-inset-top,_0px))] flex items-center justify-between border-b border-white/5 bg-[#050505]/70 backdrop-blur-xl">
        <Logo />
        <nav className="hidden md:flex items-center gap-6">
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => scrollTo(link.id)}
              className={`text-xs font-bold uppercase tracking-widest transition-all duration-300 ${
                activeSection === link.id
                  ? "text-primary drop-shadow-[0_0_8px_rgba(0,255,255,0.6)]"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {link.label}
            </button>
          ))}
        </nav>
        <div className="flex items-center gap-3">
          <Button
            size="sm"
            variant="ghost"
            className="text-muted-foreground hover:text-foreground text-xs hidden sm:flex border border-white/10 hover:bg-white/5"
            onClick={() => completeOnboarding("/")}
          >
            Member Login
          </Button>
          <Button
            size="sm"
            className="text-xs font-bold uppercase tracking-widest bg-primary/90 hover:bg-primary text-primary-foreground shadow-[0_0_20px_rgba(0,255,255,0.3)] hover:shadow-[0_0_30px_rgba(0,255,255,0.5)]"
            onClick={() => {
              hapticFeedback(20);
              playNodeTapSound(440);
              setShowPreOnboarding(true);
            }}
          >
            Start Free <ArrowRight className="w-3 h-3 ml-1" />
          </Button>
        </div>
      </header>

      {/* HERO */}
      <section
        id="hero"
        ref={heroRef}
        className="relative z-10 min-h-[100dvh] flex flex-col items-center justify-center px-4 text-center pt-24 pb-12 overflow-hidden"
      >
        {/* Ambient AI Mascot */}
        <HeroMascot />

        {/* Main heading with typewriter */}
        <h1 className="text-5xl md:text-8xl font-black tracking-tighter uppercase leading-[0.85] mb-6 max-w-4xl">
          <span className="block text-foreground min-h-[1.1em] high-res-glow">
            {typedTitle1}
            {typedTitle1.length < fullTitle1.length && (
              <span className="inline-block w-[0.08em] h-[0.8em] bg-primary ml-1 animate-pulse align-baseline" />
            )}
          </span>
          <span
            className="block min-h-[1.1em]"
            style={{
              background:
                "linear-gradient(135deg, rgba(0,255,255,1) 0%, rgba(100,200,255,1) 50%, rgba(168,85,247,1) 100%)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              backgroundClip: "text",
              filter: "drop-shadow(0 0 30px rgba(0,255,255,0.3))",
            }}
          >
            {typedTitle2}
            {typedTitle1.length === fullTitle1.length &&
              typedTitle2.length < fullTitle2.length && (
                <span
                  className="inline-block w-[0.08em] h-[0.8em] bg-primary ml-1 animate-pulse align-baseline"
                  style={{ WebkitTextFillColor: "rgba(0,255,255,1)" }}
                />
              )}
          </span>
        </h1>

        {/* Subtitle */}
        <AnimatePresence>
          {showSubtitle && (
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-sm md:text-lg text-muted-foreground mb-10 max-w-xl leading-relaxed tracking-wide"
            >
              Stop managing symptoms. Start mastering your biology. Integrate
              advanced ANS analytics to sustain{" "}
              <span className="text-primary font-semibold">
                peak cognitive flow
              </span>
              .
            </motion.p>
          )}
        </AnimatePresence>

        {/* CTA Buttons */}
        <AnimatePresence>
          {showCta && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, type: "spring" }}
              className="flex flex-col sm:flex-row items-center gap-4 w-full justify-center mb-12"
            >
              <Button
                className="h-14 px-10 rounded-2xl bg-primary/90 hover:bg-primary text-primary-foreground font-black tracking-widest uppercase text-sm shadow-[0_0_40px_rgba(0,255,255,0.3)] hover:shadow-[0_0_60px_rgba(0,255,255,0.5)] transition-all duration-500 group relative overflow-hidden"
                onClick={() => {
                  hapticFeedback(20);
                  setShowPreOnboarding(true);
                }}
              >
                <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-500 ease-out" />
                <Activity className="w-5 h-5 mr-2 animate-pulse relative z-10" />
                <span className="relative z-10">Start Neural Audit</span>
              </Button>
              <Button
                variant="outline"
                className="h-14 px-10 rounded-2xl border-white/10 text-foreground hover:bg-white/5 font-black tracking-widest uppercase text-sm transition-all duration-500 glass-panel"
                onClick={() => completeOnboarding("/calibration")}
              >
                Voice Calibration
              </Button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Social proof strip */}
        <AnimatePresence>
          {showCta && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="flex flex-wrap justify-center items-center gap-x-6 gap-y-3 text-[10px] uppercase tracking-widest text-muted-foreground font-semibold"
            >
              <div className="flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5 text-primary" />
                No subscription required
              </div>
              <div className="flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-yellow-400" />
                Setup in 60s
              </div>
              <div className="flex items-center gap-1.5">
                <Award className="w-3.5 h-3.5 text-purple-400" />
                4,200+ Operators
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Scroll indicator */}
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ repeat: Infinity, duration: 2 }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1 cursor-pointer text-muted-foreground hover:text-primary transition-colors"
          onClick={() => scrollTo("stats")}
        >
          <span className="text-[9px] uppercase tracking-widest font-bold">
            Scroll to explore
          </span>
          <ChevronRight className="w-4 h-4 rotate-90" />
        </motion.div>
      </section>

      {/* STATS SECTION */}
      <section
        id="stats"
        className="relative z-10 py-24 px-4 border-t border-white/5"
      >
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <Badge
              variant="outline"
              className="bg-primary/5 text-primary border-primary/20 px-3 py-1 mb-4 uppercase tracking-widest text-[10px]"
            >
              Proven Results
            </Badge>
            <h2 className="text-3xl md:text-5xl font-black uppercase tracking-tighter text-foreground">
              Numbers That{" "}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-purple-400">
                Don't Lie
              </span>
            </h2>
          </motion.div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <AnimatedStat
              value="40"
              suffix="%"
              label="Faster CNS Recovery"
              icon={BrainCircuit}
              color="rgba(0,255,255,1)"
            />
            <AnimatedStat
              value="4200"
              suffix="+"
              label="Elite Operators"
              icon={Users}
              color="rgba(168,85,247,1)"
            />
            <AnimatedStat
              value="92"
              suffix="%"
              label="Report Improved HRV"
              icon={HeartPulse}
              color="rgba(59,130,246,1)"
            />
            <AnimatedStat
              value="14"
              suffix="d"
              label="Avg Streak Length"
              icon={TrendingUp}
              color="rgba(250,204,21,1)"
            />
          </div>

          {/* Visual divider glow */}
          <div
            className="mt-20 h-px w-full"
            style={{
              background:
                "linear-gradient(90deg, transparent, rgba(0,255,255,0.3), transparent)",
            }}
          />
        </div>
      </section>

      {/* FEATURES SECTION */}
      <section id="features" className="relative z-10 py-24 px-4">
        <div className="max-w-5xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <Badge
              variant="outline"
              className="bg-primary/5 text-primary border-primary/20 px-3 py-1 mb-4 uppercase tracking-widest text-[10px]"
            >
              Core Protocols
            </Badge>
            <h2 className="text-3xl md:text-5xl font-black uppercase tracking-tighter text-foreground mb-4">
              Built for Operators.{" "}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-blue-400">
                Engineered for Edge.
              </span>
            </h2>
            <p className="text-muted-foreground max-w-xl mx-auto text-sm leading-relaxed">
              Every protocol inside TherapyFIT Elite is designed around one
              principle: optimise your nervous system or get left behind.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {features.map((f, i) => (
              <FeatureCard key={f.title} {...f} delay={i * 0.08} />
            ))}
          </div>
        </div>
      </section>

      {/* INTERACTIVE DEMO TEASER */}
      <section className="relative z-10 py-24 px-4 border-y border-white/5">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="relative rounded-3xl overflow-hidden border border-primary/20 bg-[#0a0a0a]/80 p-8 md:p-16"
            style={{
              boxShadow:
                "0 0 60px rgba(0,255,255,0.1), inset 0 0 60px rgba(0,0,0,0.5)",
            }}
          >
            {/* Glow corners */}
            <div
              className="absolute top-0 left-0 w-32 h-32 rounded-full blur-3xl opacity-30"
              style={{
                background: "rgba(0,255,255,0.4)",
                transform: "translate(-50%,-50%)",
              }}
            />
            <div
              className="absolute bottom-0 right-0 w-32 h-32 rounded-full blur-3xl opacity-30"
              style={{
                background: "rgba(168,85,247,0.4)",
                transform: "translate(50%,50%)",
              }}
            />

            <Badge
              variant="outline"
              className="bg-primary/10 text-primary border-primary/30 mb-6 uppercase tracking-widest text-[10px] px-3 py-1"
            >
              Live System
            </Badge>
            <h2 className="text-3xl md:text-5xl font-black uppercase tracking-tighter mb-4 text-foreground">
              Your Body Is Talking. <br />
              <span
                className="text-primary"
                style={{ textShadow: "0 0 30px rgba(0,255,255,0.5)" }}
              >
                Are You Listening?
              </span>
            </h2>
            <p className="text-muted-foreground max-w-lg mx-auto mb-8 text-sm leading-relaxed">
              Start your Neural Audit and get a full CNS readiness report in
              under 3 minutes. No wearables required. No guesswork. Just precise
              biometric intelligence.
            </p>

            {/* Fake live readout */}
            <div className="flex flex-wrap items-center justify-center gap-4 mb-10">
              {[
                { label: "HRV", value: "68ms", color: "rgba(0,255,255,1)" },
                {
                  label: "CNS Load",
                  value: "45%",
                  color: "rgba(249,115,22,1)",
                },
                {
                  label: "Readiness",
                  value: "82%",
                  color: "rgba(16,185,129,1)",
                },
              ].map((item) => (
                <motion.div
                  key={item.label}
                  animate={{ opacity: [1, 0.6, 1] }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    delay: Math.random(),
                  }}
                  className="flex items-center gap-2 px-4 py-2 rounded-full border border-white/10 bg-black/40"
                >
                  <span className="text-[10px] text-muted-foreground uppercase tracking-widest">
                    {item.label}
                  </span>
                  <span
                    className="text-sm font-black font-mono"
                    style={{
                      color: item.color,
                      textShadow: `0 0 10px ${item.color}`,
                    }}
                  >
                    {item.value}
                  </span>
                </motion.div>
              ))}
            </div>

            <motion.div whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.96 }}>
              <Button
                className="h-14 px-12 bg-primary text-primary-foreground font-black uppercase tracking-widest text-sm shadow-[0_0_40px_rgba(0,255,255,0.4)] hover:shadow-[0_0_60px_rgba(0,255,255,0.6)] transition-all duration-300"
                onClick={() => {
                  hapticFeedback(20);
                  setShowPreOnboarding(true);
                }}
              >
                <Activity className="w-5 h-5 mr-2 animate-pulse" />
                Begin Neural Audit — Free
              </Button>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section id="testimonials" className="relative z-10 py-24 px-4">
        <div className="max-w-5xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <Badge
              variant="outline"
              className="bg-primary/5 text-primary border-primary/20 px-3 py-1 mb-4 uppercase tracking-widest text-[10px]"
            >
              Operator Intel
            </Badge>
            <h2 className="text-3xl md:text-5xl font-black uppercase tracking-tighter text-foreground">
              From The{" "}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-purple-400">
                Field
              </span>
            </h2>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {testimonials.map((t, i) => (
              <TestimonialCard key={t.name} {...t} delay={i * 0.12} />
            ))}
          </div>
        </div>
      </section>

      {/* FINAL CTA */}
      <section
        id="cta-section"
        className="relative z-10 py-24 px-4 border-t border-white/5"
      >
        <div className="max-w-3xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-6xl font-black uppercase tracking-tighter mb-6 text-foreground">
              Your Edge{" "}
              <span
                className="text-primary"
                style={{ textShadow: "0 0 30px rgba(0,255,255,0.4)" }}
              >
                Awaits.
              </span>
            </h2>
            <p className="text-muted-foreground mb-10 text-sm leading-relaxed max-w-xl mx-auto">
              Join 4,200+ operators who've stopped guessing and started
              performing. Your first Neural Audit is free.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <motion.div
                whileHover={{ scale: 1.04 }}
                whileTap={{ scale: 0.96 }}
              >
                <Button
                  className="h-14 px-12 bg-primary text-primary-foreground font-black uppercase tracking-widest shadow-[0_0_40px_rgba(0,255,255,0.4)] hover:shadow-[0_0_60px_rgba(0,255,255,0.6)] transition-all"
                  onClick={() => {
                    hapticFeedback(20);
                    setShowPreOnboarding(true);
                  }}
                >
                  <Zap className="w-5 h-5 mr-2" />
                  Start For Free
                </Button>
              </motion.div>
              <motion.div
                whileHover={{ scale: 1.04 }}
                whileTap={{ scale: 0.96 }}
              >
                <Button
                  variant="outline"
                  className="h-14 px-12 border-white/10 text-muted-foreground hover:text-foreground hover:bg-white/5 font-bold uppercase tracking-widest transition-all"
                  onClick={() => completeOnboarding("/")}
                >
                  Member Login
                </Button>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative z-10 py-6 px-4 border-t border-white/5 text-center">
        <p className="text-xs text-muted-foreground">
          © 2026 TherapyFIT Elite. All rights reserved. Built for operators who
          refuse average.
        </p>
      </footer>

      {/* Pre-Onboarding Flow (carousel → tour → privacy → tracking → auth) */}
      {showPreOnboarding && (
        <PreOnboardingFlow
          onComplete={() => {
            setShowPreOnboarding(false);
            setOnboardingStep(1);
          }}
        />
      )}

      {/* Onboarding Overlay */}
      {onboardingStep !== null && (
        <div className="fixed inset-0 z-[100] bg-[#050505] flex items-center justify-center p-6 text-center">
          {/* Animated Background */}
          <div className="absolute inset-0 z-0 opacity-50">
            <NeuralBackground />
            <FloatingParticles />
          </div>

          <div className="relative z-10 max-w-2xl w-full">
            <AnimatePresence mode="wait">
              {onboardingStep === 1 && (
                <motion.div
                  key="step1"
                  initial={{ opacity: 0, scale: 0.9, y: 20 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 1.1, y: -20 }}
                  transition={{ duration: 0.5 }}
                  className="space-y-6"
                >
                  <div className="w-20 h-20 mx-auto rounded-full bg-primary/20 flex items-center justify-center border border-primary/40 shadow-[0_0_50px_rgba(0,255,255,0.3)]">
                    <BrainCircuit className="w-10 h-10 text-primary" />
                  </div>
                  <div>
                    <h2 className="text-3xl font-black uppercase tracking-widest text-white mb-2">
                      Neural Calibration
                    </h2>
                    <p className="text-sm text-muted-foreground leading-relaxed max-w-md mx-auto">
                      Tap the floating nodes to calibrate your central nervous
                      system baseline.
                    </p>
                  </div>

                  <div className="relative h-40 w-full max-w-md mx-auto border border-primary/20 rounded-2xl overflow-hidden bg-black/40 shadow-[inset_0_0_30px_rgba(0,255,255,0.05)]">
                    {[0, 1, 2].map((i) => (
                      <motion.button
                        key={i}
                        className={`absolute w-12 h-12 rounded-full border-2 ${nodesClicked.includes(i) ? "bg-primary border-primary scale-90" : "bg-black/60 border-primary/50"} flex items-center justify-center transition-colors shadow-[0_0_20px_rgba(0,255,255,0.2)]`}
                        style={{
                          left: `${20 + i * 25}%`,
                          top: `${20 + (i % 2) * 40}%`,
                        }}
                        animate={{
                          y: [0, -15, 0],
                          x: [0, i % 2 === 0 ? 10 : -10, 0],
                        }}
                        transition={{
                          duration: 3 + i,
                          delay: i * 0.2,
                          repeat: Infinity,
                          ease: "easeInOut",
                        }}
                        onClick={() => {
                          if (!nodesClicked.includes(i)) {
                            hapticFeedback(15);
                            playNodeTapSound(600 + i * 200);
                            setNodesClicked((prev) => [...prev, i]);
                          }
                        }}
                      >
                        <Zap
                          className={`w-5 h-5 ${nodesClicked.includes(i) ? "text-primary-foreground" : "text-primary"}`}
                        />
                      </motion.button>
                    ))}
                    {nodesClicked.length === 3 && (
                      <div className="absolute inset-0 flex items-center justify-center bg-primary/10 backdrop-blur-sm">
                        <span className="text-primary font-bold tracking-widest uppercase animate-pulse">
                          Calibrated
                        </span>
                      </div>
                    )}
                  </div>

                  <Button
                    disabled={nodesClicked.length < 3}
                    className="h-14 px-12 rounded-2xl bg-primary hover:bg-primary/90 text-primary-foreground font-black tracking-widest uppercase text-sm shadow-[0_0_30px_rgba(0,255,255,0.4)] disabled:opacity-50"
                    onClick={() => {
                      playSuccessChime();
                      setOnboardingStep(2);
                    }}
                  >
                    {nodesClicked.length < 3
                      ? `Calibrate Nodes (${nodesClicked.length}/3)`
                      : "Continue"}
                    {nodesClicked.length === 3 && (
                      <ArrowRight className="w-4 h-4 ml-2" />
                    )}
                  </Button>
                </motion.div>
              )}
              {onboardingStep === 2 && (
                <motion.div
                  key="step2"
                  initial={{ opacity: 0, scale: 0.9, y: 20 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 1.1, y: -20 }}
                  transition={{ duration: 0.5 }}
                  className="space-y-6"
                >
                  <div className="w-20 h-20 mx-auto rounded-full bg-yellow-500/20 flex items-center justify-center border border-yellow-500/40 shadow-[0_0_50px_rgba(250,204,21,0.3)]">
                    <Activity className="w-10 h-10 text-yellow-400" />
                  </div>
                  <div>
                    <h2 className="text-3xl font-black uppercase tracking-widest text-white mb-2">
                      High-Intensity Load
                    </h2>
                    <p className="text-sm text-muted-foreground leading-relaxed max-w-md mx-auto">
                      Tap rapidly to amplify your neural drive and stabilize the
                      system.
                    </p>
                  </div>

                  <div className="w-full max-w-md mx-auto space-y-4">
                    <div className="h-6 bg-black/50 rounded-full overflow-hidden border border-yellow-500/30 relative shadow-[inset_0_0_20px_rgba(250,204,21,0.1)]">
                      <div className="absolute inset-0 bg-yellow-500/10" />
                      <div
                        className="h-full bg-yellow-500 transition-all duration-100 ease-out shadow-[0_0_20px_rgba(250,204,21,0.8)]"
                        style={{ width: `${tapProgress}%` }}
                      />
                      <div className="absolute inset-0 flex items-center justify-center text-[10px] font-bold uppercase tracking-widest mix-blend-difference text-white">
                        {tapProgress}% Stabilized
                      </div>
                    </div>
                  </div>

                  <Button
                    className="h-14 px-12 rounded-2xl bg-yellow-500 hover:bg-yellow-400 text-yellow-950 font-black tracking-widest uppercase text-sm shadow-[0_0_30px_rgba(250,204,21,0.4)] active:scale-95 transition-transform"
                    onClick={() => {
                      if (tapProgress < 100) {
                        hapticFeedback(20);
                        playNodeTapSound(300 + tapProgress * 6);
                        setTapProgress((prev) => Math.min(prev + 20, 100));
                      } else {
                        playSuccessChime();
                        setOnboardingStep(3);
                      }
                    }}
                  >
                    {tapProgress < 100 ? "Tap to Amplify" : "Continue"}
                    {tapProgress === 100 && (
                      <ArrowRight className="w-4 h-4 ml-2" />
                    )}
                  </Button>
                </motion.div>
              )}
              {onboardingStep === 3 && (
                <motion.div
                  key="step3"
                  initial={{ opacity: 0, scale: 0.9, y: 20 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 1.1, y: -20 }}
                  transition={{ duration: 0.5 }}
                  className="space-y-6"
                >
                  <div className="w-20 h-20 mx-auto rounded-full bg-purple-500/20 flex items-center justify-center border border-purple-500/40 shadow-[0_0_50px_rgba(168,85,247,0.3)]">
                    <Shield className="w-10 h-10 text-purple-400" />
                  </div>
                  <div>
                    <h2 className="text-3xl font-black uppercase tracking-widest text-white mb-2">
                      Sovereign Command
                    </h2>
                    <p className="text-sm text-muted-foreground leading-relaxed max-w-md mx-auto">
                      Drag the slider to lock in your neural sequence and enter
                      the Hub.
                    </p>
                  </div>

                  <div className="w-full max-w-md mx-auto px-4 py-8 relative">
                    <div className="absolute inset-0 bg-purple-500/5 rounded-2xl border border-purple-500/20" />
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={sliderValue}
                      onChange={(e) => {
                        const val = parseInt(e.target.value);
                        setSliderValue(val);
                        if (val % 10 === 0) {
                          hapticFeedback(5);
                          playNodeTapSound(200 + val * 4);
                        }
                      }}
                      className="w-full relative z-10 accent-purple-500 h-2 bg-black/50 rounded-full appearance-none [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-8 [&::-webkit-slider-thumb]:h-8 [&::-webkit-slider-thumb]:bg-purple-500 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:shadow-[0_0_20px_rgba(168,85,247,0.8)] [&::-webkit-slider-thumb]:cursor-pointer"
                    />
                    <div className="flex justify-between text-[10px] text-purple-400/60 uppercase tracking-widest mt-4 font-bold relative z-10">
                      <span>Unlocked</span>
                      <span>Locked</span>
                    </div>
                  </div>

                  <Button
                    disabled={sliderValue < 100}
                    className="h-14 px-12 rounded-2xl bg-purple-500 hover:bg-purple-400 text-white font-black tracking-widest uppercase text-sm shadow-[0_0_30px_rgba(168,85,247,0.4)] disabled:opacity-50"
                    onClick={() => {
                      playSuccessChime();
                      completeOnboarding("/audit");
                    }}
                  >
                    {sliderValue < 100
                      ? "Lock Sequence to 100%"
                      : "Enter The Hub"}
                    {sliderValue === 100 && (
                      <ArrowRight className="w-4 h-4 ml-2" />
                    )}
                  </Button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      )}
    </div>
  );
}
