import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function hapticFeedback(pattern: number | number[] = 10) {
  try {
    if (localStorage.getItem("tf_haptics_enabled") === "false") return;
  } catch (e) {}

  if (typeof window !== "undefined" && navigator.vibrate) {
    navigator.vibrate(pattern);
  }
}

export function playGlassSound() {
  try {
    if (localStorage.getItem("tf_sound_enabled") === "false") return;
    const AudioContext =
      window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContext) return;
    const ctx = new AudioContext();

    const osc = ctx.createOscillator();
    const gainNode = ctx.createGain();

    osc.type = "sine";
    osc.frequency.setValueAtTime(1200, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(300, ctx.currentTime + 0.4);

    gainNode.gain.setValueAtTime(0, ctx.currentTime);
    gainNode.gain.linearRampToValueAtTime(0.1, ctx.currentTime + 0.02);
    gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.4);

    osc.connect(gainNode);
    gainNode.connect(ctx.destination);

    osc.start();
    osc.stop(ctx.currentTime + 0.4);
  } catch (e) {
    // Ignore audio errors
  }
}

export function playNodeTapSound(pitch: number = 800) {
  try {
    if (localStorage.getItem("tf_sound_enabled") === "false") return;
    const AudioContext =
      window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContext) return;
    const ctx = new AudioContext();

    const osc = ctx.createOscillator();
    const gainNode = ctx.createGain();

    osc.type = "sine";
    osc.frequency.setValueAtTime(pitch, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(
      pitch * 1.5,
      ctx.currentTime + 0.15,
    );

    gainNode.gain.setValueAtTime(0, ctx.currentTime);
    gainNode.gain.linearRampToValueAtTime(0.2, ctx.currentTime + 0.01);
    gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.15);

    osc.connect(gainNode);
    gainNode.connect(ctx.destination);

    osc.start();
    osc.stop(ctx.currentTime + 0.15);
  } catch (e) {
    // Ignore audio errors
  }
}

export function playSuccessChime() {
  try {
    if (localStorage.getItem("tf_sound_enabled") === "false") return;
    const AudioContext =
      window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContext) return;
    const ctx = new AudioContext();

    const playNote = (freq: number, startTime: number, duration: number) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(freq, startTime);

      gain.gain.setValueAtTime(0, startTime);
      gain.gain.linearRampToValueAtTime(0.2, startTime + 0.05);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + duration);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(startTime);
      osc.stop(startTime + duration);
    };

    const now = ctx.currentTime;
    playNote(523.25, now, 0.3); // C5
    playNote(659.25, now + 0.1, 0.3); // E5
    playNote(783.99, now + 0.2, 0.5); // G5
  } catch (e) {
    // Ignore audio errors
  }
}

export function playVoiceover(text: string) {
  try {
    if (localStorage.getItem("tf_voice_enabled") === "false") return;
  } catch (e) {}

  if (typeof window !== "undefined" && "speechSynthesis" in window) {
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 0.95;
    utterance.pitch = 0.9;

    const setVoiceAndSpeak = () => {
      const voices = window.speechSynthesis.getVoices();
      const preferredVoices = voices.filter(
        (v) =>
          v.lang.startsWith("en-") &&
          (v.name.includes("Google UK English Female") ||
            v.name.includes("Samantha") ||
            v.name.includes("Karen") ||
            v.name.includes("Moira") ||
            v.name.includes("Daniel") ||
            v.name.includes("Arthur")),
      );

      if (preferredVoices.length > 0) {
        utterance.voice = preferredVoices[0];
      } else if (voices.length > 0) {
        const engVoice = voices.find((v) => v.lang.startsWith("en-"));
        if (engVoice) utterance.voice = engVoice;
      }

      window.speechSynthesis.speak(utterance);
    };

    if (window.speechSynthesis.getVoices().length === 0) {
      window.speechSynthesis.addEventListener(
        "voiceschanged",
        setVoiceAndSpeak,
        { once: true },
      );
    } else {
      setVoiceAndSpeak();
    }
  }
}

// ── Ambient soundscape engine ──
let ambientHumCtx: AudioContext | null = null;
let ambientHumNodes: {
  osc: OscillatorNode;
  gain: GainNode;
  lfo: OscillatorNode;
} | null = null;

export function startAmbientHum() {
  try {
    if (localStorage.getItem("tf_sound_enabled") === "false") return;
    if (ambientHumNodes) return; // already playing
    const AudioContext =
      window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContext) return;
    ambientHumCtx = new AudioContext();
    const ctx = ambientHumCtx;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    const lfo = ctx.createOscillator();
    const lfoGain = ctx.createGain();

    // Low drone
    osc.type = "sine";
    osc.frequency.setValueAtTime(55, ctx.currentTime); // A1

    // Slow shimmer via LFO modulating gain
    lfo.type = "sine";
    lfo.frequency.setValueAtTime(0.15, ctx.currentTime);
    lfoGain.gain.setValueAtTime(0.015, ctx.currentTime);

    gain.gain.setValueAtTime(0, ctx.currentTime);
    gain.gain.linearRampToValueAtTime(0.04, ctx.currentTime + 1.5); // fade in

    lfo.connect(lfoGain);
    lfoGain.connect(gain.gain);
    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start();
    lfo.start();

    ambientHumNodes = { osc, gain, lfo };
  } catch (e) {
    // ignore
  }
}

export function stopAmbientHum() {
  try {
    if (ambientHumNodes && ambientHumCtx) {
      const { osc, gain, lfo } = ambientHumNodes;
      const ctx = ambientHumCtx;
      gain.gain.cancelScheduledValues(ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.6); // fade out
      osc.stop(ctx.currentTime + 0.7);
      lfo.stop(ctx.currentTime + 0.7);
    }
  } catch (e) {}
  ambientHumNodes = null;
  ambientHumCtx = null;
}

export function playTourChime() {
  try {
    if (localStorage.getItem("tf_sound_enabled") === "false") return;
    const AudioContext =
      window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContext) return;
    const ctx = new AudioContext();

    const playNote = (freq: number, startTime: number, duration: number) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "triangle";
      osc.frequency.setValueAtTime(freq, startTime);
      gain.gain.setValueAtTime(0, startTime);
      gain.gain.linearRampToValueAtTime(0.12, startTime + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + duration);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(startTime);
      osc.stop(startTime + duration);
    };

    const now = ctx.currentTime;
    playNote(880, now, 0.5); // A5
    playNote(1318.51, now + 0.08, 0.6); // E6
  } catch (e) {
    // ignore
  }
}
