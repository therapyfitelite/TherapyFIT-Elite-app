/**
 * Consent-aware storage helpers.
 *
 * A global guard intercepts `localStorage.setItem` so the granular
 * data-collection toggles in Settings actually enforce data minimization
 * across the entire app. If a user has opted out of a category, biometric
 * values for that category are never persisted.
 */

const NATIVE_SET = Storage.prototype.setItem.bind(localStorage);

export type DataCategory = "hrv" | "cns" | "hydration" | "sleep" | "waypoints";

const TOGGLE_KEY: Record<DataCategory, string> = {
  hrv: "tf_collect_hrv",
  cns: "tf_collect_cns",
  hydration: "tf_collect_hydration",
  sleep: "tf_collect_sleep",
  waypoints: "tf_collect_waypoints",
};

/** Map a storage key to the data category it belongs to. */
const KEY_CATEGORY: Record<string, DataCategory> = {
  tf_hrv_score: "hrv",
  tf_hrv_target: "hrv",
  tf_hrv_streak: "hrv",
  tf_cns_load: "cns",
  tf_cns_target: "cns",
  tf_cns_streak: "cns",
  tf_hydration: "hydration",
  tf_hyd_target: "hydration",
  tf_hyd_streak: "hydration",
  tf_hydration_alerts: "hydration",
  tf_sleep_target: "sleep",
  tf_sleep_streak: "sleep",
  tf_waypoints: "waypoints",
};

/** Returns true if the user has consented to collecting this category. */
export function canCollect(category: DataCategory): boolean {
  try {
    return localStorage.getItem(TOGGLE_KEY[category]) !== "false";
  } catch {
    return true; // default to allowed if storage is unavailable
  }
}

/** Returns true if a given storage key is permitted by the user's toggles. */
export function isCollectionAllowed(storageKey: string): boolean {
  const category = KEY_CATEGORY[storageKey];
  if (!category) return true; // non-biometric keys are always allowed
  return canCollect(category);
}

/**
 * Write a biometric value only if the user has consented to that category.
 * Returns true if the value was stored.
 */
export function setBiometric(key: string, value: string): boolean {
  if (!isCollectionAllowed(key)) return false;
  try {
    localStorage.setItem(key, value);
    return true;
  } catch {
    return false;
  }
}

/** Read a biometric value, respecting consent (returns null if opted out). */
export function getBiometric(key: string): string | null {
  if (!isCollectionAllowed(key)) return null;
  try {
    return localStorage.getItem(key);
  } catch {
    return null;
  }
}

/**
 * Install a global guard over `localStorage.setItem`. Any write to a
 * biometric key whose category the user has opted out of is silently
 * dropped. Non-biometric keys always pass through. Idempotent.
 */
export function installConsentGuard() {
  if (typeof window === "undefined" || typeof localStorage === "undefined")
    return;
  if ((localStorage as any).__consentGuardInstalled) return;
  (localStorage as any).__consentGuardInstalled = true;

  (localStorage as any).setItem = function (key: string, value: string) {
    if (typeof key === "string" && !isCollectionAllowed(key)) {
      return; // user opted out — drop the write silently
    }
    return NATIVE_SET(key, String(value));
  } as typeof localStorage.setItem;
}
