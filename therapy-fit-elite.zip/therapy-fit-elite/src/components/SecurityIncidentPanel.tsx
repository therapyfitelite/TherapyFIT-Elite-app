import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  ShieldCheck,
  ScrollText,
  AlertOctagon,
  Trash2,
  Download,
  RefreshCw,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { getErrorLog, clearErrorLog } from "@/components/ErrorBoundary";

interface ErrorLogEntry {
  message: string;
  stack?: string;
  componentStack?: string;
  incidentId: string;
  timestamp: string;
  route?: string;
}

const OBLIGATIONS = [
  {
    title: "Lawful Basis & Consent",
    body: "Biometric data is processed only after explicit, granular consent. Users can withdraw any category at any time via the toggles above.",
  },
  {
    title: "Data Minimization",
    body: "Only HRV, CNS load, hydration, sleep, streaks, and waypoints are stored — locally on-device. No data is sold or used for advertising.",
  },
  {
    title: "Breach Notification Plan",
    body: "If a security incident is detected, affected users will be notified within 72 hours with the scope, impact, and remediation steps.",
  },
  {
    title: "Right to Erasure",
    body: "Users can permanently delete all stored data instantly. The deletion flow above wipes every app-owned key from this device.",
  },
];

export function SecurityIncidentPanel() {
  const { toast } = useToast();
  const [log, setLog] = useState<ErrorLogEntry[]>([]);
  const [open, setOpen] = useState(false);

  const refresh = () => setLog(getErrorLog());

  useEffect(() => {
    refresh();
  }, []);

  const handleClear = () => {
    clearErrorLog();
    refresh();
    toast({
      title: "Error Log Cleared",
      description: "All captured incident records have been removed.",
    });
  };

  const handleExport = () => {
    try {
      const blob = new Blob([JSON.stringify(log, null, 2)], {
        type: "application/json",
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `therapyfit-error-log-${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
      toast({
        title: "Log Exported",
        description: "Incident log downloaded as JSON.",
      });
    } catch (e) {
      toast({
        variant: "destructive",
        title: "Export Failed",
        description: "Could not generate the log file.",
      });
    }
  };

  return (
    <Card className="bg-card/40 border-border/50 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <ShieldCheck className="h-5 w-5 text-primary" />
          Security &amp; Incident Response
        </CardTitle>
        <CardDescription>
          Legal obligations, breach plan, and live error monitoring.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-5">
        {/* Legal obligations */}
        <div className="space-y-3">
          <div className="flex items-center gap-2 text-xs uppercase tracking-widest font-bold text-muted-foreground">
            <ScrollText className="w-3.5 h-3.5" />
            Compliance Obligations
          </div>
          {OBLIGATIONS.map((o) => (
            <div
              key={o.title}
              className="rounded-xl border border-border/40 bg-muted/20 p-3"
            >
              <div className="text-sm font-semibold text-foreground mb-0.5">
                {o.title}
              </div>
              <p className="text-xs text-muted-foreground leading-relaxed">
                {o.body}
              </p>
            </div>
          ))}
        </div>

        {/* Error monitor */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs uppercase tracking-widest font-bold text-muted-foreground">
              <AlertOctagon className="w-3.5 h-3.5" />
              Error Monitor
            </div>
            <div className="flex items-center gap-2">
              <Button
                size="sm"
                variant="ghost"
                className="h-7 px-2 text-xs"
                onClick={refresh}
              >
                <RefreshCw className="w-3 h-3 mr-1" />
                Refresh
              </Button>
              <Button
                size="sm"
                variant="ghost"
                className="h-7 px-2 text-xs"
                onClick={handleExport}
                disabled={log.length === 0}
              >
                <Download className="w-3 h-3 mr-1" />
                Export
              </Button>
              <Button
                size="sm"
                variant="ghost"
                className="h-7 px-2 text-xs text-destructive hover:text-destructive"
                onClick={handleClear}
                disabled={log.length === 0}
              >
                <Trash2 className="w-3 h-3 mr-1" />
                Clear
              </Button>
            </div>
          </div>

          <div className="rounded-xl border border-border/40 bg-black/30 p-3">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-semibold">
                {log.length} incident{log.length === 1 ? "" : "s"} captured
              </span>
              <span
                className={`text-[10px] uppercase tracking-widest font-bold px-2 py-0.5 rounded-full ${
                  log.length === 0
                    ? "bg-emerald-500/15 text-emerald-400"
                    : "bg-amber-500/15 text-amber-400"
                }`}
              >
                {log.length === 0 ? "All Clear" : "Review Needed"}
              </span>
            </div>

            {log.length > 0 && (
              <button
                onClick={() => setOpen((v) => !v)}
                className="text-xs text-primary hover:text-primary/80 underline"
              >
                {open ? "Hide" : "View"} incident log
              </button>
            )}

            {open && log.length > 0 && (
              <div className="mt-3 space-y-2 max-h-64 overflow-y-auto">
                {log.map((entry, i) => (
                  <div
                    key={`${entry.incidentId}-${i}`}
                    className="rounded-lg border border-border/30 bg-muted/10 p-2"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-mono text-[10px] text-primary">
                        {entry.incidentId}
                      </span>
                      <span className="text-[10px] text-muted-foreground">
                        {new Date(entry.timestamp).toLocaleString()}
                      </span>
                    </div>
                    <div className="text-xs text-foreground break-words">
                      {entry.message}
                    </div>
                    {entry.route && (
                      <div className="text-[10px] text-muted-foreground mt-0.5">
                        Route: {entry.route}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}

            {log.length === 0 && (
              <p className="text-xs text-muted-foreground leading-relaxed">
                No runtime errors detected. The monitor captures React render
                faults and unhandled promise rejections automatically.
              </p>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default SecurityIncidentPanel;
