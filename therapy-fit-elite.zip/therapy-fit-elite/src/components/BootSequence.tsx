import { useState, useEffect } from "react";
import { cn } from "@/lib/utils";
import { Fingerprint, ScanEye, ShieldCheck, Activity } from "lucide-react";
import { Logo } from "./Logo";

export function BootSequence() {
  const [isBooting, setIsBooting] = useState(true);
  const [progress, setProgress] = useState(0);
  const [text, setText] = useState("INITIALIZING NEURAL LINK...");
  const [phase, setPhase] = useState(0);

  useEffect(() => {
    try {
      const hasBooted = sessionStorage.getItem("hasBooted");
      if (hasBooted) {
        setIsBooting(false);
        return;
      }
    } catch (e) {}

    const sequence = [
      { p: 15, t: "BYPASSING SECURITY PROTOCOLS...", phase: 1, d: 400 },
      { p: 35, t: "INITIATING RETINAL SCAN...", phase: 2, d: 1000 },
      { p: 60, t: "CALIBRATING BIOMETRIC SENSORS...", phase: 3, d: 1800 },
      { p: 85, t: "SYNCING CNS TELEMETRY...", phase: 4, d: 2600 },
      { p: 100, t: "ACCESS GRANTED. SYSTEM ONLINE.", phase: 5, d: 3200 },
    ];

    sequence.forEach(({ p, t, phase: ph, d }) => {
      setTimeout(() => {
        setProgress(p);
        setText(t);
        setPhase(ph);
      }, d);
    });

    setTimeout(() => {
      setIsBooting(false);
      try {
        sessionStorage.setItem("hasBooted", "true");
      } catch (e) {}
    }, 4000);
  }, []);

  if (!isBooting) return null;

  return (
    <div
      className={cn(
        "fixed inset-0 z-[100] flex flex-col items-center justify-center bg-[#02050A] text-primary font-mono transition-opacity duration-700 overflow-hidden",
        progress === 100 ? "opacity-0 pointer-events-none" : "opacity-100",
      )}
    >
      {/* Background Grid & Scanline */}
      <div
        className="absolute inset-0 pointer-events-none opacity-20"
        style={{
          backgroundImage:
            "linear-gradient(rgba(0, 255, 255, 0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(0, 255, 255, 0.1) 1px, transparent 1px)",
          backgroundSize: "30px 30px",
        }}
      />
      <div className="absolute inset-0 pointer-events-none bg-[linear-gradient(transparent_0%,rgba(0,255,255,0.05)_50%,transparent_100%)] h-[10px] w-full animate-[scan_2s_linear_infinite]" />
      {/* Volumetric light rays */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            "radial-gradient(ellipse 60% 40% at 50% 0%, rgba(0,255,255,0.06) 0%, transparent 70%)",
        }}
      />

      <div className="relative w-full max-w-lg px-8 flex flex-col items-center z-10">
        {/* Holographic Scanner Core */}
        <div className="relative w-48 h-48 mb-12 flex items-center justify-center">
          {/* Outer Rotating Rings */}
          <div className="absolute inset-0 rounded-full border border-primary/20 border-t-primary/80 animate-[spin_4s_linear_infinite]" />
          <div className="absolute inset-2 rounded-full border border-primary/10 border-b-primary/60 animate-[spin_3s_linear_infinite_reverse]" />
          <div className="absolute inset-6 rounded-full border border-dashed border-primary/30 animate-[spin_10s_linear_infinite]" />

          {/* Scanning Reticle */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-full h-full rounded-full bg-primary/5 backdrop-blur-sm" />
            {phase < 3 ? (
              <ScanEye
                className={cn(
                  "absolute w-16 h-16 text-primary transition-all duration-500",
                  phase === 2
                    ? "scale-110 drop-shadow-[0_0_20px_rgba(0,255,255,0.8)]"
                    : "opacity-50",
                )}
              />
            ) : phase < 5 ? (
              <Fingerprint className="absolute w-16 h-16 text-primary animate-pulse drop-shadow-[0_0_20px_rgba(0,255,255,0.8)]" />
            ) : (
              <ShieldCheck className="absolute w-16 h-16 text-emerald-400 drop-shadow-[0_0_30px_rgba(16,185,129,0.8)]" />
            )}
          </div>

          {/* Central Pulse */}
          <div className="absolute w-4 h-4 bg-primary rounded-full animate-ping opacity-50" />
        </div>

        {/* Identity & Status */}
        <div className="text-center space-y-3 mb-12 w-full flex flex-col items-center">
          <div className="scale-150 mb-2">
            <Logo showText={false} />
          </div>
          <h1 className="text-3xl font-black tracking-[0.2em] uppercase text-white high-res-glow font-tech">
            TherapyFIT Elite
          </h1>
          <div className="flex items-center justify-center gap-2 text-xs text-primary/80 uppercase tracking-widest">
            <Activity className="w-3 h-3 animate-pulse" />
            <span>Neural Authentication Gateway</span>
          </div>
        </div>

        {/* Progress Display */}
        <div className="w-full space-y-4">
          <div className="flex justify-between items-end text-[10px] font-bold tracking-widest uppercase">
            <div className="flex flex-col gap-1">
              <span className="text-muted-foreground">Status</span>
              <span
                className={cn(
                  "transition-colors duration-300",
                  phase === 5
                    ? "text-emerald-400"
                    : "text-primary animate-pulse",
                )}
              >
                {text}
              </span>
            </div>
            <div className="flex flex-col items-end gap-1">
              <span className="text-muted-foreground">Integrity</span>
              <span
                className={cn(
                  "text-lg leading-none",
                  phase === 5 ? "text-emerald-400" : "text-primary",
                )}
              >
                {progress}%
              </span>
            </div>
          </div>

          {/* High-Tech Progress Bar */}
          <div className="relative h-1.5 w-full bg-primary/10 overflow-hidden rounded-full border border-primary/20">
            <div
              className={cn(
                "absolute top-0 bottom-0 left-0 transition-all duration-300 ease-out shadow-[0_0_15px_currentColor]",
                phase === 5 ? "bg-emerald-400" : "bg-primary",
              )}
              style={{ width: `${progress}%` }}
            />
          </div>

          {/* Data stream lines below progress */}
          <div className="flex justify-between w-full opacity-40">
            {Array.from({ length: 8 }).map((_, i) => (
              <div
                key={i}
                className="w-1 h-3 bg-primary/40 animate-pulse"
                style={{ animationDelay: `${i * 0.1}s` }}
              />
            ))}
          </div>
        </div>
      </div>

      <style>{`
        @keyframes scan {
          0% { transform: translateY(-100vh); }
          100% { transform: translateY(100vh); }
        }
      `}</style>
    </div>
  );
}
