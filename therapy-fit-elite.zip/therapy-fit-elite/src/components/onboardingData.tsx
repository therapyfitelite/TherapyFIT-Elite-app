import {
  Activity,
  Crosshair,
  Hexagon,
  Globe,
  Settings,
  BrainCircuit,
} from "lucide-react";

const NEURAL_IMG =
  "https://vibe.filesafe.space/1776727899133821812/assets/9f117916-662a-448d-b536-0c52a4a21599.png";
const SOMATIC_IMG =
  "https://vibe.filesafe.space/1776727899133821812/assets/5e5027b6-a885-4ec6-95e2-4ee5d21b9934.png";

/** Expanded feature carousel — 5 detailed pillar slides with visuals. */
export const CAROUSEL_SLIDES = [
  {
    title: "Neural Readiness Engine",
    subtitle: "HRV & CNS LOAD",
    description:
      "Your central nervous system is monitored in real time. We don't just display numbers — we translate HRV and CNS fatigue into a single readiness score that tells you exactly how hard you can push today.",
    image: NEURAL_IMG,
    ringColor: "#22d3ee",
    score: 82,
    ringLabel: "READINESS",
    icon: BrainCircuit,
    color: "text-primary",
    bg: "bg-primary/10",
    border: "border-primary/30",
    shadow: "shadow-[0_0_30px_rgba(0,255,255,0.2)]",
    bullets: [
      "Real-time HRV analysis",
      "CNS fatigue prediction",
      "Single readiness score",
    ],
  },
  {
    title: "Tactical Mission Execution",
    subtitle: "GATED PROTOCOLS",
    description:
      "Training isn't a workout — it's a mission. Each protocol ships with a dossier, predicted biometric impact, and a thermal heat signature. If your CNS load hits critical, high-intensity missions lock automatically.",
    image: SOMATIC_IMG,
    ringColor: "#ef4444",
    score: 87,
    ringLabel: "THREAT",
    icon: Crosshair,
    color: "text-red-500",
    bg: "bg-red-500/10",
    border: "border-red-500/30",
    shadow: "shadow-[0_0_30px_rgba(239,68,68,0.2)]",
    bullets: [
      "Mission dossiers",
      "Predicted impact scores",
      "Auto-lock at 85% CNS",
    ],
  },
  {
    title: "Somatic Stress Mapping",
    subtitle: "17 NEURAL ZONES",
    description:
      "Cortisol lives in specific muscles. Upload a photo and the app maps 17 neural tension zones — jaw, neck, psoas, trapezius, temples — drawn from somatic psychology and entirely absent from every other fitness app.",
    image: SOMATIC_IMG,
    ringColor: "#a855f7",
    score: 64,
    ringLabel: "TENSION",
    icon: Hexagon,
    color: "text-purple-400",
    bg: "bg-purple-500/10",
    border: "border-purple-500/30",
    shadow: "shadow-[0_0_30px_rgba(168,85,247,0.2)]",
    bullets: [
      "17 mapped tension zones",
      "3D anatomy zoom",
      "Targeted release protocols",
    ],
  },
  {
    title: "Elite Recovery Intelligence",
    subtitle: "SLEEP & HYDRATION",
    description:
      "Sleep architecture analysis predicts your next-day HRV before you wake. The Revive hydration tracker keeps your nervous system primed. Recovery isn't passive — it's engineered.",
    image: NEURAL_IMG,
    ringColor: "#10b981",
    score: 91,
    ringLabel: "RECOVERY",
    icon: Activity,
    color: "text-emerald-400",
    bg: "bg-emerald-500/10",
    border: "border-emerald-500/30",
    shadow: "shadow-[0_0_30px_rgba(16,185,129,0.2)]",
    bullets: [
      "Next-day HRV prediction",
      "Sleep architecture",
      "Hydration tracking",
    ],
  },
  {
    title: "The War Room",
    subtitle: "AI TACTICAL ADVISOR",
    description:
      "A weekly AI debrief powered by advanced language models reads your biometric history and tells you what to do next. Supplement intel is evidence-rated — science only, no marketing.",
    image: NEURAL_IMG,
    ringColor: "#00FF66",
    score: 76,
    ringLabel: "INTEL",
    icon: Globe,
    color: "text-[#00FF66]",
    bg: "bg-[#00FF66]/10",
    border: "border-[#00FF66]/30",
    shadow: "shadow-[0_0_30px_rgba(0,255,102,0.2)]",
    bullets: [
      "AI weekly debrief",
      "Evidence-rated stacks",
      "Tactical advisor guidance",
    ],
  },
];

/** Bottom-nav tour — teaches navigation before entering the app. */
export const TOUR_STEPS = [
  {
    icon: Activity,
    label: "DASH",
    title: "Your Command Center",
    description:
      "The spiral readiness ring, holographic biometric cards, daily intel brief, neural streak tracker, and stress trigger logger all live here. This is where you start every day.",
    color: "text-primary",
    ring: "border-primary/40",
    glow: "shadow-[0_0_25px_rgba(0,255,255,0.3)]",
  },
  {
    icon: Crosshair,
    label: "OPS",
    title: "The Mission Library",
    description:
      "Neural missions, gym protocols, and breathwork sessions — each displayed as a thermal heat-map card with predicted biometric impact. Run them through the instrument interface and sign your receipt at the end.",
    color: "text-red-500",
    ring: "border-red-500/40",
    glow: "shadow-[0_0_25px_rgba(239,68,68,0.3)]",
  },
  {
    icon: Hexagon,
    label: "BODY",
    title: "Somatic & Sleep Intelligence",
    description:
      "Upload a photo to map 17 neural tension zones, explore the interactive 3D anatomy model, and review your sleep architecture with next-day HRV prediction. Plus the Revive hydration tracker.",
    color: "text-purple-400",
    ring: "border-purple-500/40",
    glow: "shadow-[0_0_25px_rgba(168,85,247,0.3)]",
  },
  {
    icon: Globe,
    label: "WAR ROOM",
    title: "AI Debrief & Global Intel",
    description:
      "Your weekly AI-powered debrief, evidence-rated supplement intel, and the global streak map where sectors compete for regional dominance through collective biometric streaks.",
    color: "text-[#00FF66]",
    ring: "border-[#00FF66]/40",
    glow: "shadow-[0_0_25px_rgba(0,255,102,0.3)]",
  },
  {
    icon: Settings,
    label: "SYS",
    title: "System & Privacy Controls",
    description:
      "Connect wearables (Apple Health, Garmin, Oura, Whoop), manage your granular data-collection toggles, review security incidents, and configure your operator profile and display theme.",
    color: "text-yellow-400",
    ring: "border-yellow-500/40",
    glow: "shadow-[0_0_25px_rgba(250,204,21,0.3)]",
  },
];
