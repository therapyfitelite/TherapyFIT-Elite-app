import { useState, useEffect, useRef } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import {
  MessageSquare,
  Send,
  Zap,
  Globe,
  Users,
  ShieldCheck,
  Activity,
  Volume2,
  VolumeX,
  Mic,
  MicOff,
} from "lucide-react";
import { cn, hapticFeedback } from "@/lib/utils";
import { toast } from "sonner";

interface Message {
  id: string;
  sender: string;
  avatar?: string;
  text: string;
  timestamp: string;
  role: "optimizer" | "commander" | "sentinel";
  type?: "text" | "satellite_deployed" | "sector_alert";
  location?: string;
}

const MOCK_MESSAGES: Message[] = [
  {
    id: "1",
    sender: "Nova_Prime",
    text: "Initiating global sync for Sector 7. We need more satellite coverage in the Tokyo cluster.",
    timestamp: "14:20",
    role: "commander",
  },
  {
    id: "2",
    sender: "Zen_Master",
    text: "I have a satellite ready for deployment. Confirming coordinates for Tokyo.",
    timestamp: "14:22",
    role: "optimizer",
  },
  {
    id: "3",
    sender: "System",
    text: "Neural Satellite Deployed in Tokyo Cluster.",
    timestamp: "14:23",
    role: "sentinel",
    type: "satellite_deployed",
    location: "Tokyo",
  },
  {
    id: "4",
    sender: "Ghost_Protocol",
    text: "Sector 4 is showing high neural friction. Requesting backup.",
    timestamp: "14:25",
    role: "optimizer",
    type: "sector_alert",
    location: "San Francisco",
  },
  {
    id: "5",
    sender: "Axiom_Sentinel",
    text: "Copy that. Deploying focus lens over SF. Optimizers, maintain your flow.",
    timestamp: "14:26",
    role: "sentinel",
  },
];

export default function GlobalChat({ onClose }: { onClose?: () => void }) {
  const [messages, setMessages] = useState<Message[]>(MOCK_MESSAGES);
  const [newMessage, setNewMessage] = useState("");
  const [isNarrating, setIsNarrating] = useState(false);
  const [autoNarrate, setAutoNarrate] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  const toggleListening = () => {
    const SpeechRecognition =
      (window as any).SpeechRecognition ||
      (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      toast.error("Speech recognition not supported in this browser.");
      return;
    }

    if (isListening) {
      setIsListening(false);
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = "en-US";

    recognition.onstart = () => {
      setIsListening(true);
      hapticFeedback([10, 30, 10]);
    };

    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setNewMessage((prev) => prev + (prev ? " " : "") + transcript);
      hapticFeedback(50);
    };

    recognition.onerror = () => setIsListening(false);
    recognition.onend = () => setIsListening(false);

    recognition.start();
  };

  const speakMessage = (text: string, sender: string) => {
    if (!window.speechSynthesis) return;

    // Stop any current speech
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(`${sender} says: ${text}`);

    // Neural Voice Calibration
    utterance.pitch = 0.85;
    utterance.rate = 1.05;
    utterance.volume = 0.8;

    const voices = window.speechSynthesis.getVoices();
    const neuralVoice = voices.find(
      (v) =>
        v.name.includes("Google US English") ||
        v.name.includes("Female") ||
        v.name.includes("Natural"),
    );
    if (neuralVoice) utterance.voice = neuralVoice;

    utterance.onstart = () => setIsNarrating(true);
    utterance.onend = () => setIsNarrating(false);
    utterance.onerror = () => setIsNarrating(false);

    window.speechSynthesis.speak(utterance);
  };

  useEffect(() => {
    if (autoNarrate && messages.length > 0) {
      const lastMsg = messages[messages.length - 1];
      if (lastMsg.sender !== "Elias Vance") {
        speakMessage(lastMsg.text, lastMsg.sender);
      }
    }
  }, [messages, autoNarrate]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim()) return;

    const msg: Message = {
      id: Date.now().toString(),
      sender: "Elias Vance",
      text: newMessage,
      timestamp: new Date().toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit",
      }),
      role: "optimizer",
    };

    setMessages((prev) => [...prev, msg]);
    setNewMessage("");
    hapticFeedback(10);

    // Mock reply for coordination
    if (
      newMessage.toLowerCase().includes("satellite") ||
      newMessage.toLowerCase().includes("deploy")
    ) {
      setTimeout(() => {
        const reply: Message = {
          id: (Date.now() + 1).toString(),
          sender: "Axiom_Sentinel",
          text: "Deployment coordinates received. Synchronizing with your biometric signature...",
          timestamp: new Date().toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit",
          }),
          role: "sentinel",
        };
        setMessages((prev) => [...prev, reply]);
        hapticFeedback([50, 30, 50]);
      }, 1500);
    }
  };

  const getRoleColor = (role: Message["role"]) => {
    switch (role) {
      case "commander":
        return "text-primary border-primary/30 bg-primary/10";
      case "sentinel":
        return "text-fuchsia-400 border-fuchsia-500/30 bg-fuchsia-500/10";
      default:
        return "text-muted-foreground border-border/30 bg-secondary/50";
    }
  };

  return (
    <Card className="flex flex-col h-full bg-card/95 border-primary/30 backdrop-blur-md shadow-[0_0_40px_rgba(0,255,255,0.1)] overflow-hidden">
      <CardHeader className="p-4 border-b border-border/30 flex flex-row items-center justify-between shrink-0">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-md bg-primary/20 text-primary">
            <MessageSquare className="w-4 h-4" />
          </div>
          <div>
            <CardTitle className="text-sm font-bold tracking-tight">
              GLOBAL COORDINATION
            </CardTitle>
            <CardDescription className="text-[10px] uppercase tracking-widest font-bold text-primary flex items-center gap-1">
              <Users className="w-3 h-3" />
              1,284 ACTIVE OPTIMIZERS
            </CardDescription>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            className={cn(
              "h-8 w-8",
              autoNarrate ? "text-primary" : "text-muted-foreground",
            )}
            onClick={() => {
              setAutoNarrate(!autoNarrate);
              hapticFeedback(10);
              toast.info(
                autoNarrate
                  ? "Auto-narration disabled"
                  : "Neural Voice auto-narration active",
              );
            }}
          >
            {autoNarrate ? (
              <Volume2 className="h-4 w-4" />
            ) : (
              <VolumeX className="h-4 w-4" />
            )}
          </Button>
          {onClose && (
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-muted-foreground"
              onClick={onClose}
            >
              <Zap className="h-4 w-4" />
            </Button>
          )}
        </div>
      </CardHeader>

      <ScrollArea className="flex-1 p-4" ref={scrollRef}>
        <div className="space-y-4">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={cn(
                "flex flex-col gap-1.5 animate-in fade-in slide-in-from-bottom-2 duration-300",
                msg.sender === "Elias Vance" ? "items-end" : "items-start",
              )}
            >
              <div className="flex items-center gap-2">
                {msg.sender !== "Elias Vance" && (
                  <Avatar className="h-6 w-6 border border-border/50">
                    <AvatarImage
                      src={`https://i.pravatar.cc/150?u=${msg.sender}`}
                    />
                    <AvatarFallback className="text-[8px]">
                      {msg.sender[0]}
                    </AvatarFallback>
                  </Avatar>
                )}
                <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
                  {msg.sender}
                </span>
                <Badge
                  variant="outline"
                  className={cn(
                    "text-[8px] h-4 px-1 uppercase tracking-tighter",
                    getRoleColor(msg.role),
                  )}
                >
                  {msg.role}
                </Badge>
                <span className="text-[8px] opacity-50 font-mono">
                  {msg.timestamp}
                </span>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-4 w-4 text-muted-foreground hover:text-primary opacity-0 group-hover:opacity-100 transition-opacity"
                  onClick={() => {
                    hapticFeedback(5);
                    speakMessage(msg.text, msg.sender);
                  }}
                >
                  <Volume2 className="h-2.5 w-2.5" />
                </Button>
              </div>

              <div
                className={cn(
                  "max-w-[85%] p-3 rounded-lg text-xs relative overflow-hidden",
                  msg.sender === "Elias Vance"
                    ? "bg-primary/20 border border-primary/30 text-foreground ml-auto rounded-tr-none"
                    : "bg-secondary/50 border border-border/30 text-foreground mr-auto rounded-tl-none",
                  msg.type === "satellite_deployed" &&
                    "border-fuchsia-500/50 bg-fuchsia-500/10",
                  msg.type === "sector_alert" &&
                    "border-destructive/50 bg-destructive/10",
                )}
              >
                {/* Subtle Grid Pattern for messages */}
                <div className="absolute inset-0 opacity-[0.03] pointer-events-none bg-[radial-gradient(#fff_1px,transparent_1px)] bg-[size:10px_10px]" />

                {msg.type === "satellite_deployed" && (
                  <div className="flex items-center gap-2 mb-2 text-fuchsia-400 font-bold uppercase tracking-tighter text-[10px]">
                    <Zap className="w-3 h-3 animate-pulse" />
                    SATELLITE_ONLINE: {msg.location}
                  </div>
                )}

                {msg.type === "sector_alert" && (
                  <div className="flex items-center gap-2 mb-2 text-destructive font-bold uppercase tracking-tighter text-[10px]">
                    <Activity className="w-3 h-3 animate-pulse" />
                    CRITICAL_FRICTION: {msg.location}
                  </div>
                )}

                <p className="relative z-10 leading-relaxed">{msg.text}</p>

                {msg.location && (
                  <div className="mt-2 flex items-center gap-1.5 text-[9px] font-bold text-muted-foreground uppercase">
                    <Globe className="w-2.5 h-2.5" />
                    COORDINATES: {msg.location} SECTOR
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>

      <div className="p-4 border-t border-border/30 bg-background/50 shrink-0">
        <form onSubmit={handleSendMessage} className="flex gap-2">
          <div className="relative flex-1">
            <Input
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              placeholder={
                isListening
                  ? "Listening..."
                  : "Broadcast coordination protocol..."
              }
              className={cn(
                "bg-background/50 border-border/30 h-9 text-xs pr-14 transition-all",
                isListening &&
                  "border-primary shadow-[0_0_10px_rgba(0,255,255,0.2)]",
              )}
            />
            <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className={cn(
                  "h-6 w-6 rounded-full transition-all",
                  isListening
                    ? "text-primary animate-pulse bg-primary/10"
                    : "text-muted-foreground hover:text-primary",
                )}
                onClick={toggleListening}
              >
                {isListening ? (
                  <Mic className="h-3 w-3" />
                ) : (
                  <MicOff className="h-3 w-3" />
                )}
              </Button>
              <div className="h-1.5 w-1.5 rounded-full bg-primary animate-pulse" />
            </div>
          </div>
          <Button
            type="submit"
            size="icon"
            className="h-9 w-9 shrink-0 bg-primary/20 text-primary border border-primary/30 hover:bg-primary/30"
          >
            <Send className="h-4 w-4" />
          </Button>
        </form>
        <div className="mt-2 flex items-center gap-3 overflow-x-auto pb-1 custom-scrollbar">
          <Button
            variant="ghost"
            size="sm"
            className="h-6 text-[8px] gap-1.5 px-2 border border-primary/20 text-primary uppercase font-bold hover:bg-primary/10 shrink-0"
            onClick={() =>
              setNewMessage("Requesting satellite deployment in Sector ")
            }
          >
            <Zap className="w-2.5 h-2.5" /> REQUEST DEPLOYMENT
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="h-6 text-[8px] gap-1.5 px-2 border border-fuchsia-500/20 text-fuchsia-400 uppercase font-bold hover:bg-fuchsia-500/10 shrink-0"
            onClick={() =>
              setNewMessage("Sector clear. Sync intensity optimal.")
            }
          >
            <ShieldCheck className="w-2.5 h-2.5" /> SECTOR_CLEAR
          </Button>
        </div>
      </div>
    </Card>
  );
}
