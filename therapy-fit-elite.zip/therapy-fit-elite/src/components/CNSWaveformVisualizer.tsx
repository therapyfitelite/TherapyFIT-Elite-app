import { useEffect, useRef } from "react";

/**
 * CNSWaveformVisualizer — 2027 aesthetic
 *
 * Renders 3 independent mathematical sine waves forming an organic neural mesh.
 * Each wave has its own frequency, amplitude, travel direction (speed), and
 * opacity. Strokes use horizontal linear gradients so the waveform fades to 0%
 * opacity at the left and right canvas boundaries (edge blending).
 *
 * Hardware-accelerated via requestAnimationFrame, high-DPI aware.
 */

type WaveSpec = {
  freq: number; // spatial frequency (cycles across canvas width)
  amp: number; // amplitude in px
  speed: number; // phase delta per frame (sign = travel direction)
  color: string; // base stroke color
  baseOpacity: number; // peak opacity at canvas center
  width: number; // stroke width
  yOffset: number; // vertical center offset (fraction of height)
  glow: number; // shadowBlur
};

const WAVES: WaveSpec[] = [
  {
    freq: 1.6,
    amp: 26,
    speed: 0.014,
    color: "0,242,254",
    baseOpacity: 0.95,
    width: 2.4,
    yOffset: 0.42,
    glow: 16,
  },
  {
    freq: 2.7,
    amp: 18,
    speed: -0.022,
    color: "120,80,255",
    baseOpacity: 0.55,
    width: 3.2,
    yOffset: 0.5,
    glow: 22,
  },
  {
    freq: 3.9,
    amp: 12,
    speed: 0.031,
    color: "0,200,160",
    baseOpacity: 0.4,
    width: 2,
    yOffset: 0.58,
    glow: 14,
  },
];

export default function CNSWaveformVisualizer({
  data,
  height = 220,
}: {
  data: { day: string; cns: number }[];
  height?: number;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animRef = useRef<number>(0);
  const phaseRef = useRef<number[]>([0, 0, 0]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const dpr = Math.min(window.devicePixelRatio || 1, 2);

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      canvas.width = Math.max(1, Math.floor(rect.width * dpr));
      canvas.height = Math.max(1, Math.floor(height * dpr));
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(canvas);

    const padX = 18;
    const padY = 28;

    const draw = () => {
      const rect = canvas.getBoundingClientRect();
      const w = rect.width;
      const h = height;
      ctx.clearRect(0, 0, w, h);

      // Deep moody gradient backdrop
      const bgGrad = ctx.createLinearGradient(0, 0, 0, h);
      bgGrad.addColorStop(0, "rgba(8,10,18,0.0)");
      bgGrad.addColorStop(1, "rgba(20,8,30,0.22)");
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, w, h);

      // Subtle horizontal grid lines (organic, faint)
      ctx.strokeStyle = "rgba(255,255,255,0.035)";
      ctx.lineWidth = 1;
      for (let i = 0; i <= 4; i++) {
        const y = padY + (h - padY * 2) * (i / 4);
        ctx.beginPath();
        ctx.moveTo(padX, y);
        ctx.lineTo(w - padX, y);
        ctx.stroke();
      }

      const innerW = w - padX * 2;
      const usableH = h - padY * 2;

      // --- 3 independent sine waves ---
      WAVES.forEach((wave, idx) => {
        phaseRef.current[idx] += wave.speed;
        const phase = phaseRef.current[idx];
        const baseY = padY + usableH * wave.yOffset;

        // Horizontal edge-blend gradient: 0% -> peak -> 0%
        const edgeGrad = ctx.createLinearGradient(0, 0, w, 0);
        edgeGrad.addColorStop(0, `rgba(${wave.color},0)`);
        edgeGrad.addColorStop(0.18, `rgba(${wave.color},${wave.baseOpacity})`);
        edgeGrad.addColorStop(0.5, `rgba(${wave.color},${wave.baseOpacity})`);
        edgeGrad.addColorStop(0.82, `rgba(${wave.color},${wave.baseOpacity})`);
        edgeGrad.addColorStop(1, `rgba(${wave.color},0)`);

        ctx.save();
        ctx.shadowBlur = wave.glow;
        ctx.shadowColor = `rgba(${wave.color},${wave.baseOpacity})`;
        ctx.strokeStyle = edgeGrad;
        ctx.lineWidth = wave.width;
        ctx.lineCap = "round";
        ctx.lineJoin = "round";

        ctx.beginPath();
        const steps = Math.max(48, Math.floor(innerW / 2));
        for (let s = 0; s <= steps; s++) {
          const t = s / steps;
          const x = padX + innerW * t;
          const ang = t * Math.PI * 2 * wave.freq + phase;
          const y = baseY + Math.sin(ang) * wave.amp;
          if (s === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.stroke();
        ctx.restore();
      });

      // --- Volumetric fill: soft cyan glow band behind the mesh ---
      ctx.save();
      const fillGrad = ctx.createLinearGradient(0, 0, w, 0);
      fillGrad.addColorStop(0, "rgba(0,242,254,0)");
      fillGrad.addColorStop(0.5, "rgba(0,242,254,0.07)");
      fillGrad.addColorStop(1, "rgba(0,242,254,0)");
      const bandTop = padY + usableH * 0.3;
      const bandH = usableH * 0.4;
      const radial = ctx.createLinearGradient(0, bandTop, 0, bandTop + bandH);
      radial.addColorStop(0, "rgba(0,242,254,0.05)");
      radial.addColorStop(0.5, "rgba(120,80,255,0.04)");
      radial.addColorStop(1, "rgba(0,242,254,0)");
      ctx.fillStyle = radial;
      ctx.fillRect(padX, bandTop, innerW, bandH);
      ctx.restore();

      // --- Flowing energy particles travelling the primary wave ---
      const primary = WAVES[0];
      const phase0 = phaseRef.current[0];
      const baseY0 = padY + usableH * primary.yOffset;
      const particleCount = 10;
      for (let i = 0; i < particleCount; i++) {
        const t = (((phase0 * 0.06 + i / particleCount) % 1) + 1) % 1;
        const x = padX + innerW * t;
        // fade particles near edges to match edge blending
        const edgeFade = Math.sin(t * Math.PI);
        const ang = t * Math.PI * 2 * primary.freq + phase0;
        const y = baseY0 + Math.sin(ang) * primary.amp;
        const pulse = 0.5 + 0.5 * Math.sin(phase0 * 2 + i);

        ctx.beginPath();
        ctx.arc(x, y, 2 + pulse * 1.4, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(0,242,254,${(0.5 + pulse * 0.4) * edgeFade})`;
        ctx.shadowBlur = 12 * edgeFade;
        ctx.shadowColor = `rgba(0,242,254,${0.8 * edgeFade})`;
        ctx.fill();
      }
      ctx.shadowBlur = 0;

      // --- Data point nodes + day labels ---
      if (data.length) {
        data.forEach((d, i) => {
          const x = padX + (innerW * i) / Math.max(1, data.length - 1);
          const isHigh = d.cns >= 70;
          const nodeColor = isHigh ? "239,68,68" : "0,242,254";
          const edgeFade =
            Math.sin((i / Math.max(1, data.length - 1)) * Math.PI) * 0.6 + 0.4;

          // node sits on a gentle envelope derived from cns value
          const ny = h - padY - (d.cns / 100) * (usableH * 0.7);

          ctx.beginPath();
          ctx.arc(x, ny, 3, 0, Math.PI * 2);
          ctx.fillStyle = `rgba(${nodeColor},${0.95 * edgeFade})`;
          ctx.shadowBlur = 10 * edgeFade;
          ctx.shadowColor = `rgba(${nodeColor},${0.6 * edgeFade})`;
          ctx.fill();

          ctx.shadowBlur = 0;
          ctx.fillStyle = "rgba(255,255,255,0.35)";
          ctx.font = "600 9px system-ui, sans-serif";
          ctx.textAlign = "center";
          ctx.fillText(d.day, x, h - 8);
        });
      }

      animRef.current = requestAnimationFrame(draw);
    };

    draw();
    return () => {
      cancelAnimationFrame(animRef.current);
      ro.disconnect();
    };
  }, [data, height]);

  return (
    <div className="relative w-full" style={{ height }}>
      <canvas
        ref={canvasRef}
        className="w-full h-full"
        style={{ display: "block" }}
      />
    </div>
  );
}
