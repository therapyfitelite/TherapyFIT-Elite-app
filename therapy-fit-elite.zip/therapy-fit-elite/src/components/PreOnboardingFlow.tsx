import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowRight, ChevronLeft, Volume2, VolumeX } from "lucide-react";
import { ReadinessRingPreview } from "./ReadinessRingPreview";
import { PrivacyStep, TrackingStep, AuthStep } from "./OnboardingSteps";
import { CAROUSEL_SLIDES, TOUR_STEPS } from "./onboardingData";
import {
  cn,
  hapticFeedback,
  playNodeTapSound,
  startAmbientHum,
  stopAmbientHum,
  playTourChime,
} from "@/lib/utils";

type Step = "carousel" | "tour" | "privacy" | "tracking" | "auth" | null;

export function PreOnboardingFlow({ onComplete }: { onComplete: () => void }) {
  const [step, setStep] = useState<Step>("carousel");
  const [carouselSlide, setCarouselSlide] = useState(0);
  const [tourStep, setTourStep] = useState(0);
  const [muted, setMuted] = useState<boolean>(() => {
    try {
      return localStorage.getItem("tf_sound_enabled") === "false";
    } catch {
      return false;
    }
  });

  useEffect(() => {
    if (!muted) startAmbientHum();
    return () => stopAmbientHum();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (step !== "carousel" && step !== null) stopAmbientHum();
  }, [step]);

  const toggleMute = () => {
    const next = !muted;
    setMuted(next);
    try {
      localStorage.setItem("tf_sound_enabled", next ? "false" : "true");
    } catch {}
    if (next) {
      stopAmbientHum();
    } else {
      if (step === "carousel") startAmbientHum();
      playNodeTapSound(660);
    }
    hapticFeedback(10);
  };

  const nextCarousel = () => {
    hapticFeedback(10);
    if (carouselSlide < CAROUSEL_SLIDES.length - 1) {
      setCarouselSlide((s) => s + 1);
    } else {
      setStep("tour");
    }
  };

  const prevCarousel = () => {
    hapticFeedback(8);
    if (carouselSlide > 0) setCarouselSlide((s) => s - 1);
  };

  const nextTour = () => {
    hapticFeedback(10);
    if (tourStep < TOUR_STEPS.length - 1) {
      setTourStep((s) => s + 1);
      if (!muted) playTourChime();
    } else {
      setStep("privacy");
    }
  };

  return (
    <AnimatePresence>
      {step !== null && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[200] bg-black/85 backdrop-blur-md flex items-center justify-center p-4"
        >
          <motion.div
            initial={{ scale: 0.95, y: 20 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.95, y: 20 }}
            className="glass-panel max-w-sm w-full rounded-3xl p-6 border-primary/20 shadow-[0_0_50px_rgba(0,255,255,0.1)] relative overflow-hidden"
          >
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-32 bg-primary/20 rounded-full blur-3xl pointer-events-none" />
            <button
              onClick={toggleMute}
              aria-label={muted ? "Unmute ambient sound" : "Mute ambient sound"}
              className="absolute top-3 right-3 z-30 w-9 h-9 rounded-full flex items-center justify-center bg-white/5 border border-white/10 hover:border-primary/40 hover:bg-white/10 transition-colors"
            >
              {muted ? (
                <VolumeX className="w-4 h-4 text-muted-foreground" />
              ) : (
                <Volume2 className="w-4 h-4 text-primary" />
              )}
            </button>

            {/* ── CAROUSEL ── */}
            {step === "carousel" &&
              (() => {
                const slide = CAROUSEL_SLIDES[carouselSlide];
                const Icon = slide.icon;
                return (
                  <div className="relative z-10 flex flex-col items-center text-center w-full">
                    <div className="flex items-center justify-between w-full mb-3">
                      <button
                        onClick={prevCarousel}
                        disabled={carouselSlide === 0}
                        className="text-muted-foreground hover:text-white disabled:opacity-20 transition-colors"
                      >
                        <ChevronLeft className="w-5 h-5" />
                      </button>
                      <span className="text-[9px] font-black tracking-[0.3em] text-muted-foreground">
                        {carouselSlide + 1} / {CAROUSEL_SLIDES.length}
                      </span>
                      <button
                        onClick={() => {
                          hapticFeedback(8);
                          setStep("tour");
                        }}
                        className="text-[9px] font-bold uppercase tracking-widest text-muted-foreground hover:text-primary transition-colors"
                      >
                        Skip
                      </button>
                    </div>

                    <AnimatePresence mode="wait">
                      <motion.div
                        key={carouselSlide}
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                        transition={{ duration: 0.3 }}
                        className="w-full flex flex-col items-center cursor-grab active:cursor-grabbing"
                        drag="x"
                        dragConstraints={{ left: 0, right: 0 }}
                        dragElastic={0.2}
                        onDragEnd={(_, { offset }) => {
                          if (offset.x < -50) nextCarousel();
                          else if (offset.x > 50) prevCarousel();
                        }}
                      >
                        <ReadinessRingPreview
                          image={slide.image}
                          color={slide.color}
                          ringColor={slide.ringColor}
                          score={slide.score}
                          ringLabel={slide.ringLabel}
                          icon={Icon}
                          bg={slide.bg}
                          border={slide.border}
                          shadow={slide.shadow}
                        />

                        <h4
                          className={cn(
                            "text-[10px] font-black uppercase tracking-[0.3em] mb-1",
                            slide.color,
                          )}
                        >
                          {slide.subtitle}
                        </h4>
                        <h3 className="text-xl font-tech font-black uppercase tracking-widest mb-2 text-white leading-none">
                          {slide.title}
                        </h3>
                        <p className="text-xs text-muted-foreground leading-relaxed mb-3">
                          {slide.description}
                        </p>

                        <div className="flex flex-wrap gap-1.5 justify-center mb-2">
                          {slide.bullets.map((b) => (
                            <span
                              key={b}
                              className="text-[9px] font-bold uppercase tracking-wider px-2 py-1 rounded-full bg-white/5 border border-white/10 text-muted-foreground"
                            >
                              {b}
                            </span>
                          ))}
                        </div>
                      </motion.div>
                    </AnimatePresence>

                    <div className="flex gap-1.5 mb-5 mt-2">
                      {CAROUSEL_SLIDES.map((_, i) => (
                        <div
                          key={i}
                          className={cn(
                            "h-1.5 rounded-full transition-all duration-300",
                            i === carouselSlide
                              ? "bg-primary w-6 shadow-[0_0_8px_rgba(0,255,255,0.6)]"
                              : "bg-white/20 w-1.5",
                          )}
                        />
                      ))}
                    </div>

                    <Button
                      className="w-full h-13 py-3.5 rounded-xl bg-white text-black font-black uppercase tracking-widest text-sm shadow-[0_0_20px_rgba(255,255,255,0.2)] hover:shadow-[0_0_30px_rgba(255,255,255,0.4)] transition-all"
                      onClick={nextCarousel}
                    >
                      {carouselSlide < CAROUSEL_SLIDES.length - 1
                        ? "Continue"
                        : "Begin Tour"}
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </div>
                );
              })()}

            {/* ── NAVIGATION TOUR ── */}
            {step === "tour" &&
              (() => {
                const t = TOUR_STEPS[tourStep];
                const TIcon = t.icon;
                return (
                  <div className="relative z-10 flex flex-col items-center text-center w-full">
                    <div className="flex items-center justify-between w-full mb-4">
                      <button
                        onClick={() => {
                          hapticFeedback(8);
                          if (tourStep > 0) setTourStep((s) => s - 1);
                          else setStep("carousel");
                        }}
                        className="text-muted-foreground hover:text-white transition-colors"
                      >
                        <ChevronLeft className="w-5 h-5" />
                      </button>
                      <span className="text-[9px] font-black tracking-[0.3em] text-muted-foreground">
                        NAVIGATION TOUR · {tourStep + 1}/{TOUR_STEPS.length}
                      </span>
                      <button
                        onClick={() => {
                          hapticFeedback(8);
                          setStep("privacy");
                        }}
                        className="text-[9px] font-bold uppercase tracking-widest text-muted-foreground hover:text-primary transition-colors"
                      >
                        Skip
                      </button>
                    </div>

                    <AnimatePresence mode="wait">
                      <motion.div
                        key={tourStep}
                        initial={{ opacity: 0, y: 16 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -16 }}
                        transition={{ duration: 0.3 }}
                        className="w-full flex flex-col items-center"
                      >
                        <div className="w-full max-w-[260px] rounded-2xl border border-white/10 bg-black/50 p-2 flex items-center justify-around mb-6">
                          {TOUR_STEPS.map((ts, i) => {
                            const TI = ts.icon;
                            const active = i === tourStep;
                            return (
                              <div
                                key={ts.label}
                                className={cn(
                                  "flex flex-col items-center gap-1 px-2 py-1.5 rounded-lg transition-all duration-300",
                                  active && cn(ts.color, "bg-white/5", ts.glow),
                                  !active && "text-white/30",
                                )}
                              >
                                <TI
                                  className={cn(
                                    "w-4 h-4",
                                    active &&
                                      "drop-shadow-[0_0_6px_currentColor]",
                                  )}
                                />
                                <span className="text-[7px] font-black tracking-widest">
                                  {ts.label}
                                </span>
                              </div>
                            );
                          })}
                        </div>

                        <div
                          className={cn(
                            "w-14 h-14 rounded-full flex items-center justify-center border mb-4",
                            t.ring,
                            t.glow,
                          )}
                        >
                          <TIcon className={cn("w-7 h-7", t.color)} />
                        </div>
                        <h4
                          className={cn(
                            "text-[10px] font-black uppercase tracking-[0.3em] mb-1",
                            t.color,
                          )}
                        >
                          {t.label}
                        </h4>
                        <h3 className="text-lg font-tech font-black uppercase tracking-widest mb-2 text-white leading-none">
                          {t.title}
                        </h3>
                        <p className="text-xs text-muted-foreground leading-relaxed mb-6 min-h-[3.5rem]">
                          {t.description}
                        </p>
                      </motion.div>
                    </AnimatePresence>

                    <div className="flex gap-1.5 mb-5">
                      {TOUR_STEPS.map((_, i) => (
                        <div
                          key={i}
                          className={cn(
                            "h-1.5 rounded-full transition-all duration-300",
                            i === tourStep
                              ? "bg-white w-6"
                              : "bg-white/20 w-1.5",
                          )}
                        />
                      ))}
                    </div>

                    <Button
                      className="w-full py-3.5 rounded-xl bg-primary text-primary-foreground font-black uppercase tracking-widest text-sm shadow-[0_0_20px_rgba(0,255,255,0.3)] hover:shadow-[0_0_30px_rgba(0,255,255,0.5)] transition-all"
                      onClick={nextTour}
                    >
                      {tourStep < TOUR_STEPS.length - 1
                        ? "Next Stop"
                        : "Continue"}
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </div>
                );
              })()}

            {/* ── PRIVACY ── */}
            {step === "privacy" && (
              <PrivacyStep onContinue={() => setStep("tracking")} />
            )}

            {/* ── TRACKING ── */}
            {step === "tracking" && (
              <TrackingStep onContinue={() => setStep("auth")} />
            )}

            {/* ── AUTH ── */}
            {step === "auth" && <AuthStep onComplete={onComplete} />}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
