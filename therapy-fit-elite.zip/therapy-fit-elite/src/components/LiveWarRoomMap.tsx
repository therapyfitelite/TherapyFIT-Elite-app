import { useMemo } from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Globe, Target, Zap, Shield, Activity, Radio } from "lucide-react";
import { cn, hapticFeedback } from "@/lib/utils";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface Deployment {
  id: number;
  type: string;
  target: string;
  eta: string;
  impact: string;
}

const DEPLOYMENT_COORDS: Record<string, { lat: number; lng: number }> = {
  "San Francisco": { lat: 37.7749, lng: -122.4194 },
  Berlin: { lat: 52.52, lng: 13.405 },
  Tokyo: { lat: 35.6762, lng: 139.6503 },
  London: { lat: 51.5074, lng: -0.1278 },
  "New York": { lat: 40.7128, lng: -74.006 },
  Singapore: { lat: 1.3521, lng: 103.8198 },
  Sydney: { lat: -33.8688, lng: 151.2093 },
};

interface LiveWarRoomMapProps {
  deployments: Deployment[];
  globalFriction: number;
}

export default function LiveWarRoomMap({
  deployments,
  globalFriction,
}: LiveWarRoomMapProps) {
  // Convert lat/lng to simplified X/Y for the SVG map (800x400)
  const getCoords = (lat: number, lng: number) => {
    const x = (lng + 180) * (800 / 360);
    const y = (90 - lat) * (400 / 180);
    return { x, y };
  };

  const mapDeployments = useMemo(() => {
    return deployments.map((d) => ({
      ...d,
      coords: DEPLOYMENT_COORDS[d.target] || { lat: 0, lng: 0 },
    }));
  }, [deployments]);

  return (
    <Card className="bg-card/40 border-border/50 backdrop-blur-sm overflow-hidden relative group">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(0,255,255,0.02)_0%,transparent_70%)] pointer-events-none" />

      <CardHeader className="relative z-10 flex flex-row items-center justify-between pb-2">
        <div className="space-y-1">
          <CardTitle className="flex items-center gap-2 text-lg">
            <Globe className="h-5 w-5 text-primary animate-pulse" />
            Live Deployment Map
          </CardTitle>
          <CardDescription>
            Real-time visualization of tactical neural assets.
          </CardDescription>
        </div>
        <div className="flex items-center gap-3">
          <Badge
            variant="outline"
            className="bg-primary/10 text-primary border-primary/20 gap-1.5 animate-pulse"
          >
            <div className="h-1.5 w-1.5 rounded-full bg-primary" />
            {deployments.length} ASSETS ACTIVE
          </Badge>
          <Badge
            variant="outline"
            className={cn(
              "gap-1.5",
              globalFriction > 40
                ? "bg-destructive/10 text-destructive border-destructive/20"
                : "bg-primary/10 text-primary border-primary/20",
            )}
          >
            FRICTION: {globalFriction}%
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="p-0 relative h-[300px] sm:h-[400px] bg-black/20">
        {/* Grid Overlay */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:30px_30px] pointer-events-none" />

        {/* World Map SVG */}
        <svg
          viewBox="0 0 800 400"
          className="w-full h-full opacity-20 stroke-primary/30 fill-none"
        >
          <path d="M150,100 Q200,80 250,100 T350,120 T450,100 T550,120 T650,100 T750,120" />
          <path d="M100,200 Q200,180 300,200 T500,220 T700,200" />
          <path d="M200,300 Q300,280 400,300 T600,320" />
          <circle cx="400" cy="200" r="150" className="stroke-primary/5" />
          <circle cx="400" cy="200" r="100" className="stroke-primary/5" />
        </svg>

        {/* Deployments */}
        <TooltipProvider>
          {mapDeployments.map((dep) => {
            const { x, y } = getCoords(dep.coords.lat, dep.coords.lng);
            const isSatellite = dep.type.includes("Satellite");
            const isDampener = dep.type.includes("Dampener");

            return (
              <Tooltip key={dep.id}>
                <TooltipTrigger asChild>
                  <div
                    className="absolute transition-all duration-500 hover:scale-125 cursor-crosshair z-20"
                    style={{
                      left: `${(x / 800) * 100}%`,
                      top: `${(y / 400) * 100}%`,
                      transform: "translate(-50%, -50%)",
                    }}
                    onMouseEnter={() => hapticFeedback(5)}
                  >
                    {/* Pulsing Rings */}
                    <div
                      className={cn(
                        "absolute inset-0 rounded-full animate-ping opacity-20",
                        isSatellite
                          ? "bg-fuchsia-500"
                          : isDampener
                            ? "bg-primary"
                            : "bg-blue-400",
                      )}
                      style={{ animationDuration: "3s" }}
                    />
                    <div
                      className={cn(
                        "absolute inset-[-4px] rounded-full animate-pulse opacity-10",
                        isSatellite
                          ? "bg-fuchsia-500"
                          : isDampener
                            ? "bg-primary"
                            : "bg-blue-400",
                      )}
                    />

                    {/* Asset Icon */}
                    <div
                      className={cn(
                        "relative h-8 w-8 rounded-full border-2 flex items-center justify-center shadow-lg backdrop-blur-md",
                        isSatellite
                          ? "bg-fuchsia-500/20 border-fuchsia-500 text-fuchsia-400"
                          : isDampener
                            ? "bg-primary/20 border-primary text-primary"
                            : "bg-blue-500/20 border-blue-400 text-blue-400",
                      )}
                    >
                      {isSatellite ? (
                        <Zap className="h-4 w-4" />
                      ) : isDampener ? (
                        <Shield className="h-4 w-4" />
                      ) : (
                        <Activity className="h-4 w-4" />
                      )}
                    </div>

                    {/* Label (Desktop Only) */}
                    <div className="absolute top-full mt-1 left-1/2 -translate-x-1/2 whitespace-nowrap hidden sm:block">
                      <span className="text-[8px] font-bold uppercase tracking-tighter bg-background/80 px-1 rounded border border-border/50">
                        {dep.target}
                      </span>
                    </div>
                  </div>
                </TooltipTrigger>
                <TooltipContent className="bg-card/95 border-primary/30 backdrop-blur-md p-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <div
                        className={cn(
                          "h-2 w-2 rounded-full",
                          isSatellite
                            ? "bg-fuchsia-500"
                            : isDampener
                              ? "bg-primary"
                              : "bg-blue-400",
                        )}
                      />
                      <div className="text-xs font-bold uppercase tracking-widest">
                        {dep.type}
                      </div>
                    </div>
                    <div className="text-[10px] text-muted-foreground font-mono">
                      LOCATION: {dep.target}
                    </div>
                    <div className="text-[10px] text-primary font-bold">
                      IMPACT: {dep.impact}
                    </div>
                    <div className="text-[10px] text-muted-foreground">
                      STATUS:{" "}
                      {dep.eta === "Active" ? "OPERATIONAL" : `ETA: ${dep.eta}`}
                    </div>
                  </div>
                </TooltipContent>
              </Tooltip>
            );
          })}
        </TooltipProvider>

        {/* Global Resonance Waves (Simulated) */}
        <div className="absolute bottom-4 right-4 flex items-center gap-3 bg-background/40 backdrop-blur-md border border-border/50 p-2 rounded-lg pointer-events-none">
          <Radio className="h-4 w-4 text-primary animate-pulse" />
          <div className="space-y-1">
            <div className="text-[8px] font-bold uppercase text-muted-foreground">
              Network Resonance
            </div>
            <div className="flex gap-0.5 items-end h-3">
              {[40, 70, 45, 90, 60, 80, 50].map((h, i) => (
                <div
                  key={i}
                  className="w-1 bg-primary/50 rounded-t-sm animate-pulse"
                  style={{ height: `${h}%`, animationDelay: `${i * 0.1}s` }}
                />
              ))}
            </div>
          </div>
        </div>

        {/* Tactical Overlay */}
        <div className="absolute top-4 right-4 text-right pointer-events-none">
          <div className="text-[10px] font-mono text-primary/50">
            GRID_RES: 14.2ms
          </div>
          <div className="text-[10px] font-mono text-primary/50">
            SYNC_LOCK: STABLE
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
