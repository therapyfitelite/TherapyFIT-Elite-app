import { useRef, useMemo } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { Points, PointMaterial } from "@react-three/drei";
import * as THREE from "three";

function AbstractBrain({
  cnsLoad,
  isGlowing,
}: {
  cnsLoad: number;
  isGlowing?: boolean;
}) {
  const pointsRef = useRef<THREE.Points>(null);

  const [positions, initialColors] = useMemo(() => {
    const count = 4000;
    const pos = new Float32Array(count * 3);
    const col = new Float32Array(count * 3);

    for (let i = 0; i < count; i++) {
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(Math.random() * 2 - 1);

      const r = 1.6 + Math.random() * 0.6;
      let x = r * Math.sin(phi) * Math.cos(theta) * 0.75;
      let y = r * Math.sin(phi) * Math.sin(theta) * 0.6;
      let z = r * Math.cos(phi) * 0.85;

      // Hemisphere gap
      if (Math.abs(x) < 0.15) {
        x += x > 0 ? 0.15 : -0.15;
      }

      pos[i * 3] = x;
      pos[i * 3 + 1] = y;
      pos[i * 3 + 2] = z;

      col[i * 3] = 0;
      col[i * 3 + 1] = 1;
      col[i * 3 + 2] = 1;
    }

    return [pos, col];
  }, []);

  useFrame((state) => {
    if (!pointsRef.current) return;
    const t = state.clock.getElapsedTime();

    // Rotate brain
    const targetRotY = Math.sin(t * 0.2) * 0.3 + (isGlowing ? t * 0.5 : 0);
    pointsRef.current.rotation.y = THREE.MathUtils.lerp(
      pointsRef.current.rotation.y,
      targetRotY,
      0.1,
    );
    pointsRef.current.rotation.x = Math.cos(t * 0.1) * 0.1;

    const isCritical = cnsLoad > 85;
    const isElevated = cnsLoad > 60;

    const targetR = isCritical ? 1 : isElevated ? 1 : 0;
    const targetG = isCritical ? 0.2 : isElevated ? 0.5 : 1;
    const targetB = isCritical ? 0.2 : isElevated ? 0 : 1;

    const colors = pointsRef.current.geometry.attributes.color
      .array as Float32Array;

    for (let i = 0; i < colors.length / 3; i++) {
      const x = positions[i * 3];
      const y = positions[i * 3 + 1];
      const z = positions[i * 3 + 2];

      let noise = 0;
      if (isCritical) {
        noise = Math.sin(t * 4 + x * 6) * Math.cos(t * 3 + y * 6) * 0.5 + 0.5;
      } else if (isElevated) {
        noise = Math.sin(t * 2 + z * 4) * 0.5 + 0.5;
      } else {
        noise = Math.sin(t + x * 2 + y * 2) * 0.5 + 0.5;
      }

      const intensity = isCritical
        ? noise * 0.9
        : isElevated
          ? noise * 0.6
          : noise * 0.4;
      const glowBoost = isGlowing ? 0.5 : 0;

      colors[i * 3] = THREE.MathUtils.lerp(
        colors[i * 3],
        targetR * (0.3 + intensity + glowBoost),
        0.1,
      );
      colors[i * 3 + 1] = THREE.MathUtils.lerp(
        colors[i * 3 + 1],
        targetG * (0.3 + intensity + glowBoost),
        0.1,
      );
      colors[i * 3 + 2] = THREE.MathUtils.lerp(
        colors[i * 3 + 2],
        targetB * (0.3 + intensity + glowBoost),
        0.1,
      );
    }
    pointsRef.current.geometry.attributes.color.needsUpdate = true;
  });

  return (
    <Points ref={pointsRef} positions={positions} colors={initialColors}>
      <PointMaterial
        transparent
        vertexColors
        size={0.05}
        sizeAttenuation={true}
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </Points>
  );
}

export function NeuralBrain({
  cnsLoad,
  isGlowing,
}: {
  cnsLoad: number;
  isGlowing?: boolean;
}) {
  return (
    <div
      className="absolute inset-0 z-0 pointer-events-none flex items-center justify-center mix-blend-screen opacity-80"
      style={{ pointerEvents: "none" }}
    >
      <Canvas
        camera={{ position: [0, 0, 5], fov: 45 }}
        style={{ pointerEvents: "none" }}
      >
        <AbstractBrain cnsLoad={cnsLoad} isGlowing={isGlowing} />
      </Canvas>
    </div>
  );
}
