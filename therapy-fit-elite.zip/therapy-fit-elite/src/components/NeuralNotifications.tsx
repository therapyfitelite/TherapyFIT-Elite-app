import React, { useState, useEffect } from "react";
import {
  Bell,
  Zap,
  Swords,
  AlertTriangle,
  Shield,
  CheckCircle2,
  X,
  MessageSquare,
  Info,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn, hapticFeedback } from "@/lib/utils";
import { toast } from "sonner";

export type NotificationType =
  "duel" | "sector" | "sabotage" | "system" | "reward";

export interface NeuralNotification {
  id: string;
  type: NotificationType;
  title: string;
  description: string;
  timestamp: Date;
  read: boolean;
  actionLabel?: string;
  onAction?: () => void;
}

export function NeuralNotificationCenter() {
  const [notifications, setNotifications] = useState<NeuralNotification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    setUnreadCount(notifications.filter((n) => !n.read).length);
  }, [notifications]);

  // Simulate real-time alerts
  useEffect(() => {
    const simulateAlerts = () => {
      const types: NotificationType[] = [
        "duel",
        "sector",
        "sabotage",
        "reward",
      ];
      const randomType = types[Math.floor(Math.random() * types.length)];

      let newNotification: NeuralNotification;

      switch (randomType) {
        case "duel":
          newNotification = {
            id: Math.random().toString(36).substr(2, 9),
            type: "duel",
            title: "Neural Duel Challenge",
            description:
              "Sovereign_X has challenged you to a Recovery Index duel.",
            timestamp: new Date(),
            read: false,
            actionLabel: "View Challenge",
          };
          break;
        case "sector":
          newNotification = {
            id: Math.random().toString(36).substr(2, 9),
            type: "sector",
            title: "Sector Friction Alert",
            description:
              "North America sector friction exceeding 45%. Stabilization required.",
            timestamp: new Date(),
            read: false,
            actionLabel: "Deploy Sync",
          };
          break;
        case "sabotage":
          newNotification = {
            id: Math.random().toString(36).substr(2, 9),
            type: "sabotage",
            title: "Sabotage Detected",
            description:
              "Incoming interference from Synapse Syndicate detected in your sector.",
            timestamp: new Date(),
            read: false,
            actionLabel: "Defend",
          };
          break;
        case "reward":
          newNotification = {
            id: Math.random().toString(36).substr(2, 9),
            type: "reward",
            title: "Calibration Reward",
            description:
              "You've earned 500 Neural Points for your 7-day streak milestone.",
            timestamp: new Date(),
            read: false,
          };
          break;
        default:
          return;
      }

      // Add to list and show toast
      setNotifications((prev) => [newNotification, ...prev].slice(0, 20));

      hapticFeedback([50, 30, 50]);

      toast(newNotification.title, {
        description: newNotification.description,
        icon: getIcon(newNotification.type, "h-4 w-4"),
        className: cn(
          "border-primary/50 bg-background/95 backdrop-blur-md",
          newNotification.type === "sabotage" && "border-destructive/50",
          newNotification.type === "duel" && "border-fuchsia-500/50",
        ),
      });
    };

    const timer = setInterval(() => {
      if (Math.random() > 0.85) simulateAlerts();
    }, 15000);

    return () => clearInterval(timer);
  }, []);

  const markAsRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n)),
    );
  };

  const markAllAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
    hapticFeedback(10);
  };

  const getIcon = (type: NotificationType, className?: string) => {
    switch (type) {
      case "duel":
        return <Swords className={cn("text-fuchsia-400", className)} />;
      case "sector":
        return <Zap className={cn("text-primary", className)} />;
      case "sabotage":
        return <AlertTriangle className={cn("text-destructive", className)} />;
      case "reward":
        return <CheckCircle2 className={cn("text-yellow-400", className)} />;
      default:
        return <Info className={cn("text-muted-foreground", className)} />;
    }
  };

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          className="relative h-9 w-9 hover:bg-primary/10 transition-all duration-300"
        >
          <Bell
            className={cn(
              "h-5 w-5",
              unreadCount > 0 && "animate-[pulse_2s_infinite]",
            )}
          />
          {unreadCount > 0 && (
            <Badge className="absolute -top-1 -right-1 h-4 w-4 min-w-0 p-0 flex items-center justify-center bg-primary text-primary-foreground text-[10px] border-2 border-background">
              {unreadCount}
            </Badge>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent
        className="w-80 p-0 bg-card/95 border-primary/30 backdrop-blur-xl shadow-[0_0_40px_rgba(0,255,255,0.1)]"
        align="end"
      >
        <div className="flex items-center justify-between p-4 border-b border-border/50">
          <div className="flex items-center gap-2">
            <Shield className="h-4 w-4 text-primary" />
            <h4 className="text-xs font-bold uppercase tracking-widest">
              Neural Inbox
            </h4>
          </div>
          {unreadCount > 0 && (
            <Button
              variant="ghost"
              size="sm"
              className="h-7 text-[10px] text-primary hover:text-primary hover:bg-primary/10"
              onClick={markAllAsRead}
            >
              Mark all as read
            </Button>
          )}
        </div>
        <ScrollArea className="h-[350px]">
          {notifications.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full py-12 text-center space-y-2 opacity-50">
              <Bell className="h-8 w-8 text-muted-foreground/20" />
              <p className="text-[10px] uppercase tracking-widest">
                No active alerts
              </p>
            </div>
          ) : (
            <div className="flex flex-col">
              {notifications.map((n) => (
                <div
                  key={n.id}
                  className={cn(
                    "p-4 border-b border-border/30 transition-colors hover:bg-primary/5 cursor-pointer relative overflow-hidden",
                    !n.read && "bg-primary/5",
                  )}
                  onClick={() => markAsRead(n.id)}
                >
                  {!n.read && (
                    <div className="absolute left-0 top-0 bottom-0 w-0.5 bg-primary" />
                  )}
                  <div className="flex gap-3">
                    <div className="mt-0.5">{getIcon(n.type, "h-4 w-4")}</div>
                    <div className="flex-1 space-y-1">
                      <div className="flex items-center justify-between gap-2">
                        <p
                          className={cn(
                            "text-[11px] font-bold uppercase tracking-tight",
                            !n.read
                              ? "text-foreground"
                              : "text-muted-foreground",
                          )}
                        >
                          {n.title}
                        </p>
                        <span className="text-[9px] text-muted-foreground font-mono">
                          {n.timestamp.toLocaleTimeString([], {
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </span>
                      </div>
                      <p className="text-[10px] text-muted-foreground leading-relaxed">
                        {n.description}
                      </p>
                      {n.actionLabel && (
                        <Button
                          variant="link"
                          className="h-auto p-0 text-[10px] text-primary font-bold uppercase tracking-widest mt-1"
                        >
                          {n.actionLabel}
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
        <div className="p-2 border-t border-border/50 text-center">
          <Button
            variant="ghost"
            className="w-full h-8 text-[10px] text-muted-foreground hover:text-primary uppercase tracking-widest"
          >
            View All Protocols
          </Button>
        </div>
      </PopoverContent>
    </Popover>
  );
}
