import { cn } from "@/lib/utils";

interface LogoProps {
  className?: string;
  iconClassName?: string;
  showText?: boolean;
}

export function Logo({ className, iconClassName, showText = true }: LogoProps) {
  return (
    <div className={cn("flex items-center gap-3", className)}>
      {/* Official TherapyFIT Elite Emblem — clean, transparent background */}
      <div
        className={cn(
          "relative flex h-11 w-11 items-center justify-center group shrink-0",
          iconClassName,
        )}
      >
        <img
          src="https://vibe.filesafe.space/1776727899133821812/attachments/3e739998-4cd9-49ff-a03f-e338ca34d35f.png"
          alt="TherapyFIT Elite"
          className="relative z-10 h-full w-full object-contain transition-all duration-500 group-hover:scale-105 drop-shadow-[0_0_12px_rgba(0,255,255,0.4)]"
        />
      </div>

      {showText && (
        <span className="text-xl font-extrabold tracking-tighter whitespace-nowrap flex items-center gap-1 font-tech">
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-white to-white/70 drop-shadow-[0_0_8px_rgba(255,255,255,0.15)]">
            TherapyFIT
          </span>
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-yellow-300 via-yellow-500 to-amber-600 drop-shadow-[0_0_12px_rgba(234,179,8,0.6)]">
            Elite
          </span>
        </span>
      )}
    </div>
  );
}
