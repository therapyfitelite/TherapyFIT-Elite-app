import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";

const MASCOT_IMG =
  "https://vibe.filesafe.space/1776727899133821812/assets/610afc34-4136-4b3a-aa23-4b49aa62c62d.png";

/**
 * Ambient AI operator mascot — muscular elite operator with a
 * live animated biometric readiness watch on his wrist.
 */
export function HeroMascot() {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8, y: 20 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      transition={{ duration: 1, ease: "easeOut" }}
      className="relative mb-8 group"
    >
      <div className="absolute inset-0 rounded-full blur-3xl bg-primary/20 group-hover:bg-primary/40 transition-colors duration-700 animate-pulse" />
      <motion.div
        animate={{ scale: [1, 1.02, 1] }}
        transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
        className="relative w-32 h-32 md:w-40 md:h-40 rounded-full border-2 border-primary/20 p-2 glass-panel shadow-[0_0_50px_rgba(0,255,255,0.15)] overflow-hidden bg-black/40"
      >
        <img
          src={MASCOT_IMG}
          alt="Elite muscular AI tactical operator mascot with biometric readiness watch"
          className="w-full h-full object-cover rounded-full opacity-90 hover:opacity-100 transition-opacity duration-500"
        />
        {/* Wrist readiness HUD overlay */}
        <div className="absolute bottom-2 right-2 w-7 h-7 md:w-9 md:h-9 rounded-full bg-black/70 backdrop-blur-md border border-primary/40 flex items-center justify-center shadow-[0_0_12px_rgba(0,255,255,0.5)]">
          <svg viewBox="0 0 36 36" className="w-full h-full -rotate-90">
            <circle
              cx="18"
              cy="18"
              r="14"
              fill="none"
              stroke="rgba(255,255,255,0.12)"
              strokeWidth="3"
            />
            <motion.circle
              cx="18"
              cy="18"
              r="14"
              fill="none"
              stroke="rgb(0,255,255)"
              strokeWidth="3"
              strokeLinecap="round"
              strokeDasharray={2 * Math.PI * 14}
              initial={{ strokeDashoffset: 2 * Math.PI * 14 }}
              animate={{
                strokeDashoffset: [
                  2 * Math.PI * 14,
                  2 * Math.PI * 14 * (1 - 0.82),
                  2 * Math.PI * 14 * (1 - 0.82),
                ],
              }}
              transition={{
                duration: 2.5,
                times: [0, 0.6, 1],
                repeat: Infinity,
                repeatDelay: 1.5,
                ease: "easeInOut",
              }}
              style={{ filter: "drop-shadow(0 0 3px rgb(0,255,255))" }}
            />
          </svg>
          <span className="absolute text-[7px] md:text-[8px] font-black font-mono text-primary leading-none">
            82
          </span>
        </div>
      </motion.div>
      <Badge
        variant="outline"
        className="absolute -bottom-3 left-1/2 -translate-x-1/2 bg-black/60 backdrop-blur-xl text-primary border-primary/30 px-3 py-1 uppercase tracking-widest text-[9px] font-bold shadow-[0_0_15px_rgba(0,255,255,0.2)]"
      >
        <span className="relative flex w-1.5 h-1.5 mr-2">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75" />
          <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-primary" />
        </span>
        Nexus AI Active
      </Badge>
    </motion.div>
  );
}
