import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Activity,
  Watch,
  Smartphone,
  HeartPulse,
  ShieldCheck,
  Link2,
  CheckCircle2,
} from "lucide-react";
import { cn, hapticFeedback } from "@/lib/utils";
import { toast } from "sonner";

// High-level Auth Flow via Aggregator (Terra API / Vital API)
// 1. Frontend requests a widget session URL from backend (simulated here).
// 2. Backend calls Terra/Vital API to generate a session URL for the specific device/provider.
// 3. Frontend redirects or opens an iframe to the session URL.
// 4. User authenticates with Oura/Garmin/Apple Health.
// 5. Terra/Vital API redirects back to the app with a success token/status.
// 6. Backend receives a webhook with the connection ID and user data.
// 7. Frontend updates state to show the device as connected.

const VENDORS = [
  {
    id: "apple_health",
    name: "Apple Health",
    icon: Smartphone,
    color: "text-rose-500",
    bg: "bg-rose-500/10",
    border: "border-rose-500/30",
  },
  {
    id: "garmin",
    name: "Garmin",
    icon: Watch,
    color: "text-blue-500",
    bg: "bg-blue-500/10",
    border: "border-blue-500/30",
  },
  {
    id: "oura",
    name: "Oura Ring",
    icon: Activity,
    color: "text-slate-200",
    bg: "bg-slate-200/10",
    border: "border-slate-200/30",
  },
  {
    id: "whoop",
    name: "Whoop",
    icon: HeartPulse,
    color: "text-white",
    bg: "bg-white/10",
    border: "border-white/30",
  },
  {
    id: "fitbit",
    name: "Fitbit",
    icon: Activity,
    color: "text-teal-400",
    bg: "bg-teal-400/10",
    border: "border-teal-400/30",
  },
];

export function DeviceConnectionModal({
  trigger,
}: {
  trigger?: React.ReactNode;
}) {
  const [connectedDevices, setConnectedDevices] = useState<string[]>([
    "apple_health",
  ]);
  const [isConnecting, setIsConnecting] = useState<string | null>(null);

  const handleConnect = (vendorId: string) => {
    hapticFeedback(10);
    if (connectedDevices.includes(vendorId)) {
      // Disconnect
      setConnectedDevices((prev) => prev.filter((id) => id !== vendorId));
      toast.success("Device disconnected", {
        description: "Telemetry link severed.",
      });
      return;
    }

    // Connect
    setIsConnecting(vendorId);

    // Simulate API call to aggregator to get widget URL
    setTimeout(() => {
      // In a real app, window.location.href = widgetUrl
      // Here we simulate the successful return
      setIsConnecting(null);
      setConnectedDevices((prev) => [...prev, vendorId]);
      hapticFeedback([20, 50, 20]);
      toast.success("Device Connected", {
        description: "Neural handshake complete. Biometrics syncing.",
        icon: <ShieldCheck className="text-primary w-4 h-4" />,
      });
    }, 1500);
  };

  return (
    <Dialog>
      <DialogTrigger asChild>
        {trigger || (
          <Button
            variant="outline"
            className="border-primary/50 text-primary hover:bg-primary/10 gap-2 w-full mt-4 shadow-[0_0_15px_rgba(0,255,255,0.1)] hover:shadow-[0_0_25px_rgba(0,255,255,0.2)] transition-all duration-500 rounded-xl"
          >
            <Link2 className="w-4 h-4" />
            Connect Devices
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="sm:max-w-md bg-[#0a0a0a] border-primary/20 text-foreground overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary/10 via-transparent to-transparent pointer-events-none" />
        <DialogHeader className="relative z-10">
          <DialogTitle className="flex items-center gap-2 text-primary uppercase tracking-widest text-sm font-black">
            <Activity className="w-4 h-4" /> Hardware Telemetry
          </DialogTitle>
          <DialogDescription className="text-muted-foreground text-xs">
            Link your biometric hardware via unified health API to feed the
            neural engine.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-3 py-4 relative z-10">
          {VENDORS.map((vendor) => {
            const isConnected = connectedDevices.includes(vendor.id);
            const connecting = isConnecting === vendor.id;
            const Icon = vendor.icon;

            return (
              <Card
                key={vendor.id}
                className={cn(
                  "p-3 flex items-center justify-between transition-all duration-300 border bg-black/40",
                  isConnected
                    ? "border-primary/50 shadow-[0_0_15px_rgba(0,255,255,0.1)]"
                    : "border-white/5 hover:border-white/20",
                )}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={cn(
                      "p-2 rounded-lg border",
                      vendor.bg,
                      vendor.border,
                    )}
                  >
                    <Icon className={cn("w-5 h-5", vendor.color)} />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-foreground">
                      {vendor.name}
                    </h4>
                    <p className="text-[10px] text-muted-foreground uppercase tracking-widest">
                      {isConnected ? "Syncing Data..." : "Disconnected"}
                    </p>
                  </div>
                </div>

                <Button
                  variant={isConnected ? "outline" : "default"}
                  size="sm"
                  onClick={() => handleConnect(vendor.id)}
                  disabled={!!isConnecting && !connecting}
                  className={cn(
                    "h-8 text-[10px] font-black uppercase tracking-widest transition-all",
                    isConnected
                      ? "bg-primary/10 text-primary border-primary/30 hover:bg-destructive/20 hover:text-destructive hover:border-destructive/50"
                      : "bg-white/10 text-white hover:bg-white/20 border border-white/20",
                  )}
                >
                  {connecting ? (
                    <span className="flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-current animate-pulse" />
                      Connecting
                    </span>
                  ) : isConnected ? (
                    <span className="flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" /> Active
                    </span>
                  ) : (
                    "Connect"
                  )}
                </Button>
              </Card>
            );
          })}
        </div>
      </DialogContent>
    </Dialog>
  );
}
