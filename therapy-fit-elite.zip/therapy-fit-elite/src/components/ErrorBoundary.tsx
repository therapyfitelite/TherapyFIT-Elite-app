import { Component, type ErrorInfo, type ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { Logo } from "@/components/Logo";
import { AlertTriangle, RotateCcw } from "lucide-react";

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
  incidentId: string | null;
}

const LOG_KEY = "tf_error_log";
const MAX_LOG_ENTRIES = 50;

/**
 * Persist a captured error to localStorage so the operator (and any support
 * flow) can review recent runtime incidents. This is a client-side monitor —
 * it does not transmit data anywhere automatically.
 */
export function logError(entry: {
  message: string;
  stack?: string;
  componentStack?: string;
  incidentId: string;
  timestamp: string;
  route?: string;
}) {
  try {
    const raw = localStorage.getItem(LOG_KEY);
    const log = raw ? JSON.parse(raw) : [];
    log.unshift(entry);
    const trimmed = log.slice(0, MAX_LOG_ENTRIES);
    localStorage.setItem(LOG_KEY, JSON.stringify(trimmed));
  } catch (e) {
    /* storage may be unavailable (private mode) — fail silently */
  }
}

export function getErrorLog() {
  try {
    const raw = localStorage.getItem(LOG_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function clearErrorLog() {
  try {
    localStorage.removeItem(LOG_KEY);
  } catch (e) {}
}

function generateIncidentId() {
  try {
    if (typeof crypto !== "undefined" && crypto.randomUUID) {
      return crypto.randomUUID().slice(0, 8).toUpperCase();
    }
  } catch (e) {}
  return `INC-${Math.random().toString(36).slice(2, 8).toUpperCase()}`;
}

export class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
      errorInfo: null,
      incidentId: null,
    };
  }

  static getDerivedStateFromError(error: Error): Partial<State> {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    const incidentId = generateIncidentId();
    const entry = {
      message: error.message,
      stack: error.stack,
      componentStack: errorInfo.componentStack,
      incidentId,
      timestamp: new Date().toISOString(),
      route:
        typeof window !== "undefined" ? window.location?.pathname : undefined,
    };
    logError(entry);
    this.setState({ errorInfo, incidentId });
    // Surface in console for dev tooling
    // eslint-disable-next-line no-console
    console.error(
      "[TherapyFIT ErrorBoundary] Incident",
      incidentId,
      error,
      errorInfo,
    );
  }

  handleReload = () => {
    window.location.reload();
  };

  handleReset = () => {
    try {
      localStorage.removeItem("tf_onboarded");
    } catch (e) {}
    window.location.assign("/welcome");
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-[100dvh] bg-[#050505] text-foreground flex flex-col items-center justify-center p-6 text-center relative overflow-hidden">
          <div
            className="absolute inset-0 pointer-events-none"
            style={{
              background:
                "radial-gradient(ellipse 60% 50% at 50% 0%, rgba(239,68,68,0.12) 0%, transparent 70%)",
            }}
          />
          <div className="relative z-10 max-w-md w-full space-y-6">
            <div className="flex flex-col items-center gap-4">
              <Logo />
              <div className="w-16 h-16 rounded-full bg-destructive/15 flex items-center justify-center border border-destructive/40 shadow-[0_0_30px_rgba(239,68,68,0.25)]">
                <AlertTriangle className="w-8 h-8 text-destructive" />
              </div>
            </div>
            <div className="space-y-2">
              <h1 className="text-2xl font-black uppercase tracking-widest text-foreground">
                System Fault Detected
              </h1>
              <p className="text-sm text-muted-foreground leading-relaxed">
                A runtime error was captured and logged locally. Your data is
                safe. You can reload to resume, or reset to the welcome screen.
              </p>
            </div>

            {this.state.incidentId && (
              <div className="rounded-xl border border-border/40 bg-muted/20 p-3">
                <div className="text-[10px] uppercase tracking-widest font-bold text-muted-foreground mb-1">
                  Incident ID
                </div>
                <div className="font-mono text-sm text-foreground">
                  {this.state.incidentId}
                </div>
              </div>
            )}

            {this.state.error && (
              <details className="text-left rounded-xl border border-border/40 bg-black/40 p-3">
                <summary className="text-xs uppercase tracking-widest font-bold text-muted-foreground cursor-pointer">
                  Technical Details
                </summary>
                <pre className="mt-2 text-[11px] text-destructive/80 whitespace-pre-wrap break-all font-mono">
                  {this.state.error.message}
                  {this.state.error.stack
                    ? `\n\n${this.state.error.stack}`
                    : ""}
                </pre>
              </details>
            )}

            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Button onClick={this.handleReload} className="flex-1">
                <RotateCcw className="mr-2 h-4 w-4" />
                Reload System
              </Button>
              <Button
                variant="outline"
                onClick={this.handleReset}
                className="flex-1 border-border/50"
              >
                Reset to Welcome
              </Button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
