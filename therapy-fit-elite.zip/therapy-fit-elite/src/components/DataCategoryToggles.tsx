import { useEffect, useState } from "react";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { HeartPulse, Brain, Droplet, Moon, MapPin } from "lucide-react";

const DATA_CATEGORIES = [
  {
    key: "tf_collect_hrv",
    label: "HRV / Heart Rate Variability",
    desc: "Beat-to-beat variance used for readiness scoring.",
    Icon: HeartPulse,
    color: "text-cyan-400",
  },
  {
    key: "tf_collect_cns",
    label: "CNS Load",
    desc: "Central nervous system fatigue estimation.",
    Icon: Brain,
    color: "text-orange-400",
  },
  {
    key: "tf_collect_hydration",
    label: "Hydration",
    desc: "Daily fluid intake and electrolyte tracking.",
    Icon: Droplet,
    color: "text-blue-400",
  },
  {
    key: "tf_collect_sleep",
    label: "Sleep",
    desc: "Sleep duration, stages, and next-day HRV prediction.",
    Icon: Moon,
    color: "text-purple-400",
  },
  {
    key: "tf_collect_waypoints",
    label: "Tactical Waypoints",
    desc: "Saved GPS coordinates and mission route data.",
    Icon: MapPin,
    color: "text-emerald-400",
  },
] as const;

export function DataCategoryToggles() {
  const { toast } = useToast();
  const [toggles, setToggles] = useState<Record<string, boolean>>({});

  useEffect(() => {
    const next: Record<string, boolean> = {};
    DATA_CATEGORIES.forEach((cat) => {
      next[cat.key] = localStorage.getItem(cat.key) !== "false";
    });
    setToggles(next);
  }, []);

  const handleToggle = (key: string, label: string, checked: boolean) => {
    // Write directly via the native path so the consent guard itself doesn't
    // block the toggle preference from being saved.
    try {
      localStorage.setItem(key, String(checked));
    } catch {}
    setToggles((prev) => ({ ...prev, [key]: checked }));
    window.dispatchEvent(new StorageEvent("storage", { key }));
    toast({
      title: "Collection Preference Updated",
      description: `${label} collection is now ${checked ? "enabled" : "disabled"}. ${checked ? "Data will be stored." : "Future writes are blocked."}`,
    });
  };

  return (
    <div className="space-y-3">
      <div className="text-xs uppercase tracking-widest font-bold text-muted-foreground mb-1">
        Granular Data Collection
      </div>
      <p className="text-xs text-muted-foreground mb-3 leading-relaxed">
        Opt out of specific telemetry categories at any time. Disabled
        categories are blocked from being stored anywhere in the app — enforced
        globally, not just in settings.
      </p>
      {DATA_CATEGORIES.map(({ key, label, desc, Icon, color }) => (
        <div
          key={key}
          className="flex items-center justify-between rounded-xl border border-border/40 bg-muted/20 p-3"
        >
          <div className="flex items-start gap-3">
            <Icon className={`w-4 h-4 mt-0.5 shrink-0 ${color}`} />
            <div className="space-y-0.5">
              <Label className="text-sm font-semibold">{label}</Label>
              <p className="text-xs text-muted-foreground leading-tight">
                {desc}
              </p>
            </div>
          </div>
          <Switch
            checked={toggles[key] ?? true}
            onCheckedChange={(checked) => handleToggle(key, label, checked)}
          />
        </div>
      ))}
    </div>
  );
}
