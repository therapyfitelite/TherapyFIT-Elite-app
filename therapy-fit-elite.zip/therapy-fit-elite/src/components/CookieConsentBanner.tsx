import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Cookie, ShieldCheck, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

type ConsentChoice = "accepted" | "essential" | null;

const CONSENT_KEY = "tf_cookie_consent";

export function CookieConsentBanner() {
  const [choice, setChoice] = useState<ConsentChoice>(null);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    try {
      const saved = localStorage.getItem(CONSENT_KEY) as ConsentChoice;
      if (saved === "accepted" || saved === "essential") {
        setChoice(saved);
      } else {
        setChoice(null);
      }
    } catch (e) {
      setChoice(null);
    }
    setMounted(true);
  }, []);

  const recordChoice = (value: Exclude<ConsentChoice, null>) => {
    try {
      localStorage.setItem(CONSENT_KEY, value);
    } catch (e) {}
    setChoice(value);
  };

  const dismiss = () => setChoice("essential");

  return (
    <AnimatePresence>
      {mounted && choice === null && (
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 40 }}
          transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
          className="fixed bottom-4 left-4 right-4 md:left-4 md:right-auto md:max-w-md z-[300] pointer-events-auto"
        >
          <div
            className={cn(
              "relative rounded-2xl border border-primary/30 bg-[#0a0a0a]/95 backdrop-blur-xl p-5 shadow-[0_20px_60px_rgba(0,0,0,0.6),0_0_30px_rgba(0,255,255,0.1)] overflow-hidden",
            )}
          >
            {/* Top edge illumination */}
            <div className="absolute top-0 left-10 right-10 h-px bg-gradient-to-r from-transparent via-primary/50 to-transparent" />

            <button
              onClick={dismiss}
              aria-label="Dismiss"
              className="absolute top-3 right-3 text-muted-foreground hover:text-foreground transition-colors p-1"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-start gap-3 pr-6">
              <div className="shrink-0 w-10 h-10 rounded-xl bg-primary/10 border border-primary/30 flex items-center justify-center shadow-[0_0_15px_rgba(0,255,255,0.15)]">
                <Cookie className="w-5 h-5 text-primary" />
              </div>
              <div className="flex-1">
                <h3 className="text-sm font-black uppercase tracking-widest text-foreground mb-1.5">
                  Neural Data Consent
                </h3>
                <p className="text-xs text-muted-foreground leading-relaxed mb-4">
                  TherapyFIT Elite stores biometric telemetry (HRV, CNS load,
                  hydration) locally on your device only — no third-party
                  trackers, no ad cookies, no data sold. We use essential
                  storage to keep your protocols running. Allow full local
                  analytics, or essential-only.
                </p>

                <div className="flex flex-col sm:flex-row gap-2">
                  <Button
                    size="sm"
                    className="h-10 flex-1 bg-primary text-primary-foreground font-bold uppercase tracking-widest text-[11px] shadow-[0_0_15px_rgba(0,255,255,0.3)] hover:shadow-[0_0_25px_rgba(0,255,255,0.5)]"
                    onClick={() => recordChoice("accepted")}
                  >
                    <ShieldCheck className="w-3.5 h-3.5 mr-1.5" />
                    Allow Full
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-10 flex-1 border-white/15 text-muted-foreground hover:text-foreground hover:bg-white/5 font-bold uppercase tracking-widest text-[11px]"
                    onClick={() => recordChoice("essential")}
                  >
                    Essential Only
                  </Button>
                </div>

                <p className="text-[9px] text-muted-foreground/60 mt-3 leading-relaxed">
                  You can change this or delete all data anytime in Settings →
                  Danger Zone. See our Privacy Policy.
                </p>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
