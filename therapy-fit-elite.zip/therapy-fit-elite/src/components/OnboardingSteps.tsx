import { Button } from "@/components/ui/button";
import { Shield, Activity, HeartPulse } from "lucide-react";
import { Logo } from "./Logo";
import { hapticFeedback, playNodeTapSound } from "@/lib/utils";

export function PrivacyStep({ onContinue }: { onContinue: () => void }) {
  return (
    <div className="relative z-10 flex flex-col items-center text-center">
      <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center border border-primary/30 mb-5 shadow-[0_0_20px_rgba(0,255,255,0.2)]">
        <Shield className="w-8 h-8 text-primary" />
      </div>
      <h3 className="text-xl font-tech font-black uppercase tracking-widest mb-2 text-white">
        Data Privacy & Security
      </h3>
      <p className="text-sm text-muted-foreground mb-5">
        To calibrate your neural baseline, we require consent to process your
        telemetry. You can opt out of any category later in Settings.
      </p>
      <div className="w-full space-y-2.5 mb-6 text-left">
        {[
          {
            t: "Biometric Processing",
            d: "HRV, CNS load, and readiness analytics.",
          },
          {
            t: "Secure Local Storage",
            d: "Encrypted neural profile data on your device.",
          },
          {
            t: "Granular Control",
            d: "Toggle off any data type anytime — enforced globally.",
          },
        ].map((r) => (
          <div
            key={r.t}
            className="flex items-start gap-3 p-3 rounded-xl bg-white/5 border border-white/10 hover:border-primary/30 transition-colors"
          >
            <div className="mt-0.5 w-5 h-5 rounded-full bg-primary/20 flex items-center justify-center shrink-0 border border-primary/50">
              <div className="w-2 h-2 rounded-full bg-primary" />
            </div>
            <div>
              <div className="text-sm font-bold text-white">{r.t}</div>
              <div className="text-xs text-muted-foreground mt-0.5">{r.d}</div>
            </div>
          </div>
        ))}
      </div>
      <Button
        className="w-full py-3.5 rounded-xl bg-primary text-primary-foreground font-black uppercase tracking-widest text-sm shadow-[0_0_20px_rgba(0,255,255,0.3)] hover:shadow-[0_0_30px_rgba(0,255,255,0.5)] transition-all"
        onClick={() => {
          hapticFeedback(10);
          onContinue();
        }}
      >
        Acknowledge & Consent
      </Button>
    </div>
  );
}

export function TrackingStep({ onContinue }: { onContinue: () => void }) {
  return (
    <div className="relative z-10 flex flex-col items-center text-center">
      <div className="w-16 h-16 rounded-full bg-purple-500/10 flex items-center justify-center border border-purple-500/30 mb-5 shadow-[0_0_20px_rgba(168,85,247,0.2)]">
        <Activity className="w-8 h-8 text-purple-400" />
      </div>
      <h3 className="text-xl font-tech font-black uppercase tracking-widest mb-2 text-white">
        Telemetry Link
      </h3>
      <p className="text-sm text-muted-foreground mb-6">
        Allow TherapyFIT Elite to securely handshake with external sensors to
        optimize your readiness score. Optional — you can connect later.
      </p>
      <div className="grid grid-cols-3 gap-2.5 w-full mb-6">
        {[
          {
            i: <HeartPulse className="w-5 h-5 text-white" />,
            l: "Apple Health",
          },
          {
            i: <div className="w-5 h-5 rounded-full border-2 border-white" />,
            l: "Oura",
          },
          {
            i: <span className="font-black italic text-white text-lg">W</span>,
            l: "Whoop",
          },
        ].map((d) => (
          <div
            key={d.l}
            className="flex flex-col items-center gap-2 p-3 rounded-xl bg-white/5 border border-white/10"
          >
            <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center">
              {d.i}
            </div>
            <span className="text-[10px] font-bold text-white uppercase">
              {d.l}
            </span>
          </div>
        ))}
      </div>
      <div className="w-full space-y-2.5">
        <Button
          className="w-full py-3.5 rounded-xl bg-purple-500 hover:bg-purple-400 text-white font-black uppercase tracking-widest text-sm shadow-[0_0_20px_rgba(168,85,247,0.3)] transition-all"
          onClick={() => {
            hapticFeedback(10);
            onContinue();
          }}
        >
          Authorize Sync
        </Button>
        <Button
          variant="ghost"
          className="w-full py-3 text-xs text-muted-foreground uppercase tracking-widest hover:text-white"
          onClick={() => {
            hapticFeedback(10);
            onContinue();
          }}
        >
          Skip For Now
        </Button>
      </div>
    </div>
  );
}

export function AuthStep({ onComplete }: { onComplete: () => void }) {
  return (
    <div className="relative z-10 flex flex-col items-center text-center">
      <div className="mb-6 scale-125">
        <Logo />
      </div>
      <h3 className="text-xl font-tech font-black uppercase tracking-widest mb-2 text-white">
        Initialize Operator
      </h3>
      <p className="text-sm text-muted-foreground mb-8">
        Link your identity to begin the neural calibration sequence.
      </p>
      <div className="w-full space-y-3">
        <Button
          className="w-full py-3.5 rounded-xl bg-white text-black hover:bg-gray-200 font-bold text-sm shadow-[0_0_20px_rgba(255,255,255,0.2)] flex items-center justify-center gap-3 transition-all"
          onClick={() => {
            hapticFeedback(20);
            playNodeTapSound(440);
            onComplete();
          }}
        >
          <svg viewBox="0 0 24 24" className="w-6 h-6 fill-current">
            <path d="M17.05 20.28c-.98.95-2.05.8-3.08.35-1.09-.46-2.09-.48-3.24 0-1.44.62-2.2.44-3.06-.35C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.19 2.31-.88 3.5-.88 2.52.09 3.81 1.23 4.6 2.33-2.14 1.29-1.74 4.31.42 5.23-.74 2.1-1.8 3.86-3.6 5.49zM12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.29 2.58-2.34 4.5-3.74 4.25z" />
          </svg>
          Sign in with Apple
        </Button>
        <Button
          variant="outline"
          className="w-full py-3.5 rounded-xl text-sm border-white/10 text-muted-foreground font-bold uppercase tracking-widest hover:bg-white/5 hover:text-white transition-all"
          onClick={() => {
            hapticFeedback(10);
            onComplete();
          }}
        >
          Continue as Guest
        </Button>
      </div>
      <div className="mt-8 text-[10px] text-muted-foreground/60 uppercase tracking-widest leading-relaxed">
        By proceeding, you accept our <br />
        <span className="text-primary cursor-pointer hover:text-primary/80 transition-colors">
          Terms of Service
        </span>{" "}
        and{" "}
        <span className="text-primary cursor-pointer hover:text-primary/80 transition-colors">
          Privacy Policy
        </span>
        .
      </div>
    </div>
  );
}
