import { useEffect, useState } from "react";
import { Outlet, useLocation, useNavigate } from "react-router-dom";
import {
  Hexagon,
  Activity,
  Crosshair,
  Rss,
  Grid,
  Users,
  Settings,
  Globe,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { cn, hapticFeedback, playGlassSound } from "@/lib/utils";
import { Logo } from "./Logo";
import { useDisplayTheme } from "@/hooks/use-display-theme";

const NavLink = ({
  to,
  icon: Icon,
  label,
  isActive,
  activeColorClass,
  activeShadowClass,
  activeDropShadowClass,
}: {
  to: string;
  icon: any;
  label: string;
  isActive: boolean;
  activeColorClass?: string;
  activeShadowClass?: string;
  activeDropShadowClass?: string;
}) => {
  const navigate = useNavigate();
  return (
    <button
      onClick={() => {
        hapticFeedback(5);
        if (!isActive) playGlassSound();
        navigate(to);
      }}
      className={cn(
        "relative flex flex-col items-center justify-center min-w-[64px] px-2 h-full rounded-xl space-y-1 transition-all duration-300",
        isActive
          ? cn(
              activeColorClass || "text-primary",
              "bg-white/5",
              activeShadowClass || "shadow-[0_0_20px_rgba(0,255,255,0.2)]",
            )
          : "text-foreground/50 hover:text-foreground/80 hover:bg-white/5",
      )}
    >
      <Icon
        className={cn(
          "w-5 h-5",
          isActive &&
            (activeDropShadowClass ||
              "drop-shadow-[0_0_8px_rgba(0,255,255,0.8)]"),
        )}
      />
      <span className="text-[9px] font-black tracking-widest">{label}</span>
    </button>
  );
};

/** Derive a colour and intensity from HRV score (0-100).
 *  High HRV (≥70) = calm = cyan glow, gentle pulse
 *  Mid  HRV (40-69) = moderate = amber/gold glow, medium pulse
 *  Low  HRV (<40)   = stressed = red/orange glow, intense fast pulse
 */
function hrvToPulsar(hrv: number): {
  color: string;
  glow: string;
  rings: number;
  duration: number;
  label: string;
} {
  if (hrv >= 70) {
    return {
      color: "rgba(0,255,255,0.18)",
      glow: "rgba(0,255,255,0.35)",
      rings: 2,
      duration: 1.1,
      label: "OPTIMAL",
    };
  } else if (hrv >= 40) {
    return {
      color: "rgba(251,191,36,0.18)",
      glow: "rgba(251,191,36,0.35)",
      rings: 3,
      duration: 0.8,
      label: "MODERATE",
    };
  } else {
    return {
      color: "rgba(239,68,68,0.22)",
      glow: "rgba(239,68,68,0.45)",
      rings: 4,
      duration: 0.5,
      label: "ELEVATED",
    };
  }
}

export default function Layout() {
  const location = useLocation();
  const navigate = useNavigate();
  const [blueLightLevel, setBlueLightLevel] = useState(0);
  const { displayTheme, rippleData } = useDisplayTheme() as any;

  useEffect(() => {
    const checkBlueLight = () => {
      try {
        const blRaw = localStorage.getItem("blBudget");
        if (blRaw) {
          const parsed = JSON.parse(blRaw);
          const today = new Date().toISOString().slice(0, 10);
          if (parsed.date === today) {
            const pct = Math.min(100, Math.round((parsed.total / 3000) * 100));
            setBlueLightLevel(pct);
          }
        }
      } catch (err) {}
    };

    checkBlueLight();
    const interval = setInterval(checkBlueLight, 10000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const path = location.pathname;
    if (path !== "/hub" && path !== "/welcome") {
      try {
        const recent = JSON.parse(
          localStorage.getItem("tf_recent_paths") || "[]",
        );
        const newRecent = [
          path,
          ...recent.filter((p: string) => p !== path),
        ].slice(0, 4);
        localStorage.setItem("tf_recent_paths", JSON.stringify(newRecent));
      } catch (e) {}
    }
  }, [location.pathname]);

  const navItems = [
    { icon: Activity, label: "DASH", path: "/" },
    { icon: Crosshair, label: "OPS", path: "/ops" },
    { icon: Hexagon, label: "BODY", path: "/somatic" },
    { icon: Globe, label: "WAR ROOM", path: "/war-room" },
    { icon: Grid, label: "HUB", path: "/hub" },
  ];

  // Hide bottom nav on specific routes if needed
  const hideBottomNav = false;

  return (
    <div className="flex flex-col h-[100dvh] w-full bg-background text-foreground overflow-hidden relative">
      {/* Global Blue Light Filter Overlay */}
      <div
        className="fixed inset-0 pointer-events-none z-[100] transition-opacity duration-1000 mix-blend-multiply"
        style={{
          backgroundColor: "#ff9900",
          opacity: blueLightLevel > 90 ? 0.25 : blueLightLevel > 65 ? 0.12 : 0,
        }}
      />

      {/* Biometric Pulsar — HRV-Reactive Theme Transition */}
      <AnimatePresence>
        {rippleData &&
          (() => {
            const pulsar = hrvToPulsar(rippleData.hrv);
            return (
              <div className="fixed inset-0 z-[99] pointer-events-none overflow-hidden">
                {/* Main expanding ripple wave */}
                <motion.div
                  key="ripple-main"
                  initial={{
                    clipPath: `circle(0% at ${rippleData.x}px ${rippleData.y}px)`,
                    opacity: 0.9,
                  }}
                  animate={{
                    clipPath: `circle(160% at ${rippleData.x}px ${rippleData.y}px)`,
                    opacity: [0.9, 0.7, 0],
                  }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.65, ease: [0.22, 1, 0.36, 1] }}
                  style={{
                    background: pulsar.color,
                    backdropFilter: "blur(4px)",
                  }}
                  className="absolute inset-0"
                />

                {/* Glow burst at origin */}
                <motion.div
                  key="ripple-burst"
                  initial={{ scale: 0, opacity: 1 }}
                  animate={{ scale: [0, 8, 16], opacity: [1, 0.6, 0] }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.9, ease: "easeOut" }}
                  style={{
                    position: "absolute",
                    left: rippleData.x - 40,
                    top: rippleData.y - 40,
                    width: 80,
                    height: 80,
                    borderRadius: "50%",
                    background: `radial-gradient(circle, ${pulsar.glow} 0%, transparent 70%)`,
                    boxShadow: `0 0 60px 30px ${pulsar.glow}`,
                  }}
                />

                {/* Concentric pulse rings — count & speed driven by HRV */}
                {Array.from({ length: pulsar.rings }).map((_, i) => (
                  <motion.div
                    key={`ring-${i}`}
                    initial={{ scale: 0.3, opacity: 0.8 }}
                    animate={{ scale: [0.3, 4 + i * 2], opacity: [0.8, 0] }}
                    exit={{ opacity: 0 }}
                    transition={{
                      duration: pulsar.duration + i * 0.18,
                      ease: "easeOut",
                      delay: i * 0.12,
                    }}
                    style={{
                      position: "absolute",
                      left: rippleData.x - 30,
                      top: rippleData.y - 30,
                      width: 60,
                      height: 60,
                      borderRadius: "50%",
                      border: `2px solid ${pulsar.glow}`,
                      boxShadow: `0 0 20px 4px ${pulsar.glow}`,
                    }}
                  />
                ))}

                {/* HRV status badge at click origin */}
                <motion.div
                  key="hrv-badge"
                  initial={{ opacity: 0, scale: 0.5, y: 0 }}
                  animate={{
                    opacity: [0, 1, 1, 0],
                    scale: [0.5, 1.1, 1, 0.8],
                    y: [0, -24, -40, -56],
                  }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 1.1, ease: "easeOut" }}
                  style={{
                    position: "absolute",
                    left: rippleData.x - 52,
                    top: rippleData.y - 18,
                    pointerEvents: "none",
                  }}
                  className="flex flex-col items-center gap-0.5"
                >
                  <span
                    className="text-[10px] font-black tracking-widest px-2 py-0.5 rounded-full border"
                    style={{
                      color: pulsar.glow,
                      borderColor: pulsar.glow,
                      background: `${pulsar.color}`,
                      textShadow: `0 0 8px ${pulsar.glow}`,
                      boxShadow: `0 0 12px ${pulsar.glow}`,
                    }}
                  >
                    HRV {rippleData.hrv}
                  </span>
                  <span
                    className="text-[8px] font-bold tracking-[0.2em]"
                    style={{
                      color: pulsar.glow,
                      textShadow: `0 0 6px ${pulsar.glow}`,
                    }}
                  >
                    {pulsar.label}
                  </span>
                </motion.div>
              </div>
            );
          })()}
      </AnimatePresence>
      {displayTheme === "glass" && (
        <div className="fixed inset-0 pointer-events-none z-0 glass-bg-layer" />
      )}

      {/* Desktop Top Navigation */}
      {!hideBottomNav && (
        <nav
          className={cn(
            "hidden md:flex fixed top-0 left-0 right-0 h-[calc(5rem_+_env(safe-area-inset-top,_0px))] pt-[env(safe-area-inset-top,_0px)] border-b items-center justify-between px-8 z-[100]",
            displayTheme === "glass"
              ? "glass-nav border-cyan-400/20 shadow-[0_4px_30px_rgba(0,255,255,0.08)] ring-1 ring-white/5"
              : displayTheme === "hc"
                ? "bg-background border-primary shadow-[0_0_20px_hsl(var(--primary)/0.3)]"
                : "bg-black/80 backdrop-blur-xl border-cyan-500/30 shadow-[0_0_30px_rgba(0,255,255,0.15)]",
          )}
        >
          <div
            className="flex items-center gap-2 cursor-pointer"
            onClick={() => {
              playGlassSound();
              navigate("/");
            }}
          >
            <Logo />
          </div>

          <div className="flex items-center gap-4 lg:gap-6 h-full py-2">
            {navItems.map((item) => {
              const isActive = location.pathname === item.path;
              return (
                <button
                  key={item.path}
                  onClick={() => {
                    hapticFeedback(5);
                    if (!isActive) playGlassSound();
                    navigate(item.path);
                  }}
                  className={cn(
                    "relative flex items-center gap-2 px-4 py-2 text-sm font-bold tracking-widest uppercase transition-all duration-300 rounded-lg group overflow-hidden",
                    isActive
                      ? "text-cyan-400 bg-cyan-500/10 border border-cyan-500/50 shadow-[0_0_15px_rgba(0,255,255,0.3)]"
                      : "text-white/60 hover:text-white hover:bg-white/5 border border-transparent",
                  )}
                >
                  <div
                    className={cn(
                      "absolute inset-0 bg-gradient-to-r from-transparent via-cyan-500/10 to-transparent translate-x-[-100%] transition-transform duration-500",
                      isActive
                        ? "animate-[shimmer_2s_infinite]"
                        : "group-hover:translate-x-[100%]",
                    )}
                  />
                  <item.icon
                    className={cn(
                      "w-4 h-4 relative z-10",
                      isActive && "drop-shadow-[0_0_8px_rgba(0,255,255,0.8)]",
                    )}
                  />
                  <span className="relative z-10">{item.label}</span>
                </button>
              );
            })}
            <div className="w-px h-8 bg-white/10 mx-2" />
            <NavLink
              to="/profile"
              icon={Users}
              label="USER"
              isActive={location.pathname === "/profile"}
            />
            <NavLink
              to="/settings"
              icon={Settings}
              label="SYS"
              isActive={location.pathname === "/settings"}
            />
          </div>
        </nav>
      )}

      {/* Mobile Top Navigation */}
      <nav
        className={cn(
          "md:hidden fixed top-0 left-0 right-0 z-[100] h-[calc(4.5rem_+_env(safe-area-inset-top,_0px))] pt-[env(safe-area-inset-top,_0px)] px-6 flex justify-between items-center transition-all duration-500 border-b",
          displayTheme === "glass"
            ? "glass-nav"
            : displayTheme === "hc"
              ? "bg-black border-primary"
              : "bg-[#0a0a0a]/90 backdrop-blur-md border-white/5 shadow-2xl",
        )}
      >
        <Logo className="scale-90 origin-left" />
        <div className="flex items-center gap-4 h-full py-2">
          <NavLink
            to="/hub"
            icon={Grid}
            label="HUB"
            isActive={location.pathname === "/hub"}
          />
          <NavLink
            to="/profile"
            icon={Users}
            label="USER"
            isActive={location.pathname === "/profile"}
          />
        </div>
      </nav>

      {/* Volumetric ambient light overlay */}
      <div
        className="fixed inset-0 pointer-events-none z-[1]"
        style={{
          background:
            "radial-gradient(ellipse 80% 50% at 50% 0%, rgba(0,255,255,0.04) 0%, transparent 70%), radial-gradient(ellipse 40% 30% at 100% 100%, rgba(250,204,21,0.02) 0%, transparent 60%)",
        }}
      />

      {/* Main Scrollable Content Area */}
      <main
        className="relative z-10 flex-1 w-full overflow-y-auto overflow-x-hidden pt-[calc(4.5rem_+_env(safe-area-inset-top,_0px))] md:pt-[calc(5rem_+_env(safe-area-inset-top,_0px))] pb-[calc(6rem_+_env(safe-area-inset-bottom,_0px))] md:pb-0 scrollbar-hide"
        id="main-scroll-container"
      >
        <AnimatePresence mode="wait">
          <motion.div
            key={location.pathname}
            initial={{
              opacity: 0,
              scale: 0.97,
              filter: "blur(20px) saturate(150%) brightness(1.2)",
            }}
            animate={{
              opacity: 1,
              scale: 1,
              filter: "blur(0px) saturate(100%) brightness(1)",
            }}
            exit={{
              opacity: 0,
              scale: 1.03,
              filter: "blur(20px) saturate(50%) brightness(0.8)",
            }}
            transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-col w-full min-h-full origin-center"
            style={{ willChange: "transform, filter, opacity" }}
          >
            <Outlet />
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Mobile Bottom Navigation */}
      <nav
        className={cn(
          "md:hidden fixed bottom-[calc(1rem_+_env(safe-area-inset-bottom,_0px))] left-4 right-4 z-[100] h-16 rounded-2xl flex items-center justify-around px-2 transition-all duration-500 border shadow-[0_20px_50px_rgba(0,0,0,0.5)]",
          displayTheme === "glass"
            ? "glass-nav"
            : displayTheme === "hc"
              ? "bg-black border-primary"
              : "bg-[#0d0d0d]/95 backdrop-blur-xl border-white/10",
        )}
      >
        <NavLink
          to="/"
          icon={Activity}
          label="DASH"
          isActive={location.pathname === "/"}
        />
        <NavLink
          to="/ops"
          icon={Crosshair}
          label="OPS"
          isActive={location.pathname === "/ops"}
        />
        <NavLink
          to="/somatic"
          icon={Hexagon}
          label="BODY"
          isActive={location.pathname === "/somatic"}
        />
        <NavLink
          to="/war-room"
          icon={Globe}
          label="WAR"
          isActive={location.pathname === "/war-room"}
          activeColorClass="text-[#00FF66]"
          activeShadowClass="shadow-[0_0_20px_rgba(0,255,102,0.3)] bg-[#00FF66]/10"
          activeDropShadowClass="drop-shadow-[0_0_8px_rgba(0,255,102,0.8)]"
        />
        <NavLink
          to="/settings"
          icon={Settings}
          label="SYS"
          isActive={location.pathname === "/settings"}
        />
      </nav>

      {/* Mobile Safe Area Filler */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 h-[env(safe-area-inset-bottom)] bg-black/20 pointer-events-none z-[90]" />
    </div>
  );
}
