import { useState, useEffect, type MouseEvent } from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

/**
 * Animated 3D readiness ring with a parallax neural-dashboard image layer.
 * Used inside the pre-onboarding carousel slides.
 */
export function ReadinessRingPreview({
  image,
  color,
  ringColor,
  score,
  ringLabel,
  icon: Icon,
  bg,
  border,
  shadow,
}: {
  image: string;
  color: string;
  ringColor: string;
  score: number;
  ringLabel: string;
  icon: any;
  bg: string;
  border: string;
  shadow: string;
}) {
  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  const [displayScore, setDisplayScore] = useState(0);

  // Count-up animation on mount / slide change
  useEffect(() => {
    setDisplayScore(0);
    let current = 0;
    const step = Math.max(1, Math.ceil(score / 30));
    const timer = setInterval(() => {
      current += step;
      if (current >= score) {
        setDisplayScore(score);
        clearInterval(timer);
      } else {
        setDisplayScore(current);
      }
    }, 35);
    return () => clearInterval(timer);
  }, [score]);

  const handleMove = (e: MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const px = (e.clientX - rect.left) / rect.width - 0.5;
    const py = (e.clientY - rect.top) / rect.height - 0.5;
    setTilt({ x: py * -12, y: px * 12 });
  };

  const radius = 36;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (displayScore / 100) * circumference;

  return (
    <div
      className="relative w-full h-40 rounded-2xl overflow-hidden border border-white/10 mb-4 group"
      onMouseMove={handleMove}
      onMouseLeave={() => setTilt({ x: 0, y: 0 })}
      style={{ perspective: 700 }}
    >
      {/* Parallax image layer */}
      <motion.div
        className="absolute inset-0"
        animate={{ rotateX: tilt.x, rotateY: tilt.y, scale: 1.15 }}
        transition={{ type: "spring", stiffness: 150, damping: 18 }}
        style={{ transformStyle: "preserve-3d" }}
      >
        <img
          src={image}
          alt="Neural dashboard preview"
          className="w-full h-full object-cover opacity-50 group-hover:opacity-70 transition-opacity duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/60 to-black/20" />
      </motion.div>

      {/* Icon badge */}
      <div
        className={cn(
          "absolute top-2 right-2 z-20 w-10 h-10 rounded-full flex items-center justify-center border backdrop-blur-md",
          bg,
          border,
          shadow,
        )}
        style={{ transform: "translateZ(30px)" }}
      >
        <Icon className={cn("w-5 h-5", color)} />
      </div>

      {/* Rotating outer tick ring */}
      <motion.div
        className="absolute inset-0 flex items-center justify-center z-10"
        animate={{ rotate: 360 }}
        transition={{ duration: 18, repeat: Infinity, ease: "linear" }}
        style={{ transform: "translateZ(20px)" }}
      >
        <svg width="120" height="120" viewBox="0 0 120 120">
          {Array.from({ length: 24 }).map((_, i) => {
            const angle = (i / 24) * 2 * Math.PI;
            const r1 = 52;
            const r2 = i % 6 === 0 ? 45 : 49;
            return (
              <line
                key={i}
                x1={60 + Math.cos(angle) * r1}
                y1={60 + Math.sin(angle) * r1}
                x2={60 + Math.cos(angle) * r2}
                y2={60 + Math.sin(angle) * r2}
                stroke="rgba(255,255,255,0.25)"
                strokeWidth={i % 6 === 0 ? 1.5 : 0.8}
              />
            );
          })}
        </svg>
      </motion.div>

      {/* Readiness ring + score */}
      <div
        className="absolute inset-0 flex items-center justify-center z-10"
        style={{ transform: "translateZ(40px)" }}
      >
        <svg
          width="100"
          height="100"
          viewBox="0 0 100 100"
          className="-rotate-90"
        >
          <circle
            cx="50"
            cy="50"
            r={radius}
            fill="none"
            stroke="rgba(255,255,255,0.08)"
            strokeWidth="4"
          />
          <circle
            cx="50"
            cy="50"
            r={radius}
            fill="none"
            stroke={ringColor}
            strokeWidth="4"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            style={{
              filter: `drop-shadow(0 0 6px ${ringColor})`,
              transition: "stroke-dashoffset 0.3s ease",
            }}
          />
        </svg>
        <div className="absolute flex flex-col items-center">
          <span
            className="text-2xl font-black font-mono leading-none"
            style={{ color: ringColor, textShadow: `0 0 12px ${ringColor}` }}
          >
            {displayScore}
          </span>
          <span className="text-[7px] uppercase tracking-[0.2em] text-muted-foreground mt-0.5 font-bold">
            {ringLabel}
          </span>
        </div>
      </div>
    </div>
  );
}
