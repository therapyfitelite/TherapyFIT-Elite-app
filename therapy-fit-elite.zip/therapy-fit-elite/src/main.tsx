import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./index.css";
import { installConsentGuard } from "./lib/storage";

// Apply saved display theme before first render to prevent flash
try {
  const savedTheme = localStorage.getItem("tf_display_theme");
  if (savedTheme === "glass")
    document.documentElement.classList.add("theme-glass");
  if (savedTheme === "hc") document.documentElement.classList.add("theme-hc");
} catch {}

// Enforce granular data-collection consent globally. Any biometric write
// (HRV, CNS, hydration, sleep, waypoints) is silently dropped if the user
// has opted out of that category in Settings → Data & Privacy.
installConsentGuard();

createRoot(document.getElementById("root")!).render(<App />);
